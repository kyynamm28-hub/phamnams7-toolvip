<footer class="mt-auto py-6 px-4 text-center border-t border-neutral-200/80 dark:border-gray-800/80 bg-white/30 dark:bg-gray-900/30 backdrop-blur-sm">
    <div class="text-[11px] font-bold text-neutral-400 dark:text-gray-500 uppercase tracking-widest">
        &copy; <?= date('Y') ?> ZENRO System. All rights reserved.
    </div>
    <div class="text-[10px] font-medium text-neutral-300 dark:text-gray-600 mt-1">
        Designed for High Performance
    </div>
</footer>
