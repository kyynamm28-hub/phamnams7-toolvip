<header class="sticky top-0 z-40 bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-b border-neutral-200/80 dark:border-gray-800/80 shadow-[0_4px_30px_rgba(0,0,0,0.03)] transition-colors duration-300">
    <div class="flex items-center justify-between px-4 sm:px-6 lg:px-8 h-16 sm:h-20">
        
        <div class="flex items-center gap-4">
            <button @click="sidebarOpen = true" class="lg:hidden w-10 h-10 flex items-center justify-center -ml-2 text-neutral-500 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-gray-800 rounded-xl transition-all focus:outline-none">
                <i class="ri-menu-3-line text-2xl"></i>
            </button>
            
            <a href="/admin" class="lg:hidden flex items-center gap-2">
                <div class="w-8 h-8 bg-blue-600 text-white rounded-lg flex items-center justify-center font-black text-lg shadow-sm">Z</div>
            </a>

            <div class="hidden sm:flex flex-col">
                <span class="text-[11px] font-bold text-neutral-400 dark:text-gray-500 uppercase tracking-widest mb-0.5">Control Panel</span>
                <span class="text-sm font-black text-neutral-800 dark:text-white tracking-wide">ADMINISTRATOR</span>
            </div>
        </div>

        <div class="flex items-center gap-3 sm:gap-5">
            <button @click="toggleDarkMode()" class="w-10 h-10 flex items-center justify-center rounded-xl bg-neutral-100 dark:bg-gray-800 text-neutral-600 dark:text-gray-300 hover:bg-neutral-200 dark:hover:bg-gray-700 transition-all shadow-inner focus:outline-none">
                <i x-show="!darkMode" class="ri-moon-clear-fill text-lg"></i>
                <i x-show="darkMode" x-cloak class="ri-sun-fill text-amber-400 text-lg"></i>
            </button>
            
            <div class="h-6 w-px bg-neutral-200 dark:bg-gray-700/80"></div>
            
            <div class="flex items-center gap-3 bg-neutral-50 dark:bg-gray-800/50 pr-4 pl-1.5 py-1.5 rounded-full border border-neutral-100 dark:border-gray-700/50">
                <div class="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-500 text-white flex items-center justify-center font-bold shadow-sm">
                    <i class="ri-user-star-fill text-sm"></i>
                </div>
                <div class="hidden md:flex flex-col">
                    <div class="text-[12px] font-black text-neutral-800 dark:text-white leading-tight">Admin System</div>
                    <div class="text-[10px] text-emerald-500 font-bold flex items-center gap-1">
                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> Online
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
