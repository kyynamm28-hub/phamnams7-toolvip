<?php
// Tự động nhận diện đường dẫn hiện tại để Active Menu
$current_path = $_SERVER['REQUEST_URI'];
function isActive($path) {
    global $current_path;
    return (strpos($current_path, $path) !== false) 
        ? 'bg-blue-50 text-blue-600 dark:bg-blue-500/10 dark:text-blue-400' 
        : 'text-neutral-600 hover:bg-neutral-100 dark:text-gray-400 dark:hover:bg-gray-800';
}
?>

<div x-show="sidebarOpen" x-cloak class="fixed inset-0 z-40 bg-neutral-900/60 backdrop-blur-sm lg:hidden" @click="sidebarOpen = false" x-transition.opacity></div>

<aside :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'" class="fixed inset-y-0 left-0 z-50 w-[260px] bg-white dark:bg-[#0b1120] border-r border-neutral-200 dark:border-gray-800 transition-transform duration-300 ease-in-out lg:translate-x-0 flex flex-col">
    
    <div class="h-16 sm:h-20 flex items-center px-6 border-b border-neutral-200 dark:border-gray-800">
        <a href="/admin" class="flex items-center gap-3">
            <div class="w-9 h-9 bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 rounded-xl flex items-center justify-center font-black text-xl shadow-lg">Z</div>
            <span class="text-2xl font-black tracking-widest text-neutral-900 dark:text-white uppercase">Zenro</span>
        </a>
    </div>

    <div class="flex-1 overflow-y-auto custom-scroll p-4 space-y-7">
        
        <div>
            <div class="text-[10px] font-black uppercase text-neutral-400 dark:text-gray-500 tracking-widest mb-3 px-3">Hệ Thống</div>
            <nav class="space-y-1.5">
                <a href="/admin/" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-sm transition-colors <?= $current_path == '/admin/' || $current_path == '/admin' ? 'bg-blue-50 text-blue-600 dark:bg-blue-500/10 dark:text-blue-400' : 'text-neutral-600 hover:bg-neutral-100 dark:text-gray-400 dark:hover:bg-gray-800' ?>">
                    <i class="ri-dashboard-line text-lg"></i> Tổng quan
                </a>
                <a href="/admin/transactions" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-sm transition-colors <?= isActive('/admin/transactions') ?>">
                    <i class="ri-exchange-dollar-line text-lg"></i> Giao Dịch
                </a>
                <a href="/admin/cre-gift" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-sm transition-colors <?= isActive('/admin/cre-gift') ?>">
                    <i class="ri-gift-line text-lg"></i> Mã Quà Tặng
                </a>
            </nav>
        </div>

        <div>
            <div class="text-[10px] font-black uppercase text-neutral-400 dark:text-gray-500 tracking-widest mb-3 px-3">Kinh Doanh</div>
            <nav class="space-y-1.5">
                <a href="/admin/members" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-sm transition-colors <?= isActive('/admin/members') ?>"><i class="ri-group-line text-lg"></i> Quản Lý Thành Viên</a>
                <a href="/admin/packages" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-sm transition-colors <?= isActive('/admin/packages') ?>"><i class="ri-vip-crown-line text-lg"></i> Quản Lý Gói VIP</a>
                <a href="/admin/packages-api" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-sm transition-colors <?= isActive('/admin/packages-api') ?>"><i class="ri-terminal-box-line text-lg"></i> Quản Lý Gói API</a>
                <a href="/admin/product" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-sm transition-colors <?= isActive('/admin/product') ?>"><i class="ri-shopping-bag-3-line text-lg"></i> Quản Lý Kho Hàng</a>
                <a href="/admin/partner" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-sm transition-colors <?= isActive('/admin/partner') ?>"><i class="ri-shake-hands-line text-lg"></i> Quản Lý Đối Tác</a>
            </nav>
        </div>

        <div>
            <div class="text-[10px] font-black uppercase text-neutral-400 dark:text-gray-500 tracking-widest mb-3 px-3">Truyền Thông</div>
            <nav class="space-y-1.5">
                <a href="/admin/blogs" class="flex items-center justify-between px-3 py-2.5 rounded-xl font-bold text-sm transition-colors <?= isActive('/admin/blogs') ?>">
                    <div class="flex items-center gap-3"><i class="ri-article-line text-lg"></i> Quản Lý Bài Viết</div>
                    <span class="text-[10px] px-1.5 py-0.5 rounded bg-amber-100 text-amber-600 dark:bg-amber-500/20 dark:text-amber-400 uppercase">Blog</span>
                </a>
            </nav>
        </div>

        <div>
            <div class="text-[10px] font-black uppercase text-neutral-400 dark:text-gray-500 tracking-widest mb-3 px-3">Thanh Toán & Game</div>
            <nav class="space-y-1.5">
                <a href="/admin/bank-account" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-sm transition-colors <?= isActive('/admin/bank-account') ?>"><i class="ri-bank-line text-lg"></i> Cấu Hình Bank</a>
                <a href="/admin/card" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-sm transition-colors <?= isActive('/admin/card') ?>"><i class="ri-bank-card-line text-lg"></i> Cấu Hình Card</a>
                <a href="/admin/cre-api" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-sm transition-colors <?= isActive('/admin/cre-api') ?>"><i class="ri-braces-line text-lg"></i> Cấu Hình API</a>
                <a href="/admin/games" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-sm transition-colors <?= isActive('/admin/games') ?>"><i class="ri-gamepad-line text-lg"></i> Quản Lý Games</a>
                <a href="/admin/category" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-sm transition-colors <?= isActive('/admin/category') ?>"><i class="ri-list-check-3 text-lg"></i> Quản Lý Danh Mục</a>
            </nav>
        </div>

        <div>
            <div class="text-[10px] font-black uppercase text-neutral-400 dark:text-gray-500 tracking-widest mb-3 px-3">Cài Đặt Cốt Lõi</div>
            <nav class="space-y-1.5">
                <a href="/admin/settings" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-sm transition-colors <?= isActive('/admin/settings') ?>"><i class="ri-settings-3-line text-lg"></i> Cấu Hình Website</a>
                <a href="/admin/connection" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-sm transition-colors <?= isActive('/admin/connection') ?>"><i class="ri-link-m text-lg"></i> Kết Nối</a>
                <a href="/admin/security" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-sm transition-colors <?= isActive('/admin/security') ?>"><i class="ri-shield-keyhole-line text-lg"></i> Bảo Mật</a>
            </nav>
        </div>

    </div>

    <div class="p-4 border-t border-neutral-200 dark:border-gray-800 bg-white/50 dark:bg-[#0b1120]/50 backdrop-blur-md">
        <a href="/home" class="flex items-center justify-center gap-2 w-full h-11 bg-neutral-900 hover:bg-black dark:bg-white dark:hover:bg-gray-100 text-white dark:text-neutral-900 rounded-xl font-black text-sm uppercase tracking-widest transition-all shadow-md hover:shadow-lg focus:outline-none">
            <i class="ri-home-smile-fill text-lg"></i> User Panel
        </a>
    </div>
</aside>
