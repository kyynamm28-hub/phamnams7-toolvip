<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin
if (!isset($_SESSION['user_id'])) { header("Location: /auth/#login"); exit; }
$stmtUser = $pdo->prepare("SELECT role FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);
if (!$user || strtolower($user['role']) !== 'admin') { header("Location: /home"); exit; }

// Chế độ: Thêm mới (Add) hay Chỉnh sửa (Edit)
$slug = $_GET['slug'] ?? '';
$is_edit = false;
$game = [];

if (!empty($slug)) {
    $stmt = $pdo->prepare("SELECT * FROM games WHERE slug = ? LIMIT 1");
    $stmt->execute([$slug]);
    $game = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($game) $is_edit = true;
}

$page_title = $is_edit ? 'Sửa Game: ' . htmlspecialchars($game['name']) : 'Thêm Game Mới';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); }
        .fade-in { animation: fadeIn 0.4s ease-out forwards; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .custom-scroll::-webkit-scrollbar { width: 5px; height: 5px; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #d4d4d8; border-radius: 10px; }
        .dark .custom-scroll::-webkit-scrollbar-thumb { background: #4b5563; }
        
        /* Cấu hình Input chuẩn Minimalist không bị lỗi trôi viền trên Mobile */
        .input-base {
            width: 100%;
            height: 44px;
            padding-left: 16px;
            padding-right: 16px;
            background-color: #f5f5f5;
            border: 1px solid #e5e5e5;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 500;
            color: #171717;
            outline: none;
            transition: all 0.2s ease;
        }
        .dark .input-base {
            background-color: #111827;
            border-color: #374151;
            color: #ffffff;
        }
        .input-base:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.15);
        }
        .label-base {
            display: block;
            font-size: 11px;
            font-weight: 700;
            color: #737373;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 8px;
        }
        .dark .label-base {
            color: #9ca3af;
        }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-neutral-50 dark:bg-gray-900 text-neutral-800 dark:text-gray-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 w-full max-w-4xl mx-auto fade-in" x-data="gameFormManager()">
            
            <div class="mb-6">
                <a href="/admin/games" class="inline-flex items-center gap-1.5 text-[12px] font-bold text-neutral-500 hover:text-neutral-900 dark:text-gray-400 dark:hover:text-white transition-colors uppercase tracking-widest bg-white dark:bg-gray-800 px-4 py-2 rounded-full border border-neutral-200 dark:border-gray-700 shadow-sm focus:outline-none">
                    <i class="ri-arrow-left-line text-[14px]"></i> Quay Lại Danh Sách
                </a>
            </div>

            <div class="rounded-2xl border border-neutral-200 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-soft overflow-hidden">
                
                <div class="px-6 py-5 border-b border-neutral-100 dark:border-gray-700 bg-neutral-50/50 dark:bg-gray-800/50 flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-slate-700 to-slate-800 flex items-center justify-center shadow-inner shrink-0">
                        <i class="<?= $is_edit ? 'ri-edit-2-line' : 'ri-add-line' ?> text-white text-lg"></i>
                    </div>
                    <div>
                        <div class="text-lg font-bold text-neutral-800 dark:text-white uppercase tracking-wide">
                            <?= $is_edit ? 'Sửa Cấu Hình Game' : 'Thêm Game Mới' ?>
                        </div>
                        <div class="text-xs text-neutral-500 dark:text-gray-400 font-medium mt-0.5">Thiết lập chi tiết các thông số đầu vào của trò chơi.</div>
                    </div>
                </div>

                <div class="p-5 sm:p-8 space-y-8">
                    
                    <div class="space-y-5">
                        <div class="flex items-center gap-2 mb-2 border-b border-neutral-100 dark:border-gray-700 pb-3">
                            <span class="w-6 h-6 rounded bg-neutral-100 dark:bg-gray-700 text-neutral-600 dark:text-gray-300 flex items-center justify-center text-xs font-bold shrink-0">1</span>
                            <h3 class="text-[13px] font-bold text-neutral-800 dark:text-white uppercase tracking-widest">Thông Tin Cốt Lõi</h3>
                        </div>

                        <div>
                            <label class="label-base">Tên Game <span class="text-rose-500">*</span></label>
                            <input type="text" x-model="form.name" placeholder="VD: SunWin, Go88..." class="input-base text-[14px] font-bold">
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                            <div>
                                <label class="label-base">Thể Loại Game <span class="text-rose-500">*</span></label>
                                <select x-model="form.category" class="input-base cursor-pointer">
                                    <option value="taixiu">Tài Xỉu</option>
                                    <option value="sicbo">Sicbo</option>
                                    <option value="bacarat">Baccarat</option>
                                </select>
                            </div>
                            <div>
                                <label class="label-base">Trạng Thái Hoạt Động</label>
                                <select x-model="form.status" class="input-base cursor-pointer">
                                    <option value="active">Hoạt động (Bật)</option>
                                    <option value="hidden">Đang khóa (Ẩn)</option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <label class="label-base">Đường Dẫn Ảnh Thumbnail (URL)</label>
                            <input type="text" x-model="form.image" placeholder="https://domain.com/image.png" class="input-base font-mono">
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                            <div>
                                <label class="label-base">Mác Hiển Thị (Badge)</label>
                                <input type="text" x-model="form.badge" placeholder="VD: HOT, NEW, VIP..." class="input-base uppercase text-center sm:text-left">
                            </div>
                            <div>
                                <label class="label-base">Vị Trí Sắp Xếp (Thứ tự tự tăng)</label>
                                <input type="number" x-model.number="form.position" placeholder="0" class="input-base text-center sm:text-left">
                            </div>
                        </div>

                        <div>
                            <div class="flex justify-between items-end mb-2">
                                <label class="label-base mb-0">Mô Tả Chi Tiết Game</label>
                                <span class="text-[9px] font-bold text-blue-600 bg-blue-50 dark:bg-blue-900/30 px-2 py-0.5 rounded uppercase font-mono tracking-wider">HTML hỗ trợ</span>
                            </div>
                            <textarea x-model="form.description" rows="5" placeholder="Nhập văn bản thô hoặc mã HTML định dạng màu sắc..." class="input-base h-auto py-3 custom-scroll font-mono leading-relaxed resize-y"></textarea>
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                            <div>
                                <label class="label-base">Đường Dẫn Tĩnh (Slug)</label>
                                <input type="text" x-model="form.slug" placeholder="Bỏ trống để tự động tạo" class="input-base font-mono">
                            </div>
                            <div>
                                <label class="label-base">Nguồn Nhúng Iframe (Tùy chọn)</label>
                                <input type="text" x-model="form.url_iframe" placeholder="https://domain.com/embed/..." class="input-base font-mono">
                            </div>
                        </div>
                    </div>

                    <div class="h-px w-full bg-neutral-100 dark:bg-gray-700 my-4"></div>

                    <div x-show="form.category !== 'bacarat'" x-collapse>
                        <div class="space-y-6">
                            
                            <div class="flex items-center justify-between border-b border-neutral-100 dark:border-gray-700 pb-3 mb-2">
                                <div class="flex items-center gap-2">
                                    <span class="w-6 h-6 rounded bg-neutral-100 dark:bg-gray-700 text-neutral-600 dark:text-gray-300 flex items-center justify-center text-xs font-bold shrink-0">2</span>
                                    <h3 class="text-[13px] font-bold text-neutral-800 dark:text-white uppercase tracking-widest">Cấu Hình Dữ Liệu API Ngầm</h3>
                                </div>
                                <span class="text-[10px] text-neutral-400 italic font-medium shrink-0">Bỏ trống nếu không dùng</span>
                            </div>

                            <div class="bg-neutral-50 dark:bg-gray-900 rounded-xl p-5 border border-neutral-200 dark:border-gray-700 space-y-5 shadow-inner">
                                <div>
                                    <label class="label-base text-blue-600 dark:text-blue-400 font-black"><i class="ri-braces-line mr-1"></i> Đường Dẫn API Dự Đoán</label>
                                    <input type="text" x-model="form.api_predict_url" placeholder="https://api.site.com/get-result" class="input-base font-mono bg-white dark:bg-gray-800">
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                                    <div>
                                        <label class="label-base text-[10px]">Map Node Báo Phiên</label>
                                        <input type="text" x-model="form.map_notify" placeholder="VD: session" class="input-base font-mono text-center sm:text-left bg-white dark:bg-gray-800">
                                    </div>
                                    <div>
                                        <label class="label-base text-[10px]">Map Node Dự Đoán</label>
                                        <input type="text" x-model="form.map_predict" placeholder="VD: predict" class="input-base font-mono text-center sm:text-left bg-white dark:bg-gray-800">
                                    </div>
                                    <div x-show="form.category === 'sicbo'">
                                        <label class="label-base text-[10px]">Map Node Vị (Chỉ Sicbo)</label>
                                        <input type="text" x-model="form.map_predict_vi" placeholder="VD: vi" class="input-base font-mono text-center sm:text-left bg-white dark:bg-gray-800">
                                    </div>
                                    <div>
                                        <label class="label-base text-[10px]">Map Node Tỉ Lệ (%)</label>
                                        <input type="text" x-model="form.map_rate" placeholder="VD: rate" class="input-base font-mono text-center sm:text-left bg-white dark:bg-gray-800">
                                    </div>
                                </div>
                            </div>

                            <div class="bg-neutral-50 dark:bg-gray-900 rounded-xl p-5 border border-neutral-200 dark:border-gray-700 shadow-inner">
                                <label class="label-base text-purple-600 dark:text-purple-400 font-black mb-4"><i class="ri-history-line mr-1"></i> Map Dữ Liệu Phân Tích Lịch Sử</label>
                                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                                    <div>
                                        <label class="label-base text-[10px]">Map Phiên Trước</label>
                                        <input type="text" x-model="form.map_history_prev" placeholder="phien_truoc" class="input-base font-mono text-center bg-white dark:bg-gray-800">
                                    </div>
                                    <div>
                                        <label class="label-base text-[10px]">Map Kết Quả Thô</label>
                                        <input type="text" x-model="form.map_history_result" placeholder="ket_qua" class="input-base font-mono text-center bg-white dark:bg-gray-800">
                                    </div>
                                    <div>
                                        <label class="label-base text-[10px]">Map Tổng Điểm (3 XX)</label>
                                        <input type="text" x-model="form.map_history_sum" placeholder="tong_diem" class="input-base font-mono text-center bg-white dark:bg-gray-800">
                                    </div>
                                    <div>
                                        <label class="label-base text-[10px]">Map Node Xúc Xắc 1</label>
                                        <input type="text" x-model="form.map_history_dice1" placeholder="dice1" class="input-base font-mono text-center bg-white dark:bg-gray-800">
                                    </div>
                                    <div>
                                        <label class="label-base text-[10px]">Map Node Xúc Xắc 2</label>
                                        <input type="text" x-model="form.map_history_dice2" placeholder="dice2" class="input-base font-mono text-center bg-white dark:bg-gray-800">
                                    </div>
                                    <div>
                                        <label class="label-base text-[10px]">Map Node Xúc Xắc 3</label>
                                        <input type="text" x-model="form.map_history_dice3" placeholder="dice3" class="input-base font-mono text-center bg-white dark:bg-gray-800">
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div x-show="form.category === 'bacarat'" x-collapse class="bg-neutral-50 dark:bg-gray-900 border border-neutral-200 dark:border-gray-700 rounded-xl p-5 text-center shadow-inner">
                        <i class="ri-shield-star-fill text-2xl text-amber-500 mb-1.5 block"></i>
                        <h4 class="text-[13px] font-bold text-neutral-800 dark:text-white uppercase tracking-widest mb-0.5">Quy Trình Baccarat</h4>
                        <p class="text-xs text-neutral-400 dark:text-gray-500 font-medium">Đối với Baccarat, hệ thống sẽ tự định tuyến thẳng về luồng phân tích mặc định. Không cần thiết lập cấu trúc Map API.</p>
                    </div>

                </div>

                <div class="px-6 py-5 border-t border-neutral-100 dark:border-gray-700 bg-neutral-50/50 dark:bg-gray-800/50 flex">
                    <button @click="saveGame()" :disabled="loading" class="w-full h-12 bg-neutral-800 hover:bg-black dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 text-white rounded-xl text-[13px] font-black uppercase tracking-widest transition-all shadow-md flex items-center justify-center gap-2 focus:outline-none disabled:opacity-70 disabled:cursor-not-allowed">
                        <i x-show="!loading" class="ri-save-3-line text-[16px]"></i>
                        <i x-show="loading" class="ri-loader-4-line animate-spin text-[16px]"></i>
                        <span x-text="loading ? 'Đang cập nhật...' : '<?= $is_edit ? 'Lưu Cấu Hình' : 'Tạo Game Ngay' ?>'"></span>
                    </button>
                </div>

            </div>

        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('gameFormManager', () => ({
                loading: false,
                isEdit: <?= $is_edit ? 'true' : 'false' ?>,
                form: {
                    id: <?= $is_edit ? $game['id'] : 'null' ?>,
                    category: <?= json_encode($game['category'] ?? 'taixiu') ?>,
                    slug: <?= json_encode($game['slug'] ?? '') ?>,
                    name: <?= json_encode($game['name'] ?? '') ?>,
                    image: <?= json_encode($game['image'] ?? '') ?>,
                    description: <?= json_encode($game['description'] ?? '') ?>,
                    badge: <?= json_encode($game['badge'] ?? '') ?>,
                    position: <?= (int)($game['position'] ?? 0) ?>,
                    url_iframe: <?= json_encode($game['url_iframe'] ?? '') ?>,
                    api_predict_url: <?= json_encode($game['api_predict_url'] ?? '') ?>,
                    map_notify: <?= json_encode($game['map_notify'] ?? '') ?>,
                    map_predict: <?= json_encode($game['map_predict'] ?? '') ?>,
                    map_predict_vi: <?= json_encode($game['map_predict_vi'] ?? '') ?>,
                    map_rate: <?= json_encode($game['map_rate'] ?? '') ?>,
                    map_history_prev: <?= json_encode($game['map_history_prev'] ?? '') ?>,
                    map_history_result: <?= json_encode($game['map_history_result'] ?? '') ?>,
                    map_history_sum: <?= json_encode($game['map_history_sum'] ?? '') ?>,
                    map_history_dice1: <?= json_encode($game['map_history_dice1'] ?? '') ?>,
                    map_history_dice2: <?= json_encode($game['map_history_dice2'] ?? '') ?>,
                    map_history_dice3: <?= json_encode($game['map_history_dice3'] ?? '') ?>,
                    status: <?= json_encode($game['status'] ?? 'active') ?>
                },
                
                async saveGame() {
                    if(!this.form.name || !this.form.category) {
                        Swal.fire({toast:true, position:'top-end', icon:'error', title:'Thiếu tên Game!', showConfirmButton:false, timer:2000});
                        return;
                    }
                    this.loading = true;
                    try {
                        const res = await fetch('/api-handler?action=save_game', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(this.form)
                        });
                        const data = await res.json();
                        if(data.status === 'success') {
                            Swal.fire({ icon: 'success', title: 'Thành công', text: data.message, confirmButtonColor: '#171717', customClass: { popup: document.documentElement.classList.contains('dark') ? 'bg-gray-800 text-white' : '' }})
                            .then(() => {
                                if(!this.isEdit) window.location.href = '/admin/games';
                            });
                        } else {
                            Swal.fire('Lỗi', data.message, 'error');
                        }
                    } catch(e) {
                        Swal.fire('Lỗi', 'Không thể kết nối máy chủ.', 'error');
                    } finally {
                        this.loading = false;
                    }
                }
            }));
        });
    </script>
</body>
</html>
