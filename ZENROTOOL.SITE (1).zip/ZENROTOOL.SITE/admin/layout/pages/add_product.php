<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

if (!isset($_SESSION['user_id'])) { header("Location: /auth/#login"); exit; }
$stmtUser = $pdo->prepare("SELECT role FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
if (strtolower($stmtUser->fetchColumn()) !== 'admin') { header("Location: /home"); exit; }

$slug = $_GET['slug'] ?? '';
$is_edit = false;
$product = [];

if (!empty($slug)) {
    // Lấy thông tin sản phẩm và ảnh
    $stmt = $pdo->prepare("
        SELECT p.*, pi.image_url as image 
        FROM products p 
        LEFT JOIN product_images pi ON p.id = pi.product_id AND pi.is_primary = 1
        WHERE p.slug = ? LIMIT 1
    ");
    $stmt->execute([$slug]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($product) $is_edit = true;
}

$page_title = $is_edit ? 'Sửa Sản Phẩm: ' . htmlspecialchars($product['name']) : 'Thêm Mã Nguồn Mới';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); }
        .fade-in { animation: fadeIn 0.4s ease-out forwards; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .custom-scroll::-webkit-scrollbar { width: 5px; height: 5px; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #d4d4d8; border-radius: 10px; }
        .dark .custom-scroll::-webkit-scrollbar-thumb { background: #4b5563; }
        
        .input-base {
            width: 100%; height: 44px; padding: 0 16px; 
            background-color: #f5f5f5; border: 1px solid #e5e5e5; border-radius: 12px;
            font-size: 13px; font-weight: 500; color: #171717; outline: none; transition: all 0.2s ease;
        }
        .dark .input-base { background-color: #111827; border-color: #374151; color: #ffffff; }
        .input-base:focus { border-color: #3b82f6; box-shadow: 0 0 0 3px rgba(59,130,246,0.15); }
        .label-base { display: block; font-size: 11px; font-weight: 700; color: #737373; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 8px; }
        .dark .label-base { color: #9ca3af; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-neutral-50 dark:bg-gray-900 text-neutral-800 dark:text-gray-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 w-full max-w-4xl mx-auto fade-in" x-data="productFormManager()">
            
            <div class="mb-6">
                <a href="/admin/product" class="inline-flex items-center gap-1.5 text-[12px] font-bold text-neutral-500 hover:text-neutral-900 dark:text-gray-400 dark:hover:text-white transition-colors uppercase tracking-widest bg-white dark:bg-gray-800 px-4 py-2 rounded-full border border-neutral-200 dark:border-gray-700 shadow-sm focus:outline-none">
                    <i class="ri-arrow-left-line text-[14px]"></i> Quay Lại Kho Hàng
                </a>
            </div>

            <div class="rounded-2xl border border-neutral-200 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-soft overflow-hidden">
                
                <div class="px-6 py-5 border-b border-neutral-100 dark:border-gray-700 bg-neutral-50/50 dark:bg-gray-800/50 flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-slate-700 to-slate-800 flex items-center justify-center shadow-inner shrink-0">
                        <i class="<?= $is_edit ? 'ri-edit-2-line' : 'ri-archive-line' ?> text-white text-lg"></i>
                    </div>
                    <div>
                        <div class="text-lg font-bold text-neutral-800 dark:text-white uppercase tracking-wide">
                            <?= $is_edit ? 'Chỉnh Sửa Mã Nguồn' : 'Đăng Bán Mã Nguồn' ?>
                        </div>
                        <div class="text-xs text-neutral-500 dark:text-gray-400 font-medium mt-0.5">Mô tả mã nguồn chi tiết để khách hàng tin tưởng mua.</div>
                    </div>
                </div>

                <div class="p-5 sm:p-8 space-y-8">
                    
                    <div class="space-y-5">
                        <div class="flex items-center gap-2 border-b border-neutral-100 dark:border-gray-700 pb-3">
                            <span class="w-6 h-6 rounded bg-neutral-100 dark:bg-gray-700 text-neutral-600 dark:text-gray-300 flex items-center justify-center text-xs font-bold shrink-0">1</span>
                            <h3 class="text-[13px] font-bold text-neutral-800 dark:text-white uppercase tracking-widest">Thông Tin Niêm Yết</h3>
                        </div>

                        <div>
                            <label class="label-base">Tên Sản Phẩm (Mã Nguồn) <span class="text-rose-500">*</span></label>
                            <input type="text" x-model="form.name" placeholder="VD: Source Code Game Tài Xỉu..." class="input-base text-[14px] font-bold">
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                            <div>
                                <label class="label-base">Giá Bán (VNĐ) <span class="text-rose-500">*</span></label>
                                <input type="number" x-model.number="form.price" placeholder="VD: 500000" class="input-base font-bold text-blue-600 dark:text-blue-400">
                            </div>
                            <div>
                                <label class="label-base">Trạng Thái Hiển Thị</label>
                                <select x-model="form.status" class="input-base cursor-pointer appearance-none">
                                    <option value="active">Mở bán (Active)</option>
                                    <option value="inactive">Tạm ngưng (Inactive)</option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <label class="label-base">Ảnh Đại Diện (Image URL)</label>
                            <div class="flex items-center gap-3">
                                <div class="w-11 h-11 shrink-0 bg-neutral-100 dark:bg-gray-900 rounded-lg border border-neutral-200 dark:border-gray-700 p-1 flex items-center justify-center">
                                    <img :src="form.image || 'https://cdn-icons-png.flaticon.com/512/2165/8144288.png'" class="max-w-full max-h-full object-contain">
                                </div>
                                <input type="text" x-model="form.image" placeholder="https://..." class="input-base font-mono">
                            </div>
                        </div>
                        
                        <div>
                            <label class="label-base">Tóm Tắt Ngắn (Mô tả ngắn gọn) <span class="text-rose-500">*</span></label>
                            <textarea x-model="form.short_description" rows="2" placeholder="Dùng hiển thị ở dạng lưới (Tối đa 200 chữ)..." class="input-base h-auto py-3 resize-y font-medium"></textarea>
                        </div>
                    </div>

                    <div class="space-y-5">
                        <div class="flex items-center gap-2 border-b border-neutral-100 dark:border-gray-700 pb-3">
                            <span class="w-6 h-6 rounded bg-neutral-100 dark:bg-gray-700 text-neutral-600 dark:text-gray-300 flex items-center justify-center text-xs font-bold shrink-0">2</span>
                            <h3 class="text-[13px] font-bold text-neutral-800 dark:text-white uppercase tracking-widest">Nội Dung Chi Tiết & Tải Về</h3>
                        </div>

                        <div>
                            <label class="label-base flex justify-between items-end mb-2">
                                <span>Bài Viết Chi Tiết Mã Nguồn <span class="text-rose-500">*</span></span>
                                <span class="text-[9px] text-blue-600 bg-blue-50 dark:bg-blue-900/30 px-2 py-0.5 rounded uppercase font-mono tracking-wider">Hỗ trợ HTML</span>
                            </label>
                            <textarea x-model="form.content" rows="10" placeholder="Viết giới thiệu, công nghệ sử dụng, chức năng chi tiết..." class="input-base h-auto py-4 custom-scroll font-mono leading-relaxed"></textarea>
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                            <div>
                                <label class="label-base">Link Tải File (Google Drive, Mega...)</label>
                                <input type="text" x-model="form.download_url" placeholder="https://drive.google.com/..." class="input-base font-mono">
                            </div>
                            <div>
                                <label class="label-base">Thông Tin Liên Hệ Hỗ Trợ (Sau khi mua)</label>
                                <input type="text" x-model="form.support_contact" placeholder="Zalo: 0123... - Tele: @admin" class="input-base">
                            </div>
                        </div>
                        
                        <div>
                            <label class="label-base">Đường dẫn tĩnh (Slug)</label>
                            <input type="text" x-model="form.slug" placeholder="Để trống hệ thống tự tạo" class="input-base font-mono text-neutral-500 w-full sm:w-1/2">
                        </div>
                    </div>

                </div>

                <div class="px-6 py-5 border-t border-neutral-100 dark:border-gray-700 bg-neutral-50/80 dark:bg-gray-800/80 flex">
                    <button @click="saveProduct()" :disabled="loading" class="w-full sm:w-auto ml-auto h-12 px-10 bg-neutral-900 hover:bg-black dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 text-white rounded-xl text-[13px] font-bold uppercase tracking-widest transition-all shadow-md flex items-center justify-center gap-2 focus:outline-none disabled:opacity-70 disabled:cursor-not-allowed">
                        <i x-show="!loading" class="ri-save-3-line text-[16px]"></i>
                        <i x-show="loading" class="ri-loader-4-line animate-spin text-[16px]"></i>
                        <span x-text="loading ? 'Đang lưu...' : '<?= $is_edit ? 'Cập Nhật Mã Nguồn' : 'Đăng Bán Ngay' ?>'"></span>
                    </button>
                </div>

            </div>

        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('productFormManager', () => ({
                loading: false,
                isEdit: <?= $is_edit ? 'true' : 'false' ?>,
                form: {
                    id: <?= $is_edit ? $product['id'] : 'null' ?>,
                    name: <?= json_encode($product['name'] ?? '') ?>,
                    slug: <?= json_encode($product['slug'] ?? '') ?>,
                    price: <?= (int)($product['price'] ?? 0) ?>,
                    short_description: <?= json_encode($product['short_description'] ?? '') ?>,
                    content: <?= json_encode($product['content'] ?? '') ?>,
                    image: <?= json_encode($product['image'] ?? '') ?>,
                    download_url: <?= json_encode($product['download_url'] ?? '') ?>,
                    support_contact: <?= json_encode($product['support_contact'] ?? '') ?>,
                    status: <?= json_encode($product['status'] ?? 'active') ?>
                },
                
                async saveProduct() {
                    if(!this.form.name || !this.form.price || !this.form.content || !this.form.short_description) {
                        Swal.fire({toast:true, position:'top-end', icon:'error', title:'Thiếu thông tin bắt buộc (*)!', showConfirmButton:false, timer:2000});
                        return;
                    }
                    this.loading = true;
                    try {
                        const res = await fetch('/api-handler?action=save_product', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(this.form)
                        });
                        const data = await res.json();
                        if(data.status === 'success') {
                            Swal.fire({ icon: 'success', title: 'Thành công', text: data.message, confirmButtonColor: '#171717', customClass: { popup: document.documentElement.classList.contains('dark') ? 'bg-gray-800 text-white' : '' }})
                            .then(() => {
                                if(!this.isEdit) window.location.href = '/admin/product';
                            });
                        } else {
                            Swal.fire('Lỗi', data.message, 'error');
                        }
                    } catch(e) {
                        Swal.fire('Lỗi', 'Không thể kết nối máy chủ.', 'error');
                    } finally {
                        this.loading = false;
                    }
                }
            }));
        });
    </script>
</body>
</html>
