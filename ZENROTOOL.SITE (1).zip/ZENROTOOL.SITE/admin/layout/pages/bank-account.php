<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin
if (!isset($_SESSION['user_id'])) { header("Location: /auth/#login"); exit; }
$stmtCheck = $pdo->prepare("SELECT role FROM users WHERE id = ?");
$stmtCheck->execute([$_SESSION['user_id']]);
if (strtolower($stmtCheck->fetchColumn()) !== 'admin') { header("Location: /home"); exit; }

// Lấy thông tin cấu hình hiện tại
try {
    $stmt = $pdo->query("SELECT * FROM setting_bank LIMIT 1");
    $bankConfig = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $bankConfig = null;
}

$pageTitle = 'Cấu Hình Ngân Hàng Nạp Tiền';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.02); }
        .fade-in-up { animation: fadeInUp 0.4s ease-out forwards; }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        /* Tùy chỉnh thanh cuộn cho dropdown */
        .dropdown-scroll::-webkit-scrollbar { width: 5px; }
        .dropdown-scroll::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
        .dark .dropdown-scroll::-webkit-scrollbar-thumb { background: #475569; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-[#f8fafc] dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 w-full max-w-4xl mx-auto fade-in-up" x-data="bankSettingsManager(<?= htmlspecialchars(json_encode($bankConfig ?: [])) ?>)">
            
            <div class="mb-6">
                <h1 class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Cấu Hình Ngân Hàng</h1>
                <p class="text-xs sm:text-sm text-slate-500 dark:text-gray-400 mt-1">Thiết lập tài khoản nhận tiền và kết nối SePay (Auto Bank).</p>
            </div>

            <div class="bg-white dark:bg-gray-800/80 rounded-3xl border border-slate-100 dark:border-gray-700/50 shadow-soft overflow-hidden">
                
                <div class="p-6 sm:p-10">
                    <div class="space-y-6">
                        
                        <div class="relative" @click.away="dropdownOpen = false">
                            <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Ngân Hàng Thụ Hưởng</label>
                            
                            <div @click="dropdownOpen = !dropdownOpen" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-3 px-4 flex items-center justify-between cursor-pointer hover:border-blue-400 transition-colors">
                                <template x-if="!selectedBank">
                                    <span class="text-sm text-slate-400 font-medium">-- Vui lòng chọn ngân hàng --</span>
                                </template>
                                <template x-if="selectedBank">
                                    <div class="flex items-center gap-3">
                                        <div class="w-8 h-8 rounded bg-white p-0.5 border border-slate-200 dark:border-gray-600">
                                            <img :src="selectedBank.logo" class="w-full h-full object-contain">
                                        </div>
                                        <div>
                                            <div class="text-sm font-bold text-slate-800 dark:text-white leading-tight" x-text="selectedBank.shortName"></div>
                                            <div class="text-[10px] text-slate-500 truncate max-w-[200px] sm:max-w-md" x-text="selectedBank.name"></div>
                                        </div>
                                    </div>
                                </template>
                                <i class="ri-arrow-down-s-line text-slate-400 transition-transform" :class="dropdownOpen ? 'rotate-180' : ''"></i>
                            </div>

                            <div x-show="dropdownOpen" x-transition class="absolute z-50 mt-2 w-full bg-white dark:bg-gray-800 border border-slate-200 dark:border-gray-700 rounded-2xl shadow-xl overflow-hidden">
                                <div class="p-3 border-b border-slate-100 dark:border-gray-700">
                                    <div class="relative">
                                        <i class="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
                                        <input type="text" x-model="searchQuery" placeholder="Tìm tên hoặc mã ngân hàng..." class="w-full bg-slate-50 dark:bg-gray-900/50 rounded-lg pl-9 pr-3 py-2 text-sm focus:outline-none focus:border-blue-500 border border-transparent dark:text-white transition-colors">
                                    </div>
                                </div>
                                <ul class="max-h-64 overflow-y-auto dropdown-scroll p-2">
                                    <template x-if="filteredBanks.length === 0">
                                        <li class="p-4 text-center text-sm text-slate-500">Đang tải dữ liệu ngân hàng...</li>
                                    </template>
                                    <template x-for="bank in filteredBanks" :key="bank.bin">
                                        <li @click="selectBank(bank)" class="flex items-center gap-3 p-2.5 hover:bg-slate-50 dark:hover:bg-gray-700 rounded-xl cursor-pointer transition-colors">
                                            <img :src="bank.logo" class="w-8 h-8 rounded bg-white p-0.5 border border-slate-200 shrink-0">
                                            <div class="flex-1 overflow-hidden">
                                                <div class="text-sm font-bold text-slate-800 dark:text-white" x-text="bank.shortName"></div>
                                                <div class="text-[10px] text-slate-500 truncate" x-text="bank.name"></div>
                                            </div>
                                            <div class="text-[10px] font-mono text-blue-500 font-bold px-2 bg-blue-50 dark:bg-blue-900/20 rounded">BIN: <span x-text="bank.bin"></span></div>
                                        </li>
                                    </template>
                                </ul>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Số Tài Khoản</label>
                                <input type="text" x-model="formData.account_number" placeholder="Nhập số tài khoản..." class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-3 px-4 font-black text-blue-600 dark:text-blue-400 focus:outline-none focus:border-blue-500 transition-colors">
                            </div>
                            <div>
                                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Tên Chủ Tài Khoản</label>
                                <input type="text" x-model="formData.account_name" placeholder="VD: NGUYEN VAN A" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-3 px-4 font-black text-slate-800 dark:text-white uppercase focus:outline-none focus:border-blue-500 transition-colors">
                            </div>
                        </div>

                        <div class="border-t border-slate-100 dark:border-gray-700/50 pt-6">
                            <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">Hình Thức Xử Lý Đơn Nạp</label>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <label class="relative flex p-4 cursor-pointer rounded-2xl border-2 transition-colors" :class="formData.method === 'auto' ? 'bg-emerald-50 border-emerald-500 dark:bg-emerald-900/10' : 'bg-white border-slate-200 dark:bg-gray-800 dark:border-gray-700'">
                                    <input type="radio" name="method" value="auto" x-model="formData.method" class="sr-only">
                                    <div class="flex items-center gap-3">
                                        <div class="w-10 h-10 rounded-full flex items-center justify-center text-xl" :class="formData.method === 'auto' ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-400 dark:bg-gray-700'">
                                            <i class="ri-robot-2-fill"></i>
                                        </div>
                                        <div>
                                            <div class="font-bold text-sm" :class="formData.method === 'auto' ? 'text-emerald-700 dark:text-emerald-400' : 'text-slate-700 dark:text-gray-300'">Auto Bank (SePay)</div>
                                            <div class="text-[10px] text-slate-500 mt-0.5">Tự động cộng tiền 24/7</div>
                                        </div>
                                    </div>
                                    <i class="ri-checkbox-circle-fill absolute top-4 right-4 text-emerald-500 text-xl transition-opacity" :class="formData.method === 'auto' ? 'opacity-100' : 'opacity-0'"></i>
                                </label>

                                <label class="relative flex p-4 cursor-pointer rounded-2xl border-2 transition-colors" :class="formData.method === 'manual' ? 'bg-purple-50 border-purple-500 dark:bg-purple-900/10' : 'bg-white border-slate-200 dark:bg-gray-800 dark:border-gray-700'">
                                    <input type="radio" name="method" value="manual" x-model="formData.method" class="sr-only">
                                    <div class="flex items-center gap-3">
                                        <div class="w-10 h-10 rounded-full flex items-center justify-center text-xl" :class="formData.method === 'manual' ? 'bg-purple-100 text-purple-600' : 'bg-slate-100 text-slate-400 dark:bg-gray-700'">
                                            <i class="ri-user-settings-fill"></i>
                                        </div>
                                        <div>
                                            <div class="font-bold text-sm" :class="formData.method === 'manual' ? 'text-purple-700 dark:text-purple-400' : 'text-slate-700 dark:text-gray-300'">Thủ Công (Cộng Tay)</div>
                                            <div class="text-[10px] text-slate-500 mt-0.5">Admin tự kiểm tra và cộng</div>
                                        </div>
                                    </div>
                                    <i class="ri-checkbox-circle-fill absolute top-4 right-4 text-purple-500 text-xl transition-opacity" :class="formData.method === 'manual' ? 'opacity-100' : 'opacity-0'"></i>
                                </label>
                            </div>
                        </div>

                        <div x-show="formData.method === 'auto' && !isBankSupported" x-cloak x-transition>
                            <div class="bg-rose-50 dark:bg-rose-900/20 border border-rose-200 dark:border-rose-800/30 rounded-xl p-4 flex gap-3 items-start">
                                <i class="ri-error-warning-fill text-rose-500 text-xl mt-0.5"></i>
                                <div>
                                    <h4 class="text-sm font-bold text-rose-700 dark:text-rose-400">Ngân hàng không được hỗ trợ Auto!</h4>
                                    <p class="text-xs text-rose-600/80 dark:text-rose-400/80 mt-1">SePay hiện <b>không hỗ trợ</b> kết nối với ngân hàng bạn vừa chọn. Hệ thống Auto Bank sẽ không hoạt động. Khuyên dùng: <b>Vietcombank, VPBank, ACB, Sacombank, MB, Vietinbank...</b> hoặc chuyển sang nạp <b>Thủ Công</b>.</p>
                                </div>
                            </div>
                        </div>

                        <div x-show="formData.method === 'auto'" x-collapse>
                            <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">SePay Token (YOUR_TOKEN)</label>
                            <input type="text" x-model="formData.sepay_token" placeholder="Lấy mã Token từ my.sepay.vn" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-3 px-4 font-mono text-sm text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 transition-colors">
                        </div>

                        <div>
                            <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Nạp Tối Thiểu (VNĐ)</label>
                            <input type="number" x-model="formData.min_recharge" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-3 px-4 font-bold text-sm text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 transition-colors">
                        </div>

                    </div>
                </div>
                
                <div class="p-6 border-t border-slate-100 dark:border-gray-700/50 bg-slate-50/50 dark:bg-gray-900/20">
                    <button @click="saveConfig()" :disabled="isProcessing" class="w-full h-12 bg-slate-900 hover:bg-black dark:bg-white dark:hover:bg-gray-100 dark:text-slate-900 text-white rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2 shadow-md">
                        <i x-show="!isProcessing" class="ri-save-3-line"></i>
                        <i x-show="isProcessing" class="ri-loader-4-line animate-spin"></i>
                        <span x-text="isProcessing ? 'Đang lưu cấu hình...' : 'Lưu Cấu Hình Ngân Hàng'"></span>
                    </button>
                </div>
            </div>

            <div class="mt-8 bg-blue-50 dark:bg-blue-900/10 border border-blue-200 dark:border-blue-800/30 rounded-3xl p-6 sm:p-8 flex items-center gap-4">
                <div class="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/40 text-blue-600 flex items-center justify-center shrink-0">
                    <i class="ri-api-line text-2xl"></i>
                </div>
                <div class="flex-1 overflow-hidden">
                    <h3 class="text-sm font-bold text-blue-800 dark:text-blue-300 mb-1">API Lịch Sử Giao Dịch</h3>
                    <div class="flex items-center gap-2">
                        <code class="text-xs font-mono bg-white dark:bg-gray-900 px-3 py-1.5 rounded-lg border border-blue-100 dark:border-blue-800/50 text-slate-600 dark:text-gray-300 truncate w-full">
                            <?= $_SERVER['REQUEST_SCHEME'] ?? 'http' ?>://<?= $_SERVER['HTTP_HOST'] ?>/api/v2/payment/history
                        </code>
                    </div>
                </div>
            </div>

        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('bankSettingsManager', (initData) => ({
                isProcessing: false,
                dropdownOpen: false,
                banks: [],
                searchQuery: '',
                selectedBank: null,

                // Danh sách ngân hàng SePay hỗ trợ
                supportedBanks: ['VCB', 'VPB', 'ACB', 'STB', 'SACOMBANK', 'ICB', 'VIETINBANK', 'MB', 'BIDV', 'MSB', 'TPB', 'KLB', 'KIENLONGBANK', 'OCB'],
                
                formData: {
                    bank_name: initData?.bank_name || '',
                    short_name: initData?.short_name || '',
                    bin: initData?.bin || '',
                    logo: initData?.logo || '',
                    account_number: initData?.account_number || '',
                    account_name: initData?.account_name || '',
                    min_recharge: initData?.min_recharge || 10000,
                    method: initData?.method || 'manual',
                    sepay_token: initData?.sepay_token || ''
                },

                init() {
                    // Fetch list bank từ VietQR
                    fetch('https://api.vietqr.io/v2/banks')
                        .then(res => res.json())
                        .then(data => {
                            this.banks = data.data;
                            // Phục hồi selectedBank từ initData
                            if (this.formData.bin) {
                                this.selectedBank = this.banks.find(b => b.bin === this.formData.bin) || {
                                    name: this.formData.bank_name,
                                    shortName: this.formData.short_name,
                                    bin: this.formData.bin,
                                    logo: this.formData.logo
                                };
                            }
                        });
                },

                get filteredBanks() {
                    if (this.searchQuery === '') return this.banks;
                    const q = this.searchQuery.toLowerCase();
                    return this.banks.filter(b => b.name.toLowerCase().includes(q) || b.shortName.toLowerCase().includes(q) || b.bin.includes(q));
                },

                get isBankSupported() {
                    if (!this.selectedBank) return true; // Chưa chọn thì ko báo lỗi
                    const code = (this.selectedBank.shortName || '').toUpperCase();
                    return this.supportedBanks.some(sup => code.includes(sup));
                },

                selectBank(bank) {
                    this.selectedBank = bank;
                    this.formData.bank_name = bank.name;
                    this.formData.short_name = bank.shortName;
                    this.formData.bin = bank.bin;
                    this.formData.logo = bank.logo;
                    this.dropdownOpen = false;
                    this.searchQuery = '';
                },

                async saveConfig() {
                    if (!this.formData.bin || !this.formData.account_number || !this.formData.account_name) {
                        Swal.fire({ toast: true, position: 'top-end', icon: 'warning', title: 'Điền đầy đủ Ngân hàng, STK và Tên!', showConfirmButton: false, timer: 3000 });
                        return;
                    }
                    if (this.formData.method === 'auto' && !this.formData.sepay_token) {
                        Swal.fire({ toast: true, position: 'top-end', icon: 'warning', title: 'Điền SePay Token để dùng Auto Bank!', showConfirmButton: false, timer: 3000 });
                        return;
                    }

                    this.isProcessing = true;
                    try {
                        let fd = new FormData();
                        for (let key in this.formData) fd.append(key, this.formData[key]);

                        const res = await fetch('/api-handler?action=manage_bank', { method: 'POST', body: fd });
                        const data = await res.json();

                        if (data.status === 'success') {
                            Swal.fire({ icon: 'success', title: 'Lưu Thành Công', text: 'Cấu hình ngân hàng đã được cập nhật.', confirmButtonColor: '#10b981' });
                        } else {
                            Swal.fire('Lỗi', data.message, 'error');
                        }
                    } catch (e) {
                        Swal.fire('Lỗi', 'Lỗi kết nối máy chủ.', 'error');
                    } finally {
                        this.isProcessing = false;
                    }
                }
            }));
        });
    </script>
</body>
</html>