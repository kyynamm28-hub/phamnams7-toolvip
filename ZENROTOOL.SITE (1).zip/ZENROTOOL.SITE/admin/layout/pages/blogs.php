<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin
if (!isset($_SESSION['user_id'])) { header("Location: /auth/#login"); exit; }
$stmtUser = $pdo->prepare("SELECT role FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);
if (!$user || strtolower($user['role']) !== 'admin') { header("Location: /home"); exit; }

// Lấy danh sách toàn bộ bài viết
$stmt = $pdo->query("SELECT * FROM blogs ORDER BY position ASC, id DESC");
$blogs = $stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = 'Quản Lý Bài Viết';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <style>
        .shadow-soft { box-shadow: 0 10px 40px -10px rgba(0,0,0,0.03); }
        .fade-up { opacity: 0; transform: translateY(12px); animation: fadeUp 0.5s ease-out forwards; }
        @keyframes fadeUp { to { opacity: 1; transform: translateY(0); } }
        .custom-scroll::-webkit-scrollbar { width: 4px; height: 4px; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
        .dark .custom-scroll::-webkit-scrollbar-thumb { background: #334155; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" :class="{ 'dark': darkMode }" class="bg-[#f4f6f8] dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full fade-up" x-data="blogListManager()">
            
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
                <div>
                    <h1 class="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Quản Lý Blog</h1>
                    <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Danh sách chi tiết các bài viết truyền thông trên hệ thống.</p>
                </div>
                <button @click="openCreateModal = true" class="h-11 px-5 bg-slate-900 hover:bg-black dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 rounded-xl text-[13px] font-bold transition-all shadow-md flex items-center justify-center gap-2 self-start sm:self-auto focus:outline-none">
                    <i class="ri-add-line text-lg"></i> Viết Bài Mới
                </button>
            </div>

            <div class="bg-white dark:bg-[#0f172a] rounded-[24px] border border-slate-200/60 dark:border-slate-800 shadow-soft overflow-hidden">
                <?php if (empty($blogs)): ?>
                    <div class="py-16 text-center text-slate-400">
                        <div class="w-16 h-16 bg-slate-50 dark:bg-slate-800/50 rounded-full flex items-center justify-center mx-auto mb-4"><i class="ri-article-line text-2xl"></i></div>
                        <p class="text-sm font-medium">Chưa có bài viết nào trên hệ thống.</p>
                    </div>
                <?php else: ?>
                    <div class="flex flex-col divide-y divide-slate-100 dark:divide-slate-800/60">
                        <?php foreach ($blogs as $b): ?>
                            <div class="p-5 sm:p-6 flex flex-col sm:flex-row gap-5 items-start sm:items-center hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors group">
                                <div class="w-full sm:w-32 h-40 sm:h-20 rounded-xl overflow-hidden shrink-0 bg-slate-100 dark:bg-slate-800 border border-slate-200/50 dark:border-slate-700/50">
                                    <img src="<?= !empty($b['image']) ? htmlspecialchars($b['image']) : 'https://placehold.co/600x400/e2e8f0/475569?text=Image' ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                                </div>
                                
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-center gap-2 mb-1">
                                        <span class="inline-flex px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-widest <?= $b['status'] == 'active' ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400' : 'bg-slate-100 text-slate-500 dark:bg-slate-800' ?>">
                                            <?= $b['status'] == 'active' ? 'Hiển thị' : 'Đang Ẩn' ?>
                                        </span>
                                        <span class="text-[10px] text-slate-400 font-mono">Top <?= $b['position'] ?></span>
                                    </div>
                                    <h3 class="text-[15px] font-black text-slate-900 dark:text-white leading-snug mb-1 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors line-clamp-1"><?= htmlspecialchars($b['title']) ?></h3>
                                    <p class="text-[12px] text-slate-500 dark:text-slate-400 line-clamp-1 mb-2"><?= htmlspecialchars($b['short_description'] ?: 'Không có mô tả...') ?></p>
                                    
                                    <div class="flex items-center gap-4 text-[11px] font-bold text-slate-400">
                                        <span class="flex items-center gap-1"><i class="ri-eye-line text-blue-500 text-[13px]"></i> <?= number_format($b['views'] ?? 0) ?> views</span>
                                        <span class="flex items-center gap-1"><i class="ri-heart-3-line text-rose-500 text-[13px]"></i> <?= number_format($b['likes'] ?? 0) ?> likes</span>
                                        <span class="flex items-center gap-1"><i class="ri-time-line text-slate-400 text-[13px]"></i> <?= date('d/m/Y', strtotime($b['created_at'])) ?></span>
                                    </div>
                                </div>
                                
                                <div class="w-full sm:w-auto mt-2 sm:mt-0">
                                    <a href="/admin/blogs/<?= htmlspecialchars($b['token']) ?>" class="w-full sm:w-10 sm:h-10 py-2 sm:py-0 rounded-xl sm:rounded-full bg-slate-100 dark:bg-[#1e293b] text-slate-600 dark:text-slate-300 hover:bg-slate-900 hover:text-white dark:hover:bg-white dark:hover:text-slate-900 transition-colors flex items-center justify-center gap-2 focus:outline-none">
                                        <span class="sm:hidden text-xs font-bold">Chỉnh Sửa</span>
                                        <i class="ri-edit-2-line text-[15px]"></i>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div x-show="openCreateModal" x-cloak class="fixed inset-0 z-50 flex items-center justify-center p-4">
                <div class="absolute inset-0 bg-slate-900/40 dark:bg-black/60 backdrop-blur-sm" @click="openCreateModal = false" x-transition.opacity></div>
                <div class="relative bg-white dark:bg-[#0f172a] w-full max-w-3xl rounded-[24px] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 scale-95 translate-y-4" x-transition:enter-end="opacity-100 scale-100 translate-y-0">
                    
                    <div class="px-8 py-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
                        <h3 class="text-lg font-black text-slate-900 dark:text-white uppercase tracking-tight">Tạo Bài Viết Mới</h3>
                        <button @click="openCreateModal = false" class="w-8 h-8 flex items-center justify-center rounded-full bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-rose-500 transition-colors focus:outline-none"><i class="ri-close-line text-xl"></i></button>
                    </div>
                    
                    <div class="p-8 overflow-y-auto space-y-6 custom-scroll">
                        <div class="flex flex-col gap-2">
                            <label class="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Tiêu Đề Bài Viết <span class="text-rose-500">*</span></label>
                            <input type="text" x-model="newBlog.title" placeholder="Nhập tiêu đề..." class="w-full h-12 px-4 bg-slate-50 dark:bg-[#1e293b] border-none rounded-xl text-[13px] font-bold text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-shadow">
                        </div>
                        <div class="flex flex-col gap-2">
                            <label class="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Mô Tả Ngắn <span class="text-rose-500">*</span></label>
                            <textarea x-model="newBlog.short_description" placeholder="Nhập tóm tắt..." rows="2" class="w-full p-4 bg-slate-50 dark:bg-[#1e293b] border-none rounded-xl text-[13px] font-medium text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-shadow resize-none"></textarea>
                        </div>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            <div class="flex flex-col gap-2">
                                <label class="text-[11px] font-bold text-slate-500 uppercase tracking-widest">URL Ảnh bìa</label>
                                <input type="text" x-model="newBlog.image" placeholder="https://..." class="w-full h-12 px-4 bg-slate-50 dark:bg-[#1e293b] border-none rounded-xl text-[13px] font-mono text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-shadow">
                            </div>
                            <div class="grid grid-cols-2 gap-4">
                                <div class="flex flex-col gap-2">
                                    <label class="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Sắp Xếp</label>
                                    <input type="number" x-model.number="newBlog.position" class="w-full h-12 px-4 bg-slate-50 dark:bg-[#1e293b] border-none rounded-xl text-[13px] font-bold text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-shadow text-center">
                                </div>
                                <div class="flex flex-col gap-2">
                                    <label class="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Trạng Thái</label>
                                    <select x-model="newBlog.status" class="w-full h-12 px-3 bg-slate-50 dark:bg-[#1e293b] border-none rounded-xl text-[13px] font-bold text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-shadow cursor-pointer appearance-none">
                                        <option value="active">Bật (Hiện)</option>
                                        <option value="hidden">Tắt (Ẩn)</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="flex flex-col gap-2">
                            <div class="flex justify-between items-end">
                                <label class="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Nội Dung Chi Tiết <span class="text-rose-500">*</span></label>
                                <span class="text-[10px] font-bold text-blue-500 bg-blue-50 dark:bg-blue-500/10 px-2 py-1 rounded lowercase font-mono">&lt;html&gt;</span>
                            </div>
                            <textarea x-model="newBlog.content" placeholder="Nhập mã HTML..." rows="8" class="w-full p-4 bg-slate-50 dark:bg-[#1e293b] border-none rounded-xl text-[13px] font-mono text-slate-800 dark:text-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-shadow custom-scroll leading-relaxed"></textarea>
                        </div>
                    </div>
                    
                    <div class="px-8 py-5 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-3 bg-slate-50/50 dark:bg-[#0b1120]/50">
                        <button @click="openCreateModal = false" class="h-11 px-6 bg-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 rounded-xl text-[13px] font-bold transition-colors focus:outline-none">Hủy bỏ</button>
                        <button @click="createBlog()" :disabled="isSaving" class="h-11 px-8 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-[13px] font-bold transition-all shadow-md shadow-blue-500/20 flex items-center gap-2 focus:outline-none disabled:opacity-70">
                            <i x-show="isSaving" class="ri-loader-4-line animate-spin text-[16px]"></i>
                            <span x-text="isSaving ? 'Đang lưu...' : 'Xuất Bản Blog'"></span>
                        </button>
                    </div>
                </div>
            </div>

        </main>
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('blogListManager', () => ({
                openCreateModal: false,
                isSaving: false,
                newBlog: { title: '', short_description: '', image: '', content: '', status: 'active', position: 0 },

                async createBlog() {
                    if(!this.newBlog.title || !this.newBlog.content || !this.newBlog.short_description) {
                        Swal.fire({toast: true, position: 'top-end', icon: 'error', title: 'Điền thông tin bắt buộc (*)', showConfirmButton: false, timer: 3000});
                        return;
                    }
                    this.isSaving = true;
                    try {
                        const response = await fetch('/api-handler?action=create_blog', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(this.newBlog)
                        });
                        const data = await response.json();
                        if(data.status === 'success') {
                            Swal.fire({icon: 'success', title: 'Thành công', text: data.message, confirmButtonColor: '#2563eb', background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#ffffff', color: document.documentElement.classList.contains('dark') ? '#ffffff' : '#0f172a'})
                            .then(() => window.location.reload());
                        } else { Swal.fire('Lỗi', data.message, 'error'); }
                    } catch(e) { Swal.fire('Lỗi', 'Không thể kết nối máy chủ.', 'error'); } 
                    finally { this.isSaving = false; }
                }
            }));
        });
    </script>
</body>
</html>
