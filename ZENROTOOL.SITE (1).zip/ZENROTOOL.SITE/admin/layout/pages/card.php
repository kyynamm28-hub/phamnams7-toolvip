<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin
if (!isset($_SESSION['user_id'])) {
    header("Location: /auth/#login");
    exit;
}

$stmtUser = $pdo->prepare("SELECT role FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);

if (!$user || strtolower($user['role']) !== 'admin') {
    header("Location: /home");
    exit;
}

// Lấy dữ liệu cấu hình thẻ cào
$stmtCard = $pdo->query("SELECT * FROM setting_card LIMIT 1");
$cardConfig = $stmtCard->fetch(PDO::FETCH_ASSOC);

// Nếu chưa có dữ liệu trong DB, tạo dữ liệu mặc định
if (!$cardConfig) {
    $defaultDiscounts = json_encode([
        'VIETTEL' => ['10000'=>20, '20000'=>20, '50000'=>20, '100000'=>20, '200000'=>20, '500000'=>20],
        'VINAPHONE' => ['10000'=>20, '20000'=>20, '50000'=>20, '100000'=>20, '200000'=>20, '500000'=>20],
        'MOBIFONE' => ['10000'=>20, '20000'=>20, '50000'=>20, '100000'=>20, '200000'=>20, '500000'=>20],
        'GARENA' => ['20000'=>25, '50000'=>25, '100000'=>25, '200000'=>25, '500000'=>25]
    ]);
    $cardConfig = [
        'partner_id' => '',
        'partner_key' => '',
        'status' => 'active',
        'discounts' => $defaultDiscounts
    ];
}

$page_title = 'Cấu Hình Nạp Thẻ';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../../../admin/layout/include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); }
        .fade-up { opacity: 0; transform: translateY(15px); animation: fadeUp 0.5s ease-out forwards; }
        .delay-100 { animation-delay: 100ms; }
        .delay-200 { animation-delay: 200ms; }
        @keyframes fadeUp { to { opacity: 1; transform: translateY(0); } }
        /* Tùy chỉnh thanh cuộn cho bảng */
        .custom-scroll::-webkit-scrollbar { height: 6px; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
        .dark .custom-scroll::-webkit-scrollbar-thumb { background: #475569; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" :class="{ 'dark': darkMode }" class="bg-[#f4f6f8] dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-300 relative overflow-x-hidden">
    
    <?php include __DIR__ . '/../../../admin/layout/include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        
        <?php include __DIR__ . '/../../../admin/layout/include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full" x-data="cardAdminManager()">
            
            <div class="mb-6 fade-up">
                <h1 class="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Cấu Hình Nạp Thẻ Cào</h1>
                <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Quản lý kết nối API GachTheFast và thiết lập chiết khấu cho từng nhà mạng.</p>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8">
                
                <div class="lg:col-span-4 flex flex-col gap-6 fade-up delay-100">
                    <div class="bg-white dark:bg-[#0f172a] rounded-2xl border border-slate-200 dark:border-slate-800 shadow-soft overflow-hidden">
                        <div class="px-6 pt-6 pb-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-[#1e293b]/30">
                            <h3 class="text-[15px] font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                <i class="ri-settings-4-fill text-blue-500"></i> Kết Nối Đối Tác
                            </h3>
                        </div>
                        <div class="p-6 space-y-5">
                            
                            <div>
                                <label class="block text-[12px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-2">Partner ID</label>
                                <input type="text" x-model="config.partner_id" placeholder="Nhập Partner ID..." class="w-full h-11 px-4 bg-slate-50 dark:bg-[#1e293b] border border-slate-200 dark:border-slate-700 rounded-xl text-[13px] font-mono text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 transition-colors">
                            </div>

                            <div>
                                <label class="block text-[12px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-2">Partner Key</label>
                                <div class="relative" x-data="{ showKey: false }">
                                    <input :type="showKey ? 'text' : 'password'" x-model="config.partner_key" placeholder="Nhập Partner Key..." class="w-full h-11 px-4 pr-10 bg-slate-50 dark:bg-[#1e293b] border border-slate-200 dark:border-slate-700 rounded-xl text-[13px] font-mono text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 transition-colors">
                                    <button @click="showKey = !showKey" class="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-blue-500 transition-colors">
                                        <i :class="showKey ? 'ri-eye-line' : 'ri-eye-off-line'"></i>
                                    </button>
                                </div>
                            </div>

                            <div>
                                <label class="block text-[12px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-2">Trạng thái Nạp Thẻ</label>
                                <select x-model="config.status" class="w-full h-11 px-4 bg-slate-50 dark:bg-[#1e293b] border border-slate-200 dark:border-slate-700 rounded-xl text-[13px] font-bold text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer">
                                    <option value="active">Hoạt động (Cho phép nạp)</option>
                                    <option value="maintenance">Bảo trì (Tạm khóa)</option>
                                </select>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="lg:col-span-8 flex flex-col gap-6 fade-up delay-200">
                    <div class="bg-white dark:bg-[#0f172a] rounded-2xl shadow-soft border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full">
                        
                        <div class="px-6 pt-6 pb-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-[#1e293b]/30">
                            <h3 class="text-[15px] font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                <i class="ri-percent-line text-emerald-500"></i> Bảng Chiết Khấu (%)
                            </h3>
                            <button @click="saveConfig()" :disabled="isSaving" class="h-9 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition-all shadow-md hover:shadow-blue-500/30 flex items-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed">
                                <i x-show="!isSaving" class="ri-save-3-fill"></i>
                                <i x-show="isSaving" class="ri-loader-4-line animate-spin"></i>
                                <span x-text="isSaving ? 'Đang lưu...' : 'Lưu Thay Đổi'"></span>
                            </button>
                        </div>

                        <div class="p-6 overflow-x-auto custom-scroll flex-1">
                            <table class="w-full text-left text-[13px] whitespace-nowrap">
                                <thead>
                                    <tr class="text-[11px] uppercase tracking-widest text-slate-400 border-b border-slate-200 dark:border-slate-700">
                                        <th class="pb-3 font-bold">Mệnh giá</th>
                                        <th class="pb-3 font-bold text-center text-blue-500">Viettel</th>
                                        <th class="pb-3 font-bold text-center text-sky-500">Vinaphone</th>
                                        <th class="pb-3 font-bold text-center text-red-500">Mobifone</th>
                                        <th class="pb-3 font-bold text-center text-rose-500">Garena</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-slate-100 dark:divide-slate-800/60">
                                    <template x-for="amt in amounts" :key="amt">
                                        <tr class="hover:bg-slate-50 dark:hover:bg-[#1e293b]/30 transition-colors group">
                                            <td class="py-3 font-black text-slate-800 dark:text-slate-200" x-text="new Intl.NumberFormat('vi-VN').format(amt) + 'đ'"></td>
                                            
                                            <template x-for="net in networks" :key="net">
                                                <td class="py-3 px-2 text-center">
                                                    <template x-if="config.discounts[net][amt] !== undefined">
                                                        <div class="relative inline-block w-20">
                                                            <input type="number" step="0.1" min="0" max="100" 
                                                                   x-model.number="config.discounts[net][amt]" 
                                                                   class="w-full h-9 px-2 pr-6 text-center bg-transparent border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-white font-mono focus:bg-white dark:focus:bg-[#0f172a] focus:border-blue-500 focus:outline-none transition-colors group-hover:border-slate-300 dark:group-hover:border-slate-600">
                                                            <span class="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 text-[10px] pointer-events-none">%</span>
                                                        </div>
                                                    </template>
                                                    <template x-if="config.discounts[net][amt] === undefined">
                                                        <span class="text-slate-300 dark:text-slate-600">-</span>
                                                    </template>
                                                </td>
                                            </template>
                                            
                                        </tr>
                                    </template>
                                </tbody>
                            </table>
                            <p class="mt-4 text-[11px] text-slate-500 flex items-center gap-1.5"><i class="ri-information-fill text-blue-500"></i> Chiết khấu là phần trăm phí dịch vụ bị trừ đi. Khách hàng thực nhận = Mệnh giá - (Mệnh giá * Chiết khấu / 100).</p>
                        </div>

                    </div>
                </div>

            </div>
        </main>
        
        <?php include __DIR__ . '/../../../admin/layout/include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('cardAdminManager', () => ({
                isSaving: false,
                networks: ['VIETTEL', 'VINAPHONE', 'MOBIFONE', 'GARENA'],
                amounts: [10000, 20000, 50000, 100000, 200000, 500000],
                
                // Dữ liệu ban đầu lấy từ PHP
                config: {
                    partner_id: '<?= htmlspecialchars($cardConfig['partner_id']) ?>',
                    partner_key: '<?= htmlspecialchars($cardConfig['partner_key']) ?>',
                    status: '<?= htmlspecialchars($cardConfig['status']) ?>',
                    discounts: <?= $cardConfig['discounts'] ?>
                },

                async saveConfig() {
                    this.isSaving = true;
                    try {
                        const response = await fetch('/api-handler?action=manage_card', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(this.config)
                        });
                        
                        const result = await response.json();
                        
                        if (result.status === 'success') {
                            Swal.fire({
                                toast: true, position: 'top-end', icon: 'success', 
                                title: 'Đã lưu cấu hình thẻ cào!', 
                                showConfirmButton: false, timer: 2000,
                                background: document.documentElement.classList.contains('dark') ? '#1e293b' : '#fff',
                                color: document.documentElement.classList.contains('dark') ? '#fff' : '#000'
                            });
                        } else {
                            Swal.fire('Lỗi', result.message, 'error');
                        }
                    } catch (error) {
                        Swal.fire('Lỗi kết nối', 'Không thể lưu dữ liệu.', 'error');
                    } finally {
                        this.isSaving = false;
                    }
                }
            }));
        });
    </script>
</body>
</html>
