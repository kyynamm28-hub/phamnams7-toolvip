<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

if (!isset($_SESSION['user_id'])) { header("Location: /auth/#login"); exit; }
$stmtUser = $pdo->prepare("SELECT role FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);
if (!$user || strtolower($user['role']) !== 'admin') { header("Location: /home"); exit; }

$page_title = 'Quản Lý Danh Mục';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); }
        .fade-in { animation: fadeIn 0.4s ease-out forwards; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        
        .input-base {
            width: 100%; height: 44px; padding: 0 16px; 
            background-color: #f5f5f5; border: 1px solid #e5e5e5; border-radius: 12px;
            font-size: 13px; font-weight: 500; color: #171717; outline: none; transition: all 0.2s ease;
        }
        .dark .input-base { background-color: #1e293b; border-color: #334155; color: #ffffff; }
        .input-base:focus { border-color: #3b82f6; box-shadow: 0 0 0 3px rgba(59,130,246,0.15); }
        .label-base { display: block; font-size: 11px; font-weight: 700; color: #737373; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 8px; }
        .dark .label-base { color: #9ca3af; }
        
        .custom-scrollbar::-webkit-scrollbar { width: 5px; height: 5px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #d4d4d8; border-radius: 10px; }
        .dark .custom-scrollbar::-webkit-scrollbar-thumb { background: #4b5563; }
        [x-cloak] { display: none !important; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-neutral-50 dark:bg-[#0b1120] text-neutral-800 dark:text-gray-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 w-full max-w-6xl mx-auto fade-in" x-data="categoryManager()">
            
            <div class="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                    <h1 class="text-2xl sm:text-3xl font-black text-neutral-900 dark:text-white uppercase tracking-tight">Danh Mục Công Cụ</h1>
                    <p class="text-[13px] text-neutral-500 dark:text-gray-400 mt-1">Sắp xếp, phân loại hệ sinh thái các trò chơi và tiện ích.</p>
                </div>
                <button @click="openModal()" class="h-11 px-5 bg-neutral-900 hover:bg-black dark:bg-white dark:text-neutral-900 dark:hover:bg-gray-100 text-white rounded-[14px] text-[13px] font-black uppercase tracking-widest transition-all shadow-md flex items-center justify-center gap-2 focus:outline-none">
                    <i class="ri-add-line text-lg"></i> Thêm Danh Mục
                </button>
            </div>

            <div class="bg-white dark:bg-[#0f172a] rounded-[24px] shadow-soft border border-neutral-200/60 dark:border-gray-800 overflow-hidden">
                <div class="overflow-x-auto custom-scrollbar">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-neutral-50 dark:bg-[#1e293b]/50 border-b border-neutral-200/60 dark:border-gray-800">
                                <th class="py-4 px-6 text-[10px] font-black text-neutral-500 dark:text-gray-400 uppercase tracking-widest">Icon / Tên</th>
                                <th class="py-4 px-6 text-[10px] font-black text-neutral-500 dark:text-gray-400 uppercase tracking-widest">Đường dẫn (Slug)</th>
                                <th class="py-4 px-6 text-[10px] font-black text-neutral-500 dark:text-gray-400 uppercase tracking-widest text-center">Vị trí</th>
                                <th class="py-4 px-6 text-[10px] font-black text-neutral-500 dark:text-gray-400 uppercase tracking-widest text-center">Trạng thái</th>
                                <th class="py-4 px-6 text-[10px] font-black text-neutral-500 dark:text-gray-400 uppercase tracking-widest text-right">Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <template x-for="cat in categories" :key="cat.id">
                                <tr class="border-b border-neutral-100 dark:border-gray-800/60 hover:bg-neutral-50/50 dark:hover:bg-white/[0.02] transition-colors">
                                    <td class="py-4 px-6">
                                        <div class="flex items-center gap-3">
                                            <div class="w-10 h-10 rounded-xl bg-neutral-100 dark:bg-gray-800 flex items-center justify-center shrink-0 border border-neutral-200/60 dark:border-gray-700">
                                                <img :src="cat.icon" class="w-5 h-5 object-contain brightness-0 dark:invert">
                                            </div>
                                            <span class="text-[14px] font-bold text-neutral-800 dark:text-white" x-text="cat.name"></span>
                                        </div>
                                    </td>
                                    <td class="py-4 px-6">
                                        <span class="inline-flex px-2 py-1 bg-neutral-100 dark:bg-gray-800 text-neutral-600 dark:text-gray-400 rounded text-[11px] font-mono border border-neutral-200 dark:border-gray-700" x-text="cat.slug"></span>
                                    </td>
                                    <td class="py-4 px-6 text-center">
                                        <span class="text-[13px] font-bold text-neutral-600 dark:text-gray-400" x-text="cat.position"></span>
                                    </td>
                                    <td class="py-4 px-6 text-center">
                                        <span x-show="cat.status === 'active'" class="inline-flex items-center px-2 py-1 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/30 rounded text-[10px] font-black uppercase tracking-widest">Hoạt động</span>
                                        <span x-show="cat.status !== 'active'" class="inline-flex items-center px-2 py-1 bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800/30 rounded text-[10px] font-black uppercase tracking-widest">Đang tắt</span>
                                    </td>
                                    <td class="py-4 px-6 text-right">
                                        <button @click="openModal(cat)" class="w-8 h-8 inline-flex items-center justify-center rounded-lg bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 hover:bg-blue-500 hover:text-white dark:hover:bg-blue-500 transition-colors focus:outline-none">
                                            <i class="ri-edit-2-line"></i>
                                        </button>
                                        <button @click="deleteCategory(cat.id)" class="w-8 h-8 inline-flex items-center justify-center rounded-lg bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 hover:bg-rose-500 hover:text-white dark:hover:bg-rose-500 transition-colors focus:outline-none ml-1">
                                            <i class="ri-delete-bin-line"></i>
                                        </button>
                                    </td>
                                </tr>
                            </template>
                            <tr x-show="categories.length === 0" x-cloak>
                                <td colspan="5" class="py-12 text-center text-neutral-500 dark:text-gray-400 text-sm font-medium">Chưa có danh mục nào.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div x-show="isModalOpen" x-cloak class="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-0">
                <div class="absolute inset-0 bg-neutral-900/60 dark:bg-black/60 backdrop-blur-sm" @click="closeModal()"></div>
                
                <div class="relative bg-white dark:bg-[#0f172a] w-full max-w-2xl rounded-[28px] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
                     x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 scale-95" x-transition:enter-end="opacity-100 scale-100">
                    
                    <div class="px-6 py-5 border-b border-neutral-100 dark:border-gray-800 flex items-center justify-between bg-neutral-50/50 dark:bg-transparent shrink-0">
                        <h3 class="text-lg font-black text-neutral-900 dark:text-white uppercase tracking-tight" x-text="form.id ? 'Sửa Danh Mục' : 'Thêm Danh Mục Mới'"></h3>
                        <button @click="closeModal()" class="w-8 h-8 flex items-center justify-center rounded-full bg-neutral-200/50 dark:bg-gray-800 text-neutral-500 hover:text-neutral-900 dark:hover:text-white transition-colors focus:outline-none">
                            <i class="ri-close-line text-lg"></i>
                        </button>
                    </div>

                    <div class="p-6 overflow-y-auto custom-scrollbar flex-1">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                            <div>
                                <label class="label-base">Tên danh mục <span class="text-rose-500">*</span></label>
                                <input type="text" x-model="form.name" @input="if(!form.id) form.slug = stringToSlug(form.name)" placeholder="VD: Tài Xỉu" class="input-base">
                            </div>
                            <div>
                                <label class="label-base">Đường dẫn (Slug) <span class="text-rose-500">*</span></label>
                                <input type="text" x-model="form.slug" placeholder="VD: taixiu" class="input-base font-mono">
                            </div>
                            <div>
                                <label class="label-base">Liên kết Icon (URL)</label>
                                <div class="flex items-center gap-3">
                                    <div class="w-11 h-11 rounded-xl bg-neutral-50 dark:bg-gray-800 border border-neutral-200 dark:border-gray-700 flex items-center justify-center shrink-0 p-2">
                                        <img :src="form.icon || 'https://cdn-icons-png.flaticon.com/512/8144/8144288.png'" class="w-full h-full object-contain brightness-0 dark:invert opacity-70">
                                    </div>
                                    <input type="text" x-model="form.icon" placeholder="https://..." class="input-base font-mono">
                                </div>
                            </div>
                            <div class="grid grid-cols-2 gap-4">
                                <div>
                                    <label class="label-base">Vị trí</label>
                                    <input type="number" x-model="form.position" class="input-base text-center">
                                </div>
                                <div>
                                    <label class="label-base">Trạng thái</label>
                                    <select x-model="form.status" class="input-base cursor-pointer">
                                        <option value="active">Hoạt động</option>
                                        <option value="inactive">Tạm tắt</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="pt-6 border-t border-neutral-100 dark:border-gray-800">
                            <label class="label-base flex items-center justify-between mb-3">
                                <span>Phân Bổ Công Cụ / Game</span>
                                <span class="text-[9px] font-bold text-blue-600 bg-blue-50 dark:bg-blue-900/30 px-2 py-0.5 rounded uppercase font-mono tracking-wider">Tùy chọn</span>
                            </label>
                            <p class="text-xs text-neutral-500 dark:text-gray-400 mb-4">Chọn các công cụ sẽ hiển thị trong danh mục này (Đánh dấu check).</p>
                            
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[200px] overflow-y-auto custom-scrollbar pr-2">
                                <template x-for="game in games" :key="game.id">
                                    <label class="flex items-center p-3 border border-neutral-200 dark:border-gray-700 rounded-xl cursor-pointer hover:bg-neutral-50 dark:hover:bg-gray-800 transition-colors">
                                        <input type="checkbox" :value="game.slug" x-model="form.selected_games" class="w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600">
                                        <div class="ml-3 flex items-center gap-2">
                                            <div class="w-6 h-6 rounded bg-neutral-100 dark:bg-gray-900 overflow-hidden shrink-0">
                                                <img :src="game.image || 'https://placehold.co/100'" class="w-full h-full object-cover">
                                            </div>
                                            <span class="text-[13px] font-bold text-neutral-800 dark:text-gray-200 truncate" x-text="game.name"></span>
                                        </div>
                                    </label>
                                </template>
                            </div>
                        </div>
                    </div>

                    <div class="px-6 py-4 border-t border-neutral-100 dark:border-gray-800 bg-neutral-50/50 dark:bg-transparent flex justify-end gap-3 shrink-0">
                        <button @click="closeModal()" class="h-10 px-5 bg-white dark:bg-gray-800 border border-neutral-200 dark:border-gray-700 text-neutral-600 dark:text-gray-300 rounded-xl text-[12px] font-bold uppercase tracking-widest hover:bg-neutral-50 dark:hover:bg-gray-700 transition-colors focus:outline-none">
                            Hủy
                        </button>
                        <button @click="saveCategory()" :disabled="isLoading" class="h-10 px-8 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-[12px] font-black uppercase tracking-widest transition-all shadow-md shadow-blue-500/20 flex items-center gap-2 focus:outline-none disabled:opacity-70 disabled:cursor-not-allowed">
                            <i x-show="!isLoading" class="ri-save-3-line text-[15px]"></i>
                            <i x-show="isLoading" class="ri-loader-4-line animate-spin text-[15px]"></i>
                            <span x-text="isLoading ? 'Đang lưu...' : 'Lưu Danh Mục'"></span>
                        </button>
                    </div>
                </div>
            </div>
        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('categoryManager', () => ({
                categories: [],
                games: [],
                isModalOpen: false,
                isLoading: false,
                form: {
                    id: '', name: '', slug: '', icon: '', position: 0, status: 'active', selected_games: []
                },

                init() {
                    this.fetchData();
                },

                fetchData() {
                    fetch('/api-handler?action=get_categories')
                        .then(r => r.json())
                        .then(res => {
                            this.categories = res.categories || [];
                            this.games = res.games || [];
                        });
                },

                openModal(cat = null) {
                    if (cat) {
                        this.form = { ...cat };
                        this.form.selected_games = this.games.filter(g => g.category && g.category.toLowerCase() === cat.slug.toLowerCase()).map(g => g.slug);
                    } else {
                        this.form = { id: '', name: '', slug: '', icon: 'https://cdn-icons-png.flaticon.com/512/8144/8144288.png', position: this.categories.length, status: 'active', selected_games: [] };
                    }
                    this.isModalOpen = true;
                },

                closeModal() {
                    this.isModalOpen = false;
                },

                stringToSlug(str) {
                    return str.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w\s-]/g, '').replace(/[\s_-]+/g, '-').replace(/^-+|-+$/g, '');
                },

                async saveCategory() {
                    if (!this.form.name || !this.form.slug) {
                        Swal.fire('Lỗi', 'Vui lòng nhập Tên và Slug.', 'error'); return;
                    }
                    this.isLoading = true;
                    try {
                        const res = await fetch('/api-handler?action=save_category', {
                            method: 'POST', headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(this.form)
                        });
                        const data = await res.json();
                        if (data.status === 'success') {
                            this.fetchData();
                            this.closeModal();
                            Swal.fire({ icon: 'success', title: 'Thành công', text: data.message, showConfirmButton: false, timer: 1500, background: document.documentElement.classList.contains('dark') ? '#1e293b' : '#fff', color: document.documentElement.classList.contains('dark') ? '#fff' : '#000' });
                        } else {
                            Swal.fire('Lỗi', data.message, 'error');
                        }
                    } catch (e) {
                        Swal.fire('Lỗi', 'Mất kết nối máy chủ.', 'error');
                    } finally {
                        this.isLoading = false;
                    }
                },

                deleteCategory(id) {
                    Swal.fire({
                        title: 'Xóa danh mục?',
                        text: "Hành động này không thể hoàn tác!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#ef4444',
                        cancelButtonColor: '#e5e5e5',
                        confirmButtonText: 'Xóa ngay',
                        cancelButtonText: '<span style="color:#171717">Hủy</span>',
                        background: document.documentElement.classList.contains('dark') ? '#1e293b' : '#fff',
                        color: document.documentElement.classList.contains('dark') ? '#fff' : '#000'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            fetch('/api-handler?action=delete_category', {
                                method: 'POST', headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ id: id })
                            })
                            .then(r => r.json())
                            .then(res => {
                                if (res.status === 'success') {
                                    this.fetchData();
                                } else {
                                    Swal.fire('Lỗi', res.message, 'error');
                                }
                            });
                        }
                    });
                }
            }));
        });
    </script>
</body>
</html>
