<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin
if (!isset($_SESSION['user_id'])) { header("Location: /auth/#login"); exit; }
$stmtUser = $pdo->prepare("SELECT role FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);
if (!$user || strtolower($user['role']) !== 'admin') { header("Location: /home"); exit; }

// Lấy danh sách game
$stmt = $pdo->query("SELECT * FROM games ORDER BY position ASC, id DESC");
$games = $stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = 'Quản Lý Game & Tools';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); }
        .fade-in { animation: fadeIn 0.4s ease-out forwards; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .custom-scroll::-webkit-scrollbar { width: 5px; height: 5px; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #d4d4d8; border-radius: 10px; }
        .dark .custom-scroll::-webkit-scrollbar-thumb { background: #4b5563; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-neutral-50 dark:bg-gray-900 text-neutral-800 dark:text-gray-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 w-full max-w-6xl mx-auto fade-in" x-data="gameListManager()">
            
            <div class="rounded-2xl border border-neutral-200 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-soft overflow-hidden">
                
                <div class="px-6 py-5 border-b border-neutral-100 dark:border-gray-700 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-slate-700 to-slate-800 flex items-center justify-center shadow-inner shrink-0">
                            <i class="ri-gamepad-line text-white text-lg"></i>
                        </div>
                        <div>
                            <div class="text-lg font-bold text-neutral-800 dark:text-white uppercase tracking-wide">Hệ Sinh Thái Game</div>
                            <div class="text-xs text-neutral-500 dark:text-gray-400 font-medium mt-0.5">Quản lý Iframe, API và Tool dự đoán soi cầu.</div>
                        </div>
                    </div>
                    <div class="flex items-center justify-end shrink-0">
                        <a href="/admin/games/add" class="h-9 px-5 bg-neutral-800 hover:bg-neutral-900 dark:bg-white dark:text-neutral-900 dark:hover:bg-gray-100 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 shadow-sm focus:outline-none">
                            <i class="ri-add-line text-[15px]"></i> Thêm Game Mới
                        </a>
                    </div>
                </div>

                <div class="bg-neutral-50/30 dark:bg-transparent">
                    <?php if (empty($games)): ?>
                        <div class="flex flex-col items-center justify-center py-16">
                            <div class="w-16 h-16 rounded-full bg-neutral-100 dark:bg-gray-700 flex items-center justify-center mb-4">
                                <i class="ri-gamepad-line text-2xl text-neutral-400"></i>
                            </div>
                            <div class="text-neutral-800 dark:text-white font-bold text-lg">Chưa Có Dữ Liệu</div>
                            <div class="text-neutral-500 text-sm mt-1 text-center">Hệ thống chưa có Game/Tool nào được cấu hình.</div>
                        </div>
                    <?php else: ?>
                        <div class="flex flex-col divide-y divide-neutral-100 dark:divide-gray-700/60">
                            <?php foreach ($games as $g): ?>
                                <div class="p-5 sm:p-6 flex flex-col sm:flex-row gap-5 items-start sm:items-center hover:bg-neutral-50 dark:hover:bg-gray-700/30 transition-colors group">
                                    
                                    <div class="w-full sm:w-28 h-36 sm:h-20 rounded-xl overflow-hidden shrink-0 bg-neutral-100 dark:bg-gray-800 border border-neutral-200/50 dark:border-gray-600/50 relative">
                                        <img src="<?= !empty($g['image']) ? htmlspecialchars($g['image']) : 'https://placehold.co/600x400/e5e5e5/737373?text=Game' ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                                    </div>
                                    
                                    <div class="flex-1 min-w-0">
                                        <div class="flex items-center gap-2 mb-1.5">
                                            <span class="inline-flex px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-widest <?= $g['status'] == 'active' ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400' : 'bg-neutral-100 text-neutral-500 dark:bg-gray-800 dark:text-gray-400' ?>">
                                                <?= $g['status'] == 'active' ? 'Hoạt động' : 'Đang Ẩn' ?>
                                            </span>
                                            <span class="text-[9px] font-bold uppercase tracking-widest text-blue-600 bg-blue-50 dark:bg-blue-500/10 dark:text-blue-400 px-2 py-0.5 rounded"><?= htmlspecialchars($g['category']) ?></span>
                                            <?php if($g['badge']): ?>
                                                <span class="text-[9px] font-bold uppercase tracking-widest text-rose-600 bg-rose-50 dark:bg-rose-500/10 dark:text-rose-400 px-2 py-0.5 rounded"><?= htmlspecialchars($g['badge']) ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <h3 class="text-base font-bold text-neutral-900 dark:text-white leading-tight mb-1 truncate"><?= htmlspecialchars($g['name']) ?></h3>
                                        <div class="text-[11px] font-medium text-neutral-500 dark:text-gray-400 flex items-center gap-3">
                                            <span>Slug: /<?= htmlspecialchars($g['slug']) ?></span>
                                            <span>•</span>
                                            <span>Vị trí: <?= $g['position'] ?></span>
                                        </div>
                                    </div>
                                    
                                    <div class="w-full sm:w-auto mt-3 sm:mt-0 flex gap-2 shrink-0">
                                        <a href="/admin/games/edit/<?= htmlspecialchars($g['slug']) ?>" class="flex-1 sm:flex-none h-9 px-4 rounded-lg border border-neutral-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-neutral-700 dark:text-gray-200 hover:bg-neutral-50 dark:hover:bg-gray-600 transition-colors flex items-center justify-center gap-1.5 text-xs font-bold focus:outline-none">
                                            <i class="ri-edit-2-line text-[14px]"></i> Sửa
                                        </a>
                                        <button @click="deleteGame(<?= $g['id'] ?>)" class="flex-1 sm:flex-none h-9 w-9 sm:px-0 rounded-lg bg-rose-50 dark:bg-rose-500/10 text-rose-500 hover:bg-rose-500 hover:text-white transition-colors flex items-center justify-center focus:outline-none">
                                            <i class="ri-delete-bin-line text-[15px]"></i>
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

            </div>
        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('gameListManager', () => ({
                async deleteGame(id) {
                    const cf = await Swal.fire({
                        title: 'Xóa công cụ này?',
                        text: "Hành động này không thể hoàn tác!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#171717',
                        cancelButtonColor: '#e5e5e5',
                        cancelButtonText: '<span style="color:#171717">Hủy bỏ</span>',
                        confirmButtonText: 'Đồng ý xóa',
                        customClass: { popup: document.documentElement.classList.contains('dark') ? 'bg-gray-800 text-white' : '' }
                    });
                    if(cf.isConfirmed) {
                        try {
                            const res = await fetch('/api-handler?action=delete_game', { method: 'POST', body: JSON.stringify({id: id}) });
                            const data = await res.json();
                            if(data.status==='success') window.location.reload();
                            else Swal.fire('Lỗi', data.message, 'error');
                        } catch(e) { Swal.fire('Lỗi', 'Không thể xóa.', 'error'); }
                    }
                }
            }));
        });
    </script>
</body>
</html>
