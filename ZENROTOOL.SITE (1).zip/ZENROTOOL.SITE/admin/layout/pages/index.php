<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin
if (!isset($_SESSION['user_id'])) { header("Location: /auth/#login"); exit; }
$stmtCheck = $pdo->prepare("SELECT role FROM users WHERE id = ?");
$stmtCheck->execute([$_SESSION['user_id']]);
if (strtolower($stmtCheck->fetchColumn()) !== 'admin') { header("Location: /home"); exit; }

// ==========================================
// 1. THỐNG KÊ TỔNG QUAN HÔM NAY
// ==========================================
try {
    $total_users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $new_users = $pdo->query("SELECT COUNT(*) FROM users WHERE DATE(created_at) = CURDATE()")->fetchColumn();
    $rev_today = $pdo->query("SELECT SUM(amount) FROM transfer_history WHERE status IN ('paid', 'success') AND DATE(created_at) = CURDATE()")->fetchColumn() ?: 0;
    $rev_total = $pdo->query("SELECT SUM(amount) FROM transfer_history WHERE status IN ('paid', 'success')")->fetchColumn() ?: 0;
} catch (Exception $e) {
    $total_users = $new_users = $rev_today = $rev_total = 0;
}

// ==========================================
// 2. DỮ LIỆU BIỂU ĐỒ 7 NGÀY (GỌN GÀNG)
// ==========================================
$chart_dates = [];
$chart_revenue = [];
$chart_users = [];

try {
    for ($i = 6; $i >= 0; $i--) {
        $date = date('Y-m-d', strtotime("-$i days"));
        $chart_dates[] = date('d/m', strtotime("-$i days"));
        
        $stmtRev = $pdo->prepare("SELECT SUM(amount) FROM transfer_history WHERE DATE(created_at) = ? AND status IN ('paid', 'success')");
        $stmtRev->execute([$date]);
        $chart_revenue[] = (int)$stmtRev->fetchColumn();
        
        $stmtUsr = $pdo->prepare("SELECT COUNT(*) FROM users WHERE DATE(created_at) = ?");
        $stmtUsr->execute([$date]);
        $chart_users[] = (int)$stmtUsr->fetchColumn();
    }
} catch (Exception $e) {
    $chart_dates = ['-6d', '-5d', '-4d', '-3d', '-2d', '-1d', 'Hôm nay'];
    $chart_revenue = $chart_users = [0, 0, 0, 0, 0, 0, 0];
}

// ==========================================
// 3. GIAO DỊCH THÀNH CÔNG MỚI NHẤT
// ==========================================
try {
    $stmtRecent = $pdo->query("
        SELECT t.*, u.username, u.display_name 
        FROM transfer_history t 
        LEFT JOIN users u ON t.user_id = u.id 
        WHERE t.status IN ('paid', 'success') 
        ORDER BY t.paid_at DESC, t.id DESC 
        LIMIT 6
    ");
    $recent_transactions = $stmtRecent->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $recent_transactions = [];
}

$pageTitle = 'Dashboard';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.02); }
        .fade-in-up { animation: fadeInUp 0.5s ease-out forwards; }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        /* Toggle Switch Style */
        .toggle-btn { transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
        .toggle-active { background-color: #ffffff; color: #171717; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        .dark .toggle-active { background-color: #374151; color: #ffffff; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-[#f8fafc] dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 w-full max-w-[1400px] mx-auto fade-in-up">
            
            <div class="mb-6">
                <h1 class="text-xl sm:text-2xl font-black uppercase tracking-tight text-slate-900 dark:text-white">Tổng Quan</h1>
                <p class="text-xs text-slate-500 mt-1">Cập nhật nhanh tình hình hệ thống hôm nay.</p>
            </div>

            <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                
                <div class="bg-white dark:bg-gray-800/80 rounded-2xl p-4 sm:p-5 border border-slate-100 dark:border-gray-700/50 shadow-soft flex items-center justify-between group cursor-pointer hover:border-emerald-200 dark:hover:border-emerald-800/50 transition-colors">
                    <div>
                        <div class="text-[10px] font-bold text-slate-400 dark:text-gray-500 uppercase tracking-widest mb-1">Doanh Thu Nay</div>
                        <div class="text-xl sm:text-2xl font-black text-slate-800 dark:text-white tracking-tight"><?= number_format($rev_today) ?><span class="text-sm text-slate-400 ml-0.5 font-semibold">đ</span></div>
                    </div>
                    <div class="w-10 h-10 rounded-full bg-emerald-50 dark:bg-emerald-900/20 text-emerald-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                        <i class="ri-money-dollar-circle-line text-xl"></i>
                    </div>
                </div>

                <div class="bg-white dark:bg-gray-800/80 rounded-2xl p-4 sm:p-5 border border-slate-100 dark:border-gray-700/50 shadow-soft flex items-center justify-between group cursor-pointer hover:border-blue-200 dark:hover:border-blue-800/50 transition-colors">
                    <div>
                        <div class="text-[10px] font-bold text-slate-400 dark:text-gray-500 uppercase tracking-widest mb-1">User Đăng Ký Nay</div>
                        <div class="text-xl sm:text-2xl font-black text-slate-800 dark:text-white tracking-tight"><?= number_format($new_users) ?></div>
                    </div>
                    <div class="w-10 h-10 rounded-full bg-blue-50 dark:bg-blue-900/20 text-blue-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                        <i class="ri-user-add-line text-xl"></i>
                    </div>
                </div>

                <div class="bg-white dark:bg-gray-800/80 rounded-2xl p-4 sm:p-5 border border-slate-100 dark:border-gray-700/50 shadow-soft flex items-center justify-between group cursor-pointer hover:border-purple-200 dark:hover:border-purple-800/50 transition-colors">
                    <div>
                        <div class="text-[10px] font-bold text-slate-400 dark:text-gray-500 uppercase tracking-widest mb-1">Tổng Doanh Thu</div>
                        <div class="text-xl sm:text-2xl font-black text-slate-800 dark:text-white tracking-tight"><?= number_format($rev_total) ?><span class="text-sm text-slate-400 ml-0.5 font-semibold">đ</span></div>
                    </div>
                    <div class="w-10 h-10 rounded-full bg-purple-50 dark:bg-purple-900/20 text-purple-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                        <i class="ri-line-chart-line text-xl"></i>
                    </div>
                </div>

                <div class="bg-white dark:bg-gray-800/80 rounded-2xl p-4 sm:p-5 border border-slate-100 dark:border-gray-700/50 shadow-soft flex items-center justify-between group cursor-pointer hover:border-slate-300 dark:hover:border-gray-600 transition-colors">
                    <div>
                        <div class="text-[10px] font-bold text-slate-400 dark:text-gray-500 uppercase tracking-widest mb-1">Tổng Thành Viên</div>
                        <div class="text-xl sm:text-2xl font-black text-slate-800 dark:text-white tracking-tight"><?= number_format($total_users) ?></div>
                    </div>
                    <div class="w-10 h-10 rounded-full bg-slate-100 dark:bg-gray-700/50 text-slate-500 dark:text-gray-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                        <i class="ri-group-line text-xl"></i>
                    </div>
                </div>
                
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div class="lg:col-span-2" x-data="minimalChart()">
                    <div class="bg-white dark:bg-gray-800/80 rounded-2xl border border-slate-100 dark:border-gray-700/50 shadow-soft p-5 h-full flex flex-col">
                        
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                            <div>
                                <h2 class="text-sm font-black uppercase text-slate-800 dark:text-white tracking-wide">Biểu Đồ 7 Ngày</h2>
                            </div>
                            
                            <div class="inline-flex bg-slate-100 dark:bg-gray-900/50 rounded-xl p-1 w-full sm:w-auto">
                                <button @click="setTab('revenue')" :class="activeTab === 'revenue' ? 'toggle-active' : 'text-slate-500 hover:text-slate-700 dark:hover:text-gray-300'" class="toggle-btn flex-1 sm:flex-none px-4 py-1.5 rounded-lg text-[11px] font-bold uppercase tracking-wider">
                                    Doanh Thu
                                </button>
                                <button @click="setTab('users')" :class="activeTab === 'users' ? 'toggle-active' : 'text-slate-500 hover:text-slate-700 dark:hover:text-gray-300'" class="toggle-btn flex-1 sm:flex-none px-4 py-1.5 rounded-lg text-[11px] font-bold uppercase tracking-wider">
                                    Đăng Ký
                                </button>
                            </div>
                        </div>
                        
                        <div class="flex-1 relative min-h-[300px]">
                            <div id="chartContainer" class="w-full h-full absolute inset-0"></div>
                        </div>
                    </div>
                </div>

                <div class="lg:col-span-1">
                    <div class="bg-white dark:bg-gray-800/80 rounded-2xl border border-slate-100 dark:border-gray-700/50 shadow-soft flex flex-col h-full">
                        <div class="p-5 flex items-center justify-between">
                            <h2 class="text-sm font-black uppercase text-slate-800 dark:text-white tracking-wide">Vừa Nạp Gần Đây</h2>
                            <a href="/admin/transactions" class="text-[10px] font-bold text-blue-500 hover:text-blue-600 uppercase tracking-widest transition-colors">Xem hết</a>
                        </div>

                        <div class="px-5 pb-5 flex-1 overflow-y-auto custom-scroll">
                            <?php if (empty($recent_transactions)): ?>
                                <div class="flex flex-col items-center justify-center h-full opacity-50 py-10">
                                    <i class="ri-inbox-line text-3xl mb-2"></i>
                                    <span class="text-xs font-medium">Chưa có giao dịch</span>
                                </div>
                            <?php else: ?>
                                <div class="space-y-4">
                                    <?php foreach ($recent_transactions as $row): 
                                        $name = !empty($row['username']) ? $row['username'] : $row['display_name'];
                                        $isManual = strpos(mb_strtolower($row['content'], 'UTF-8'), 'thủ công') !== false || strpos(mb_strtolower($row['content'], 'UTF-8'), 'admin') !== false;
                                        $iconColor = $isManual ? 'text-purple-500 bg-purple-50 dark:bg-purple-500/10' : 'text-emerald-500 bg-emerald-50 dark:bg-emerald-500/10';
                                        $icon = $isManual ? 'ri-user-settings-line' : 'ri-bank-card-line';
                                    ?>
                                    <div class="flex items-center justify-between group">
                                        <div class="flex items-center gap-3 overflow-hidden">
                                            <div class="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 <?= $iconColor ?>">
                                                <i class="<?= $icon ?> text-base"></i>
                                            </div>
                                            <div class="overflow-hidden">
                                                <div class="text-[13px] font-bold text-slate-800 dark:text-white truncate" title="<?= htmlspecialchars($name) ?>">
                                                    <?= htmlspecialchars($name) ?>
                                                </div>
                                                <div class="text-[10px] font-medium text-slate-400 mt-0.5 truncate">
                                                    <?= date('H:i - d/m', strtotime($row['paid_at'] ?? $row['created_at'])) ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="text-right shrink-0 ml-2">
                                            <div class="text-[13px] font-black text-emerald-500">+<?= number_format($row['amount']) ?>đ</div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

            </div>

        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('minimalChart', () => ({
                activeTab: 'revenue',
                chart: null,
                categories: <?= json_encode($chart_dates) ?>,
                revData: <?= json_encode($chart_revenue) ?>,
                userData: <?= json_encode($chart_users) ?>,
                
                init() {
                    this.$nextTick(() => { this.renderChart(); });
                    
                    const observer = new MutationObserver(() => {
                        if(this.chart) {
                            const isDark = document.documentElement.classList.contains('dark');
                            this.chart.updateOptions({
                                grid: { borderColor: isDark ? '#374151' : '#f1f5f9' },
                                tooltip: { theme: isDark ? 'dark' : 'light' }
                            });
                        }
                    });
                    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
                },

                renderChart() {
                    const isDark = document.documentElement.classList.contains('dark');
                    const options = {
                        chart: { 
                            type: 'bar', height: '100%', parentHeightOffset: 0,
                            toolbar: { show: false },
                            fontFamily: 'Inter, sans-serif',
                            animations: { enabled: true, easing: 'easeinout', speed: 500 }
                        },
                        series: [{ name: 'Doanh Thu', data: this.revData }],
                        colors: ['#10b981'],
                        plotOptions: {
                            bar: {
                                borderRadius: 4, 
                                columnWidth: '30%', // Cột thon gọn hơn
                                dataLabels: { position: 'top' }
                            }
                        },
                        dataLabels: { 
                            enabled: true, offsetY: -20,
                            style: { fontSize: '9px', colors: ['#94a3b8'], fontWeight: 600 },
                            formatter: (val) => val > 0 ? (val > 9999 ? (val/1000) + 'k' : val) : ""
                        },
                        stroke: { show: false },
                        xaxis: { 
                            categories: this.categories,
                            labels: { style: { colors: '#94a3b8', fontSize: '11px', fontWeight: 600 } },
                            axisBorder: { show: false }, axisTicks: { show: false }
                        },
                        yaxis: { show: false }, // Ẩn trục Y cho gọn
                        grid: { 
                            borderColor: isDark ? '#374151' : '#f1f5f9', 
                            strokeDashArray: 3, 
                            xaxis: { lines: { show: false } },
                            yaxis: { lines: { show: true } },
                            padding: { top: 0, right: 0, bottom: 0, left: 10 }
                        },
                        tooltip: { theme: isDark ? 'dark' : 'light', y: { formatter: (val) => new Intl.NumberFormat('vi-VN').format(val) } }
                    };

                    this.chart = new ApexCharts(document.querySelector("#chartContainer"), options);
                    this.chart.render();
                },

                setTab(tab) {
                    if (this.activeTab === tab) return;
                    this.activeTab = tab;
                    
                    if (tab === 'revenue') {
                        this.chart.updateSeries([{ name: 'Doanh Thu', data: this.revData }]);
                        this.chart.updateOptions({ colors: ['#10b981'] });
                    } else {
                        this.chart.updateSeries([{ name: 'Đăng Ký', data: this.userData }]);
                        this.chart.updateOptions({ colors: ['#3b82f6'] });
                    }
                }
            }));
        });
    </script>
</body>
</html>
