<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin
if (!isset($_SESSION['user_id'])) { header("Location: /auth/#login"); exit; }
$stmtCheck = $pdo->prepare("SELECT role FROM users WHERE id = ?");
$stmtCheck->execute([$_SESSION['user_id']]);
if (strtolower($stmtCheck->fetchColumn()) !== 'admin') { header("Location: /home"); exit; }

// ==========================================
// 1. THỐNG KÊ TỔNG QUAN
// ==========================================
try {
    $total_users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $new_today = $pdo->query("SELECT COUNT(*) FROM users WHERE DATE(created_at) = CURDATE()")->fetchColumn();
    $total_balance = $pdo->query("SELECT SUM(balance) FROM users")->fetchColumn() ?: 0;
} catch (Exception $e) {
    $total_users = $new_today = $total_balance = 0;
}

// ==========================================
// 2. BỘ LỌC & PHÂN TRANG
// ==========================================
$where = ["1=1"];
$params = [];
$search = $_GET['q'] ?? '';
$role_filter = $_GET['role'] ?? 'all';

if (!empty($search)) {
    $where[] = "(username LIKE :q OR email LIKE :q OR display_name LIKE :q OR id = :id)";
    $params[':q'] = "%$search%";
    $params[':id'] = $search;
}
if ($role_filter !== 'all') {
    $where[] = "role = :role";
    $params[':role'] = $role_filter;
}

$whereClause = "WHERE " . implode(' AND ', $where);

$limit = 20;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

$countQuery = "SELECT COUNT(*) FROM users $whereClause";
$stmtCount = $pdo->prepare($countQuery);
foreach ($params as $key => $val) { $stmtCount->bindValue($key, $val); }
$stmtCount->execute();
$totalRecords = $stmtCount->fetchColumn();
$totalPages = ceil($totalRecords / $limit);

$dataQuery = "SELECT * FROM users $whereClause ORDER BY id DESC LIMIT :limit OFFSET :offset";
$stmtData = $pdo->prepare($dataQuery);
foreach ($params as $key => $val) { $stmtData->bindValue($key, $val); }
$stmtData->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmtData->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmtData->execute();
$users = $stmtData->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Quản Lý Thành Viên';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.02); }
        .fade-in-up { animation: fadeInUp 0.4s ease-out forwards; }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-[#f8fafc] dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 w-full max-w-[1400px] mx-auto fade-in-up" x-data="memberManager()">
            
            <div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                    <h1 class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Quản Lý Thành Viên</h1>
                    <p class="text-xs sm:text-sm text-slate-500 dark:text-gray-400 mt-1">Kiểm soát tài khoản, số dư và phân quyền hệ thống.</p>
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-5 mb-6">
                <div class="bg-white dark:bg-gray-800/80 rounded-2xl p-4 sm:p-5 border border-slate-100 dark:border-gray-700/50 shadow-soft flex items-center justify-between group hover:border-blue-200 dark:hover:border-blue-800/50 transition-colors">
                    <div>
                        <div class="text-[10px] font-bold text-slate-400 dark:text-gray-500 uppercase tracking-widest mb-1">Tổng Thành Viên</div>
                        <div class="text-xl sm:text-2xl font-black text-slate-800 dark:text-white tracking-tight"><?= number_format($total_users) ?></div>
                    </div>
                    <div class="w-10 h-10 rounded-full bg-blue-50 dark:bg-blue-900/20 text-blue-500 flex items-center justify-center">
                        <i class="ri-group-line text-xl"></i>
                    </div>
                </div>

                <div class="bg-white dark:bg-gray-800/80 rounded-2xl p-4 sm:p-5 border border-slate-100 dark:border-gray-700/50 shadow-soft flex items-center justify-between group hover:border-emerald-200 dark:hover:border-emerald-800/50 transition-colors">
                    <div>
                        <div class="text-[10px] font-bold text-slate-400 dark:text-gray-500 uppercase tracking-widest mb-1">Đăng Ký Hôm Nay</div>
                        <div class="text-xl sm:text-2xl font-black text-slate-800 dark:text-white tracking-tight"><?= number_format($new_today) ?></div>
                    </div>
                    <div class="w-10 h-10 rounded-full bg-emerald-50 dark:bg-emerald-900/20 text-emerald-500 flex items-center justify-center">
                        <i class="ri-user-add-line text-xl"></i>
                    </div>
                </div>

                <div class="bg-white dark:bg-gray-800/80 rounded-2xl p-4 sm:p-5 border border-slate-100 dark:border-gray-700/50 shadow-soft flex items-center justify-between group hover:border-amber-200 dark:hover:border-amber-800/50 transition-colors">
                    <div>
                        <div class="text-[10px] font-bold text-slate-400 dark:text-gray-500 uppercase tracking-widest mb-1">Tổng Số Dư Lưu Trữ</div>
                        <div class="text-xl sm:text-2xl font-black text-slate-800 dark:text-white tracking-tight"><?= number_format($total_balance) ?><span class="text-sm font-semibold ml-0.5 text-slate-400">đ</span></div>
                    </div>
                    <div class="w-10 h-10 rounded-full bg-amber-50 dark:bg-amber-900/20 text-amber-500 flex items-center justify-center">
                        <i class="ri-wallet-3-line text-xl"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white dark:bg-gray-800/80 rounded-2xl border border-slate-100 dark:border-gray-700/50 shadow-soft p-5 mb-6">
                <form method="GET" action="" class="grid grid-cols-1 md:grid-cols-12 gap-4">
                    <div class="md:col-span-6">
                        <label class="block text-[10px] font-bold text-slate-400 dark:text-gray-500 uppercase tracking-widest mb-1.5">Tìm kiếm (Tên, Email, ID)</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400"><i class="ri-search-line"></i></div>
                            <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Nhập từ khoá..." class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2 pl-9 pr-3 text-sm focus:outline-none focus:border-blue-500 dark:text-white transition-colors">
                        </div>
                    </div>
                    <div class="md:col-span-4">
                        <label class="block text-[10px] font-bold text-slate-400 dark:text-gray-500 uppercase tracking-widest mb-1.5">Phân Quyền</label>
                        <select name="role" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2 px-3 text-sm focus:outline-none focus:border-blue-500 dark:text-white transition-colors appearance-none">
                            <option value="all" <?= $role_filter === 'all' ? 'selected' : '' ?>>Tất cả thành viên</option>
                            <option value="user" <?= $role_filter === 'user' ? 'selected' : '' ?>>Chỉ hiển thị User</option>
                            <option value="admin" <?= $role_filter === 'admin' ? 'selected' : '' ?>>Chỉ hiển thị Admin</option>
                        </select>
                    </div>
                    <div class="md:col-span-2 flex items-end gap-2">
                        <button type="submit" class="flex-1 bg-slate-900 hover:bg-black dark:bg-white dark:text-slate-900 dark:hover:bg-gray-100 text-white rounded-xl py-2 font-bold text-sm transition-colors shadow-sm">Lọc</button>
                    </div>
                </form>
            </div>

            <div class="bg-white dark:bg-gray-800/80 rounded-2xl border border-slate-100 dark:border-gray-700/50 shadow-soft overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full">
                        <thead class="bg-slate-50/50 dark:bg-gray-900/30 border-b border-slate-100 dark:border-gray-700/50">
                            <tr class="whitespace-nowrap">
                                <th class="px-5 py-4 text-left text-[11px] font-bold text-slate-500 dark:text-gray-400 uppercase tracking-wider w-16">ID</th>
                                <th class="px-5 py-4 text-left text-[11px] font-bold text-slate-500 dark:text-gray-400 uppercase tracking-wider">Tài Khoản</th>
                                <th class="px-5 py-4 text-left text-[11px] font-bold text-slate-500 dark:text-gray-400 uppercase tracking-wider">Số Dư</th>
                                <th class="px-5 py-4 text-left text-[11px] font-bold text-slate-500 dark:text-gray-400 uppercase tracking-wider">Trạng Thái VIP</th>
                                <th class="px-5 py-4 text-left text-[11px] font-bold text-slate-500 dark:text-gray-400 uppercase tracking-wider">Ngày Tạo</th>
                                <th class="px-5 py-4 text-right text-[11px] font-bold text-slate-500 dark:text-gray-400 uppercase tracking-wider">Thao Tác</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-50 dark:divide-gray-700/30">
                            <?php if (empty($users)): ?>
                            <tr>
                                <td colspan="6" class="px-5 py-12 text-center">
                                    <div class="w-16 h-16 rounded-full bg-slate-50 dark:bg-gray-800 flex items-center justify-center mx-auto mb-3">
                                        <i class="ri-user-search-line text-2xl text-slate-400"></i>
                                    </div>
                                    <p class="text-slate-500 dark:text-gray-400 font-medium">Không tìm thấy thành viên nào.</p>
                                </td>
                            </tr>
                            <?php else: ?>
                                <?php foreach ($users as $row): 
                                    $avatar = $row['avatar'] ?: '/client/layout/assets/images/user.png';
                                    $isAdmin = ($row['role'] === 'admin');
                                    $roleClass = $isAdmin ? 'text-rose-500 bg-rose-50 border-rose-200 dark:bg-rose-900/20 dark:border-rose-800/30' : 'text-slate-500 bg-slate-50 border-slate-200 dark:bg-gray-800 dark:border-gray-700';
                                    $is_vip = !empty($row['vip_name']) && strtotime($row['vip_expire_at']) > time();
                                ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-gray-800/30 transition-colors">
                                    <td class="px-5 py-4 whitespace-nowrap">
                                        <span class="text-xs font-bold text-slate-400">#<?= $row['id'] ?></span>
                                    </td>
                                    
                                    <td class="px-5 py-4 min-w-[200px]">
                                        <div class="flex items-center gap-3">
                                            <img src="<?= htmlspecialchars($avatar) ?>" alt="Avatar" class="w-9 h-9 rounded-full object-cover border border-slate-200 dark:border-gray-700 shrink-0">
                                            <div>
                                                <div class="flex items-center gap-2 mb-0.5">
                                                    <span class="text-[13px] font-bold text-slate-800 dark:text-white"><?= htmlspecialchars($row['username'] ?? $row['display_name']) ?></span>
                                                    <span class="text-[9px] font-black uppercase px-1.5 py-0.5 rounded border <?= $roleClass ?>"><?= $row['role'] ?></span>
                                                </div>
                                                <div class="text-[11px] text-slate-500 dark:text-gray-400 truncate max-w-[150px]"><?= htmlspecialchars($row['email']) ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    
                                    <td class="px-5 py-4 whitespace-nowrap">
                                        <div class="text-[13px] font-black text-blue-600 dark:text-blue-400" id="balance_<?= $row['id'] ?>"><?= number_format($row['balance']) ?>đ</div>
                                    </td>

                                    <td class="px-5 py-4 whitespace-nowrap">
                                        <?php if ($is_vip): ?>
                                            <div class="text-[11px] font-bold text-amber-500 dark:text-amber-400 mb-0.5"><i class="ri-vip-crown-fill mr-1"></i><?= htmlspecialchars($row['vip_name']) ?></div>
                                            <div class="text-[10px] text-slate-400">Hết: <?= date('d/m/y', strtotime($row['vip_expire_at'])) ?></div>
                                        <?php else: ?>
                                            <span class="text-[10px] font-bold text-slate-400 bg-slate-100 dark:bg-gray-800 px-2 py-1 rounded-md">Không có</span>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td class="px-5 py-4 whitespace-nowrap">
                                        <div class="text-xs font-semibold text-slate-600 dark:text-gray-400"><?= date('d/m/Y', strtotime($row['created_at'])) ?></div>
                                    </td>

                                    <td class="px-5 py-4 whitespace-nowrap text-right">
                                        <div class="flex items-center justify-end gap-1.5">
                                            <button @click="openBalanceModal(<?= $row['id'] ?>, '<?= htmlspecialchars($row['username'] ?? $row['display_name']) ?>', 'add')" class="w-7 h-7 rounded bg-emerald-50 hover:bg-emerald-100 text-emerald-600 dark:bg-emerald-900/20 dark:hover:bg-emerald-900/40 dark:text-emerald-400 transition-colors" title="Cộng tiền">
                                                <i class="ri-add-line font-bold"></i>
                                            </button>
                                            
                                            <button @click="openBalanceModal(<?= $row['id'] ?>, '<?= htmlspecialchars($row['username'] ?? $row['display_name']) ?>', 'sub')" class="w-7 h-7 rounded bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-900/20 dark:hover:bg-rose-900/40 dark:text-rose-400 transition-colors" title="Trừ tiền">
                                                <i class="ri-subtract-line font-bold"></i>
                                            </button>

                                            <button @click="openEditModal(<?= htmlspecialchars(json_encode([
                                                'id' => $row['id'],
                                                'username' => $row['username'],
                                                'email' => $row['email'],
                                                'role' => $row['role']
                                            ])) ?>)" class="w-7 h-7 rounded bg-slate-100 hover:bg-slate-200 text-slate-600 dark:bg-gray-800 dark:hover:bg-gray-700 dark:text-gray-300 transition-colors ml-1" title="Chỉnh sửa chi tiết">
                                                <i class="ri-edit-2-line"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($totalPages > 1): ?>
                <div class="px-5 py-4 border-t border-slate-100 dark:border-gray-700/50 flex items-center justify-between bg-slate-50/30 dark:bg-transparent">
                    <div class="text-xs text-slate-500 font-medium">Trang <span class="font-bold text-slate-800 dark:text-white"><?= $page ?></span> / <?= $totalPages ?></div>
                    <?php
                        $qs = $_GET; unset($qs['page']);
                        $queryString = http_build_query($qs);
                        $baseUrl = "?$queryString" . ($queryString ? '&' : '');
                    ?>
                    <div class="flex items-center gap-1">
                        <?php if ($page > 1): ?>
                            <a href="<?= $baseUrl . 'page=' . ($page - 1) ?>" class="w-7 h-7 flex items-center justify-center rounded border border-slate-200 dark:border-gray-700 text-slate-500 hover:bg-slate-100 dark:hover:bg-gray-800 transition-colors"><i class="ri-arrow-left-s-line"></i></a>
                        <?php endif; ?>
                        <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                            <a href="<?= $baseUrl . 'page=' . $i ?>" class="w-7 h-7 flex items-center justify-center rounded text-[11px] font-bold transition-colors <?= $i === $page ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900' : 'border border-slate-200 dark:border-gray-700 text-slate-500 hover:bg-slate-100 dark:hover:bg-gray-800' ?>"><?= $i ?></a>
                        <?php endfor; ?>
                        <?php if ($page < $totalPages): ?>
                            <a href="<?= $baseUrl . 'page=' . ($page + 1) ?>" class="w-7 h-7 flex items-center justify-center rounded border border-slate-200 dark:border-gray-700 text-slate-500 hover:bg-slate-100 dark:hover:bg-gray-800 transition-colors"><i class="ri-arrow-right-s-line"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <div x-show="showBalanceModal" x-cloak class="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-0">
                <div class="absolute inset-0 bg-slate-900/60 dark:bg-black/80 backdrop-blur-sm" @click="showBalanceModal = false"></div>
                <div class="relative bg-white dark:bg-gray-800 w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden" 
                     x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 scale-95 translate-y-4" x-transition:enter-end="opacity-100 scale-100 translate-y-0">
                    
                    <div class="p-7">
                        <div class="flex justify-between items-center mb-6">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-full flex items-center justify-center text-lg"
                                     :class="actionType === 'add' ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-900/20' : 'bg-rose-50 text-rose-600 dark:bg-rose-900/20'">
                                    <i :class="actionType === 'add' ? 'ri-add-circle-fill' : 'ri-indeterminate-circle-fill'"></i>
                                </div>
                                <div>
                                    <h3 class="text-base font-black text-slate-800 dark:text-white leading-tight uppercase tracking-tight" x-text="actionType === 'add' ? 'Cộng Số Dư' : 'Trừ Số Dư'"></h3>
                                    <div class="text-[11px] text-slate-500 font-medium" x-text="'User: ' + targetUser"></div>
                                </div>
                            </div>
                            <button @click="showBalanceModal = false" class="text-slate-400 hover:text-red-500 transition-colors"><i class="ri-close-line text-2xl"></i></button>
                        </div>
                        
                        <div class="space-y-4 mb-6">
                            <div>
                                <label class="block text-[10px] font-bold text-slate-400 dark:text-gray-500 uppercase tracking-widest mb-1.5">Số tiền thao tác (VNĐ)</label>
                                <input type="number" x-model="amount" placeholder="VD: 50000" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2.5 px-3 text-sm font-bold text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 transition-colors">
                            </div>
                            <div>
                                <label class="block text-[10px] font-bold text-slate-400 dark:text-gray-500 uppercase tracking-widest mb-1.5 flex items-center justify-between">
                                    Nội dung ghi chú
                                    <button @click="generateRandomReason()" class="text-blue-500 hover:text-blue-600 text-[9px]">Tạo lại random</button>
                                </label>
                                <input type="text" x-model="reason" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2.5 px-3 text-sm font-mono text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 transition-colors">
                            </div>
                        </div>

                        <button @click="submitBalance()" :disabled="isProcessing" 
                                class="w-full h-11 text-white rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2 shadow-sm"
                                :class="actionType === 'add' ? 'bg-emerald-500 hover:bg-emerald-600' : 'bg-rose-500 hover:bg-rose-600'">
                            <i x-show="!isProcessing" class="ri-check-line"></i>
                            <i x-show="isProcessing" class="ri-loader-4-line animate-spin"></i>
                            <span x-text="actionType === 'add' ? 'Xác Nhận Cộng' : 'Xác Nhận Trừ'"></span>
                        </button>
                    </div>
                </div>
            </div>

            <div x-show="showEditModal" x-cloak class="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-0">
                <div class="absolute inset-0 bg-slate-900/60 dark:bg-black/80 backdrop-blur-sm" @click="showEditModal = false"></div>
                <div class="relative bg-white dark:bg-gray-800 w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden" 
                     x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 scale-95 translate-y-4" x-transition:enter-end="opacity-100 scale-100 translate-y-0">
                    
                    <div class="p-7">
                        <div class="flex justify-between items-center mb-6">
                            <h3 class="text-base font-black text-slate-800 dark:text-white uppercase tracking-tight">Sửa Thông Tin</h3>
                            <button @click="showEditModal = false" class="text-slate-400 hover:text-red-500 transition-colors"><i class="ri-close-line text-2xl"></i></button>
                        </div>
                        
                        <div class="space-y-4 mb-6">
                            <div>
                                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Tên Đăng Nhập</label>
                                <input type="text" x-model="editData.username" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2 px-3 text-sm font-bold text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 transition-colors">
                            </div>
                            <div>
                                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Email</label>
                                <input type="email" x-model="editData.email" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2 px-3 text-sm text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 transition-colors">
                            </div>
                            <div>
                                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Phân Quyền</label>
                                <select x-model="editData.role" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2 px-3 text-sm font-bold text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 transition-colors appearance-none">
                                    <option value="user">USER (Người dùng)</option>
                                    <option value="admin">ADMIN (Quản trị viên)</option>
                                </select>
                            </div>
                            <div class="pt-2">
                                <label class="block text-[10px] font-bold text-rose-500 uppercase tracking-widest mb-1.5">Đổi Mật Khẩu (Bỏ trống nếu không đổi)</label>
                                <input type="text" x-model="editData.password" placeholder="Nhập mật khẩu mới..." class="w-full bg-rose-50/50 dark:bg-rose-900/10 border border-rose-200 dark:border-rose-800/30 rounded-xl py-2 px-3 text-sm text-slate-800 dark:text-white focus:outline-none focus:border-rose-500 transition-colors">
                            </div>
                        </div>

                        <button @click="submitEdit()" :disabled="isProcessing" class="w-full h-11 bg-slate-900 hover:bg-black dark:bg-white dark:hover:bg-gray-100 dark:text-slate-900 text-white rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2 shadow-sm">
                            <i x-show="!isProcessing" class="ri-save-line"></i>
                            <i x-show="isProcessing" class="ri-loader-4-line animate-spin"></i>
                            <span x-text="isProcessing ? 'Đang lưu...' : 'Lưu Thay Đổi'"></span>
                        </button>
                    </div>
                </div>
            </div>

        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('memberManager', () => ({
                showBalanceModal: false,
                showEditModal: false,
                isProcessing: false,
                
                // Trạng thái cộng tiền
                targetId: null,
                targetUser: '',
                actionType: 'add',
                amount: '',
                reason: '',

                // Trạng thái sửa User
                editData: { id: '', username: '', email: '', role: 'user', password: '' },

                // Thuật toán tạo mã 10 ký tự CHỮ & SỐ NGẪU NHIÊN
                generateRandomReason() {
                    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
                    let result = '';
                    for (let i = 0; i < 10; i++) {
                        result += chars.charAt(Math.floor(Math.random() * chars.length));
                    }
                    this.reason = (this.actionType === 'add' ? 'NAP_' : 'TRU_') + result;
                },

                openBalanceModal(id, user, type) {
                    this.targetId = id;
                    this.targetUser = user;
                    this.actionType = type;
                    this.amount = '';
                    this.generateRandomReason(); // Tự động tạo mã ngẫu nhiên khi mở modal
                    this.showBalanceModal = true;
                },

                openEditModal(userData) {
                    this.editData = {
                        id: userData.id,
                        username: userData.username,
                        email: userData.email,
                        role: userData.role,
                        password: ''
                    };
                    this.showEditModal = true;
                },

                async submitBalance() {
                    if (!this.amount || this.amount <= 0) {
                        Swal.fire({ toast: true, position: 'top-end', icon: 'warning', title: 'Nhập số tiền hợp lệ!', showConfirmButton: false, timer: 2000 });
                        return;
                    }

                    this.isProcessing = true;
                    try {
                        let fd = new FormData();
                        fd.append('user_id', this.targetId);
                        fd.append('type', this.actionType);
                        fd.append('amount', this.amount);
                        fd.append('reason', this.reason);

                        const res = await fetch('/api-handler?action=update_balance', { method: 'POST', body: fd });
                        const data = await res.json();

                        if (data.status === 'success') {
                            this.showBalanceModal = false;
                            Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: data.message, showConfirmButton: false, timer: 2000 });
                            document.getElementById('balance_' + this.targetId).innerText = new Intl.NumberFormat('vi-VN').format(data.new_balance) + 'đ';
                        } else {
                            Swal.fire('Lỗi', data.message, 'error');
                        }
                    } catch (e) {
                        Swal.fire('Lỗi', 'Lỗi kết nối máy chủ.', 'error');
                    } finally {
                        this.isProcessing = false;
                    }
                },

                async submitEdit() {
                    if (!this.editData.username) {
                        Swal.fire({ toast: true, position: 'top-end', icon: 'warning', title: 'Tên không được để trống!', showConfirmButton: false, timer: 2000 });
                        return;
                    }

                    this.isProcessing = true;
                    try {
                        let fd = new FormData();
                        for (let key in this.editData) {
                            fd.append(key, this.editData[key]);
                        }

                        const res = await fetch('/api-handler?action=edit_user', { method: 'POST', body: fd });
                        const data = await res.json();

                        if (data.status === 'success') {
                            this.showEditModal = false;
                            Swal.fire({ icon: 'success', title: 'Thành công', text: data.message, confirmButtonColor: '#10b981' })
                            .then(() => window.location.reload());
                        } else {
                            Swal.fire('Lỗi', data.message, 'error');
                        }
                    } catch (e) {
                        Swal.fire('Lỗi', 'Lỗi kết nối máy chủ.', 'error');
                    } finally {
                        this.isProcessing = false;
                    }
                }
            }));
        });
    </script>
</body>
</html>
