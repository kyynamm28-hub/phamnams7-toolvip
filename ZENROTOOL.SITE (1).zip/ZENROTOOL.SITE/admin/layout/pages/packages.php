<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin
if (!isset($_SESSION['user_id'])) { header("Location: /auth/#login"); exit; }
$stmtCheck = $pdo->prepare("SELECT role FROM users WHERE id = ?");
$stmtCheck->execute([$_SESSION['user_id']]);
if (strtolower($stmtCheck->fetchColumn()) !== 'admin') { header("Location: /home"); exit; }

// Lấy danh sách các gói VIP
try {
    $stmt = $pdo->query("SELECT * FROM packages ORDER BY price ASC");
    $packages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $total_active = 0;
    foreach($packages as $p) { if($p['status'] === 'active') $total_active++; }
} catch (Exception $e) {
    $packages = [];
    $total_active = 0;
}

$pageTitle = 'Quản Lý Gói VIP';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.02); }
        .fade-in-up { animation: fadeInUp 0.4s ease-out forwards; }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-[#f8fafc] dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 w-full max-w-[1400px] mx-auto fade-in-up" x-data="packageManager()">
            
            <div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                    <h1 class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Quản Lý Gói VIP</h1>
                    <p class="text-xs sm:text-sm text-slate-500 dark:text-gray-400 mt-1">Thêm, sửa, xóa và cấu hình giá bán các gói VIP.</p>
                </div>
                <div class="flex items-center gap-3">
                    <div class="hidden sm:flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 rounded-xl border border-slate-200 dark:border-gray-700 shadow-sm text-sm font-bold text-slate-600 dark:text-gray-300">
                        <i class="ri-checkbox-circle-fill text-emerald-500"></i> Đang hoạt động: <?= $total_active ?>/<?= count($packages) ?>
                    </div>
                    <button @click="openModal('add')" class="px-5 py-2.5 bg-slate-900 hover:bg-black dark:bg-white dark:text-slate-900 dark:hover:bg-gray-100 text-white rounded-xl font-bold text-sm transition-colors shadow-sm flex items-center gap-2">
                        <i class="ri-add-line"></i> Thêm Gói Mới
                    </button>
                </div>
            </div>

            <?php if (empty($packages)): ?>
                <div class="flex flex-col items-center justify-center min-h-[400px] bg-white dark:bg-gray-800/80 rounded-3xl border border-dashed border-slate-200 dark:border-gray-700">
                    <div class="w-16 h-16 rounded-full bg-slate-50 dark:bg-gray-800 flex items-center justify-center mb-4">
                        <i class="ri-vip-crown-line text-2xl text-slate-400"></i>
                    </div>
                    <div class="text-slate-800 dark:text-white font-bold text-lg">Chưa Có Gói VIP Nào</div>
                    <div class="text-slate-500 text-sm mt-1 mb-4 text-center">Bấm vào nút thêm mới để tạo gói VIP đầu tiên.</div>
                    <button @click="openModal('add')" class="px-6 py-2.5 bg-amber-500 hover:bg-amber-600 text-white rounded-full font-bold text-sm shadow-md transition-colors">Tạo Ngay</button>
                </div>
            <?php else: ?>
                <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                    <?php foreach ($packages as $pkg): 
                        $isActive = $pkg['status'] === 'active';
                        $statusClass = $isActive ? 'text-emerald-600 bg-emerald-50 border-emerald-200 dark:bg-emerald-900/20 dark:border-emerald-800/30 dark:text-emerald-400' : 'text-slate-500 bg-slate-50 border-slate-200 dark:bg-gray-800 dark:border-gray-700';
                    ?>
                    <div class="bg-white dark:bg-gray-800/80 rounded-3xl border border-slate-100 dark:border-gray-700/50 shadow-soft p-6 flex flex-col h-full hover:border-amber-200 dark:hover:border-amber-500/50 transition-colors group relative overflow-hidden">
                        
                        <?php if (!$isActive): ?>
                        <div class="absolute inset-0 bg-slate-50/50 dark:bg-black/40 z-10 backdrop-blur-[1px] pointer-events-none"></div>
                        <?php endif; ?>

                        <div class="relative z-20 flex-1">
                            <div class="flex items-start justify-between mb-5">
                                <div class="w-14 h-14 rounded-2xl bg-slate-50 dark:bg-gray-900/50 flex items-center justify-center border border-slate-100 dark:border-gray-700 p-2">
                                    <img src="<?= htmlspecialchars($pkg['image']) ?>" alt="Icon" class="w-full h-full object-contain">
                                </div>
                                <div class="flex flex-col items-end gap-2">
                                    <span class="inline-flex items-center px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider border <?= $statusClass ?>">
                                        <?= $isActive ? 'Hoạt động' : 'Tạm ẩn' ?>
                                    </span>
                                    <div class="inline-flex items-center px-2.5 py-1 bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 border border-amber-100 dark:border-amber-800/30 rounded-lg text-[10px] font-black">
                                        <i class="ri-time-line mr-1"></i> <?= $pkg['duration_days'] ?> Ngày
                                    </div>
                                </div>
                            </div>

                            <h3 class="text-lg font-black text-slate-800 dark:text-white mb-2"><?= htmlspecialchars($pkg['name']) ?></h3>
                            <p class="text-[13px] text-slate-500 dark:text-gray-400 leading-relaxed mb-6 line-clamp-3">
                                <?= htmlspecialchars($pkg['description']) ?>
                            </p>
                        </div>

                        <div class="relative z-20 mt-auto pt-5 border-t border-slate-100 dark:border-gray-700/50 flex items-end justify-between">
                            <div>
                                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Giá Bán</div>
                                <div class="text-xl font-black text-amber-500 dark:text-amber-400">
                                    <?= number_format($pkg['price']) ?><span class="text-sm font-semibold text-slate-400 ml-0.5">đ</span>
                                </div>
                            </div>
                            
                            <div class="flex items-center gap-1.5">
                                <button @click="toggleStatus(<?= $pkg['id'] ?>, '<?= $pkg['status'] ?>')" class="w-8 h-8 rounded-lg flex items-center justify-center transition-colors <?= $isActive ? 'bg-rose-50 text-rose-500 hover:bg-rose-100 dark:bg-rose-900/20 dark:hover:bg-rose-900/40' : 'bg-emerald-50 text-emerald-500 hover:bg-emerald-100 dark:bg-emerald-900/20 dark:hover:bg-emerald-900/40' ?>" title="<?= $isActive ? 'Tạm ẩn gói' : 'Mở bán lại' ?>">
                                    <i class="<?= $isActive ? 'ri-eye-off-line' : 'ri-eye-line' ?>"></i>
                                </button>
                                <button @click="openModal('edit', <?= htmlspecialchars(json_encode($pkg)) ?>)" class="w-8 h-8 rounded-lg bg-blue-50 text-blue-500 hover:bg-blue-100 dark:bg-blue-900/20 dark:hover:bg-blue-900/40 transition-colors" title="Chỉnh sửa">
                                    <i class="ri-edit-2-line"></i>
                                </button>
                                <button @click="deletePackage(<?= $pkg['id'] ?>)" class="w-8 h-8 rounded-lg bg-slate-100 text-slate-500 hover:bg-slate-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600 transition-colors" title="Xóa vĩnh viễn">
                                    <i class="ri-delete-bin-line"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div x-show="showModal" x-cloak class="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-0">
                <div class="absolute inset-0 bg-slate-900/60 dark:bg-black/80 backdrop-blur-sm" @click="showModal = false"></div>
                <div class="relative bg-white dark:bg-gray-800 w-full max-w-lg rounded-[24px] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]" 
                     x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 scale-95 translate-y-4" x-transition:enter-end="opacity-100 scale-100 translate-y-0">
                    
                    <div class="px-6 py-5 border-b border-slate-100 dark:border-gray-700 flex justify-between items-center">
                        <h3 class="text-lg font-black text-slate-800 dark:text-white uppercase tracking-tight" x-text="isEdit ? 'Chỉnh Sửa Gói VIP' : 'Thêm Gói VIP Mới'"></h3>
                        <button @click="showModal = false" class="text-slate-400 hover:text-red-500 transition-colors"><i class="ri-close-line text-2xl"></i></button>
                    </div>
                    
                    <div class="p-6 overflow-y-auto custom-scroll">
                        <div class="space-y-4">
                            <div>
                                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Tên Gói VIP</label>
                                <input type="text" x-model="formData.name" placeholder="VD: VIP Pro 1 Tháng..." class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2.5 px-3 text-sm font-bold text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 transition-colors">
                            </div>
                            
                            <div class="grid grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Giá Bán (VNĐ)</label>
                                    <input type="number" x-model="formData.price" placeholder="VD: 50000" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2.5 px-3 text-sm font-bold text-slate-800 dark:text-white focus:outline-none focus:border-amber-500 transition-colors">
                                </div>
                                <div>
                                    <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Thời Hạn (Ngày)</label>
                                    <input type="number" x-model="formData.duration_days" placeholder="VD: 30" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2.5 px-3 text-sm font-bold text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 transition-colors">
                                </div>
                            </div>

                            <div>
                                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Link Ảnh Icon (URL)</label>
                                <div class="flex items-center gap-2">
                                    <div class="w-10 h-10 shrink-0 bg-slate-50 dark:bg-gray-900 rounded-xl border border-slate-200 dark:border-gray-700 p-1 flex items-center justify-center">
                                        <img :src="formData.image || 'https://cdn-icons-png.flaticon.com/512/8144/8144288.png'" class="max-w-full max-h-full object-contain">
                                    </div>
                                    <input type="text" x-model="formData.image" placeholder="https://..." class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2.5 px-3 text-sm text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 transition-colors">
                                </div>
                            </div>

                            <div>
                                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Quyền Lợi & Mô tả (Có thể dùng HTML)</label>
                                <textarea x-model="formData.description" rows="4" placeholder="Nhập mô tả đặc quyền..." class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2.5 px-3 text-sm text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 transition-colors custom-scroll"></textarea>
                            </div>
                            
                            <div>
                                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Trạng Thái</label>
                                <select x-model="formData.status" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2.5 px-3 text-sm font-bold text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 transition-colors appearance-none">
                                    <option value="active">Hiển thị (Mở bán)</option>
                                    <option value="inactive">Tạm ẩn (Ngừng bán)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="p-6 border-t border-slate-100 dark:border-gray-700">
                        <button @click="submitData()" :disabled="isProcessing" class="w-full h-12 bg-slate-900 hover:bg-black dark:bg-white dark:hover:bg-gray-100 dark:text-slate-900 text-white rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2 shadow-md">
                            <i x-show="!isProcessing" class="ri-save-line"></i>
                            <i x-show="isProcessing" class="ri-loader-4-line animate-spin"></i>
                            <span x-text="isProcessing ? 'Đang xử lý...' : 'Lưu Gói VIP'"></span>
                        </button>
                    </div>

                </div>
            </div>

        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('packageManager', () => ({
                showModal: false,
                isEdit: false,
                isProcessing: false,
                
                formData: {
                    id: '', name: '', price: '', duration_days: '', image: 'https://cdn-icons-png.flaticon.com/512/8144/8144288.png', description: '', status: 'active'
                },

                openModal(mode, data = null) {
                    this.isEdit = mode === 'edit';
                    if (this.isEdit && data) {
                        this.formData = { ...data };
                    } else {
                        this.formData = { id: '', name: '', price: '', duration_days: '', image: 'https://cdn-icons-png.flaticon.com/512/8144/8144288.png', description: '', status: 'active' };
                    }
                    this.showModal = true;
                },

                async submitData() {
                    if (!this.formData.name || !this.formData.price || !this.formData.duration_days) {
                        Swal.fire({ toast: true, position: 'top-end', icon: 'warning', title: 'Vui lòng điền đủ thông tin!', showConfirmButton: false, timer: 2000 });
                        return;
                    }
                    this.isProcessing = true;
                    try {
                        let fd = new FormData();
                        fd.append('action', this.isEdit ? 'edit' : 'add');
                        for (let key in this.formData) fd.append(key, this.formData[key]);

                        const res = await fetch('/api-handler?action=manage_package', { method: 'POST', body: fd });
                        const data = await res.json();

                        if (data.status === 'success') {
                            Swal.fire({ icon: 'success', title: 'Thành công', text: data.message, confirmButtonColor: '#10b981' })
                            .then(() => window.location.reload());
                        } else {
                            Swal.fire('Lỗi', data.message, 'error');
                        }
                    } catch (e) {
                        Swal.fire('Lỗi', 'Kết nối máy chủ thất bại.', 'error');
                    } finally {
                        this.isProcessing = false;
                    }
                },

                async toggleStatus(id, currentStatus) {
                    const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
                    try {
                        let fd = new FormData();
                        fd.append('action', 'toggle');
                        fd.append('id', id);
                        fd.append('status', newStatus);

                        const res = await fetch('/api-handler?action=manage_package', { method: 'POST', body: fd });
                        const data = await res.json();
                        
                        if (data.status === 'success') window.location.reload();
                    } catch(e) {}
                },

                async deletePackage(id) {
                    const confirm = await Swal.fire({
                        title: 'Xóa gói VIP này?',
                        text: "Hành động này không thể hoàn tác!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#ef4444',
                        cancelButtonColor: '#94a3b8',
                        confirmButtonText: 'Đồng ý xóa'
                    });

                    if (confirm.isConfirmed) {
                        try {
                            let fd = new FormData();
                            fd.append('action', 'delete');
                            fd.append('id', id);
                            
                            const res = await fetch('/api-handler?action=manage_package', { method: 'POST', body: fd });
                            const data = await res.json();
                            
                            if (data.status === 'success') {
                                window.location.reload();
                            } else {
                                Swal.fire('Lỗi', data.message, 'error');
                            }
                        } catch(e) {}
                    }
                }
            }));
        });
    </script>
</body>
</html>
