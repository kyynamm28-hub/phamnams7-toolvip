<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin
if (!isset($_SESSION['user_id'])) { header("Location: /auth/#login"); exit; }
$stmtCheck = $pdo->prepare("SELECT role FROM users WHERE id = ?");
$stmtCheck->execute([$_SESSION['user_id']]);
if (strtolower($stmtCheck->fetchColumn()) !== 'admin') { header("Location: /home"); exit; }

// Lấy danh sách đối tác từ bảng `partners`
try {
    $stmt = $pdo->query("SELECT * FROM partners ORDER BY id DESC");
    $partners = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $total_active = 0;
    foreach($partners as $p) { if($p['status'] === 'active') $total_active++; }
} catch (Exception $e) {
    $partners = [];
    $total_active = 0;
}

// Lấy cấu hình giá thuê từ bảng `setting_partner`
try {
    $stmtSet = $pdo->query("SELECT * FROM setting_partner LIMIT 1");
    $setting = $stmtSet->fetch(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $setting = ['price_day' => 0, 'price_week' => 0, 'price_month' => 0, 'contact_link' => ''];
}

$pageTitle = 'Quản Lý Đối Tác';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.02); }
        .fade-in-up { animation: fadeInUp 0.4s ease-out forwards; }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .toggle-btn { transition: all 0.3s ease; }
        .toggle-active { background-color: #ffffff; color: #171717; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        .dark .toggle-active { background-color: #374151; color: #ffffff; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-[#f8fafc] dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 w-full max-w-[1400px] mx-auto fade-in-up" x-data="partnerManager()">
            
            <div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                    <h1 class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Đối Tác & Dịch Vụ</h1>
                    <p class="text-xs sm:text-sm text-slate-500 dark:text-gray-400 mt-1">Quản lý banner đối tác và thiết lập giá thuê quảng cáo.</p>
                </div>
                <div class="flex items-center gap-3">
                    <div class="inline-flex bg-slate-100 dark:bg-gray-800 rounded-xl p-1 border border-slate-200 dark:border-gray-700/50">
                        <button @click="activeTab = 'list'" :class="activeTab === 'list' ? 'toggle-active' : 'text-slate-500'" class="toggle-btn px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center">
                            <i class="ri-group-line mr-1.5"></i> Danh Sách
                        </button>
                        <button @click="activeTab = 'settings'" :class="activeTab === 'settings' ? 'toggle-active' : 'text-slate-500'" class="toggle-btn px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center">
                            <i class="ri-settings-3-line mr-1.5"></i> Giá Thuê
                        </button>
                    </div>
                    
                    <button x-show="activeTab === 'list'" @click="openModal('add')" class="px-5 py-2.5 bg-rose-500 hover:bg-rose-600 text-white rounded-xl font-bold text-sm transition-colors shadow-sm flex items-center gap-2">
                        <i class="ri-add-line"></i> Thêm Mới
                    </button>
                </div>
            </div>

            <div x-show="activeTab === 'list'" x-transition>
                <?php if (empty($partners)): ?>
                    <div class="flex flex-col items-center justify-center min-h-[400px] bg-white dark:bg-gray-800/80 rounded-3xl border border-dashed border-slate-200 dark:border-gray-700">
                        <div class="w-16 h-16 rounded-full bg-slate-50 dark:bg-gray-800 flex items-center justify-center mb-4">
                            <i class="ri-user-star-line text-2xl text-slate-400"></i>
                        </div>
                        <div class="text-slate-800 dark:text-white font-bold text-lg">Chưa Có Đối Tác Nào</div>
                        <div class="text-slate-500 text-sm mt-1 mb-4 text-center">Bấm vào nút thêm mới để cấu hình đối tác đầu tiên.</div>
                        <button @click="openModal('add')" class="px-6 py-2.5 bg-rose-500 hover:bg-rose-600 text-white rounded-full font-bold text-sm shadow-md transition-colors">Tạo Ngay</button>
                    </div>
                <?php else: ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                        <?php foreach ($partners as $partner): 
                            $isActive = $partner['status'] === 'active';
                            $statusClass = $isActive ? 'text-emerald-600 bg-emerald-50 border-emerald-200 dark:bg-emerald-900/20 dark:border-emerald-800/30' : 'text-slate-500 bg-slate-50 border-slate-200 dark:bg-gray-800 dark:border-gray-700';
                        ?>
                        <div class="bg-white dark:bg-gray-800/80 rounded-3xl border border-slate-100 dark:border-gray-700/50 shadow-soft p-6 flex flex-col h-full hover:border-rose-200 dark:hover:border-rose-500/50 transition-colors group relative overflow-hidden">
                            
                            <?php if (!$isActive): ?>
                            <div class="absolute inset-0 bg-slate-50/50 dark:bg-black/40 z-10 backdrop-blur-[1px] pointer-events-none"></div>
                            <?php endif; ?>

                            <div class="relative z-20 flex-1">
                                <div class="flex items-start justify-between mb-5">
                                    <div class="w-14 h-14 rounded-2xl bg-white dark:bg-gray-900 flex items-center justify-center border border-slate-100 dark:border-gray-700 p-1.5 shrink-0 overflow-hidden shadow-sm">
                                        <img src="<?= htmlspecialchars($partner['logo_url'] ?: 'https://placehold.co/200x200/rose/white?text=Logo') ?>" alt="Logo" class="w-full h-full object-contain rounded-xl">
                                    </div>
                                    <span class="inline-flex items-center px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider border <?= $statusClass ?>">
                                        <?= $isActive ? 'Hiển thị' : 'Đang Ẩn' ?>
                                    </span>
                                </div>

                                <h3 class="text-lg font-black text-slate-800 dark:text-white mb-1.5"><?= htmlspecialchars($partner['name']) ?></h3>
                                <a href="<?= htmlspecialchars($partner['website_url']) ?>" target="_blank" class="inline-flex items-center text-xs font-bold text-blue-500 hover:text-blue-600 mb-4 transition-colors">
                                    <i class="ri-links-line mr-1"></i> Truy cập Website
                                </a>
                                
                                <div class="text-[12px] text-slate-500 dark:text-gray-400 leading-relaxed line-clamp-3 bg-slate-50/50 dark:bg-gray-900/30 p-3 rounded-xl border border-slate-100 dark:border-gray-700/30">
                                    <?= strip_tags($partner['description']) ?: '<i>(Chưa cập nhật mô tả)</i>' ?>
                                </div>
                            </div>

                            <div class="relative z-20 mt-6 pt-5 border-t border-slate-100 dark:border-gray-700/50 flex justify-end">
                                <div class="flex items-center gap-1.5">
                                    <button @click="toggleStatus(<?= $partner['id'] ?>, '<?= $partner['status'] ?>')" class="w-8 h-8 rounded-lg flex items-center justify-center transition-colors <?= $isActive ? 'bg-amber-50 text-amber-500 hover:bg-amber-100 dark:bg-amber-900/20' : 'bg-emerald-50 text-emerald-500 hover:bg-emerald-100 dark:bg-emerald-900/20' ?>" title="<?= $isActive ? 'Ẩn đối tác' : 'Hiển thị lại' ?>">
                                        <i class="<?= $isActive ? 'ri-eye-off-line' : 'ri-eye-line' ?>"></i>
                                    </button>
                                    <button @click="openModal('edit', <?= htmlspecialchars(json_encode($partner)) ?>)" class="w-8 h-8 rounded-lg bg-blue-50 text-blue-500 hover:bg-blue-100 dark:bg-blue-900/20 transition-colors" title="Chỉnh sửa">
                                        <i class="ri-edit-2-line"></i>
                                    </button>
                                    <button @click="deletePartner(<?= $partner['id'] ?>)" class="w-8 h-8 rounded-lg bg-slate-100 text-slate-500 hover:bg-slate-200 dark:bg-gray-700 transition-colors" title="Xóa vĩnh viễn">
                                        <i class="ri-delete-bin-line"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div x-show="activeTab === 'settings'" x-cloak x-transition>
                <div class="bg-white dark:bg-gray-800/80 rounded-3xl border border-slate-100 dark:border-gray-700/50 shadow-soft p-6 sm:p-10 max-w-3xl mx-auto">
                    <div class="text-center mb-8">
                        <div class="w-14 h-14 rounded-full bg-rose-50 text-rose-500 dark:bg-rose-900/20 flex items-center justify-center mx-auto mb-3">
                            <i class="ri-money-dollar-circle-line text-2xl"></i>
                        </div>
                        <h2 class="text-xl font-black text-slate-800 dark:text-white uppercase">Bảng Giá Cho Thuê Banner</h2>
                        <p class="text-sm text-slate-500 mt-1">Cấu hình giá hiển thị công khai trên website cho khách hàng.</p>
                    </div>

                    <div class="space-y-5">
                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-5">
                            <div>
                                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Giá Thuê 1 Ngày</label>
                                <input type="number" x-model="settingsData.price_day" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-3 px-4 font-black text-slate-800 dark:text-white focus:outline-none focus:border-rose-500 transition-colors">
                            </div>
                            <div>
                                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Giá Thuê 1 Tuần</label>
                                <input type="number" x-model="settingsData.price_week" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-3 px-4 font-black text-slate-800 dark:text-white focus:outline-none focus:border-rose-500 transition-colors">
                            </div>
                            <div>
                                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Giá Thuê 1 Tháng</label>
                                <input type="number" x-model="settingsData.price_month" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-3 px-4 font-black text-slate-800 dark:text-white focus:outline-none focus:border-rose-500 transition-colors">
                            </div>
                        </div>

                        <div>
                            <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Link Liên Hệ Thuê (Telegram/Zalo)</label>
                            <input type="text" x-model="settingsData.contact_link" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-3 px-4 text-sm font-bold text-blue-500 focus:outline-none focus:border-rose-500 transition-colors">
                        </div>

                        <button @click="saveSettings()" :disabled="isProcessing" class="w-full mt-4 h-12 bg-slate-900 hover:bg-black dark:bg-white dark:hover:bg-gray-100 dark:text-slate-900 text-white rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2 shadow-md">
                            <i x-show="!isProcessing" class="ri-save-3-line"></i>
                            <i x-show="isProcessing" class="ri-loader-4-line animate-spin"></i>
                            <span x-text="isProcessing ? 'Đang cập nhật...' : 'Cập Nhật Bảng Giá'"></span>
                        </button>
                    </div>
                </div>
            </div>

            <div x-show="showModal" x-cloak class="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-0">
                <div class="absolute inset-0 bg-slate-900/60 dark:bg-black/80 backdrop-blur-sm" @click="showModal = false"></div>
                <div class="relative bg-white dark:bg-gray-800 w-full max-w-lg rounded-[24px] shadow-2xl overflow-hidden flex flex-col max-h-[95vh]" 
                     x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 scale-95 translate-y-4" x-transition:enter-end="opacity-100 scale-100 translate-y-0">
                    
                    <div class="px-6 py-5 border-b border-slate-100 dark:border-gray-700 flex justify-between items-center">
                        <h3 class="text-lg font-black text-slate-800 dark:text-white uppercase tracking-tight" x-text="isEdit ? 'Chỉnh Sửa Đối Tác' : 'Thêm Đối Tác Mới'"></h3>
                        <button @click="showModal = false" class="text-slate-400 hover:text-red-500 transition-colors"><i class="ri-close-line text-2xl"></i></button>
                    </div>
                    
                    <div class="p-6 overflow-y-auto custom-scroll">
                        <div class="space-y-4">
                            <div>
                                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Tên Đối Tác / Brand</label>
                                <input type="text" x-model="formData.name" placeholder="VD: Zenro Agency..." class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2.5 px-3 text-sm font-bold text-slate-800 dark:text-white focus:outline-none focus:border-rose-500 transition-colors">
                            </div>
                            
                            <div>
                                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Link Website (URL)</label>
                                <input type="text" x-model="formData.website_url" placeholder="https://..." class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2.5 px-3 text-sm font-bold text-blue-500 focus:outline-none focus:border-rose-500 transition-colors">
                            </div>

                            <div>
                                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Hình Ảnh Logo (URL)</label>
                                <div class="flex items-center gap-2">
                                    <div class="w-10 h-10 shrink-0 bg-slate-50 dark:bg-gray-900 rounded-xl border border-slate-200 dark:border-gray-700 p-1 flex items-center justify-center overflow-hidden">
                                        <img :src="formData.logo_url || 'https://placehold.co/200x200/e2e8f0/64748b?text=Logo'" class="w-full h-full object-contain rounded-lg">
                                    </div>
                                    <input type="text" x-model="formData.logo_url" placeholder="https://..." class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2.5 px-3 text-sm text-slate-800 dark:text-white focus:outline-none focus:border-rose-500 transition-colors">
                                </div>
                            </div>

                            <div>
                                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Mô Tả Dịch Vụ (Hỗ Trợ HTML)</label>
                                <textarea x-model="formData.description" rows="4" placeholder="Mô tả dịch vụ của đối tác..." class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2.5 px-3 text-sm text-slate-800 dark:text-white focus:outline-none focus:border-rose-500 transition-colors custom-scroll"></textarea>
                            </div>
                            
                            <div>
                                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Trạng Thái Hiển Thị</label>
                                <select x-model="formData.status" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2.5 px-3 text-sm font-bold text-slate-800 dark:text-white focus:outline-none focus:border-rose-500 transition-colors appearance-none">
                                    <option value="active">Hiển thị (Đang hợp tác)</option>
                                    <option value="hidden">Tạm ẩn (Ngừng hợp tác)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="p-6 border-t border-slate-100 dark:border-gray-700">
                        <button @click="submitPartner()" :disabled="isProcessing" class="w-full h-12 bg-slate-900 hover:bg-black dark:bg-white dark:hover:bg-gray-100 dark:text-slate-900 text-white rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2 shadow-md">
                            <i x-show="!isProcessing" class="ri-save-line"></i>
                            <i x-show="isProcessing" class="ri-loader-4-line animate-spin"></i>
                            <span x-text="isProcessing ? 'Đang xử lý...' : 'Lưu Thay Đổi'"></span>
                        </button>
                    </div>

                </div>
            </div>

        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('partnerManager', () => ({
                activeTab: 'list',
                showModal: false,
                isEdit: false,
                isProcessing: false,
                
                formData: {
                    id: '', name: '', website_url: '', logo_url: '', description: '', status: 'active'
                },

                settingsData: {
                    price_day: <?= $setting['price_day'] ?? 20000 ?>,
                    price_week: <?= $setting['price_week'] ?? 80000 ?>,
                    price_month: <?= $setting['price_month'] ?? 300000 ?>,
                    contact_link: '<?= htmlspecialchars($setting['contact_link'] ?? '') ?>'
                },

                openModal(mode, data = null) {
                    this.isEdit = mode === 'edit';
                    if (this.isEdit && data) {
                        this.formData = { ...data };
                    } else {
                        this.formData = { id: '', name: '', website_url: '', logo_url: '', description: '', status: 'active' };
                    }
                    this.showModal = true;
                },

                async submitPartner() {
                    if (!this.formData.name || !this.formData.logo_url) {
                        Swal.fire({ toast: true, position: 'top-end', icon: 'warning', title: 'Điền tên và Logo!', showConfirmButton: false, timer: 2000 });
                        return;
                    }
                    this.isProcessing = true;
                    try {
                        let fd = new FormData();
                        fd.append('action', this.isEdit ? 'edit_partner' : 'add_partner');
                        for (let key in this.formData) fd.append(key, this.formData[key]);

                        const res = await fetch('/api-handler?action=manage_partner', { method: 'POST', body: fd });
                        const data = await res.json();

                        if (data.status === 'success') {
                            Swal.fire({ icon: 'success', title: 'Thành công', text: data.message, confirmButtonColor: '#f43f5e' })
                            .then(() => window.location.reload());
                        } else {
                            Swal.fire('Lỗi', data.message, 'error');
                        }
                    } catch (e) {
                        Swal.fire('Lỗi', 'Kết nối máy chủ thất bại.', 'error');
                    } finally {
                        this.isProcessing = false;
                    }
                },

                async toggleStatus(id, currentStatus) {
                    const newStatus = currentStatus === 'active' ? 'hidden' : 'active';
                    try {
                        let fd = new FormData();
                        fd.append('action', 'toggle_partner');
                        fd.append('id', id);
                        fd.append('status', newStatus);

                        const res = await fetch('/api-handler?action=manage_partner', { method: 'POST', body: fd });
                        const data = await res.json();
                        if (data.status === 'success') window.location.reload();
                    } catch(e) {}
                },

                async deletePartner(id) {
                    const confirm = await Swal.fire({
                        title: 'Xóa đối tác này?',
                        text: "Dữ liệu sẽ bị xóa vĩnh viễn!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#ef4444',
                        cancelButtonColor: '#94a3b8',
                        confirmButtonText: 'Đồng ý xóa'
                    });

                    if (confirm.isConfirmed) {
                        try {
                            let fd = new FormData();
                            fd.append('action', 'delete_partner');
                            fd.append('id', id);
                            
                            const res = await fetch('/api-handler?action=manage_partner', { method: 'POST', body: fd });
                            const data = await res.json();
                            if (data.status === 'success') window.location.reload();
                        } catch(e) {}
                    }
                },

                async saveSettings() {
                    this.isProcessing = true;
                    try {
                        let fd = new FormData();
                        fd.append('action', 'save_settings');
                        for (let key in this.settingsData) fd.append(key, this.settingsData[key]);

                        const res = await fetch('/api-handler?action=manage_partner', { method: 'POST', body: fd });
                        const data = await res.json();

                        if (data.status === 'success') {
                            Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: data.message, showConfirmButton: false, timer: 2000 });
                        } else {
                            Swal.fire('Lỗi', data.message, 'error');
                        }
                    } catch (e) {
                        Swal.fire('Lỗi', 'Lỗi lưu cấu hình.', 'error');
                    } finally {
                        this.isProcessing = false;
                    }
                }
            }));
        });
    </script>
</body>
</html>