<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin
if (!isset($_SESSION['user_id'])) { header("Location: /auth/#login"); exit; }
$stmtCheck = $pdo->prepare("SELECT role FROM users WHERE id = ?");
$stmtCheck->execute([$_SESSION['user_id']]);
if (strtolower($stmtCheck->fetchColumn()) !== 'admin') { header("Location: /home"); exit; }

// ==========================================
// 1. THỐNG KÊ KHO HÀNG
// ==========================================
try {
    $total_products = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
    $active_products = $pdo->query("SELECT COUNT(*) FROM products WHERE status = 'active'")->fetchColumn();
    $total_sales = $pdo->query("SELECT COUNT(*) FROM history_product")->fetchColumn() ?: 0;
} catch (Exception $e) {
    $total_products = $active_products = $total_sales = 0;
}

// ==========================================
// 2. LẤY DANH SÁCH SẢN PHẨM & ẢNH ĐẠI DIỆN
// ==========================================
try {
    // Lấy sản phẩm kèm ảnh chính (is_primary = 1)
    $stmtProd = $pdo->query("
        SELECT p.*, pi.image_url as image 
        FROM products p 
        LEFT JOIN product_images pi ON p.id = pi.product_id AND pi.is_primary = 1
        ORDER BY p.id DESC
    ");
    $products = $stmtProd->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $products = [];
}

// ==========================================
// 3. LẤY DANH SÁCH LỊCH SỬ MUA (history_product)
// ==========================================
try {
    $stmtBuyers = $pdo->query("SELECT * FROM history_product ORDER BY id DESC LIMIT 50");
    $buyers = $stmtBuyers->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $buyers = [];
}

$pageTitle = 'Quản Lý Kho Mã Nguồn';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); }
        .fade-in { animation: fadeIn 0.4s ease-out forwards; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .custom-scroll::-webkit-scrollbar { width: 5px; height: 5px; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #d4d4d8; border-radius: 10px; }
        .dark .custom-scroll::-webkit-scrollbar-thumb { background: #4b5563; }
    </style>
</head>
<body x-data="{ activeTab: 'inventory', sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-neutral-50 dark:bg-gray-900 text-neutral-800 dark:text-gray-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 w-full max-w-6xl mx-auto fade-in">
            
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
                <div>
                    <h1 class="text-2xl sm:text-3xl font-black text-neutral-900 dark:text-white uppercase tracking-tight">Quản Lý Kho Hàng</h1>
                    <p class="text-[13px] text-neutral-500 dark:text-gray-400 mt-1">Cấu hình sản phẩm, mã nguồn (Source Code) và theo dõi lịch sử bán hàng.</p>
                </div>
                
                <div class="flex flex-col sm:flex-row items-center gap-3">
                    <div class="inline-flex bg-white dark:bg-gray-800 rounded-xl p-1.5 border border-neutral-200 dark:border-gray-700 shadow-sm w-full sm:w-auto">
                        <button @click="activeTab = 'inventory'" :class="activeTab === 'inventory' ? 'bg-neutral-100 dark:bg-gray-700 text-blue-600 dark:text-blue-400 font-bold shadow-sm' : 'text-neutral-500 hover:text-neutral-800 dark:hover:text-white font-medium'" class="flex-1 sm:px-6 py-2 rounded-lg text-xs transition-all focus:outline-none">
                            <i class="ri-store-2-line mr-1"></i> Kho Hàng
                        </button>
                        <button @click="activeTab = 'buyers'" :class="activeTab === 'buyers' ? 'bg-neutral-100 dark:bg-gray-700 text-blue-600 dark:text-blue-400 font-bold shadow-sm' : 'text-neutral-500 hover:text-neutral-800 dark:hover:text-white font-medium'" class="flex-1 sm:px-6 py-2 rounded-lg text-xs transition-all focus:outline-none">
                            <i class="ri-history-line mr-1"></i> Lịch Sử Bán
                        </button>
                    </div>
                    <a x-show="activeTab === 'inventory'" href="/admin/product/add" class="w-full sm:w-auto h-10 px-6 bg-neutral-900 hover:bg-black dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 text-white rounded-xl text-[12px] font-bold uppercase tracking-widest transition-all shadow-sm flex items-center justify-center gap-1.5 focus:outline-none shrink-0">
                        <i class="ri-add-line text-[15px]"></i> Thêm SP
                    </a>
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
                <div class="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-neutral-200/60 dark:border-gray-700 shadow-soft flex items-center gap-4">
                    <div class="w-12 h-12 rounded-xl bg-blue-50 dark:bg-blue-900/20 text-blue-500 flex items-center justify-center text-xl shrink-0"><i class="ri-archive-line"></i></div>
                    <div>
                        <div class="text-[10px] font-bold text-neutral-400 dark:text-gray-500 uppercase tracking-widest mb-1">Loại Sản Phẩm</div>
                        <div class="text-xl font-black text-neutral-900 dark:text-white leading-none"><?= number_format($total_products) ?></div>
                    </div>
                </div>
                <div class="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-neutral-200/60 dark:border-gray-700 shadow-soft flex items-center gap-4">
                    <div class="w-12 h-12 rounded-xl bg-emerald-50 dark:bg-emerald-900/20 text-emerald-500 flex items-center justify-center text-xl shrink-0"><i class="ri-checkbox-circle-line"></i></div>
                    <div>
                        <div class="text-[10px] font-bold text-neutral-400 dark:text-gray-500 uppercase tracking-widest mb-1">Đang Mở Bán</div>
                        <div class="text-xl font-black text-neutral-900 dark:text-white leading-none"><?= number_format($active_products) ?></div>
                    </div>
                </div>
                <div class="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-neutral-200/60 dark:border-gray-700 shadow-soft flex items-center gap-4">
                    <div class="w-12 h-12 rounded-xl bg-purple-50 dark:bg-purple-900/20 text-purple-500 flex items-center justify-center text-xl shrink-0"><i class="ri-shopping-cart-2-line"></i></div>
                    <div>
                        <div class="text-[10px] font-bold text-neutral-400 dark:text-gray-500 uppercase tracking-widest mb-1">Tổng Lượt Bán</div>
                        <div class="text-xl font-black text-neutral-900 dark:text-white leading-none"><?= number_format($total_sales) ?></div>
                    </div>
                </div>
            </div>

            <div x-show="activeTab === 'inventory'" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" x-data="productAction()">
                <div class="bg-white dark:bg-gray-800 rounded-[24px] border border-neutral-200/60 dark:border-gray-700 shadow-soft overflow-hidden">
                    <?php if (empty($products)): ?>
                        <div class="py-20 text-center">
                            <div class="w-16 h-16 rounded-full bg-neutral-100 dark:bg-gray-700 flex items-center justify-center mx-auto mb-4">
                                <i class="ri-price-tag-3-line text-2xl text-neutral-400"></i>
                            </div>
                            <div class="text-neutral-800 dark:text-white font-bold text-lg mb-1">Kho Hàng Trống</div>
                            <div class="text-neutral-500 text-sm">Chưa có sản phẩm hoặc mã nguồn nào được tải lên.</div>
                        </div>
                    <?php else: ?>
                        <div class="flex flex-col divide-y divide-neutral-100 dark:divide-gray-700/60">
                            <?php foreach ($products as $pkg): ?>
                                <div class="p-5 sm:p-6 flex flex-col sm:flex-row gap-5 items-start sm:items-center hover:bg-neutral-50 dark:hover:bg-gray-700/30 transition-colors group">
                                    
                                    <div class="w-full sm:w-28 h-32 sm:h-24 rounded-[14px] overflow-hidden shrink-0 bg-neutral-100 dark:bg-gray-900 border border-neutral-200/50 dark:border-gray-700/50 relative p-2 flex items-center justify-center">
                                        <img src="<?= !empty($pkg['image']) ? htmlspecialchars($pkg['image']) : 'https://cdn-icons-png.flaticon.com/512/2165/8144288.png' ?>" class="max-w-full max-h-full object-contain group-hover:scale-110 transition-transform duration-500">
                                    </div>
                                    
                                    <div class="flex-1 min-w-0">
                                        <div class="flex items-center gap-2 mb-1.5">
                                            <span class="inline-flex px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-widest <?= $pkg['status'] == 'active' ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400' : 'bg-neutral-100 text-neutral-500 dark:bg-gray-800 dark:text-gray-400' ?>">
                                                <?= $pkg['status'] == 'active' ? 'Mở Bán' : 'Tạm Khóa' ?>
                                            </span>
                                            <span class="text-[10px] font-mono text-neutral-400">ID: <?= $pkg['id'] ?></span>
                                        </div>
                                        <h3 class="text-base font-black text-neutral-900 dark:text-white leading-tight mb-1 truncate group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors"><?= htmlspecialchars($pkg['name']) ?></h3>
                                        <p class="text-[12px] text-neutral-500 dark:text-gray-400 line-clamp-1 mb-2"><?= htmlspecialchars($pkg['short_description']) ?></p>
                                        <div class="text-[15px] font-black text-blue-600 dark:text-blue-400">
                                            <?= number_format($pkg['price']) ?><span class="text-[11px] font-bold ml-0.5 text-neutral-400">đ</span>
                                        </div>
                                    </div>
                                    
                                    <div class="w-full sm:w-auto mt-3 sm:mt-0 flex gap-2 shrink-0">
                                        <a href="/admin/product/edit/<?= htmlspecialchars($pkg['slug']) ?>" class="flex-1 sm:flex-none h-10 px-4 rounded-xl border border-neutral-200 dark:border-gray-600 bg-white dark:bg-gray-800 text-neutral-700 dark:text-gray-200 hover:bg-neutral-50 dark:hover:bg-gray-700 transition-colors flex items-center justify-center gap-1.5 text-xs font-bold focus:outline-none">
                                            <i class="ri-edit-2-line text-[15px]"></i> Sửa
                                        </a>
                                        <button @click="deleteProduct(<?= $pkg['id'] ?>)" class="flex-1 sm:flex-none h-10 w-10 sm:px-0 rounded-xl bg-rose-50 dark:bg-rose-500/10 text-rose-500 hover:bg-rose-500 hover:text-white transition-colors flex items-center justify-center focus:outline-none">
                                            <i class="ri-delete-bin-line text-[16px]"></i>
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div x-show="activeTab === 'buyers'" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" style="display: none;">
                <div class="bg-white dark:bg-gray-800 rounded-[24px] border border-neutral-200/60 dark:border-gray-700 shadow-soft overflow-hidden">
                    <div class="overflow-x-auto custom-scroll">
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr class="bg-neutral-50/50 dark:bg-gray-900/50 border-b border-neutral-100 dark:border-gray-700 text-[10px] font-black uppercase tracking-widest text-neutral-400 dark:text-gray-500">
                                    <th class="py-4 px-6">Thời gian</th>
                                    <th class="py-4 px-6">Khách hàng</th>
                                    <th class="py-4 px-6">Sản phẩm</th>
                                    <th class="py-4 px-6 text-right">Giá tiền</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-neutral-100 dark:divide-gray-700/60">
                                <?php if (empty($buyers)): ?>
                                    <tr>
                                        <td colspan="4" class="py-12 text-center text-neutral-400 text-sm font-medium">Chưa có giao dịch mua hàng nào.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($buyers as $b): ?>
                                        <tr class="hover:bg-neutral-50/50 dark:hover:bg-gray-700/20 transition-colors">
                                            <td class="py-4 px-6 text-[12px] text-neutral-500 dark:text-gray-400 font-medium">
                                                <?= date('H:i d/m/Y', strtotime($b['purchased_at'])) ?>
                                            </td>
                                            <td class="py-4 px-6 text-[13px] font-bold text-neutral-900 dark:text-white">
                                                <?= htmlspecialchars($b['username']) ?>
                                            </td>
                                            <td class="py-4 px-6 text-[13px] text-blue-600 dark:text-blue-400 font-medium truncate max-w-[200px]" title="<?= htmlspecialchars($b['product_name']) ?>">
                                                <?= htmlspecialchars($b['product_name']) ?>
                                            </td>
                                            <td class="py-4 px-6 text-[13px] font-black text-neutral-900 dark:text-white text-right">
                                                <?= number_format($b['price']) ?>đ
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </main>
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('productAction', () => ({
                async deleteProduct(id) {
                    const cf = await Swal.fire({
                        title: 'Xóa sản phẩm này?',
                        text: "Sản phẩm và hình ảnh sẽ bị gỡ khỏi hệ thống!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#171717',
                        cancelButtonColor: '#e5e5e5',
                        cancelButtonText: '<span style="color:#171717">Hủy bỏ</span>',
                        confirmButtonText: 'Đồng ý xóa',
                        customClass: { popup: document.documentElement.classList.contains('dark') ? 'bg-gray-800 text-white' : '' }
                    });
                    if(cf.isConfirmed) {
                        try {
                            const res = await fetch('/api-handler?action=delete_product', { method: 'POST', body: JSON.stringify({id: id}) });
                            const data = await res.json();
                            if(data.status === 'success') window.location.reload();
                            else Swal.fire('Lỗi', data.message, 'error');
                        } catch(e) { Swal.fire('Lỗi', 'Không thể xóa.', 'error'); }
                    }
                }
            }));
        });
    </script>
</body>
</html>
