<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin
if (!isset($_SESSION['user_id'])) { header("Location: /auth/#login"); exit; }
$stmtUser = $pdo->prepare("SELECT role FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);
if (!$user || strtolower($user['role']) !== 'admin') { header("Location: /home"); exit; }

// Lấy toàn bộ Setting từ Database
$stmt = $pdo->query("SELECT * FROM settings");
$rawSettings = $stmt->fetchAll(PDO::FETCH_ASSOC);
$settings = [];
foreach ($rawSettings as $s) {
    $settings[$s['key']] = $s['value'];
}

$page_title = 'Cài Đặt Hệ Thống';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); }
        .fade-in { animation: fadeIn 0.4s ease-out forwards; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        
        .input-base {
            width: 100%; height: 44px; padding: 0 16px; 
            background-color: #f5f5f5; border: 1px solid #e5e5e5; border-radius: 12px;
            font-size: 13px; font-weight: 500; color: #171717; outline: none; transition: all 0.2s ease;
        }
        .dark .input-base { background-color: #111827; border-color: #374151; color: #ffffff; }
        .input-base:focus { border-color: #3b82f6; box-shadow: 0 0 0 3px rgba(59,130,246,0.15); }
        .label-base { display: block; font-size: 11px; font-weight: 700; color: #737373; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 8px; }
        .dark .label-base { color: #9ca3af; }

        .toggle-checkbox:checked { right: 0; border-color: #10b981; }
        .toggle-checkbox:checked + .toggle-label { background-color: #10b981; }
        .custom-scroll::-webkit-scrollbar { width: 5px; height: 5px; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #d4d4d8; border-radius: 10px; }
        .dark .custom-scroll::-webkit-scrollbar-thumb { background: #4b5563; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-neutral-50 dark:bg-[#0b1120] text-neutral-800 dark:text-gray-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 w-full max-w-5xl mx-auto fade-in" x-data="settingsManager()">
            
            <div class="mb-8">
                <h1 class="text-2xl sm:text-3xl font-black text-neutral-900 dark:text-white uppercase tracking-tight">Cấu Hình Website</h1>
                <p class="text-[13px] text-neutral-500 dark:text-gray-400 mt-1">Quản lý chuyên sâu các thông số, giao diện và chức năng của hệ thống.</p>
            </div>

            <div class="flex items-center gap-2 overflow-x-auto pb-4 mb-4 custom-scroll border-b border-neutral-200 dark:border-gray-800">
                <button @click="activeTab = 'general'" :class="activeTab === 'general' ? 'border-blue-500 text-blue-600 dark:text-blue-400' : 'border-transparent text-neutral-400 hover:text-neutral-700 dark:hover:text-gray-300'" class="px-4 py-2 border-b-2 font-bold text-[13px] uppercase tracking-widest transition-colors whitespace-nowrap focus:outline-none">
                    <i class="ri-global-line mr-1"></i> Thông Tin Chung
                </button>
                <button @click="activeTab = 'security'" :class="activeTab === 'security' ? 'border-blue-500 text-blue-600 dark:text-blue-400' : 'border-transparent text-neutral-400 hover:text-neutral-700 dark:hover:text-gray-300'" class="px-4 py-2 border-b-2 font-bold text-[13px] uppercase tracking-widest transition-colors whitespace-nowrap focus:outline-none">
                    <i class="ri-shield-keyhole-line mr-1"></i> Bảo Mật & API
                </button>
                <button @click="activeTab = 'ui'" :class="activeTab === 'ui' ? 'border-blue-500 text-blue-600 dark:text-blue-400' : 'border-transparent text-neutral-400 hover:text-neutral-700 dark:hover:text-gray-300'" class="px-4 py-2 border-b-2 font-bold text-[13px] uppercase tracking-widest transition-colors whitespace-nowrap focus:outline-none">
                    <i class="ri-paint-brush-line mr-1"></i> Giao Diện & Script
                </button>
                <button @click="activeTab = 'maintenance'" :class="activeTab === 'maintenance' ? 'border-blue-500 text-blue-600 dark:text-blue-400' : 'border-transparent text-neutral-400 hover:text-neutral-700 dark:hover:text-gray-300'" class="px-4 py-2 border-b-2 font-bold text-[13px] uppercase tracking-widest transition-colors whitespace-nowrap focus:outline-none">
                    <i class="ri-tools-line mr-1"></i> Bảo Trì
                </button>
                <button @click="activeTab = 'social'" :class="activeTab === 'social' ? 'border-blue-500 text-blue-600 dark:text-blue-400' : 'border-transparent text-neutral-400 hover:text-neutral-700 dark:hover:text-gray-300'" class="px-4 py-2 border-b-2 font-bold text-[13px] uppercase tracking-widest transition-colors whitespace-nowrap focus:outline-none">
                    <i class="ri-share-line mr-1"></i> Liên Kết Footer
                </button>
            </div>

            <div class="bg-white dark:bg-[#0f172a] rounded-[24px] shadow-soft border border-neutral-200/60 dark:border-gray-800 overflow-hidden">
                
                <div x-show="activeTab === 'general'" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" class="p-6 sm:p-8 space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="label-base">Tiêu đề Website (Site Title)</label>
                            <input type="text" x-model="form.site_title" class="input-base">
                        </div>
                        <div>
                            <label class="label-base">Từ khóa SEO (Keywords)</label>
                            <input type="text" x-model="form.site_keywords" class="input-base">
                        </div>
                    </div>
                    
                    <div>
                        <label class="label-base">Mô tả Website (Description)</label>
                        <textarea x-model="form.site_description" rows="3" class="input-base h-auto py-3 resize-y custom-scroll"></textarea>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="label-base">Logo Navbar (URL)</label>
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-xl bg-neutral-50 dark:bg-[#1e293b] border border-neutral-200/60 dark:border-gray-700 p-1 flex justify-center items-center shrink-0">
                                    <img :src="form.navbar_logo || 'https://placehold.co/100x100?text=Logo'" class="max-w-full max-h-full object-contain">
                                </div>
                                <input type="text" x-model="form.navbar_logo" class="input-base font-mono">
                            </div>
                        </div>
                        <div>
                            <label class="label-base">Favicon (URL)</label>
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-xl bg-neutral-50 dark:bg-[#1e293b] border border-neutral-200/60 dark:border-gray-700 p-1 flex justify-center items-center shrink-0">
                                    <img :src="form.favicon || 'https://placehold.co/100x100?text=Fav'" class="max-w-full max-h-full object-contain">
                                </div>
                                <input type="text" x-model="form.favicon" class="input-base font-mono">
                            </div>
                        </div>
                    </div>
                </div>

                <div x-show="activeTab === 'security'" style="display: none;" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" class="p-6 sm:p-8 space-y-6">
                    <div class="bg-amber-50 dark:bg-amber-900/10 border border-amber-200 dark:border-amber-800/30 rounded-xl p-4 mb-2">
                        <h4 class="text-[12px] font-bold text-amber-700 dark:text-amber-500 uppercase tracking-widest flex items-center gap-2 mb-1">
                            <i class="ri-information-fill text-[16px]"></i> Cấu hình Geetest V4 Captcha
                        </h4>
                        <p class="text-[13px] text-amber-600 dark:text-amber-400 font-medium">Bảo vệ trang đăng nhập/đăng ký khỏi Bot spam. Lấy API Key tại <a href="https://www.geetest.com" target="_blank" class="font-bold underline">geetest.com</a></p>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="label-base">Geetest Captcha ID</label>
                            <input type="text" x-model="form.geetest_id" placeholder="VD: 1234567890abcdef1234567890abcdef" class="input-base font-mono">
                        </div>
                        <div>
                            <label class="label-base">Geetest Captcha Key (Secret)</label>
                            <input type="password" x-model="form.geetest_key" placeholder="VD: 1234567890abcdef1234567890abcdef" class="input-base font-mono">
                        </div>
                    </div>

                    <div class="pt-4 border-t border-neutral-100 dark:border-gray-800">
                        <label class="label-base">Giới Hạn Đăng Ký Tài Khoản / IP</label>
                        <p class="text-xs text-neutral-500 mb-3">Số lượng tài khoản tối đa được phép tạo trên cùng 1 địa chỉ mạng (Mặc định: 3).</p>
                        <input type="number" x-model="form.max_register_per_ip" placeholder="3" min="1" max="100" class="input-base w-32">
                    </div>
                </div>

                <div x-show="activeTab === 'ui'" style="display: none;" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" class="p-6 sm:p-8 space-y-8">
                    
                    <div>
                        <label class="label-base flex justify-between items-end mb-2">
                            <span>Tailwind Configuration (JSON)</span>
                            <span class="text-[9px] font-bold text-blue-600 bg-blue-50 dark:bg-blue-900/30 px-2 py-0.5 rounded uppercase font-mono tracking-wider">Cấu hình màu sắc, Font</span>
                        </label>
                        <p class="text-xs text-neutral-500 mb-3">Chỉnh sửa JSON để thay đổi mã màu chủ đạo toàn hệ thống (brand colors).</p>
                        <textarea x-model="form.tailwind_config" rows="7" placeholder="{ theme: { extend: { colors: { brand: { 500: '#465fff' } } } } }" class="input-base h-auto py-4 custom-scroll font-mono text-xs bg-slate-900 text-green-400 border-none rounded-[16px] shadow-inner"></textarea>
                    </div>

                    <div>
                        <label class="label-base flex justify-between items-end mb-2">
                            <span>Custom CSS Trình Bày (Global Styles)</span>
                            <span class="text-[9px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-900/30 px-2 py-0.5 rounded uppercase font-mono tracking-wider">CSS Tùy Chỉnh</span>
                        </label>
                        <p class="text-xs text-neutral-500 mb-3">Tự do nhúng các Class CSS, Keyframes hiệu ứng (như .fade-up, .floating-dot...) vào Head.</p>
                        <textarea x-model="form.custom_css" rows="6" placeholder="/* CSS Animations & Styles */" class="input-base h-auto py-4 custom-scroll font-mono text-xs bg-slate-900 text-sky-400 border-none rounded-[16px] shadow-inner"></textarea>
                    </div>

                    <div>
                        <label class="label-base flex justify-between items-end mb-2">
                            <span>Header Scripts (Analytics / Meta / Ads Pixel)</span>
                            <span class="text-[9px] font-bold text-purple-600 bg-purple-50 dark:bg-purple-900/30 px-2 py-0.5 rounded uppercase font-mono tracking-wider">Thẻ &lt;script&gt;</span>
                        </label>
                        <textarea x-model="form.header_script" rows="4" placeholder="" class="input-base h-auto py-4 custom-scroll font-mono text-xs bg-slate-900 text-yellow-400 border-none rounded-[16px] shadow-inner"></textarea>
                    </div>
                </div>

                <div x-show="activeTab === 'maintenance'" style="display: none;" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" class="p-6 sm:p-8 space-y-6">
                    
                    <div class="flex items-center justify-between p-6 bg-neutral-50 dark:bg-[#1e293b]/50 rounded-[20px] border border-neutral-200/60 dark:border-gray-800 shadow-sm">
                        <div>
                            <h3 class="text-[14px] font-black text-neutral-900 dark:text-white uppercase tracking-widest">Kích Hoạt Bảo Trì</h3>
                            <p class="text-xs text-neutral-500 mt-1">Hệ thống sẽ khóa truy cập với User, chỉ cho phép Admin sử dụng.</p>
                        </div>
                        
                        <div class="relative inline-block w-12 mr-2 align-middle select-none transition duration-200 ease-in">
                            <input type="checkbox" name="toggle" id="maintenance_toggle" x-model="isMaintenance" class="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer z-10 transition-transform duration-300 top-0 left-0 border-neutral-300 dark:border-gray-600"/>
                            <label for="maintenance_toggle" class="toggle-label block overflow-hidden h-6 rounded-full bg-neutral-300 dark:bg-gray-700 cursor-pointer transition-colors duration-300"></label>
                        </div>
                    </div>

                    <div x-show="isMaintenance" x-collapse>
                        <label class="label-base flex justify-between items-end mb-2">
                            <span>Nội Dung Thông Báo Bảo Trì (Trang Đích)</span>
                            <span class="text-[9px] font-bold text-blue-600 bg-blue-50 dark:bg-blue-900/30 px-2 py-0.5 rounded uppercase font-mono tracking-wider">Hỗ trợ HTML</span>
                        </label>
                        <textarea x-model="form.maintenance_html" rows="6" placeholder="<h1>Hệ thống đang nâng cấp</h1>" class="input-base h-auto py-4 custom-scroll font-mono leading-relaxed"></textarea>
                    </div>

                </div>

                <div x-show="activeTab === 'social'" style="display: none;" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" class="p-6 sm:p-8 space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="label-base"><i class="ri-telegram-line text-blue-500 mr-1"></i> Link Cộng Đồng</label>
                            <input type="text" x-model="form.community_link" class="input-base font-mono">
                        </div>
                        <div>
                            <label class="label-base"><i class="ri-customer-service-2-line text-emerald-500 mr-1"></i> Link Hỗ Trợ (CSKH)</label>
                            <input type="text" x-model="form.support_link" class="input-base font-mono">
                        </div>
                    </div>
                    
                    <div>
                        <label class="label-base flex justify-between items-end mb-2">
                            <span>Nội Dung Footer (Chân Trang)</span>
                            <span class="text-[9px] font-bold text-blue-600 bg-blue-50 dark:bg-blue-900/30 px-2 py-0.5 rounded uppercase font-mono tracking-wider">Hỗ trợ HTML</span>
                        </label>
                        <textarea x-model="form.footer_html" rows="4" class="input-base h-auto py-3 custom-scroll font-mono"></textarea>
                    </div>
                </div>

                <div class="px-6 py-5 border-t border-neutral-100 dark:border-gray-800 bg-neutral-50/80 dark:bg-transparent flex justify-end">
                    <button @click="saveSettings()" :disabled="loading" class="w-full sm:w-auto h-12 px-10 bg-neutral-900 hover:bg-black dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 text-white rounded-[14px] text-[13px] font-black uppercase tracking-widest transition-all shadow-md flex items-center justify-center gap-2 focus:outline-none disabled:opacity-70 disabled:cursor-not-allowed">
                        <i x-show="!loading" class="ri-save-3-line text-[16px]"></i>
                        <i x-show="loading" class="ri-loader-4-line animate-spin text-[16px]"></i>
                        <span x-text="loading ? 'Đang lưu hệ thống...' : 'Lưu Cấu Hình Mới'"></span>
                    </button>
                </div>

            </div>
        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('settingsManager', () => ({
                activeTab: 'general',
                loading: false,
                isMaintenance: <?= (isset($settings['maintenance_mode']) && $settings['maintenance_mode'] === '1') ? 'true' : 'false' ?>,
                form: {
                    site_title: <?= json_encode($settings['site_title'] ?? '') ?>,
                    site_keywords: <?= json_encode($settings['site_keywords'] ?? '') ?>,
                    site_description: <?= json_encode($settings['site_description'] ?? '') ?>,
                    navbar_logo: <?= json_encode($settings['navbar_logo'] ?? '') ?>,
                    favicon: <?= json_encode($settings['favicon'] ?? '') ?>,
                    community_link: <?= json_encode($settings['community_link'] ?? '') ?>,
                    support_link: <?= json_encode($settings['support_link'] ?? '') ?>,
                    footer_html: <?= json_encode($settings['footer_html'] ?? '') ?>,
                    maintenance_html: <?= json_encode($settings['maintenance_html'] ?? '') ?>,
                    
                    // Cấu hình UI
                    tailwind_config: <?= json_encode($settings['tailwind_config'] ?? "{ theme: { extend: { colors: { brand: { 500: '#3b82f6' } } } } }") ?>,
                    custom_css: <?= json_encode($settings['custom_css'] ?? "/* Custom CSS */") ?>,
                    header_script: <?= json_encode($settings['header_script'] ?? "") ?>,
                    
                    // Cấu hình Bảo Mật
                    geetest_id: <?= json_encode($settings['geetest_id'] ?? '') ?>,
                    geetest_key: <?= json_encode($settings['geetest_key'] ?? '') ?>,
                    max_register_per_ip: <?= json_encode($settings['max_register_per_ip'] ?? '3') ?>
                },
                
                async saveSettings() {
                    this.loading = true;
                    const payload = { ...this.form, maintenance_mode: this.isMaintenance ? '1' : '0' };
                    
                    try {
                        const res = await fetch('/api-handler?action=save_settings', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(payload)
                        });
                        const data = await res.json();
                        if(data.status === 'success') {
                            Swal.fire({ icon: 'success', title: 'Thành công', text: 'Cấu hình đã được áp dụng toàn trang!', confirmButtonColor: '#171717', customClass: { popup: document.documentElement.classList.contains('dark') ? 'bg-gray-800 text-white' : '' }});
                        } else {
                            Swal.fire('Lỗi', data.message, 'error');
                        }
                    } catch(e) {
                        Swal.fire('Lỗi', 'Mất kết nối tới máy chủ.', 'error');
                    } finally {
                        this.loading = false;
                    }
                }
            }));
        });
    </script>
</body>
</html>