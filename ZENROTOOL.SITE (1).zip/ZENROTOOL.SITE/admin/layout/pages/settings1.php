<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin
if (!isset($_SESSION['user_id'])) { header("Location: /auth/#login"); exit; }
$stmtUser = $pdo->prepare("SELECT role FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);
if (!$user || strtolower($user['role']) !== 'admin') { header("Location: /home"); exit; }

// Lấy toàn bộ Setting từ Database
$stmt = $pdo->query("SELECT * FROM settings");
$rawSettings = $stmt->fetchAll(PDO::FETCH_ASSOC);
$settings = [];
foreach ($rawSettings as $s) {
    $settings[$s['key']] = $s['value'];
}

$page_title = 'Cài Đặt Hệ Thống';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); }
        .fade-in { animation: fadeIn 0.4s ease-out forwards; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        
        /* Cấu trúc Input Minimalist */
        .input-base {
            width: 100%; height: 44px; padding: 0 16px; 
            background-color: #f5f5f5; border: 1px solid #e5e5e5; border-radius: 12px;
            font-size: 13px; font-weight: 500; color: #171717; outline: none; transition: all 0.2s ease;
        }
        .dark .input-base { background-color: #111827; border-color: #374151; color: #ffffff; }
        .input-base:focus { border-color: #3b82f6; box-shadow: 0 0 0 3px rgba(59,130,246,0.15); }
        .label-base { display: block; font-size: 11px; font-weight: 700; color: #737373; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 8px; }
        .dark .label-base { color: #9ca3af; }

        /* Custom Toggle Switch */
        .toggle-checkbox:checked {
            right: 0;
            border-color: #10b981;
        }
        .toggle-checkbox:checked + .toggle-label {
            background-color: #10b981;
        }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-neutral-50 dark:bg-gray-900 text-neutral-800 dark:text-gray-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 w-full max-w-5xl mx-auto fade-in" x-data="settingsManager()">
            
            <div class="mb-8">
                <h1 class="text-2xl sm:text-3xl font-black text-neutral-900 dark:text-white uppercase tracking-tight">Cấu Hình Website</h1>
                <p class="text-[13px] text-neutral-500 dark:text-gray-400 mt-1">Quản lý chuyên sâu các thông số hoạt động của hệ thống.</p>
            </div>

            <div class="flex items-center gap-2 overflow-x-auto pb-4 mb-4 scrollbar-hide border-b border-neutral-200 dark:border-gray-700">
                <button @click="activeTab = 'general'" :class="activeTab === 'general' ? 'border-neutral-900 text-neutral-900 dark:border-white dark:text-white' : 'border-transparent text-neutral-400 hover:text-neutral-700 dark:hover:text-gray-300'" class="px-4 py-2 border-b-2 font-bold text-[13px] uppercase tracking-widest transition-colors whitespace-nowrap focus:outline-none">
                    <i class="ri-global-line mr-1"></i> Thông Tin Chung
                </button>
                <button @click="activeTab = 'maintenance'" :class="activeTab === 'maintenance' ? 'border-neutral-900 text-neutral-900 dark:border-white dark:text-white' : 'border-transparent text-neutral-400 hover:text-neutral-700 dark:hover:text-gray-300'" class="px-4 py-2 border-b-2 font-bold text-[13px] uppercase tracking-widest transition-colors whitespace-nowrap focus:outline-none">
                    <i class="ri-tools-line mr-1"></i> Bảo Trì
                </button>
                <button @click="activeTab = 'social'" :class="activeTab === 'social' ? 'border-neutral-900 text-neutral-900 dark:border-white dark:text-white' : 'border-transparent text-neutral-400 hover:text-neutral-700 dark:hover:text-gray-300'" class="px-4 py-2 border-b-2 font-bold text-[13px] uppercase tracking-widest transition-colors whitespace-nowrap focus:outline-none">
                    <i class="ri-share-line mr-1"></i> Liên Kết & Mạng Xã Hội
                </button>
            </div>

            <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-soft border border-neutral-200 dark:border-gray-700 overflow-hidden">
                
                <div x-show="activeTab === 'general'" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" class="p-6 sm:p-8 space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="label-base">Tiêu đề Website (Title)</label>
                            <input type="text" x-model="form.site_title" class="input-base">
                        </div>
                        <div>
                            <label class="label-base">Từ khóa SEO (Keywords)</label>
                            <input type="text" x-model="form.site_keywords" class="input-base">
                        </div>
                    </div>
                    
                    <div>
                        <label class="label-base">Mô tả Website (Description)</label>
                        <textarea x-model="form.site_description" rows="3" class="input-base h-auto py-3 resize-y"></textarea>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="label-base">Logo Navbar (URL)</label>
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-lg bg-neutral-100 dark:bg-gray-900 border border-neutral-200 dark:border-gray-700 p-1 flex justify-center items-center shrink-0">
                                    <img :src="form.navbar_logo || 'https://placehold.co/100x100?text=Logo'" class="max-w-full max-h-full object-contain">
                                </div>
                                <input type="text" x-model="form.navbar_logo" class="input-base font-mono">
                            </div>
                        </div>
                        <div>
                            <label class="label-base">Favicon (URL)</label>
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-lg bg-neutral-100 dark:bg-gray-900 border border-neutral-200 dark:border-gray-700 p-1 flex justify-center items-center shrink-0">
                                    <img :src="form.favicon || 'https://placehold.co/100x100?text=Fav'" class="max-w-full max-h-full object-contain">
                                </div>
                                <input type="text" x-model="form.favicon" class="input-base font-mono">
                            </div>
                        </div>
                    </div>
                </div>

                <div x-show="activeTab === 'maintenance'" style="display: none;" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" class="p-6 sm:p-8 space-y-6">
                    
                    <div class="flex items-center justify-between p-5 bg-neutral-50 dark:bg-gray-900 rounded-xl border border-neutral-200 dark:border-gray-700 shadow-sm">
                        <div>
                            <h3 class="text-[14px] font-black text-neutral-900 dark:text-white uppercase tracking-widest">Chế Độ Bảo Trì</h3>
                            <p class="text-xs text-neutral-500 mt-1">Khi bật, tất cả người dùng (trừ Admin) sẽ nhìn thấy trang thông báo bảo trì.</p>
                        </div>
                        
                        <div class="relative inline-block w-12 mr-2 align-middle select-none transition duration-200 ease-in">
                            <input type="checkbox" name="toggle" id="maintenance_toggle" x-model="isMaintenance" class="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer z-10 transition-transform duration-300 top-0 left-0 border-neutral-300 dark:border-gray-600"/>
                            <label for="maintenance_toggle" class="toggle-label block overflow-hidden h-6 rounded-full bg-neutral-300 dark:bg-gray-700 cursor-pointer transition-colors duration-300"></label>
                        </div>
                    </div>

                    <div x-show="isMaintenance" x-collapse>
                        <label class="label-base flex justify-between items-end mb-2">
                            <span>Nội Dung Thông Báo Bảo Trì</span>
                            <span class="text-[9px] font-bold text-blue-600 bg-blue-50 dark:bg-blue-900/30 px-2 py-0.5 rounded uppercase font-mono tracking-wider">Hỗ trợ HTML</span>
                        </label>
                        <textarea x-model="form.maintenance_html" rows="6" placeholder="<h1>Website đang bảo trì</h1><p>Vui lòng quay lại sau ít phút...</p>" class="input-base h-auto py-4 custom-scroll font-mono leading-relaxed"></textarea>
                    </div>

                </div>

                <div x-show="activeTab === 'social'" style="display: none;" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" class="p-6 sm:p-8 space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="label-base"><i class="ri-telegram-line text-blue-500 mr-1"></i> Link Group Cộng Đồng</label>
                            <input type="text" x-model="form.community_link" class="input-base font-mono">
                        </div>
                        <div>
                            <label class="label-base"><i class="ri-customer-service-2-line text-emerald-500 mr-1"></i> Link Liên Hệ Hỗ Trợ (CSKH)</label>
                            <input type="text" x-model="form.support_link" class="input-base font-mono">
                        </div>
                    </div>
                    
                    <div>
                        <label class="label-base flex justify-between items-end mb-2">
                            <span>Nội Dung Footer (Chân Trang)</span>
                            <span class="text-[9px] font-bold text-blue-600 bg-blue-50 dark:bg-blue-900/30 px-2 py-0.5 rounded uppercase font-mono tracking-wider">Hỗ trợ HTML</span>
                        </label>
                        <textarea x-model="form.footer_html" rows="4" class="input-base h-auto py-3 custom-scroll font-mono"></textarea>
                    </div>
                </div>

                <div class="px-6 py-5 border-t border-neutral-100 dark:border-gray-700 bg-neutral-50/80 dark:bg-gray-800/80 flex justify-end">
                    <button @click="saveSettings()" :disabled="loading" class="w-full sm:w-auto h-12 px-10 bg-neutral-900 hover:bg-black dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 text-white rounded-xl text-[13px] font-black uppercase tracking-widest transition-all shadow-md flex items-center justify-center gap-2 focus:outline-none disabled:opacity-70 disabled:cursor-not-allowed">
                        <i x-show="!loading" class="ri-save-3-line text-[16px]"></i>
                        <i x-show="loading" class="ri-loader-4-line animate-spin text-[16px]"></i>
                        <span x-text="loading ? 'Đang lưu...' : 'Lưu Cấu Hình'"></span>
                    </button>
                </div>

            </div>
        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('settingsManager', () => ({
                activeTab: 'general',
                loading: false,
                isMaintenance: <?= (isset($settings['maintenance_mode']) && $settings['maintenance_mode'] === '1') ? 'true' : 'false' ?>,
                form: {
                    site_title: <?= json_encode($settings['site_title'] ?? '') ?>,
                    site_keywords: <?= json_encode($settings['site_keywords'] ?? '') ?>,
                    site_description: <?= json_encode($settings['site_description'] ?? '') ?>,
                    navbar_logo: <?= json_encode($settings['navbar_logo'] ?? '') ?>,
                    favicon: <?= json_encode($settings['favicon'] ?? '') ?>,
                    community_link: <?= json_encode($settings['community_link'] ?? '') ?>,
                    support_link: <?= json_encode($settings['support_link'] ?? '') ?>,
                    footer_html: <?= json_encode($settings['footer_html'] ?? '') ?>,
                    maintenance_html: <?= json_encode($settings['maintenance_html'] ?? '') ?>
                },
                
                async saveSettings() {
                    this.loading = true;
                    // Bổ sung dữ liệu trạng thái bảo trì vào form
                    const payload = { ...this.form, maintenance_mode: this.isMaintenance ? '1' : '0' };
                    
                    try {
                        const res = await fetch('/api-handler?action=save_settings', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(payload)
                        });
                        const data = await res.json();
                        if(data.status === 'success') {
                            Swal.fire({ icon: 'success', title: 'Thành công', text: 'Đã cập nhật hệ thống!', confirmButtonColor: '#171717', customClass: { popup: document.documentElement.classList.contains('dark') ? 'bg-gray-800 text-white' : '' }});
                        } else {
                            Swal.fire('Lỗi', data.message, 'error');
                        }
                    } catch(e) {
                        Swal.fire('Lỗi', 'Không thể kết nối máy chủ.', 'error');
                    } finally {
                        this.loading = false;
                    }
                }
            }));
        });
    </script>
</body>
</html>
