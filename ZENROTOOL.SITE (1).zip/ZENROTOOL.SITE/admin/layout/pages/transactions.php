<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin
if (!isset($_SESSION['user_id'])) { header("Location: /auth/#login"); exit; }
$stmtCheck = $pdo->prepare("SELECT role FROM users WHERE id = ?");
$stmtCheck->execute([$_SESSION['user_id']]);
if (strtolower($stmtCheck->fetchColumn()) !== 'admin') { header("Location: /home"); exit; }

// ==========================================
// 1. XỬ LÝ BỘ LỌC (FILTERS)
// ==========================================
// ĐIỀU KIỆN 1: CHỈ LẤY GIAO DỊCH THÀNH CÔNG
// ĐIỀU KIỆN 2: CHỈ LẤY AUTO BANK (Không chứa từ khóa nạp thủ công)
$where = [
    "t.status IN ('paid', 'success', 'completed')",
    "LOWER(t.content) NOT LIKE '%admin%'",
    "LOWER(t.content) NOT LIKE '%cộng%'",
    "LOWER(t.content) NOT LIKE '%thủ công%'"
];
$params = [];

$filter_ref = $_GET['ref'] ?? '';
$filter_time = $_GET['time'] ?? 'all';
$filter_start = $_GET['start_date'] ?? '';
$filter_end = $_GET['end_date'] ?? '';

// Lọc theo mã giao dịch
if (!empty($filter_ref)) {
    $where[] = "t.order_token LIKE :ref";
    $params[':ref'] = '%' . $filter_ref . '%';
}

// Lọc nhanh theo thời gian
if ($filter_time === 'today') {
    $where[] = "DATE(t.created_at) = CURDATE()";
} elseif ($filter_time === 'week') {
    $where[] = "YEARWEEK(t.created_at, 1) = YEARWEEK(CURDATE(), 1)";
} elseif ($filter_time === 'month') {
    $where[] = "MONTH(t.created_at) = MONTH(CURDATE()) AND YEAR(t.created_at) = YEAR(CURDATE())";
}

// Lọc theo khoảng ngày
if (!empty($filter_start)) {
    $where[] = "DATE(t.created_at) >= :start_date";
    $params[':start_date'] = $filter_start;
}
if (!empty($filter_end)) {
    $where[] = "DATE(t.created_at) <= :end_date";
    $params[':end_date'] = $filter_end;
}

$whereClause = "WHERE " . implode(' AND ', $where);

// ==========================================
// 2. XỬ LÝ PHÂN TRANG
// ==========================================
$limit = 20; // Tối đa 20 giao dịch/trang
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

// Đếm tổng số bản ghi
$countQuery = "SELECT COUNT(*) FROM transfer_history t $whereClause";
$stmtCount = $pdo->prepare($countQuery);
foreach ($params as $key => $val) {
    $stmtCount->bindValue($key, $val);
}
$stmtCount->execute();
$totalRecords = $stmtCount->fetchColumn();
$totalPages = ceil($totalRecords / $limit);

// Lấy dữ liệu giao dịch
$dataQuery = "SELECT t.*, u.username FROM transfer_history t LEFT JOIN users u ON t.user_id = u.id $whereClause ORDER BY t.id DESC LIMIT :limit OFFSET :offset";
$stmtData = $pdo->prepare($dataQuery);
foreach ($params as $key => $val) {
    $stmtData->bindValue($key, $val);
}
$stmtData->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmtData->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmtData->execute();
$transactions = $stmtData->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Lịch Sử Auto Bank';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); }
        .fade-in-up { animation: fadeInUp 0.4s ease-out forwards; }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(15px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true', toggleDarkMode() { this.darkMode = !this.darkMode; localStorage.setItem('darkMode', this.darkMode); } }" 
      :class="{ 'dark': darkMode }" 
      class="bg-[#f8fafc] dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 w-full max-w-[1400px] mx-auto fade-in-up">
            
            <div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                    <h1 class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white uppercase tracking-wide">Lịch Sử Auto Bank</h1>
                    <p class="text-xs sm:text-sm text-slate-500 dark:text-gray-400 mt-1">Danh sách các giao dịch nạp tiền hoàn toàn tự động qua hệ thống.</p>
                </div>
            </div>

            <div class="bg-white dark:bg-gray-800/80 rounded-2xl border border-slate-100 dark:border-gray-700/50 shadow-soft p-5 mb-6">
                <form method="GET" action="" class="grid grid-cols-1 md:grid-cols-12 gap-4">
                    
                    <div class="md:col-span-3">
                        <label class="block text-[10px] font-bold text-slate-400 dark:text-gray-500 uppercase tracking-widest mb-1.5">Mã Giao Dịch</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400"><i class="ri-search-line"></i></div>
                            <input type="text" name="ref" value="<?= htmlspecialchars($filter_ref) ?>" placeholder="Nhập mã tham chiếu..." class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2 pl-9 pr-3 text-sm focus:outline-none focus:border-blue-500 dark:text-white transition-colors">
                        </div>
                    </div>

                    <div class="md:col-span-3">
                        <label class="block text-[10px] font-bold text-slate-400 dark:text-gray-500 uppercase tracking-widest mb-1.5">Mốc Thời Gian</label>
                        <select name="time" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2 px-3 text-sm focus:outline-none focus:border-blue-500 dark:text-white transition-colors appearance-none">
                            <option value="all" <?= $filter_time === 'all' ? 'selected' : '' ?>>Tất cả thời gian</option>
                            <option value="today" <?= $filter_time === 'today' ? 'selected' : '' ?>>Hôm nay</option>
                            <option value="week" <?= $filter_time === 'week' ? 'selected' : '' ?>>Tuần này</option>
                            <option value="month" <?= $filter_time === 'month' ? 'selected' : '' ?>>Tháng này</option>
                        </select>
                    </div>

                    <div class="md:col-span-2">
                        <label class="block text-[10px] font-bold text-slate-400 dark:text-gray-500 uppercase tracking-widest mb-1.5">Từ Ngày</label>
                        <input type="date" name="start_date" value="<?= htmlspecialchars($filter_start) ?>" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2 px-3 text-sm focus:outline-none focus:border-blue-500 dark:text-white transition-colors">
                    </div>

                    <div class="md:col-span-2">
                        <label class="block text-[10px] font-bold text-slate-400 dark:text-gray-500 uppercase tracking-widest mb-1.5">Đến Ngày</label>
                        <input type="date" name="end_date" value="<?= htmlspecialchars($filter_end) ?>" class="w-full bg-slate-50 dark:bg-gray-900/50 border border-slate-200 dark:border-gray-700 rounded-xl py-2 px-3 text-sm focus:outline-none focus:border-blue-500 dark:text-white transition-colors">
                    </div>

                    <div class="md:col-span-2 flex items-end gap-2">
                        <button type="submit" class="flex-1 bg-slate-900 hover:bg-black dark:bg-white dark:text-slate-900 dark:hover:bg-gray-100 text-white rounded-xl py-2 font-bold text-sm transition-colors shadow-sm">
                            <i class="ri-filter-3-line"></i> Lọc
                        </button>
                        <a href="/admin/transactions" class="w-10 h-[38px] flex items-center justify-center bg-slate-100 dark:bg-gray-800 hover:bg-slate-200 dark:hover:bg-gray-700 text-slate-600 dark:text-gray-300 rounded-xl transition-colors shadow-sm" title="Làm mới bộ lọc">
                            <i class="ri-refresh-line"></i>
                        </a>
                    </div>
                </form>
            </div>

            <div class="bg-white dark:bg-gray-800/80 rounded-2xl border border-slate-100 dark:border-gray-700/50 shadow-soft overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full">
                        <thead class="bg-slate-50/50 dark:bg-gray-900/30 border-b border-slate-100 dark:border-gray-700/50">
                            <tr class="whitespace-nowrap">
                                <th class="px-5 py-4 text-left text-[11px] font-bold text-slate-500 dark:text-gray-400 uppercase tracking-wider">Mã Giao Dịch</th>
                                <th class="px-5 py-4 text-left text-[11px] font-bold text-slate-500 dark:text-gray-400 uppercase tracking-wider">Người Nạp</th>
                                <th class="px-5 py-4 text-left text-[11px] font-bold text-slate-500 dark:text-gray-400 uppercase tracking-wider">Hình Thức</th>
                                <th class="px-5 py-4 text-left text-[11px] font-bold text-slate-500 dark:text-gray-400 uppercase tracking-wider">Số Tiền</th>
                                <th class="px-5 py-4 text-left text-[11px] font-bold text-slate-500 dark:text-gray-400 uppercase tracking-wider">Thời Gian</th>
                                <th class="px-5 py-4 text-left text-[11px] font-bold text-slate-500 dark:text-gray-400 uppercase tracking-wider">Trạng Thái</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-50 dark:divide-gray-700/30">
                            <?php if (empty($transactions)): ?>
                            <tr>
                                <td colspan="6" class="px-5 py-16 text-center">
                                    <div class="w-16 h-16 rounded-full bg-slate-50 dark:bg-gray-800 flex items-center justify-center mx-auto mb-3">
                                        <i class="ri-inbox-line text-2xl text-slate-400"></i>
                                    </div>
                                    <p class="text-slate-500 dark:text-gray-400 font-medium">Chưa có giao dịch Auto Bank nào.</p>
                                </td>
                            </tr>
                            <?php else: ?>
                                <?php foreach ($transactions as $row): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-gray-800/30 transition-colors">
                                    
                                    <td class="px-5 py-4 whitespace-nowrap">
                                        <button onclick="copyOrderToken('<?= htmlspecialchars($row['order_token']) ?>')" 
                                                class="group inline-flex items-center gap-1.5 font-mono text-[11px] font-bold text-slate-600 dark:text-gray-300 bg-slate-100 dark:bg-gray-900/50 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-gray-700 hover:bg-blue-50 hover:text-blue-600 dark:hover:bg-blue-900/30 dark:hover:text-blue-400 dark:hover:border-blue-800/50 transition-all" 
                                                title="Nhấn để copy toàn bộ mã">
                                            <?= htmlspecialchars(substr($row['order_token'], 0, 15)) ?>...
                                            <i class="ri-file-copy-line text-slate-400 group-hover:text-blue-500 transition-colors"></i>
                                        </button>
                                    </td>
                                    
                                    <td class="px-5 py-4">
                                        <div class="flex items-center gap-3">
                                            <div class="w-8 h-8 rounded-full bg-slate-100 dark:bg-gray-800 border border-slate-200 dark:border-gray-700 flex items-center justify-center text-slate-500 dark:text-gray-400 font-black text-xs uppercase shrink-0">
                                                <?= substr($row['username'] ?? 'U', 0, 1) ?>
                                            </div>
                                            <div>
                                                <div class="text-[13px] font-bold text-slate-800 dark:text-white"><?= htmlspecialchars($row['username'] ?? 'Unknown') ?></div>
                                                <div class="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">ID: <?= $row['user_id'] ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    
                                    <td class="px-5 py-4 whitespace-nowrap">
                                        <span class="inline-flex items-center px-2 py-1 rounded-md text-[10px] font-bold border uppercase tracking-wider bg-blue-50 text-blue-600 border-blue-100 dark:bg-blue-900/20 dark:text-blue-400 dark:border-blue-800/30">
                                            <i class="ri-robot-2-line mr-1.5 text-xs"></i> Auto Bank
                                        </span>
                                    </td>

                                    <td class="px-5 py-4">
                                        <div class="text-sm font-black text-emerald-500 dark:text-emerald-400 mb-0.5">+<?= number_format($row['amount']) ?>đ</div>
                                        <?php if(!empty($row['content'])): ?>
                                        <div class="text-[10px] font-medium text-slate-500 dark:text-gray-400 mt-0.5 truncate max-w-[200px]" title="<?= htmlspecialchars($row['content']) ?>">
                                            <?= htmlspecialchars($row['content']) ?>
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td class="px-5 py-4 whitespace-nowrap">
                                        <div class="text-xs font-semibold text-slate-700 dark:text-gray-300"><?= date('H:i - d/m/Y', strtotime($row['created_at'])) ?></div>
                                    </td>

                                    <td class="px-5 py-4 whitespace-nowrap">
                                        <span class="inline-flex items-center px-2.5 py-1 rounded-md text-[10px] font-bold border uppercase tracking-wider bg-emerald-50 text-emerald-600 border-emerald-100 dark:bg-emerald-900/20 dark:text-emerald-400 dark:border-emerald-800/30">
                                            <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1.5"></span> Thành Công
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($totalPages > 1): ?>
                <div class="px-5 py-4 border-t border-slate-100 dark:border-gray-700/50 flex items-center justify-between bg-slate-50/30 dark:bg-transparent">
                    <div class="text-xs text-slate-500 dark:text-gray-400 font-medium">
                        Đang xem trang <span class="font-bold text-slate-800 dark:text-white"><?= $page ?></span> / <?= $totalPages ?>
                    </div>
                    
                    <?php
                        $qs = $_GET;
                        unset($qs['page']);
                        $queryString = http_build_query($qs);
                        $baseUrl = "?$queryString" . ($queryString ? '&' : '');
                    ?>
                    
                    <div class="flex items-center gap-1.5">
                        <?php if ($page > 1): ?>
                            <a href="<?= $baseUrl . 'page=' . ($page - 1) ?>" class="w-8 h-8 flex items-center justify-center rounded-lg border border-slate-200 dark:border-gray-700 text-slate-500 hover:bg-slate-100 dark:hover:bg-gray-800 transition-colors"><i class="ri-arrow-left-s-line"></i></a>
                        <?php endif; ?>

                        <?php
                            $startPage = max(1, $page - 2);
                            $endPage = min($totalPages, $page + 2);
                            for ($i = $startPage; $i <= $endPage; $i++):
                        ?>
                            <a href="<?= $baseUrl . 'page=' . $i ?>" class="w-8 h-8 flex items-center justify-center rounded-lg text-xs font-bold transition-colors <?= $i === $page ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-sm' : 'border border-slate-200 dark:border-gray-700 text-slate-500 hover:bg-slate-100 dark:hover:bg-gray-800' ?>">
                                <?= $i ?>
                            </a>
                        <?php endfor; ?>

                        <?php if ($page < $totalPages): ?>
                            <a href="<?= $baseUrl . 'page=' . ($page + 1) ?>" class="w-8 h-8 flex items-center justify-center rounded-lg border border-slate-200 dark:border-gray-700 text-slate-500 hover:bg-slate-100 dark:hover:bg-gray-800 transition-colors"><i class="ri-arrow-right-s-line"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        function copyOrderToken(token) {
            navigator.clipboard.writeText(token).then(() => {
                Swal.fire({
                    toast: true,
                    position: 'top-end',
                    icon: 'success',
                    title: 'Đã sao chép mã giao dịch!',
                    showConfirmButton: false,
                    timer: 2000,
                    customClass: {
                        popup: document.documentElement.classList.contains('dark') ? 'bg-gray-800 text-white' : ''
                    }
                });
            }).catch(() => {
                Swal.fire({ toast: true, position: 'top-end', icon: 'error', title: 'Lỗi sao chép', showConfirmButton: false, timer: 2000 });
            });
        }
    </script>
</body>
</html>
