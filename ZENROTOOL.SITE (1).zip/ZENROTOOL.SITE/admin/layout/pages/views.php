<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

if (!isset($_SESSION['user_id'])) { header("Location: /auth/#login"); exit; }
$stmtUser = $pdo->prepare("SELECT role FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);
if (!$user || strtolower($user['role']) !== 'admin') { header("Location: /home"); exit; }

$token = isset($_GET['token']) ? trim($_GET['token']) : '';
$stmtBlog = $pdo->prepare("SELECT * FROM blogs WHERE token = ? LIMIT 1");
$stmtBlog->execute([$token]);
$blog = $stmtBlog->fetch(PDO::FETCH_ASSOC);

if (!$blog) {
    die("<div style='padding:50px; text-align:center; font-family:sans-serif;'><h2>Bài viết không tồn tại.</h2><a href='/admin/blogs'>Quay lại</a></div>");
}

$page_title = 'Chỉnh sửa: ' . $blog['title'];
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <style>
        .shadow-soft { box-shadow: 0 10px 40px -10px rgba(0,0,0,0.04); }
        .fade-up { opacity: 0; transform: translateY(15px); animation: fadeUp 0.4s ease-out forwards; }
        @keyframes fadeUp { to { opacity: 1; transform: translateY(0); } }
        .custom-scroll::-webkit-scrollbar { width: 5px; height: 5px; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
        .dark .custom-scroll::-webkit-scrollbar-thumb { background: #334155; }
        
        /* Typography Content Preview chuẩn Minimalist */
        .html-preview-frame { font-size: 15px; line-height: 1.8; color: #334155; }
        .dark .html-preview-frame { color: #cbd5e1; }
        .html-preview-frame img { max-width: 100%; height: auto; border-radius: 16px; margin: 24px 0; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
        .html-preview-frame p { margin-bottom: 16px; }
        .html-preview-frame h1, .html-preview-frame h2, .html-preview-frame h3 { font-weight: 900; margin: 32px 0 16px 0; color: #0f172a; line-height: 1.3; }
        .dark .html-preview-frame h1, .dark .html-preview-frame h2, .dark .html-preview-frame h3 { color: #f8fafc; }
        .html-preview-frame b, .html-preview-frame strong { color: #0f172a; font-weight: 800; }
        .dark .html-preview-frame b, .dark .html-preview-frame strong { color: #ffffff; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" :class="{ 'dark': darkMode }" class="bg-[#f4f6f8] dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 w-full fade-up" x-data="blogDetailManager()">
            
            <div class="max-w-4xl mx-auto">
                <div class="flex justify-between items-center mb-6">
                    <a href="/admin/blogs" class="inline-flex items-center gap-2 text-[11px] font-bold text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white transition-colors uppercase tracking-widest bg-white dark:bg-[#0f172a] px-4 py-2 rounded-full border border-slate-200/60 dark:border-slate-800 shadow-sm focus:outline-none">
                        <i class="ri-arrow-left-line text-[14px]"></i> Quay Lại
                    </a>
                    <button @click="deleteBlog()" class="text-[11px] font-bold text-rose-500 hover:text-rose-600 transition-colors uppercase tracking-widest flex items-center gap-1.5 focus:outline-none bg-rose-50 dark:bg-rose-500/10 px-4 py-2 rounded-full">
                        <i class="ri-delete-bin-line"></i> Xóa Bài
                    </button>
                </div>

                <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                    <div class="bg-white dark:bg-[#0f172a] p-5 rounded-[20px] border border-slate-200/60 dark:border-slate-800 shadow-soft">
                        <div class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5"><i class="ri-eye-line text-blue-500 mr-1"></i> Lượt xem</div>
                        <div class="text-xl font-black text-slate-900 dark:text-white"><?= number_format($blog['views'] ?? 0) ?></div>
                    </div>
                    <div class="bg-white dark:bg-[#0f172a] p-5 rounded-[20px] border border-slate-200/60 dark:border-slate-800 shadow-soft">
                        <div class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5"><i class="ri-heart-3-line text-rose-500 mr-1"></i> Lượt thích</div>
                        <div class="text-xl font-black text-slate-900 dark:text-white"><?= number_format($blog['likes'] ?? 0) ?></div>
                    </div>
                    <div class="bg-white dark:bg-[#0f172a] p-5 rounded-[20px] border border-slate-200/60 dark:border-slate-800 shadow-soft">
                        <div class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5"><i class="ri-sort-desc text-amber-500 mr-1"></i> Vị trí ưu tiên</div>
                        <div class="text-xl font-black text-slate-900 dark:text-white">Top <?= number_format($blog['position'] ?? 0) ?></div>
                    </div>
                    <div class="bg-white dark:bg-[#0f172a] p-5 rounded-[20px] border border-slate-200/60 dark:border-slate-800 shadow-soft">
                        <div class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5"><i class="ri-key-line text-purple-500 mr-1"></i> Mã Token</div>
                        <div class="text-sm font-mono font-bold text-slate-600 dark:text-slate-400 truncate mt-1.5" title="<?= htmlspecialchars($blog['token']) ?>"><?= htmlspecialchars($blog['token']) ?></div>
                    </div>
                </div>

                <div class="bg-white dark:bg-[#0f172a] rounded-[24px] border border-slate-200/60 dark:border-slate-800 shadow-soft overflow-hidden">
                    
                    <div class="px-4 py-4 sm:px-8 border-b border-slate-100 dark:border-slate-800 flex justify-center bg-slate-50/50 dark:bg-slate-900/30">
                        <div class="flex bg-slate-100 dark:bg-[#1e293b] p-1.5 rounded-[14px] w-full sm:w-[400px]">
                            <button @click="mode = 'edit'" :class="mode === 'edit' ? 'bg-white dark:bg-[#0f172a] shadow-sm text-blue-600 dark:text-blue-400 font-bold' : 'text-slate-500 dark:text-slate-400 font-medium'" class="flex-1 py-2.5 rounded-xl text-[13px] transition-all focus:outline-none flex items-center justify-center gap-2">
                                <i class="ri-edit-line text-[15px]"></i> Chỉnh Sửa HTML
                            </button>
                            <button @click="mode = 'preview'" :class="mode === 'preview' ? 'bg-white dark:bg-[#0f172a] shadow-sm text-emerald-600 dark:text-emerald-400 font-bold' : 'text-slate-500 dark:text-slate-400 font-medium'" class="flex-1 py-2.5 rounded-xl text-[13px] transition-all focus:outline-none flex items-center justify-center gap-2">
                                <i class="ri-eye-line text-[15px]"></i> Xem Giao Diện
                            </button>
                        </div>
                    </div>

                    <div x-show="mode === 'edit'" x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100" class="p-5 sm:p-8 space-y-6">
                        
                        <div class="flex flex-col gap-2">
                            <label class="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Tiêu đề bài viết</label>
                            <input type="text" x-model="form.title" class="w-full h-12 px-4 bg-slate-50 dark:bg-[#1e293b] border-none rounded-xl text-[14px] font-bold text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500/30 outline-none transition-shadow">
                        </div>

                        <div class="flex flex-col gap-2">
                            <label class="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Tóm tắt nội dung</label>
                            <textarea x-model="form.short_description" rows="2" class="w-full p-4 bg-slate-50 dark:bg-[#1e293b] border-none rounded-xl text-[13px] font-medium text-slate-800 dark:text-white focus:ring-2 focus:ring-blue-500/30 outline-none transition-shadow resize-none"></textarea>
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            <div class="flex flex-col gap-2">
                                <label class="text-[11px] font-bold text-slate-500 uppercase tracking-widest">URL Ảnh bìa</label>
                                <input type="text" x-model="form.image" class="w-full h-12 px-4 bg-slate-50 dark:bg-[#1e293b] border-none rounded-xl text-[13px] font-mono text-slate-800 dark:text-white focus:ring-2 focus:ring-blue-500/30 outline-none transition-shadow">
                            </div>
                            <div class="grid grid-cols-2 gap-4">
                                <div class="flex flex-col gap-2">
                                    <label class="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Sắp xếp (Pos)</label>
                                    <input type="number" x-model.number="form.position" class="w-full h-12 px-4 bg-slate-50 dark:bg-[#1e293b] border-none rounded-xl text-[13px] font-bold text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500/30 outline-none transition-shadow text-center">
                                </div>
                                <div class="flex flex-col gap-2">
                                    <label class="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Trạng thái</label>
                                    <select x-model="form.status" class="w-full h-12 px-3 bg-slate-50 dark:bg-[#1e293b] border-none rounded-xl text-[13px] font-bold text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500/30 outline-none transition-shadow cursor-pointer appearance-none">
                                        <option value="active">Hiển thị</option>
                                        <option value="hidden">Ẩn bài</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="flex flex-col gap-2">
                            <div class="flex justify-between items-end">
                                <label class="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Mã HTML / Nội dung</label>
                                <span class="text-[10px] font-bold text-blue-500 bg-blue-50 dark:bg-blue-500/10 px-2 py-1 rounded lowercase font-mono">&lt;html&gt;</span>
                            </div>
                            <textarea x-model="form.content" rows="18" class="w-full p-5 bg-slate-50 dark:bg-[#1e293b] border-none rounded-xl text-[14px] font-mono text-slate-800 dark:text-gray-300 focus:ring-2 focus:ring-blue-500/30 outline-none transition-shadow custom-scroll leading-relaxed"></textarea>
                        </div>
                        
                        <div class="pt-4 border-t border-slate-100 dark:border-slate-800">
                            <button @click="save()" :disabled="loading" class="w-full h-14 bg-slate-900 hover:bg-black dark:bg-white dark:hover:bg-gray-100 text-white dark:text-slate-900 rounded-xl text-[13px] font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-md hover:shadow-lg focus:outline-none disabled:opacity-70 disabled:cursor-not-allowed">
                                <i x-show="!loading" class="ri-save-3-line text-[16px]"></i>
                                <i x-show="loading" class="ri-loader-4-line animate-spin text-[16px]"></i>
                                <span x-text="loading ? 'Đang lưu hệ thống...' : 'Lưu Thay Đổi'"></span>
                            </button>
                        </div>
                    </div>

                    <div x-show="mode === 'preview'" x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100" class="p-6 sm:p-10 bg-slate-50 dark:bg-gray-900" style="display: none;">
                        
                        <div class="bg-white dark:bg-[#0f172a] rounded-[24px] border border-slate-100 dark:border-slate-800 p-6 sm:p-10 shadow-sm mx-auto w-full">
                            
                            <div class="text-center mb-8">
                                <div class="inline-block text-[10px] font-black text-emerald-500 bg-emerald-50 dark:bg-emerald-500/10 px-3 py-1.5 rounded-full uppercase tracking-widest mb-4">
                                    <i class="ri-live-line mr-1"></i> Live Preview
                                </div>
                                <h1 class="text-2xl sm:text-4xl font-black text-slate-900 dark:text-white leading-tight mb-4" x-text="form.title || 'Tiêu đề bài viết...'"></h1>
                                <p class="text-[12px] text-slate-500 dark:text-slate-400 font-medium flex items-center justify-center gap-4">
                                    <span><i class="ri-time-line mr-1"></i><?= date('d/m/Y H:i', strtotime($blog['created_at'])) ?></span>
                                    <span><i class="ri-user-star-line mr-1"></i>Quản trị viên</span>
                                </p>
                            </div>

                            <div class="h-56 sm:h-[400px] w-full bg-slate-100 dark:bg-[#1e293b] rounded-2xl overflow-hidden mb-10">
                                <img :src="form.image || 'https://placehold.co/800x400/e2e8f0/475569?text=Image'" class="w-full h-full object-cover">
                            </div>
                            
                            <div class="html-preview-frame" x-html="form.content"></div>
                        </div>

                    </div>

                </div>
            </div>
        </main>
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('blogDetailManager', () => ({
                mode: 'edit', // 'edit' hoặc 'preview'
                loading: false,
                // Render JSON encode để không lỗi Syntax Javascript do nháy đơn, nháy kép
                form: {
                    token: <?= json_encode($blog['token']) ?>,
                    title: <?= json_encode($blog['title']) ?>,
                    short_description: <?= json_encode($blog['short_description']) ?>,
                    image: <?= json_encode($blog['image']) ?>,
                    content: <?= json_encode($blog['content']) ?>,
                    status: <?= json_encode($blog['status']) ?>,
                    position: <?= (int)$blog['position'] ?>
                },
                async save() {
                    this.loading = true;
                    try {
                        const res = await fetch('/api-handler?action=update_blog', { method: 'POST', body: JSON.stringify(this.form) });
                        const data = await res.json();
                        if(data.status==='success') Swal.fire({toast:true, position:'top-end', icon:'success', title: data.message, showConfirmButton:false, timer:2000});
                        else Swal.fire('Lỗi', data.message, 'error');
                    } catch(e) { Swal.fire('Lỗi', 'Mất kết nối máy chủ.', 'error'); } 
                    finally { this.loading = false; }
                },
                async deleteBlog() {
                    const cf = await Swal.fire({ 
                        title: 'Xóa bài viết này?', 
                        text: "Dữ liệu sẽ bị xóa vĩnh viễn khỏi Database.",
                        icon: 'warning', 
                        showCancelButton: true, 
                        confirmButtonColor: '#ef4444', 
                        cancelButtonColor: '#64748b',
                        confirmButtonText: 'Đồng ý xóa',
                        cancelButtonText: 'Hủy',
                        background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#ffffff',
                        color: document.documentElement.classList.contains('dark') ? '#ffffff' : '#0f172a'
                    });
                    if(cf.isConfirmed) {
                        try {
                            const res = await fetch('/api-handler?action=delete_blog', { method: 'POST', body: JSON.stringify({token: this.form.token}) });
                            const data = await res.json();
                            if(data.status==='success') window.location.href = '/admin/blogs';
                            else Swal.fire('Lỗi', data.message, 'error');
                        } catch(e) { Swal.fire('Lỗi', 'Không thể xóa.', 'error'); }
                    }
                }
            }));
        });
    </script>
</body>
</html>
