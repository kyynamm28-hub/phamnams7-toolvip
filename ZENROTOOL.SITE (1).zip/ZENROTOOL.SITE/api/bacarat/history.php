<?php
ob_start();
if (session_status() === PHP_SESSION_NONE) { session_start(); }

// 1. KIỂM TRA BẢO MẬT: CHỈ CHO PHÉP GỌI AJAX NỘI BỘ
if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    header('Location: https://google.com'); 
    exit;
}

// 2. KIỂM TRA ĐĂNG NHẬP VÀ TOKEN BẢO MẬT
if (!isset($_SESSION['user_id'])) {
    header('Location: https://google.com'); 
    exit;
}

header('Content-Type: application/json; charset=utf-8');

if (!isset($_POST['secure_token']) || $_POST['secure_token'] !== $_SESSION['zenro_secure_token']) {
    die(json_encode(['status' => 'error', 'msg' => 'Bảo vệ cấp 1: Chặn truy cập trái phép.']));
}

// 3. GỌI API GỐC LẤY DỮ LIỆU BACCARAT
$api_url = "http://103.249.117.228:46566/history";
$ch = curl_init($api_url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_TIMEOUT => 5,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
]);
$raw_json = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// 4. MÃ HÓA AES NẾU THÀNH CÔNG
if ($http_code >= 200 && $http_code < 300 && $raw_json) {
    // Thuật toán Mã hóa AES-256-CBC
    $session_key = bin2hex(random_bytes(32));
    $session_iv  = bin2hex(random_bytes(16));
    $key_hash = hash('sha256', $session_key, true);
    $iv_hash  = substr(hash('sha256', $session_iv), 0, 16);
    
    $encrypted = openssl_encrypt($raw_json, 'aes-256-cbc', $key_hash, OPENSSL_RAW_DATA, $iv_hash);
    $base64_safe = strtr(base64_encode($encrypted), '+/', '-_');
    
    ob_end_clean();
    echo json_encode(['status' => 'success', 'data' => $base64_safe, 'k' => $session_key, 'i' => $session_iv]);
} else {
    ob_end_clean();
    echo json_encode(['status' => 'error', 'msg' => 'Server Baccarat Đang Bảo Trì Hoặc Quá Tải.']);
}
exit;
?>
