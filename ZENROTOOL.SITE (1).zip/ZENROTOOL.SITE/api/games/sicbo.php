<?php
ob_start();
if (session_status() === PHP_SESSION_NONE) { session_start(); }

// 1. KIỂM TRA BẢO MẬT: CHẶN TRUY CẬP TRỰC TIẾP
if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    header('Location: https://google.com'); 
    exit;
}

// 2. KIỂM TRA ĐĂNG NHẬP VÀ TOKEN BẢO MẬT
if (!isset($_SESSION['user_id'])) {
    header('Location: https://google.com'); 
    exit;
}

header('Content-Type: application/json; charset=utf-8');

if (!isset($_POST['secure_token']) || $_POST['secure_token'] !== $_SESSION['zenro_secure_token']) {
    die(json_encode(['status' => 'error', 'msg' => 'Bảo vệ cấp 1: Chặn truy cập trái phép.']));
}

require_once __DIR__ . '/../../config/database.php';

$slug = $_POST['slug'] ?? '';
if (empty($slug)) {
    die(json_encode(['status' => 'error', 'msg' => 'Thiếu định danh Game.']));
}

// Lấy thông tin cấu hình của Game
$stmtGame = $pdo->prepare("SELECT * FROM games WHERE slug = ? AND status = 'active' LIMIT 1");
$stmtGame->execute([$slug]);
$game = $stmtGame->fetch(PDO::FETCH_ASSOC);

if (!$game || empty($game['api_predict_url'])) {
    die(json_encode(['status' => 'error', 'msg' => 'Trò chơi chưa được cấu hình API ngầm.']));
}

// Gọi API Đối tác
$api_url = $game['api_predict_url'];
$ch = curl_init($api_url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_TIMEOUT => 5,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
]);
$raw_json = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($http_code >= 200 && $http_code < 300 && $raw_json) {
    $raw_data = json_decode($raw_json, true);
    
    function getMapVal($array, $path) {
        if(empty($path)) return '';
        $keys = explode('.', $path);
        foreach ($keys as $key) {
            if (is_array($array) && array_key_exists($key, $array)) {
                $array = $array[$key];
            } else { return ''; }
        }
        return $array;
    }

    // Lọc dữ liệu theo Config của Admin (Bổ sung thêm Dự Đoán Vị)
    $standardized_data = [
        'phien_hien_tai' => getMapVal($raw_data, $game['map_notify']) ?: '---',
        'do_tin_cay'     => getMapVal($raw_data, $game['map_rate']) ?: '0%',
        'du_doan'        => getMapVal($raw_data, $game['map_predict']) ?: '---',
        'du_doan_vi'     => getMapVal($raw_data, $game['map_predict_vi']) ?: '---',
        'phien'          => getMapVal($raw_data, $game['map_history_prev']) ?: '---',
        'ket_qua'        => getMapVal($raw_data, $game['map_history_result']) ?: '---',
        'tong'           => getMapVal($raw_data, $game['map_history_sum']) ?: '-',
        'xuc_xac_1'      => getMapVal($raw_data, $game['map_history_dice1']) ?: '-',
        'xuc_xac_2'      => getMapVal($raw_data, $game['map_history_dice2']) ?: '-',
        'xuc_xac_3'      => getMapVal($raw_data, $game['map_history_dice3']) ?: '-'
    ];

    $json_to_encrypt = json_encode($standardized_data);

    // Thuật toán Mã hóa AES-256-CBC
    $session_key = bin2hex(random_bytes(32));
    $session_iv  = bin2hex(random_bytes(16));
    $key_hash = hash('sha256', $session_key, true);
    $iv_hash  = substr(hash('sha256', $session_iv), 0, 16);
    $encrypted = openssl_encrypt($json_to_encrypt, 'aes-256-cbc', $key_hash, OPENSSL_RAW_DATA, $iv_hash);
    $base64_safe = strtr(base64_encode($encrypted), '+/', '-_');
    
    ob_end_clean(); 
    echo json_encode(['status' => 'success', 'data' => $base64_safe, 'k' => $session_key, 'i' => $session_iv]);
} else {
    ob_end_clean();
    echo json_encode(['status' => 'error', 'msg' => 'Server API Gốc Đang Bảo Trì.']);
}
exit;
?>
