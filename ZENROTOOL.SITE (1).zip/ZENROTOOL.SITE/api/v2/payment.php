<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../config/database.php';

try {
    // 1. Lấy thông tin cấu hình từ DB để gọi SePay
    $stmt = $pdo->query("SELECT account_number, sepay_token FROM setting_bank WHERE method = 'auto' LIMIT 1");
    $bank = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$bank || empty($bank['sepay_token'])) {
        throw new Exception("Chưa cấu hình Auto Bank trong Admin Panel.");
    }

    // 2. Gọi API SePay
    $url = "https://my.sepay.vn/userapi/transactions/list?account_number=" . $bank['account_number'] . "&limit=20";
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer " . $bank['sepay_token'],
        "Content-Type: application/json"
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200) {
        throw new Exception("Lỗi kết nối tới SePay (Code: $httpCode)");
    }

    $data = json_decode($response, true);

    // 3. Trả về kết quả cho client
    echo json_encode([
        'error' => 0,
        'message' => 'Lấy dữ liệu từ SePay thành công',
        'data' => $data['transactions'] ?? []
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 1,
        'message' => $e->getMessage()
    ]);
}
?>