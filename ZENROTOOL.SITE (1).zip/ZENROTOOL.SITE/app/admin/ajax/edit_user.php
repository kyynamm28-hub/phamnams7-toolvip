<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Lỗi truy cập']); exit;
}
$stmtCheck = $pdo->prepare("SELECT role FROM users WHERE id = ?");
$stmtCheck->execute([$_SESSION['user_id']]);
if (strtolower($stmtCheck->fetchColumn()) !== 'admin') { 
    echo json_encode(['status' => 'error', 'message' => 'Không có quyền truy cập']); exit; 
}

$id = (int)$_POST['id'];
$username = trim($_POST['username']);
$email = trim($_POST['email']);
$role = $_POST['role'];
$password = trim($_POST['password']);

if (empty($username)) {
    echo json_encode(['status' => 'error', 'message' => 'Tên đăng nhập không được để trống.']); exit;
}

try {
    // Nếu Admin có nhập mật khẩu mới
    if (!empty($password)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, role = ?, password = ? WHERE id = ?");
        $stmt->execute([$username, $email, $role, $hashedPassword, $id]);
    } else {
        // Chỉ cập nhật thông tin thường
        $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, role = ? WHERE id = ?");
        $stmt->execute([$username, $email, $role, $id]);
    }

    echo json_encode(['status' => 'success', 'message' => 'Đã cập nhật thông tin thành viên thành công!']);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Lỗi cập nhật CSDL: ' . $e->getMessage()]);
}
?>
