<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Lỗi truy cập']); exit;
}
$stmtCheck = $pdo->prepare("SELECT role FROM users WHERE id = ?");
$stmtCheck->execute([$_SESSION['user_id']]);
if (strtolower($stmtCheck->fetchColumn()) !== 'admin') { 
    echo json_encode(['status' => 'error', 'message' => 'Không có quyền truy cập']); exit; 
}

$action = $_POST['action'] ?? '';
$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

try {
    // Xử lý Xóa
    if ($action === 'delete') {
        $pdo->prepare("DELETE FROM api_packages WHERE id = ?")->execute([$id]);
        echo json_encode(['status' => 'success', 'message' => 'Đã xóa gói API!']);
        exit;
    }
    
    // Xử lý Tắt/Bật
    if ($action === 'toggle') {
        $status = $_POST['status'];
        $pdo->prepare("UPDATE api_packages SET status = ? WHERE id = ?")->execute([$status, $id]);
        echo json_encode(['status' => 'success']);
        exit;
    }

    // Xử lý Thêm / Sửa
    $name = trim($_POST['name'] ?? '');
    $price = (int)($_POST['price'] ?? 0);
    $duration = (int)($_POST['duration_days'] ?? 0);
    $image = trim($_POST['image'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $status = $_POST['status'] ?? 'active';

    if (empty($name) || $price < 0 || $duration <= 0) {
        throw new Exception("Vui lòng điền thông tin hợp lệ (Giá và Ngày phải lớn hơn 0).");
    }

    if ($action === 'add') {
        $stmt = $pdo->prepare("INSERT INTO api_packages (name, description, price, duration_days, image, status) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $description, $price, $duration, $image, $status]);
        echo json_encode(['status' => 'success', 'message' => 'Đã thêm gói API mới!']);
    } 
    elseif ($action === 'edit') {
        $stmt = $pdo->prepare("UPDATE api_packages SET name=?, description=?, price=?, duration_days=?, image=?, status=? WHERE id=?");
        $stmt->execute([$name, $description, $price, $duration, $image, $status, $id]);
        echo json_encode(['status' => 'success', 'message' => 'Cập nhật gói API thành công!']);
    }

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
