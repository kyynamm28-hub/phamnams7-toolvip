<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Lỗi truy cập']); exit;
}
$stmtCheck = $pdo->prepare("SELECT role FROM users WHERE id = ?");
$stmtCheck->execute([$_SESSION['user_id']]);
if (strtolower($stmtCheck->fetchColumn()) !== 'admin') { 
    echo json_encode(['status' => 'error', 'message' => 'Không có quyền truy cập']); exit; 
}

try {
    $bank_name = trim($_POST['bank_name'] ?? '');
    $short_name = trim($_POST['short_name'] ?? '');
    $bin = trim($_POST['bin'] ?? '');
    $logo = trim($_POST['logo'] ?? '');
    $account_number = trim($_POST['account_number'] ?? '');
    $account_name = mb_strtoupper(trim($_POST['account_name'] ?? ''), 'UTF-8');
    $min_recharge = (int)($_POST['min_recharge'] ?? 10000);
    $method = $_POST['method'] ?? 'manual';
    $sepay_token = trim($_POST['sepay_token'] ?? '');

    if (empty($bin) || empty($account_number) || empty($account_name)) {
        throw new Exception("Dữ liệu gửi lên không đầy đủ.");
    }

    // Kiểm tra xem bảng đã có dòng id = 1 chưa, nếu có thì UPDATE, chưa có thì INSERT
    $check = $pdo->query("SELECT id FROM setting_bank WHERE id = 1");
    if ($check->rowCount() > 0) {
        $stmt = $pdo->prepare("UPDATE setting_bank SET bank_name=?, short_name=?, bin=?, logo=?, account_number=?, account_name=?, min_recharge=?, method=?, sepay_token=? WHERE id=1");
        $stmt->execute([$bank_name, $short_name, $bin, $logo, $account_number, $account_name, $min_recharge, $method, $sepay_token]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO setting_bank (id, bank_name, short_name, bin, logo, account_number, account_name, min_recharge, method, sepay_token) VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$bank_name, $short_name, $bin, $logo, $account_number, $account_name, $min_recharge, $method, $sepay_token]);
    }

    echo json_encode(['status' => 'success']);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>