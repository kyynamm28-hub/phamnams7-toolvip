<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin bảo mật cấp cao
if (!isset($_SESSION['user_id'])) { exit(json_encode(['status' => 'error', 'message' => 'Unauthorized'])); }
$stmtUser = $pdo->prepare("SELECT role FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);
if (!$user || strtolower($user['role']) !== 'admin') { exit(json_encode(['status' => 'error', 'message' => 'Access Denied'])); }

// Đọc dữ liệu gửi lên
$input = json_decode(file_get_contents('php://input'), true) ?: [];
$action = isset($_GET['action']) ? trim($_GET['action']) : '';

function generateBlogToken() {
    return 'blog_' . bin2hex(random_bytes(10)); // Giới hạn dưới 64 ký tự
}

try {
    // THAO TÁC 1: TẠO BÀI VIẾT MỚI
    if ($action === 'create_blog') {
        $title = trim($input['title'] ?? '');
        $short_description = trim($input['short_description'] ?? '');
        $image = trim($input['image'] ?? '');
        $content = $input['content'] ?? ''; 
        $status = trim($input['status'] ?? 'active');
        $position = (int)($input['position'] ?? 0);
        $token = generateBlogToken();

        if (empty($title) || empty($content)) {
            throw new Exception("Tiêu đề và nội dung bài viết không được để trống!");
        }

        $stmt = $pdo->prepare("INSERT INTO blogs (token, title, short_description, content, image, position, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$token, $title, $short_description, $content, $image, $position, $status]);

        echo json_encode(['status' => 'success', 'message' => 'Đăng tải bài viết thành công.']);
        exit;
    }

    // THAO TÁC 2: CẬP NHẬT BÀI VIẾT
    if ($action === 'update_blog') {
        $token = trim($input['token'] ?? '');
        $title = trim($input['title'] ?? '');
        $short_description = trim($input['short_description'] ?? '');
        $image = trim($input['image'] ?? '');
        $content = $input['content'] ?? '';
        $status = trim($input['status'] ?? 'active');
        $position = (int)($input['position'] ?? 0);

        if (empty($token) || empty($title) || empty($content)) {
            throw new Exception("Thiếu thông tin bài viết cần chỉnh sửa!");
        }

        $stmt = $pdo->prepare("UPDATE blogs SET title = ?, short_description = ?, content = ?, image = ?, position = ?, status = ? WHERE token = ?");
        $stmt->execute([$title, $short_description, $content, $image, $position, $status, $token]);

        echo json_encode(['status' => 'success', 'message' => 'Cập nhật bài viết thành công.']);
        exit;
    }

    // THAO TÁC 3: XÓA BÀI VIẾT
    if ($action === 'delete_blog') {
        $token = trim($input['token'] ?? '');
        if (empty($token)) throw new Exception("Thiếu mã bài viết cần xóa!");

        $stmt = $pdo->prepare("DELETE FROM blogs WHERE token = ?");
        $stmt->execute([$token]);

        echo json_encode(['status' => 'success', 'message' => 'Đã xóa bài viết thành công khỏi hệ thống.']);
        exit;
    }

    throw new Exception("Hành động không hợp lệ.");

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
