<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$stmtUser = $pdo->prepare("SELECT role FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);

if (!$user || strtolower($user['role']) !== 'admin') {
    echo json_encode(['status' => 'error', 'message' => 'Permission Denied']);
    exit;
}

// Nhận dữ liệu JSON
$input = json_decode(file_get_contents('php://input'), true);

$partner_id = trim($input['partner_id'] ?? '');
$partner_key = trim($input['partner_key'] ?? '');
$status = trim($input['status'] ?? 'active');
$discounts = isset($input['discounts']) ? json_encode($input['discounts'], JSON_UNESCAPED_UNICODE) : '';

if (empty($discounts)) {
    echo json_encode(['status' => 'error', 'message' => 'Dữ liệu chiết khấu không hợp lệ.']);
    exit;
}

try {
    // Kiểm tra xem đã có row nào trong setting_card chưa
    $check = $pdo->query("SELECT id FROM setting_card LIMIT 1")->fetch();

    if ($check) {
        // Update
        $stmt = $pdo->prepare("UPDATE setting_card SET partner_id = ?, partner_key = ?, status = ?, discounts = ? WHERE id = ?");
        $stmt->execute([$partner_id, $partner_key, $status, $discounts, $check['id']]);
    } else {
        // Insert
        $stmt = $pdo->prepare("INSERT INTO setting_card (partner_id, partner_key, status, discounts) VALUES (?, ?, ?, ?)");
        $stmt->execute([$partner_id, $partner_key, $status, $discounts]);
    }

    echo json_encode(['status' => 'success', 'message' => 'Cập nhật cấu hình thành công.']);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Lỗi hệ thống: ' . $e->getMessage()]);
}
?>
