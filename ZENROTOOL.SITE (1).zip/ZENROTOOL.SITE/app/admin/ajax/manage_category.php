<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']); exit;
}
$stmtUser = $pdo->prepare("SELECT role FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
if (strtolower($stmtUser->fetchColumn()) !== 'admin') {
    echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
}

$action = $_GET['action'] ?? '';
$input = json_decode(file_get_contents('php://input'), true);

try {
    if ($action === 'get_categories') {
        $stmtCat = $pdo->query("SELECT * FROM category ORDER BY position ASC");
        $categories = $stmtCat->fetchAll(PDO::FETCH_ASSOC);
        
        $stmtGames = $pdo->query("SELECT id, name, slug, category, image FROM games ORDER BY name ASC");
        $games = $stmtGames->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['status' => 'success', 'categories' => $categories, 'games' => $games]);
    } 
    
    elseif ($action === 'save_category') {
        $id = $input['id'] ?? '';
        $name = trim($input['name']);
        $slug = trim($input['slug']);
        $icon = trim($input['icon']);
        $position = (int)($input['position'] ?? 0);
        $status = $input['status'] ?? 'active';
        $selectedGames = $input['selected_games'] ?? []; // Mảng chứa slug các game

        // Kiểm tra slug trùng lặp
        $stmtCheck = $pdo->prepare("SELECT id FROM category WHERE slug = ? AND id != ?");
        $stmtCheck->execute([$slug, $id ?: 0]);
        if ($stmtCheck->fetch()) {
            echo json_encode(['status' => 'error', 'message' => 'Slug danh mục đã tồn tại.']); exit;
        }

        $pdo->beginTransaction();

        if (empty($id)) {
            // Thêm mới
            $stmt = $pdo->prepare("INSERT INTO category (name, slug, icon, position, status) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $slug, $icon, $position, $status]);
        } else {
            // Cập nhật
            $stmt = $pdo->prepare("UPDATE category SET name = ?, slug = ?, icon = ?, position = ?, status = ? WHERE id = ?");
            $stmt->execute([$name, $slug, $icon, $position, $status, $id]);
            
            // Xóa category hiện tại của các game đang mang slug cũ (reset về rỗng) nếu đổi slug
            $stmtOldSlug = $pdo->prepare("SELECT slug FROM category WHERE id = ?");
            $stmtOldSlug->execute([$id]);
            $oldSlug = $stmtOldSlug->fetchColumn();
            
            if ($oldSlug && $oldSlug !== $slug) {
                $pdo->prepare("UPDATE games SET category = '' WHERE category = ?")->execute([$oldSlug]);
            }
        }

        // Cập nhật phân bổ Game
        // Đầu tiên reset category = '' cho tất cả các game hiện đang thuộc danh mục này
        $pdo->prepare("UPDATE games SET category = '' WHERE category = ?")->execute([$slug]);
        
        // Sau đó set category = slug cho các game được tích chọn
        if (!empty($selectedGames)) {
            $inQuery = implode(',', array_fill(0, count($selectedGames), '?'));
            $stmtUpdateGames = $pdo->prepare("UPDATE games SET category = ? WHERE slug IN ($inQuery)");
            $params = array_merge([$slug], $selectedGames);
            $stmtUpdateGames->execute($params);
        }

        $pdo->commit();
        echo json_encode(['status' => 'success', 'message' => 'Lưu danh mục thành công.']);
    } 
    
    elseif ($action === 'delete_category') {
        $id = $input['id'] ?? '';
        if (empty($id)) throw new Exception("Không tìm thấy danh mục.");
        
        $pdo->beginTransaction();
        
        $stmtSlug = $pdo->prepare("SELECT slug FROM category WHERE id = ?");
        $stmtSlug->execute([$id]);
        $slug = $stmtSlug->fetchColumn();
        
        $pdo->prepare("DELETE FROM category WHERE id = ?")->execute([$id]);
        if ($slug) {
            $pdo->prepare("UPDATE games SET category = '' WHERE category = ?")->execute([$slug]);
        }
        
        $pdo->commit();
        echo json_encode(['status' => 'success', 'message' => 'Đã xóa danh mục.']);
    }
} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
