<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền
if (!isset($_SESSION['user_id'])) exit(json_encode(['status' => 'error', 'message' => 'Unauthorized']));
$stmtUser = $pdo->prepare("SELECT role FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);
if (!$user || strtolower($user['role']) !== 'admin') exit(json_encode(['status' => 'error', 'message' => 'Access Denied']));

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$action = $_GET['action'] ?? '';

// Hàm tự động tạo Slug
function createSlug($str) {
    $str = preg_replace("/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/", 'a', $str);
    $str = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $str);
    $str = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $str);
    $str = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/", 'o', $str);
    $str = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $str);
    $str = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $str);
    $str = preg_replace("/(đ)/", 'd', $str);
    $str = preg_replace("/(À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ)/", 'A', $str);
    $str = preg_replace("/(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)/", 'E', $str);
    $str = preg_replace("/(Ì|Í|Ị|Ỉ|Ĩ)/", 'I', $str);
    $str = preg_replace("/(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|MỠ)/", 'O', $str);
    $str = preg_replace("/(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)/", 'U', $str);
    $str = preg_replace("/(Ỳ|Ý|Ỵ|Ỷ|Ỹ)/", 'Y', $str);
    $str = preg_replace("/(Đ)/", 'D', $str);
    $str = strtolower(trim($str));
    $str = preg_replace('/[^a-z0-9-]+/', '-', $str);
    return preg_replace('/-+/', '-', $str);
}

try {
    if ($action === 'save_game') {
        $id = $input['id'] ?? null;
        $name = trim($input['name'] ?? '');
        $category = trim($input['category'] ?? '');
        $slug = trim($input['slug'] ?? '');
        
        if (empty($name)) throw new Exception("Tên Game không được để trống!");
        if (empty($slug)) $slug = createSlug($name);

        $data = [
            $category, $slug, $name, 
            $input['image'] ?? '', $input['description'] ?? '', $input['badge'] ?? '', 
            (int)($input['position'] ?? 0), $input['url_iframe'] ?? '', 
            $input['api_predict_url'] ?? '', $input['map_notify'] ?? '', 
            $input['map_predict'] ?? '', $input['map_predict_vi'] ?? '', 
            $input['map_rate'] ?? '', $input['map_history_prev'] ?? '', 
            $input['map_history_result'] ?? '', $input['map_history_sum'] ?? '', 
            $input['map_history_dice1'] ?? '', $input['map_history_dice2'] ?? '', 
            $input['map_history_dice3'] ?? '', $input['status'] ?? 'active'
        ];

        if ($id) {
            // Update
            $sql = "UPDATE games SET category=?, slug=?, name=?, image=?, description=?, badge=?, position=?, url_iframe=?, api_predict_url=?, map_notify=?, map_predict=?, map_predict_vi=?, map_rate=?, map_history_prev=?, map_history_result=?, map_history_sum=?, map_history_dice1=?, map_history_dice2=?, map_history_dice3=?, status=? WHERE id=?";
            $data[] = $id;
            $stmt = $pdo->prepare($sql);
            $stmt->execute($data);
            $msg = 'Cập nhật cấu hình Game thành công!';
        } else {
            // Insert (Cần check trùng slug)
            $check = $pdo->prepare("SELECT id FROM games WHERE slug = ?");
            $check->execute([$slug]);
            if ($check->fetch()) {
                $slug = $slug . '-' . rand(100,999); // Tránh trùng lặp
                $data[1] = $slug;
            }

            $sql = "INSERT INTO games (category, slug, name, image, description, badge, position, url_iframe, api_predict_url, map_notify, map_predict, map_predict_vi, map_rate, map_history_prev, map_history_result, map_history_sum, map_history_dice1, map_history_dice2, map_history_dice3, status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($data);
            $msg = 'Thêm Game mới thành công!';
        }

        echo json_encode(['status' => 'success', 'message' => $msg]);
    }

    elseif ($action === 'delete_game') {
        $id = $input['id'] ?? null;
        if (!$id) throw new Exception("Không tìm thấy ID game!");
        $pdo->prepare("DELETE FROM games WHERE id = ?")->execute([$id]);
        echo json_encode(['status' => 'success', 'message' => 'Đã xóa game!']);
    }

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>