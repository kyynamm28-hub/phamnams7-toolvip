<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Lỗi truy cập']); exit;
}
$stmtCheck = $pdo->prepare("SELECT role FROM users WHERE id = ?");
$stmtCheck->execute([$_SESSION['user_id']]);
if (strtolower($stmtCheck->fetchColumn()) !== 'admin') { 
    echo json_encode(['status' => 'error', 'message' => 'Không có quyền truy cập']); exit; 
}

$action = $_POST['action'] ?? '';

try {
    // ----------------------------------------------------
    // XỬ LÝ TAB 2: CẤU HÌNH GIÁ THUÊ CHUNG (setting_partner)
    // ----------------------------------------------------
    if ($action === 'save_settings') {
        $day = (int)$_POST['price_day'];
        $week = (int)$_POST['price_week'];
        $month = (int)$_POST['price_month'];
        $contact = trim($_POST['contact_link']);

        $pdo->prepare("UPDATE setting_partner SET price_day=?, price_week=?, price_month=?, contact_link=? WHERE id=1")
            ->execute([$day, $week, $month, $contact]);
            
        echo json_encode(['status' => 'success', 'message' => 'Đã lưu cấu hình bảng giá!']);
        exit;
    }

    // ----------------------------------------------------
    // XỬ LÝ TAB 1: DANH SÁCH ĐỐI TÁC (partners)
    // ----------------------------------------------------
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

    if ($action === 'delete_partner') {
        $pdo->prepare("DELETE FROM partners WHERE id = ?")->execute([$id]);
        echo json_encode(['status' => 'success', 'message' => 'Đã xóa đối tác!']);
        exit;
    }
    
    if ($action === 'toggle_partner') {
        $status = $_POST['status'];
        $pdo->prepare("UPDATE partners SET status = ? WHERE id = ?")->execute([$status, $id]);
        echo json_encode(['status' => 'success']);
        exit;
    }

    if ($action === 'add_partner' || $action === 'edit_partner') {
        $name = trim($_POST['name'] ?? '');
        $logo = trim($_POST['logo_url'] ?? '');
        $website = trim($_POST['website_url'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $status = $_POST['status'] ?? 'active';

        if (empty($name) || empty($logo)) {
            throw new Exception("Vui lòng điền tên và logo đối tác.");
        }

        if ($action === 'add_partner') {
            $stmt = $pdo->prepare("INSERT INTO partners (name, logo_url, website_url, description, status) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $logo, $website, $description, $status]);
            echo json_encode(['status' => 'success', 'message' => 'Đã thêm đối tác mới!']);
        } 
        else {
            $stmt = $pdo->prepare("UPDATE partners SET name=?, logo_url=?, website_url=?, description=?, status=? WHERE id=?");
            $stmt->execute([$name, $logo, $website, $description, $status, $id]);
            echo json_encode(['status' => 'success', 'message' => 'Đã cập nhật thông tin đối tác!']);
        }
    }

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>