<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../../../config/database.php';

if (!isset($_SESSION['user_id'])) exit(json_encode(['status' => 'error', 'message' => 'Unauthorized']));
$stmtUser = $pdo->prepare("SELECT role FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
if (strtolower($stmtUser->fetchColumn()) !== 'admin') exit(json_encode(['status' => 'error', 'message' => 'Access Denied']));

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$action = $_GET['action'] ?? '';

function createSlug($str) {
    $str = mb_strtolower(trim($str), 'UTF-8');
    $str = preg_replace('/[^a-z0-9-]+/', '-', $str);
    return trim(preg_replace('/-+/', '-', $str), '-');
}

try {
    if ($action === 'save_product') {
        $id = $input['id'] ?? null;
        $name = trim($input['name'] ?? '');
        $slug = trim($input['slug'] ?? '');
        $price = (int)($input['price'] ?? 0);
        $short_desc = trim($input['short_description'] ?? '');
        $content = $input['content'] ?? '';
        $status = $input['status'] ?? 'active';
        $download_url = trim($input['download_url'] ?? '');
        $support_contact = trim($input['support_contact'] ?? '');
        $image = trim($input['image'] ?? '');
        
        if (empty($name)) throw new Exception("Tên sản phẩm không được trống!");
        if (empty($slug)) $slug = createSlug($name);

        $pdo->beginTransaction();

        if ($id) {
            // Update SP
            $stmt = $pdo->prepare("UPDATE products SET name=?, slug=?, price=?, short_description=?, content=?, status=?, download_url=?, support_contact=? WHERE id=?");
            $stmt->execute([$name, $slug, $price, $short_desc, $content, $status, $download_url, $support_contact, $id]);
            
            // Xử lý Ảnh riêng
            $imgCheck = $pdo->prepare("SELECT id FROM product_images WHERE product_id = ? AND is_primary = 1");
            $imgCheck->execute([$id]);
            if ($imgCheck->fetch()) {
                $pdo->prepare("UPDATE product_images SET image_url = ? WHERE product_id = ? AND is_primary = 1")->execute([$image, $id]);
            } else {
                $pdo->prepare("INSERT INTO product_images (product_id, image_url, is_primary) VALUES (?, ?, 1)")->execute([$id, $image]);
            }
            
            $msg = 'Cập nhật mã nguồn thành công!';
        } else {
            // Insert SP Mới
            $check = $pdo->prepare("SELECT id FROM products WHERE slug = ?");
            $check->execute([$slug]);
            if ($check->fetch()) {
                $slug = $slug . '-' . rand(100,999);
            }

            $stmt = $pdo->prepare("INSERT INTO products (name, slug, price, short_description, content, status, download_url, support_contact) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$name, $slug, $price, $short_desc, $content, $status, $download_url, $support_contact]);
            
            $new_id = $pdo->lastInsertId();
            
            // Insert Ảnh
            if (!empty($image)) {
                $pdo->prepare("INSERT INTO product_images (product_id, image_url, is_primary) VALUES (?, ?, 1)")->execute([$new_id, $image]);
            }
            
            $msg = 'Đăng bán mã nguồn thành công!';
        }

        $pdo->commit();
        echo json_encode(['status' => 'success', 'message' => $msg]);
        
    } elseif ($action === 'delete_product') {
        $id = $input['id'] ?? null;
        if (!$id) throw new Exception("Không tìm thấy ID sản phẩm!");
        
        $pdo->prepare("DELETE FROM products WHERE id = ?")->execute([$id]);
        echo json_encode(['status' => 'success', 'message' => 'Đã gỡ sản phẩm khỏi kho hàng!']);
    }
} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
