<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Lỗi truy cập']); exit;
}
$stmtCheck = $pdo->prepare("SELECT role FROM users WHERE id = ?");
$stmtCheck->execute([$_SESSION['user_id']]);
if (strtolower($stmtCheck->fetchColumn()) !== 'admin') { 
    echo json_encode(['status' => 'error', 'message' => 'Không có quyền truy cập']); exit; 
}

$action = $_POST['action'] ?? '';
$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

// Hàm tạo slug tự động từ tiếng Việt
function createSlug($str) {
    $str = preg_replace("/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/", 'a', $str);
    $str = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $str);
    $str = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $str);
    $str = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/", 'o', $str);
    $str = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $str);
    $str = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $str);
    $str = preg_replace("/(đ)/", 'd', $str);
    $str = preg_replace("/([^a-zA-SU-Z0-9\s-])/", '', $str);
    $str = preg_replace("/([\s-]+)/", '-', $str);
    return strtolower(trim($str, '-'));
}

try {
    if ($action === 'delete') {
        $pdo->prepare("DELETE FROM products WHERE id = ?")->execute([$id]);
        echo json_encode(['status' => 'success', 'message' => 'Đã gỡ sản phẩm khỏi kho hàng thành công!']);
        exit;
    }
    
    if ($action === 'toggle') {
        $status = $_POST['status'];
        $pdo->prepare("UPDATE products SET status = ? WHERE id = ?")->execute([$status, $id]);
        echo json_encode(['status' => 'success']);
        exit;
    }

    // Xử lý Thêm / Sửa sản phẩm
    $name = trim($_POST['name'] ?? '');
    $price = (int)($_POST['price'] ?? 0);
    $duration = (int)($_POST['duration_days'] ?? 30);
    $image = trim($_POST['image'] ?? '');
    $description = trim($_POST['description'] ?? ''); // Giữ nguyên mã HTML nhận được từ textarea
    $status = $_POST['status'] ?? 'active';
    
    $slug = trim($_POST['slug'] ?? '');
    if (empty($slug)) {
        $slug = createSlug($name);
    }

    if (empty($name) || $price < 0) {
        throw new Exception("Thông tin nhập vào kho hàng chưa hợp lệ.");
    }

    if ($action === 'add') {
        $stmt = $pdo->prepare("INSERT INTO products (name, slug, description, price, duration_days, image, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $slug, $description, $price, $duration, $image, $status]);
        echo json_encode(['status' => 'success', 'message' => 'Đã đưa sản phẩm mới vào kho thành công!']);
    } 
    elseif ($action === 'edit') {
        $stmt = $pdo->prepare("UPDATE products SET name=?, slug=?, description=?, price=?, duration_days=?, image=?, status=? WHERE id=?");
        $stmt->execute([$name, $slug, $description, $price, $duration, $image, $status, $id]);
        echo json_encode(['status' => 'success', 'message' => 'Đã lưu trữ thay đổi sản phẩm!']);
    }

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
