<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền Admin
if (!isset($_SESSION['user_id'])) exit(json_encode(['status' => 'error', 'message' => 'Unauthorized']));
$stmtUser = $pdo->prepare("SELECT role FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
if (strtolower($stmtUser->fetchColumn()) !== 'admin') exit(json_encode(['status' => 'error', 'message' => 'Access Denied']));

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$action = $_GET['action'] ?? '';

try {
    if ($action === 'save_settings') {
        $pdo->beginTransaction();
        
        // Cập nhật từng key trong bảng settings
        $stmtUpdate = $pdo->prepare("UPDATE settings SET value = ? WHERE `key` = ?");
        $stmtInsert = $pdo->prepare("INSERT INTO settings (`key`, value) VALUES (?, ?)");
        
        foreach ($input as $key => $value) {
            // Kiểm tra xem key đã tồn tại chưa
            $check = $pdo->prepare("SELECT 1 FROM settings WHERE `key` = ?");
            $check->execute([$key]);
            if ($check->fetch()) {
                $stmtUpdate->execute([$value, $key]);
            } else {
                $stmtInsert->execute([$key, $value]);
            }
        }
        
        $pdo->commit();
        echo json_encode(['status' => 'success', 'message' => 'Cập nhật cấu hình thành công']);
    } else {
        throw new Exception("Action không hợp lệ.");
    }
} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
