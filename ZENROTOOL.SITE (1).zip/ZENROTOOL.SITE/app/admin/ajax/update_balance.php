<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Kiểm tra quyền (Bảo mật)
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Lỗi truy cập']); exit;
}
$stmtCheck = $pdo->prepare("SELECT role FROM users WHERE id = ?");
$stmtCheck->execute([$_SESSION['user_id']]);
if (strtolower($stmtCheck->fetchColumn()) !== 'admin') { 
    echo json_encode(['status' => 'error', 'message' => 'Không có quyền truy cập']); exit; 
}

$target_user_id = (int)$_POST['user_id'];
$type = $_POST['type'] ?? 'add';
$amount = (int)$_POST['amount'];
$reason = trim($_POST['reason']);

if ($amount <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Số tiền không hợp lệ.']); exit;
}

try {
    $pdo->beginTransaction();

    // Lock tài khoản user để update an toàn. Bổ sung lấy thêm ref_by
    $stmtUser = $pdo->prepare("SELECT balance, ref_by FROM users WHERE id = ? FOR UPDATE");
    $stmtUser->execute([$target_user_id]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$user) throw new Exception("Không tìm thấy người dùng.");

    $current_balance = (float)$user['balance'];

    if ($type === 'add') {
        $new_balance = $current_balance + $amount;
        $order_token = md5(uniqid('ADD_', true));
        $status = 'success';
    } else {
        if ($current_balance < $amount) throw new Exception("Số dư của user không đủ để trừ.");
        $new_balance = $current_balance - $amount;
        $order_token = md5(uniqid('SUB_', true));
        $status = 'expired'; 
    }

    // Cập nhật số dư User
    $pdo->prepare("UPDATE users SET balance = ? WHERE id = ?")->execute([$new_balance, $target_user_id]);

    // Thêm lịch sử & Tính hoa hồng CTV nếu là lệnh Cộng
    if ($type === 'add') {
        $stmtHistory = $pdo->prepare("INSERT INTO transfer_history (user_id, order_token, amount, content, status, created_at, expires_at) VALUES (?, ?, ?, ?, 'success', NOW(), NOW())");
        $stmtHistory->execute([$target_user_id, $order_token, $amount, $reason]);

        // ==========================================
        // LOGIC CỘNG HOA HỒNG CHO CTV
        // ==========================================
        if (!empty($user['ref_by'])) {
            $ref_by = (int)$user['ref_by'];

            // Lấy % hoa hồng từ cài đặt (mặc định 10% nếu ko có)
            $stmtCtv = $pdo->query("SELECT commission_rate FROM setting_ctv LIMIT 1");
            $ctvData = $stmtCtv->fetch(PDO::FETCH_ASSOC);
            $commission_rate = $ctvData ? (float)$ctvData['commission_rate'] : 10;

            // Tính số tiền hoa hồng
            $commission_amount = $amount * ($commission_rate / 100);

            // Cộng tiền vào quỹ hoa hồng của người giới thiệu
            if ($commission_amount > 0) {
                $pdo->prepare("UPDATE users SET commission_balance = commission_balance + ? WHERE id = ?")
                    ->execute([$commission_amount, $ref_by]);
            }
        }
    }

    // Lưu log thao tác của Admin
    $pdo->prepare("INSERT INTO user_logs (user_id, action, created_at) VALUES (?, ?, NOW())")
        ->execute([$_SESSION['user_id'], "Đã " . ($type == 'add' ? 'cộng' : 'trừ') . " " . number_format($amount) . "đ cho User ID $target_user_id"]);

    $pdo->commit();

    echo json_encode([
        'status' => 'success', 
        'message' => ($type === 'add' ? 'Cộng' : 'Trừ') . ' tiền thành công!',
        'new_balance' => $new_balance
    ]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) { $pdo->rollBack(); }
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>