<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../../config/database.php';

// Lấy settings từ CSDL
$stmt = $pdo->query("SELECT * FROM settings");
$settings = [];
foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $s) {
    $settings[$s['key']] = $s['value'];
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

// Hàm kiểm tra Geetest v4
function verifyGeetest($data, $settings) {
    $captcha_id = $settings['geetest_id'] ?? '';
    $captcha_key = $settings['geetest_key'] ?? '';
    
    // Nếu Admin chưa nhập Key Geetest trong DB thì tạm thời Bypass (Cho qua)
    if (empty($captcha_id) || empty($captcha_key)) return true;
    
    $lot_number = $data['lot_number'] ?? '';
    $captcha_output = $data['captcha_output'] ?? '';
    $pass_token = $data['pass_token'] ?? '';
    $gen_time = $data['gen_time'] ?? '';
    
    $sign_token = hash_hmac('sha256', $lot_number, $captcha_key);
    $query = http_build_query([
        'lot_number' => $lot_number,
        'captcha_output' => $captcha_output,
        'pass_token' => $pass_token,
        'gen_time' => $gen_time,
        'sign_token' => $sign_token
    ]);
    
    $ch = curl_init("https://gcaptcha4.geetest.com/validate?captcha_id={$captcha_id}");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $query);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $res = curl_exec($ch);
    curl_close($ch);
    
    $result = json_decode($res, true);
    return ($result['result'] === 'success');
}

// -------------------------------------------------------------
// [TÍNH NĂNG MỚI] KIỂM TRA AUTO-LOGOUT ĐA THIẾT BỊ
// -------------------------------------------------------------
if ($action === 'check_multi_device') {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['status' => 'guest']); exit;
    }
    
    $userId = $_SESSION['user_id'];
    $currentSessionId = session_id();
    
    // Lấy phiên đăng nhập MỚI NHẤT của user này
    $stmt = $pdo->prepare("SELECT session_id FROM user_devices WHERE user_id = ? ORDER BY id DESC LIMIT 1");
    $stmt->execute([$userId]);
    $latestSession = $stmt->fetchColumn();
    
    // Nếu phiên hiện tại khác phiên mới nhất trên DB -> Đã có người đăng nhập thiết bị khác
    if ($latestSession && $latestSession !== $currentSessionId) {
        session_destroy();
        echo json_encode(['status' => 'logout', 'message' => 'Tài khoản của bạn vừa được đăng nhập trên một thiết bị khác.']);
    } else {
        echo json_encode(['status' => 'ok']);
    }
    exit;
}

// -------------------------------------------------------------
// XỬ LÝ ĐĂNG KÝ / ĐĂNG NHẬP / GOOGLE
// -------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] !== 'POST') exit;

if (in_array($action, ['login', 'register', 'finalize_google'])) {
    
    // 1. Xác thực Captcha
    if (!verifyGeetest($_POST, $settings)) {
        echo json_encode(['status' => 'error', 'message' => 'Xác thực Captcha thất bại! Bạn là Robot?']);
        exit;
    }
    
    $ip_address = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    $session_id = session_id();

    // 2. XỬ LÝ ĐĂNG KÝ
    if ($action === 'register') {
        $maxIpRegister = isset($settings['max_register_per_ip']) ? (int)$settings['max_register_per_ip'] : 3;
        $stmtCheckIp = $pdo->prepare("SELECT COUNT(DISTINCT user_id) FROM user_devices WHERE ip_address = ?");
        $stmtCheckIp->execute([$ip_address]);
        if ($stmtCheckIp->fetchColumn() >= $maxIpRegister) {
            echo json_encode(['status' => 'error', 'message' => "Hệ thống từ chối: IP này đã đạt giới hạn tạo tài khoản."]); exit;
        }

        $displayName = trim($_POST['display_name']);
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $password = $_POST['password'];
        
        if ($password !== $_POST['password_confirm']) {
            echo json_encode(['status' => 'error', 'message' => 'Mật khẩu xác nhận không khớp!']); exit;
        }

        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
        $stmt->execute([$email, $username]);
        if ($stmt->fetch()) {
            echo json_encode(['status' => 'error', 'message' => 'Email hoặc Tên đăng nhập đã tồn tại!']); exit;
        }

        $referredBy = null;
        if (!empty($_POST['referral_code'])) {
            $stmtRef = $pdo->prepare("SELECT id FROM users WHERE username = ?");
            $stmtRef->execute([trim($_POST['referral_code'])]);
            $refUser = $stmtRef->fetch();
            if ($refUser) $referredBy = $refUser['id'];
            else { echo json_encode(['status' => 'error', 'message' => 'Mã mời không tồn tại!']); exit; }
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (display_name, username, email, password, referred_by) VALUES (?, ?, ?, ?, ?)");
        if ($stmt->execute([$displayName, $username, $email, $hashedPassword, $referredBy])) {
            $userId = $pdo->lastInsertId();
            $_SESSION['user_id'] = $userId;
            
            // Xóa log cũ, ghi log mới để chặn đa thiết bị
            $pdo->prepare("DELETE FROM user_devices WHERE user_id = ?")->execute([$userId]);
            $pdo->prepare("INSERT INTO user_devices (user_id, session_id, user_agent, ip_address) VALUES (?, ?, ?, ?)")->execute([$userId, $session_id, $user_agent, $ip_address]);

            echo json_encode(['status' => 'success', 'message' => 'Đăng ký thành công!', 'redirect' => '/home']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Lỗi máy chủ, thử lại sau.']);
        }
        exit;
    }

    // 3. XỬ LÝ ĐĂNG NHẬP
    if ($action === 'login') {
        $login_id = trim($_POST['login_id']);
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? OR username = ?");
        $stmt->execute([$login_id, $login_id]);
        $user = $stmt->fetch();

        if ($user && password_verify($_POST['password'], $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            
            // Xóa phiên cũ, ghi đè phiên mới
            $pdo->prepare("DELETE FROM user_devices WHERE user_id = ?")->execute([$user['id']]);
            $pdo->prepare("INSERT INTO user_devices (user_id, session_id, user_agent, ip_address) VALUES (?, ?, ?, ?)")->execute([$user['id'], $session_id, $user_agent, $ip_address]);

            echo json_encode(['status' => 'success', 'message' => 'Đăng nhập thành công!', 'redirect' => '/home']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Tài khoản hoặc mật khẩu không chính xác!']);
        }
        exit;
    }

    // 4. XỬ LÝ GOOGLE (Sau khi giải xong Captcha)
    if ($action === 'finalize_google') {
        if (!isset($_SESSION['pending_google_user'])) {
            echo json_encode(['status' => 'error', 'message' => 'Hết hạn phiên kết nối Google. Vui lòng thử lại.']); exit;
        }
        $googleUser = $_SESSION['pending_google_user'];
        
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$googleUser['email']]);
        $user = $stmt->fetch();

        if (!$user) {
            $maxIpRegister = isset($settings['max_register_per_ip']) ? (int)$settings['max_register_per_ip'] : 3;
            $stmtCheckIp = $pdo->prepare("SELECT COUNT(DISTINCT user_id) FROM user_devices WHERE ip_address = ?");
            $stmtCheckIp->execute([$ip_address]);
            if ($stmtCheckIp->fetchColumn() >= $maxIpRegister) {
                unset($_SESSION['pending_google_user']);
                echo json_encode(['status' => 'error', 'message' => "IP này đã đạt giới hạn tạo tài khoản."]); exit;
            }

            $stmt = $pdo->prepare("INSERT INTO users (display_name, email, google_id) VALUES (?, ?, ?)");
            $stmt->execute([$googleUser['name'], $googleUser['email'], $googleUser['id']]);
            $userId = $pdo->lastInsertId();
        } else {
            $userId = $user['id'];
            if(empty($user['google_id'])) {
                $pdo->prepare("UPDATE users SET google_id = ? WHERE id = ?")->execute([$googleUser['id'], $userId]);
            }
        }
        
        $_SESSION['user_id'] = $userId;
        unset($_SESSION['pending_google_user']);

        $pdo->prepare("DELETE FROM user_devices WHERE user_id = ?")->execute([$userId]);
        $pdo->prepare("INSERT INTO user_devices (user_id, session_id, user_agent, ip_address) VALUES (?, ?, ?, ?)")->execute([$userId, $session_id, $user_agent, $ip_address]);

        echo json_encode(['status' => 'success', 'message' => 'Đăng nhập Google thành công!', 'redirect' => '/home']);
        exit;
    }
}
?>