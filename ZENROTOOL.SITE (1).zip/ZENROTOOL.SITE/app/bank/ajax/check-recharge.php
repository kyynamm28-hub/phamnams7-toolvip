<?php
// Bật header trả về JSON chuẩn
header('Content-Type: application/json; charset=utf-8');
session_start();

// 1. Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Vui lòng đăng nhập để sử dụng chức năng này.']);
    exit;
}

// 2. Kết nối Database (Nhớ chỉnh lại số cấp lùi thư mục cho đúng với thực tế)
require_once __DIR__ . '/../../../config/database.php';

$user_id = $_SESSION['user_id'];

try {
    // 3. Logic kiểm tra nạp tiền (Ví dụ: Kiểm tra trong bảng recharges xem có giao dịch nào mới hoàn thành chưa)
    // is_notified = 0 để tránh thông báo trùng nhiều lần
    $stmt = $pdo->prepare("SELECT id, amount, transaction_code FROM recharges WHERE user_id = :uid AND status = 'completed' AND is_notified = 0 ORDER BY id DESC LIMIT 1");
    $stmt->execute(['uid' => $user_id]);
    $latest_recharge = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($latest_recharge) {
        // Cập nhật trạng thái đã thông báo để lần sau fetch không bị lặp lại
        $updateStmt = $pdo->prepare("UPDATE recharges SET is_notified = 1 WHERE id = :id");
        $updateStmt->execute(['id' => $latest_recharge['id']]);

        echo json_encode([
            'status' => 'success',
            'message' => 'Nạp tiền thành công ' . number_format($latest_recharge['amount']) . ' VNĐ!',
            'data' => [
                'amount' => $latest_recharge['amount'],
                'trans_code' => $latest_recharge['transaction_code']
            ]
        ]);
        exit;
    }

    // Nếu không có giao dịch mới, trả về trạng thái pending
    echo json_encode([
        'status' => 'pending',
        'message' => 'Hệ thống đang chờ nhận tiền...'
    ]);

} catch (Exception $e) {
    // Bắt lỗi hệ thống
    echo json_encode([
        'status' => 'error', 
        'message' => 'Lỗi kết nối máy chủ, vui lòng thử lại sau.'
    ]);
}
?>
