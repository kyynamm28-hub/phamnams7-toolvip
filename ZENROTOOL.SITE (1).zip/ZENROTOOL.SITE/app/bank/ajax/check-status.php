<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../../config/database.php';

$token = $_POST['token'] ?? '';
if (!$token) { echo json_encode(['status' => 'error']); exit; }

$stmt = $pdo->prepare("SELECT status, expires_at FROM transfer_history WHERE order_token = ? LIMIT 1");
$stmt->execute([$token]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) { echo json_encode(['status' => 'error']); exit; }

if ($order['status'] === 'paid') {
    echo json_encode(['status' => 'paid']);
} elseif (strtotime($order['expires_at']) < time()) {
    $pdo->prepare("UPDATE transfer_history SET status = 'expired' WHERE order_token = ?")->execute([$token]);
    echo json_encode(['status' => 'expired']);
} else {
    echo json_encode(['status' => 'pending']);
}
?>
