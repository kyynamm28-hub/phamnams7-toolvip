<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Chưa đăng nhập']); exit;
}

$amount = isset($_POST['amount']) ? (int)$_POST['amount'] : 0;
$user_id = $_SESSION['user_id'];

// Check min nạp
$stmtBank = $pdo->query("SELECT min_recharge FROM setting_bank LIMIT 1");
$minRecharge = $stmtBank->fetchColumn() ?: 10000;

if ($amount < $minRecharge) {
    echo json_encode(['status' => 'error', 'message' => 'Số tiền nạp tối thiểu là ' . number_format($minRecharge) . 'đ']); exit;
}

// ---------------------------------------------------------
// LOGIC TẠO NỘI DUNG CHUYỂN KHOẢN (GHÉP CHỮ NGẪU NHIÊN)
// ---------------------------------------------------------

// 1. Kho từ vựng để ghép (Có thể tự thêm bớt tùy ý)
$words = [
    'AN', 'BINH', 'CHAU', 'DUNG', 'GIANG', 'HOA', 'KHOA', 'LINH', 'MINH', 'NAM', 
    'PHONG', 'QUAN', 'SON', 'TRANG', 'TUNG', 'VIET', 'XUAN', 'YEN', 'BAO', 'CUONG', 
    'DUC', 'HAI', 'HUNG', 'KHANG', 'LONG', 'NGOC', 'PHUC', 'QUANG', 'THAI', 'TUAN', 
    'VINH', 'DAT', 'KIEN', 'LAM', 'NHAN', 'PHAT', 'SANG', 'TAI', 'TOAN', 'KHOI', 
    'THINH', 'VU', 'NGUYEN', 'LE', 'TRAN', 'PHAM', 'HOANG', 'HUYNH', 'PHAN', 'VUONG'
];

// 2. Bốc ngẫu nhiên 3 từ ghép lại thành 1 Tên riêng biệt
$randomWord1 = $words[array_rand($words)];
$randomWord2 = $words[array_rand($words)];
$randomWord3 = $words[array_rand($words)];

$randomName = $randomWord1 . ' ' . $randomWord2 . ' ' . $randomWord3;

// 3. Ghép với hậu tố
$baseContent = $randomName . ' CHUYEN KHOAN QUA QR';

// Giới hạn max 40 ký tự để mã QR của Bank không bị lỗi (VietQR thường giới hạn 50 ký tự)
if (strlen($baseContent) > 40) {
    $baseContent = substr($baseContent, 0, 40);
}

$content = $baseContent;

// 4. Kiểm tra xem Nội dung này có trùng với đơn Pending nào không
$checkStmt = $pdo->prepare("SELECT id FROM transfer_history WHERE content = :content AND status = 'pending'");
$checkStmt->execute(['content' => $content]);

if ($checkStmt->rowCount() > 0) {
    // NẾU TRÙNG: Random thêm 4 ký tự gồm chữ và số nối vào đuôi
    $randomCode = strtoupper(substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 4));
    
    // Đảm bảo không vượt quá độ dài sau khi nối
    if (strlen($baseContent) > 35) {
        $content = trim(substr($baseContent, 0, 35)) . ' ' . $randomCode;
    } else {
        $content = $baseContent . ' ' . $randomCode;
    }
}

// ---------------------------------------------------------
// TẠO ĐƠN & LƯU VÀO DATABASE
// ---------------------------------------------------------

// Tạo Token đơn nạp (32 ký tự ngẫu nhiên)
$order_token = bin2hex(random_bytes(16));
// Đơn nạp hết hạn sau 15 phút
$expires_at = date('Y-m-d H:i:s', strtotime('+15 minutes'));

$stmtInsert = $pdo->prepare("
    INSERT INTO transfer_history (user_id, order_token, amount, content, status, created_at, expires_at) 
    VALUES (?, ?, ?, ?, 'pending', NOW(), ?)
");

if ($stmtInsert->execute([$user_id, $order_token, $amount, $content, $expires_at])) {
    echo json_encode([
        'status' => 'success', 
        'redirect_url' => '/bank/recharge/transfer?token=' . $order_token
    ]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Lỗi tạo đơn nạp, vui lòng thử lại!']);
}
