<?php
// Bật header trả về JSON để Frontend dễ bắt lỗi
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../../config/database.php';

$token = $_POST['token'] ?? '';
if (empty($token)) {
    echo json_encode(['status' => 'error', 'message' => 'Thiếu dữ liệu token đơn nạp.']);
    exit;
}

try {
    // 1. Lấy thông tin siêu chi tiết của đơn nạp và User
    $stmt = $pdo->prepare("
        SELECT th.*, u.username, u.email, u.display_name 
        FROM transfer_history th 
        JOIN users u ON th.user_id = u.id 
        WHERE th.order_token = ? LIMIT 1
    ");
    $stmt->execute([$token]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($order) {
        // 2. Lấy config Bot từ CSDL
        $stmtBot = $pdo->query("SELECT telegram_token, chat_id FROM setting_bot LIMIT 1");
        $bot = $stmtBot->fetch(PDO::FETCH_ASSOC);

        if ($bot && !empty($bot['telegram_token']) && !empty($bot['chat_id'])) {
            
            // Xóa khoảng trắng thừa (nếu có) để tránh lỗi API
            $botToken = trim($bot['telegram_token']);
            $chatId = trim($bot['chat_id']);
            
            // Dùng htmlspecialchars để bọc các biến động, TRÁNH LỖI PARSE HTML CỦA TELEGRAM
            $user_display = !empty($order['username']) ? $order['username'] : $order['display_name'];
            $amount_format = number_format($order['amount']) . " VNĐ";
            $time_format = date('H:i:s - d/m/Y', strtotime($order['created_at']));
            $content_safe = htmlspecialchars($order['content']);
            
            // Xác định tiêu đề dựa trên trạng thái (Auto hay Thủ công)
            if ($order['status'] === 'paid' || $order['status'] === 'success') {
                $title = "✅ <b>NẠP TIỀN AUTO BANK THÀNH CÔNG</b>";
                $footer = "💡 <i>Hệ thống đã tự động cộng tiền cho User này!</i>";
            } else {
                $title = "🔔 <b>YÊU CẦU KIỂM TRA NẠP THỦ CÔNG</b>";
                $footer = "💡 <i>User báo đã chuyển khoản. Hãy check Bank và cộng tiền thủ công!</i>";
            }

            // 3. Xây dựng nội dung tin nhắn SIÊU CHI TIẾT
            $msg = $title . "\n";
            $msg .= "━━━━━━━━━━━━━━━━━━\n";
            $msg .= "👤 <b>THÔNG TIN KHÁCH HÀNG:</b>\n";
            $msg .= " ├ ID User: <code>" . $order['user_id'] . "</code>\n";
            $msg .= " ├ Tên: <b>" . htmlspecialchars($user_display) . "</b>\n";
            $msg .= " └ Email: " . htmlspecialchars($order['email']) . "\n\n";
            
            $msg .= "💳 <b>THÔNG TIN GIAO DỊCH:</b>\n";
            $msg .= " ├ Mã Đơn: <code>" . substr($order['order_token'], 0, 12) . "...</code>\n";
            $msg .= " ├ Số Tiền: <b>" . $amount_format . "</b>\n";
            $msg .= " ├ Nội Dung CK: <code>" . $content_safe . "</code>\n";
            $msg .= " ├ Thời Gian: " . $time_format . "\n";
            $msg .= " └ Trạng Thái: " . strtoupper($order['status']) . "\n";
            $msg .= "━━━━━━━━━━━━━━━━━━\n";
            $msg .= $footer;
            
            // 4. Gửi bằng cURL (Bỏ check SSL để tương thích mọi Hosting)
            $url = "https://api.telegram.org/bot" . $botToken . "/sendMessage";
            
            $post_fields = [
                'chat_id' => $chatId,
                'text' => $msg,
                'parse_mode' => 'HTML'
            ];
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Quan trọng
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            
            $result = curl_exec($ch);
            $err = curl_error($ch);
            curl_close($ch);
            
            if ($err) {
                echo json_encode(['status' => 'error', 'message' => 'Lỗi máy chủ CURL: ' . $err]);
            } else {
                $response = json_decode($result, true);
                if (isset($response['ok']) && $response['ok'] == true) {
                    echo json_encode(['status' => 'success', 'message' => 'Đã gửi thông báo siêu chi tiết cho Admin!']);
                } else {
                    // Trả về lỗi chi tiết từ Telegram để bạn dễ debug
                    $error_desc = $response['description'] ?? 'Lỗi không xác định từ Telegram';
                    echo json_encode(['status' => 'error', 'message' => 'Lỗi Telegram: ' . $error_desc]);
                }
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Hệ thống chưa cấu hình Token Bot hoặc Chat ID.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Không tìm thấy hóa đơn này trên hệ thống.']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Lỗi hệ thống backend: ' . $e->getMessage()]);
}
?>
