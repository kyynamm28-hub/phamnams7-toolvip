<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Bảo mật API
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Lỗi truy cập']); exit;
}

$user_id = $_SESSION['user_id'];
$blog_id = isset($_POST['blog_id']) ? (int)$_POST['blog_id'] : 0;

try {
    // Khóa dòng để tránh spam
    $pdo->beginTransaction();

    // Check xem blog có tồn tại không
    $stmtCheck = $pdo->prepare("SELECT id, likes FROM blogs WHERE id = ? FOR UPDATE");
    $stmtCheck->execute([$blog_id]);
    $blog = $stmtCheck->fetch();

    if (!$blog) {
        throw new Exception("Không tìm thấy bài viết");
    }

    // Check Like status
    $stmtLiked = $pdo->prepare("SELECT 1 FROM blog_likes WHERE user_id = ? AND blog_id = ?");
    $stmtLiked->execute([$user_id, $blog_id]);
    $alreadyLiked = $stmtLiked->fetchColumn();

    if ($alreadyLiked) {
        // Nếu đã Like -> Hủy Like
        $pdo->prepare("DELETE FROM blog_likes WHERE user_id = ? AND blog_id = ?")->execute([$user_id, $blog_id]);
        $pdo->prepare("UPDATE blogs SET likes = likes - 1 WHERE id = ?")->execute([$blog_id]);
    } else {
        // Nếu chưa Like -> Thêm Like
        $pdo->prepare("INSERT INTO blog_likes (user_id, blog_id) VALUES (?, ?)")->execute([$user_id, $blog_id]);
        $pdo->prepare("UPDATE blogs SET likes = likes + 1 WHERE id = ?")->execute([$blog_id]);
    }

    $pdo->commit();
    echo json_encode(['status' => 'success']);

} catch (Exception $e) {
    if ($pdo->inTransaction()) { $pdo->rollBack(); }
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
