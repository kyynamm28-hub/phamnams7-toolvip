<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Vui lòng đăng nhập!']);
    exit;
}

$user_id = $_SESSION['user_id'];
$package_id = isset($_POST['package_id']) ? (int)$_POST['package_id'] : 0;

try {
    $pdo->beginTransaction();

    // 1. Lock dòng User để kiểm tra số dư (Tránh lỗi thao tác đồng thời)
    $stmtUser = $pdo->prepare("SELECT balance, vip_expire_at FROM users WHERE id = :uid FOR UPDATE");
    $stmtUser->execute(['uid' => $user_id]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    // 2. Lấy thông tin gói VIP
    $stmtPkg = $pdo->prepare("SELECT * FROM packages WHERE id = :id AND status = 'active' LIMIT 1");
    $stmtPkg->execute(['id' => $package_id]);
    $package = $stmtPkg->fetch(PDO::FETCH_ASSOC);

    if (!$package) {
        throw new Exception('Gói VIP không tồn tại hoặc đã ngừng bán.');
    }

    if ($user['balance'] < $package['price']) {
        throw new Exception('Số dư không đủ để thanh toán.');
    }

    // 3. Tính toán thời gian hết hạn mới
    // Nếu User vẫn còn hạn VIP -> Cộng dồn số ngày vào ngày hết hạn hiện tại
    // Nếu chưa có hoặc đã hết hạn -> Tính từ thời điểm HIỆN TẠI
    $currentTime = time();
    $currentExpire = strtotime($user['vip_expire_at'] ?? '0');
    
    if ($currentExpire > $currentTime) {
        $newExpire = date('Y-m-d H:i:s', strtotime('+' . $package['duration_days'] . ' days', $currentExpire));
    } else {
        $newExpire = date('Y-m-d H:i:s', strtotime('+' . $package['duration_days'] . ' days', $currentTime));
    }

    // 4. Trừ tiền và Cập nhật trạng thái VIP cho User
    $updateUser = $pdo->prepare("UPDATE users SET balance = balance - :price, vip_name = :vname, vip_expire_at = :expire WHERE id = :uid");
    $updateUser->execute([
        'price' => $package['price'],
        'vname' => $package['name'],
        'expire' => $newExpire,
        'uid' => $user_id
    ]);

    // 5. Lưu lịch sử thuê gói siêu chi tiết
    $insertHistory = $pdo->prepare("
        INSERT INTO history_package (user_id, package_id, package_name, price, duration_days, purchased_at, expires_at) 
        VALUES (:uid, :pid, :pname, :price, :days, NOW(), :expire)
    ");
    $insertHistory->execute([
        'uid' => $user_id,
        'pid' => $package['id'],
        'pname' => $package['name'],
        'price' => $package['price'],
        'days' => $package['duration_days'],
        'expire' => $newExpire
    ]);
    $history_id = $pdo->lastInsertId();

    $pdo->commit();
    echo json_encode(['status' => 'success', 'history_id' => $history_id]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) { $pdo->rollBack(); }
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
