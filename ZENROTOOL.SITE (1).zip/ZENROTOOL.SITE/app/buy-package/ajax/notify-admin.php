<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../../config/database.php';

$history_id = isset($_POST['history_id']) ? (int)$_POST['history_id'] : 0;
if ($history_id <= 0) exit;

try {
    // 1. Lấy thông tin hóa đơn MUA VIP + thông tin user
    $stmt = $pdo->prepare("
        SELECT h.*, u.username
        FROM history_package h 
        JOIN users u ON h.user_id = u.id 
        WHERE h.id = ? LIMIT 1
    ");
    $stmt->execute([$history_id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($data) {
        // 2. Lấy thông tin Bot Telegram
        $stmtBot = $pdo->query("SELECT * FROM setting_bot LIMIT 1");
        $bot = $stmtBot->fetch(PDO::FETCH_ASSOC);

        if ($bot && !empty($bot['telegram_token']) && !empty($bot['chat_id'])) {
            $botToken = trim($bot['telegram_token']);
            $chatId = trim($bot['chat_id']);

            // 3. Soạn nội dung siêu chi tiết cho thông báo MUA VIP
            $msg = "🎉 <b>THÔNG BÁO MUA GÓI VIP MỚI</b>\n";
            $msg .= "━━━━━━━━━━━━━━━━━━\n";
            $msg .= "👤 <b>Khách hàng:</b> <code>" . ($data['username'] ?? 'Unknown') . "</code> (ID: ".$data['user_id'].")\n";
            $msg .= "📦 <b>Gói VIP:</b> <b>" . $data['package_name'] . "</b>\n";
            $msg .= "💵 <b>Thanh toán:</b> " . number_format($data['price']) . " VNĐ\n";
            $msg .= "⏳ <b>Thời hạn:</b> " . $data['duration_days'] . " Ngày\n";
            $msg .= "🕒 <b>Hết hạn:</b> " . $data['expires_at'] . "\n";
            $msg .= "📅 <b>Ngày mua:</b> " . $data['purchased_at'] . "\n";
            $msg .= "━━━━━━━━━━━━━━━━━━\n";
            $msg .= "📢 <b>Kênh chính thức:</b> @zenrotool\n";
            $msg .= "👨‍💻 <b>Owner:</b> @ThienNhanVn";

            // 4. Tạo nút Inline Keyboard (Nút bấm dưới tin nhắn Telegram)
            $keyboard = [
                'inline_keyboard' => [
                    [
                        [
                            'text' => '🌐 Truy cập Website', 
                            'url' => 'https://zenrotool.site/auth/#register'
                        ]
                    ]
                ]
            ];

            // 5. Gửi qua cURL
            $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
            $post_fields = [
                'chat_id' => $chatId, 
                'text' => $msg, 
                'parse_mode' => 'HTML',
                'reply_markup' => json_encode($keyboard)
            ];
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_exec($ch);
            curl_close($ch);
        }
    }
} catch (Exception $e) {}

// Vẫn trả về JSON để Frontend tắt vòng xoay loading
echo json_encode(['status' => 'success']);
?>
