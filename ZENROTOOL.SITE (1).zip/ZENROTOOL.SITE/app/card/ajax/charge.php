<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 100, 'message' => 'Vui lòng đăng nhập để nạp thẻ.']); exit;
}

$user_id = $_SESSION['user_id'];
$input = json_decode(file_get_contents('php://input'), true);
$telco  = trim($input['telco'] ?? '');
$amount = trim($input['amount'] ?? '');
$serial = trim($input['serial'] ?? '');
$code   = trim($input['code'] ?? '');

try {
    if (empty($telco) || empty($amount) || empty($serial) || empty($code)) throw new Exception("Vui lòng điền đủ thông tin!");

    $stmtCard = $pdo->query("SELECT partner_id, partner_key, status FROM setting_card LIMIT 1");
    $cardConfig = $stmtCard->fetch(PDO::FETCH_ASSOC);

    if (!$cardConfig || $cardConfig['status'] !== 'active' || empty($cardConfig['partner_id'])) {
        throw new Exception("Hệ thống nạp thẻ đang bảo trì.");
    }

    $stmtCheck = $pdo->prepare("SELECT id FROM card_history WHERE serial = ? AND code = ? AND status IN (1, 2, 99)");
    $stmtCheck->execute([$serial, $code]);
    if ($stmtCheck->fetch()) throw new Exception("Thẻ này đã tồn tại hoặc đang xử lý!");

    $request_id = time() . rand(1000, 9999);
    $sign = md5($cardConfig['partner_key'] . $code . $serial);

    $postData = [
        'telco' => $telco, 'code' => $code, 'serial' => $serial, 'amount' => $amount,
        'request_id' => $request_id, 'partner_id' => $cardConfig['partner_id'], 'sign' => $sign, 'command' => 'charging'
    ];

    $ch = curl_init('https://gachthefast.com/chargingws/v2');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $response = json_decode(curl_exec($ch), true);
    curl_close($ch);

    $api_status = $response['status'] ?? 100;
    $api_message = $response['message'] ?? 'Lỗi kết nối tới đối tác.';

    if (in_array($api_status, [1, 2, 99])) {
        // Chỉ lưu DB, KHÔNG BÁO TELEGRAM Ở ĐÂY
        $stmtInsert = $pdo->prepare("INSERT INTO card_history (user_id, telco, amount, serial, code, request_id, status, message) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmtInsert->execute([$user_id, $telco, $amount, $serial, $code, $request_id, $api_status, $api_message]);
    }
    
    // Trả thêm request_id để Frontend chạy Ajax Polling
    echo json_encode(['status' => $api_status, 'message' => $api_message, 'request_id' => $request_id]);

} catch (Exception $e) {
    echo json_encode(['status' => 100, 'message' => $e->getMessage()]);
}
?>
