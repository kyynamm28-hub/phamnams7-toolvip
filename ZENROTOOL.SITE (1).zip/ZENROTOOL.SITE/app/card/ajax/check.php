<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../../../config/database.php';

if (!isset($_SESSION['user_id'])) exit(json_encode(['status' => 100]));
$user_id = $_SESSION['user_id'];

$input = json_decode(file_get_contents('php://input'), true);
$request_id = trim($input['request_id'] ?? '');

if (empty($request_id)) exit(json_encode(['status' => 100, 'message' => 'Thiếu Request ID']));

// Lấy thông tin thẻ trong DB
$stmtCard = $pdo->prepare("SELECT * FROM card_history WHERE request_id = ? AND user_id = ?");
$stmtCard->execute([$request_id, $user_id]);
$card = $stmtCard->fetch(PDO::FETCH_ASSOC);

if (!$card) exit(json_encode(['status' => 100, 'message' => 'Không tìm thấy thẻ.']));
if ($card['status'] != 99) exit(json_encode(['status' => (int)$card['status'], 'message' => $card['message']]));

// Lấy cấu hình
$stmtConfig = $pdo->query("SELECT partner_id, partner_key, discounts FROM setting_card LIMIT 1");
$cConfig = $stmtConfig->fetch(PDO::FETCH_ASSOC);
$discounts = json_decode($cConfig['discounts'], true);

// Gửi lệnh check lên đối tác
$sign = md5($cConfig['partner_key'] . $card['code'] . $card['serial']);
$postData = [
    'telco' => $card['telco'], 'code' => $card['code'], 'serial' => $card['serial'],
    'amount' => $card['amount'], 'request_id' => $card['request_id'],
    'partner_id' => $cConfig['partner_id'], 'sign' => $sign, 'command' => 'check'
];

$ch = curl_init('https://gachthefast.com/chargingws/v2');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
$resArray = json_decode(curl_exec($ch), true);
curl_close($ch);

if (is_array($resArray) && isset($resArray['status'])) {
    $api_status = (int)$resArray['status'];
    
    // NẾU CÓ KẾT QUẢ TỪ NHÀ MẠNG
    if ($api_status != 99) {
        $amount_real = isset($resArray['declared_value']) ? (int)$resArray['declared_value'] : 0;
        $money_add = 0;
        $req_amount = (int)$card['amount'];
        $msg = 'Thất bại';

        // Xử lý tính tiền
        if ($api_status == 1) {
            $msg = 'Thẻ nạp thành công!';
            $money_add = $req_amount * (1 - ($discounts[$card['telco']][$req_amount] ?? 20) / 100);
        } elseif ($api_status == 2) {
            $msg = "Sai mệnh giá (Thực nhận từ thẻ: " . number_format($amount_real) . "đ)";
            $money_add = $amount_real * (1 - ($discounts[$card['telco']][$amount_real] ?? 30) / 100);
        } else {
            $msg = $resArray['message'] ?? 'Thẻ sai hoặc đã được sử dụng.';
        }

        $pdo->beginTransaction();
        try {
            // Cập nhật DB
            $pdo->prepare("UPDATE card_history SET status=?, message=?, real_amount=? WHERE id=?")->execute([$api_status, $msg, $amount_real, $card['id']]);
            
            // Nếu có cộng tiền -> BẮN TELEGRAM
            if ($money_add > 0) {
                $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id=?")->execute([$money_add, $user_id]);
                
                // Gửi Telegram
                $stmtBot = $pdo->query("SELECT telegram_token, chat_id FROM setting_bot LIMIT 1");
                $bot = $stmtBot->fetch(PDO::FETCH_ASSOC);
                
                if (!empty($bot['telegram_token']) && !empty($bot['chat_id'])) {
                    $uStmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
                    $uStmt->execute([$user_id]);
                    $username = $uStmt->fetchColumn();

                    $msg_tele = "✅ <b>NẠP THẺ THÀNH CÔNG</b>\n";
                    $msg_tele .= "━━━━━━━━━━━━━━━━━\n";
                    $msg_tele .= "👤 User: <b>$username</b>\n";
                    $msg_tele .= "📶 Loại thẻ: <b>{$card['telco']}</b>\n";
                    $msg_tele .= "💵 Gửi lên: <b>" . number_format($req_amount) . "đ</b>\n";
                    $msg_tele .= "💰 Web cộng: <b>+" . number_format($money_add) . "đ</b>\n";

                    $urlTele = "https://api.telegram.org/bot{$bot['telegram_token']}/sendMessage";
                    $post_tele = ['chat_id' => $bot['chat_id'], 'text' => $msg_tele, 'parse_mode' => 'HTML'];
                    
                    $chBot = curl_init($urlTele);
                    curl_setopt($chBot, CURLOPT_POST, 1);
                    curl_setopt($chBot, CURLOPT_POSTFIELDS, $post_tele);
                    curl_setopt($chBot, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($chBot, CURLOPT_TIMEOUT, 3);
                    curl_exec($chBot);
                    curl_close($chBot);
                }
            }
            $pdo->commit();
            echo json_encode(['status' => $api_status, 'message' => $msg]);
        } catch (Exception $e) {
            $pdo->rollBack();
            echo json_encode(['status' => 100, 'message' => 'Lỗi cập nhật CSDL']);
        }
    } else {
        // Vẫn 99
        echo json_encode(['status' => 99, 'message' => 'Đang xử lý']);
    }
} else {
    echo json_encode(['status' => 99, 'message' => 'Đang chờ máy chủ phản hồi']);
}
?>
