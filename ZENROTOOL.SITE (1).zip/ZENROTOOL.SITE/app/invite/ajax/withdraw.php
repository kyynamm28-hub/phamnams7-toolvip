<?php
// app/invite/ajax/withdraw.php
session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/settings.php';

if (!isset($_SESSION['user_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Truy cập trái phép.']);
    exit;
}

$userId = (int)$_SESSION['user_id'];
$bank_name = trim($_POST['bank_name'] ?? '');
$account_number = trim($_POST['account_number'] ?? '');
$account_name = strtoupper(trim($_POST['account_name'] ?? ''));
$amount = (int)($_POST['amount'] ?? 0);

if (empty($bank_name) || empty($account_number) || empty($account_name) || $amount <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Vui lòng nhập đầy đủ và chính xác thông tin.']);
    exit;
}

try {
    $pdo->beginTransaction();

    // Khóa dòng user để chống Spam (Double Click)
    $stmtUser = $pdo->prepare("SELECT * FROM users WHERE id = ? FOR UPDATE");
    $stmtUser->execute([$userId]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    $stmtCtv = $pdo->query("SELECT * FROM setting_ctv LIMIT 1");
    $ctvData = $stmtCtv->fetch(PDO::FETCH_ASSOC);
    
    $min_withdraw = (int)($ctvData['min_withdraw'] ?? 50000);
    $withdraw_fee = (int)($ctvData['withdraw_fee'] ?? 5);

    if ($amount < $min_withdraw) {
        throw new Exception("Số tiền rút tối thiểu là " . number_format($min_withdraw) . "đ");
    }

    if ((float)$user['commission_balance'] < $amount) {
        throw new Exception("Số dư hoa hồng không đủ để thực hiện giao dịch.");
    }

    // Tính toán thực nhận
    $actual_amount = $amount - ($amount * $withdraw_fee / 100);

    // Trừ tiền hoa hồng của User
    $stmtUpdate = $pdo->prepare("UPDATE users SET commission_balance = commission_balance - ? WHERE id = ?");
    $stmtUpdate->execute([$amount, $userId]);

    // Thêm vào lịch sử rút tiền
    $stmtHistory = $pdo->prepare("INSERT INTO history_bank_ctv (user_id, bank_name, account_number, account_name, amount, actual_amount, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");
    $stmtHistory->execute([$userId, $bank_name, $account_number, $account_name, $amount, $actual_amount]);
    $withdrawId = $pdo->lastInsertId();

    $pdo->commit();

    // ===============================================
    // GỬI THÔNG BÁO BOT TELEGRAM 
    // ===============================================
    $stmtBot = $pdo->query("SELECT * FROM setting_bot LIMIT 1");
    $botData = $stmtBot->fetch(PDO::FETCH_ASSOC);

    if ($botData && !empty($botData['telegram_token']) && !empty($botData['chat_id'])) {
        $username = $user['username'] ?: $user['email'];
        $message = "🚨 <b>YÊU CẦU RÚT HOA HỒNG MỚI</b> 🚨\n"
                 . "👤 User: <b>{$username}</b>\n"
                 . "🏦 Ngân hàng: <b>{$bank_name}</b>\n"
                 . "💳 Số TK: <code>{$account_number}</code>\n"
                 . "📝 Chủ TK: <b>{$account_name}</b>\n"
                 . "💰 Yêu cầu rút: <b>" . number_format($amount) . "đ</b>\n"
                 . "💸 Thực nhận (-{$withdraw_fee}%): <b>" . number_format($actual_amount) . "đ</b>\n"
                 . "⏰ Thời gian: " . date('Y-m-d H:i:s') . "\n"
                 . "👉 Admin vui lòng check Panel để duyệt lệnh!";

        $url = "https://api.telegram.org/bot" . $botData['telegram_token'] . "/sendMessage";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
            'chat_id' => $botData['chat_id'],
            'text' => $message,
            'parse_mode' => 'HTML'
        ]));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 3); // Timeout nhanh 3s để không làm lag website
        curl_exec($ch);
        curl_close($ch);
    }

    echo json_encode(['status' => 'success', 'message' => 'Lệnh rút tiền đã được tạo! Bạn vui lòng chờ Admin xử lý.']);

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>