<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Bảo mật: Chỉ nhận POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Truy cập trái phép.']);
    exit;
}

$user_id = $_SESSION['user_id'];
$package_id = isset($_POST['package_id']) ? (int)$_POST['package_id'] : 0;

try {
    $pdo->beginTransaction();

    // Lấy User và Lock Row
    $stmtUser = $pdo->prepare("SELECT username, balance FROM users WHERE id = :uid FOR UPDATE");
    $stmtUser->execute(['uid' => $user_id]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    // Lấy gói API
    $stmtPkg = $pdo->prepare("SELECT * FROM api_packages WHERE id = :id AND status = 'active' LIMIT 1");
    $stmtPkg->execute(['id' => $package_id]);
    $package = $stmtPkg->fetch(PDO::FETCH_ASSOC);

    if (!$package) throw new Exception('Gói API không tồn tại hoặc đã đóng.');
    if ($user['balance'] < $package['price']) throw new Exception('Số dư không đủ. Vui lòng nạp thêm tiền.');

    // Sinh API Token (Mã hóa SHA-256)
    $raw_token_string = uniqid('zenro_api_', true) . $user_id . time() . random_bytes(16);
    $api_token = hash('sha256', $raw_token_string);

    // Tính hạn dùng
    $expires_at = date('Y-m-d H:i:s', strtotime('+' . $package['duration_days'] . ' days'));

    // Trừ tiền User
    $updateUser = $pdo->prepare("UPDATE users SET balance = balance - :price WHERE id = :uid");
    $updateUser->execute(['price' => $package['price'], 'uid' => $user_id]);

    // Lưu Lịch sử 
    $insertHistory = $pdo->prepare("
        INSERT INTO history_token (user_id, username, package_id, package_name, price, duration_days, api_token, purchased_at, expires_at) 
        VALUES (:uid, :uname, :pid, :pname, :price, :days, :token, NOW(), :expire)
    ");
    $insertHistory->execute([
        'uid' => $user_id,
        'uname' => $user['username'],
        'pid' => $package['id'],
        'pname' => $package['name'],
        'price' => $package['price'],
        'days' => $package['duration_days'],
        'token' => $api_token,
        'expire' => $expires_at
    ]);
    
    $history_id = $pdo->lastInsertId();
    $pdo->commit();

    echo json_encode([
        'status' => 'success', 
        'history_id' => $history_id,
        'api_token' => $api_token,
        'expires_at' => date('d/m/Y H:i', strtotime($expires_at))
    ]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) { $pdo->rollBack(); }
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
