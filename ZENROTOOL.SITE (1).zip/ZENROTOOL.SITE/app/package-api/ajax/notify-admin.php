<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../../config/database.php';

// Chỉ nhận nội bộ POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') exit;

$history_id = isset($_POST['history_id']) ? (int)$_POST['history_id'] : 0;
if (!$history_id) exit;

try {
    // Lấy thông tin history_token
    $stmt = $pdo->prepare("SELECT * FROM history_token WHERE id = ? LIMIT 1");
    $stmt->execute([$history_id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($data) {
        $stmtBot = $pdo->query("SELECT telegram_token, chat_id FROM setting_bot LIMIT 1");
        $bot = $stmtBot->fetch(PDO::FETCH_ASSOC);

        if ($bot && !empty($bot['telegram_token']) && !empty($bot['chat_id'])) {
            $botToken = trim($bot['telegram_token']);
            $chatId = trim($bot['chat_id']);

            $msg = "⚡️ <b>USER VỪA THUÊ API TOKEN</b>\n";
            $msg .= "━━━━━━━━━━━━━━━━━\n";
            $msg .= "👤 <b>Người mua:</b> <code>" . $data['username'] . "</code> (ID: ".$data['user_id'].")\n";
            $msg .= "📦 <b>Tên gói API:</b> <b>" . $data['package_name'] . "</b>\n";
            $msg .= "💰 <b>Giá mua:</b> " . number_format($data['price']) . " VNĐ\n";
            $msg .= "⏳ <b>Thời hạn:</b> " . $data['duration_days'] . " Ngày\n";
            $msg .= "🔑 <b>Mã Token (Ẩn 1 phần):</b> <code>" . substr($data['api_token'], 0, 10) . "******" . "</code>\n";
            $msg .= "📅 <b>Thời gian:</b> " . $data['purchased_at'] . "\n";
            $msg .= "━━━━━━━━━━━━━━━━━\n";

            $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
            $post_fields = ['chat_id' => $chatId, 'text' => $msg, 'parse_mode' => 'HTML'];
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_exec($ch);
            curl_close($ch);
        }
    }
} catch (Exception $e) {}
?>
