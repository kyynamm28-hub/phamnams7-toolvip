<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Lỗi truy cập']); exit;
}

$user_id = $_SESSION['user_id'];
$product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;

try {
    $pdo->beginTransaction();

    // Khóa dòng user để tránh bug click đúp
    $stmtUser = $pdo->prepare("SELECT username, balance FROM users WHERE id = :uid FOR UPDATE");
    $stmtUser->execute(['uid' => $user_id]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    // Lấy thông tin sản phẩm (Lấy luôn download_url)
    $stmtProd = $pdo->prepare("SELECT * FROM products WHERE id = :id AND status = 'active' LIMIT 1");
    $stmtProd->execute(['id' => $product_id]);
    $product = $stmtProd->fetch(PDO::FETCH_ASSOC);

    if (!$product) throw new Exception('Sản phẩm không tồn tại.');
    if ($user['balance'] < $product['price']) throw new Exception('Số dư không đủ.');

    // Trừ tiền
    $updateUser = $pdo->prepare("UPDATE users SET balance = balance - :price WHERE id = :uid");
    $updateUser->execute(['price' => $product['price'], 'uid' => $user_id]);

    // Lưu lịch sử
    $insertHistory = $pdo->prepare("
        INSERT INTO history_product (user_id, username, product_id, product_name, price, download_url, purchased_at) 
        VALUES (:uid, :uname, :pid, :pname, :price, :durl, NOW())
    ");
    $insertHistory->execute([
        'uid' => $user_id,
        'uname' => $user['username'],
        'pid' => $product['id'],
        'pname' => $product['name'],
        'price' => $product['price'],
        'durl' => $product['download_url']
    ]);
    
    $history_id = $pdo->lastInsertId();
    $pdo->commit();

    // Trả về Download URL chỉ khi thanh toán thành công
    echo json_encode([
        'status' => 'success', 
        'history_id' => $history_id,
        'download_url' => $product['download_url']
    ]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) { $pdo->rollBack(); }
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
