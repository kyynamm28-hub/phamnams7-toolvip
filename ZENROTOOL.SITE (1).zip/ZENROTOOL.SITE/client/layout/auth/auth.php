<?php
require_once __DIR__ . '/../../../config/database.php';

// Cấu hình callback cho Google
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$redirectUri = $protocol . "://" . $_SERVER['HTTP_HOST'] . "/auth/";

// --- XỬ LÝ ĐĂNG NHẬP BẰNG GOOGLE ---
if (isset($_GET['action']) && $_GET['action'] == 'google_login') {
    $client_id = getenv('GOOGLE_CLIENT_ID');
    $googleOauthURL = 'https://accounts.google.com/o/oauth2/v2/auth?scope=' . urlencode('https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email') . '&redirect_uri=' . urlencode($redirectUri) . '&response_type=code&client_id=' . $client_id . '&access_type=online';
    header('Location: ' . $googleOauthURL);
    exit;
}

if (isset($_GET['code'])) {
    $client_id = getenv('GOOGLE_CLIENT_ID');
    $client_secret = getenv('GOOGLE_CLIENT_SECRET');

    // Đổi code lấy token
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://oauth2.googleapis.com/token');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'code' => $_GET['code'],
        'client_id' => $client_id,
        'client_secret' => $client_secret,
        'redirect_uri' => $redirectUri,
        'grant_type' => 'authorization_code'
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    
    $tokenInfo = json_decode($response, true);

    if (isset($tokenInfo['access_token'])) {
        // Lấy thông tin user
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.googleapis.com/oauth2/v2/userinfo');
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $tokenInfo['access_token']]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $googleUser = json_decode(curl_exec($ch), true);
        curl_close($ch);

        if (!empty($googleUser['email'])) {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$googleUser['email']]);
            $user = $stmt->fetch();

            if (!$user) {
                // Tạo mới nếu chưa có
                $stmt = $pdo->prepare("INSERT INTO users (display_name, email, google_id) VALUES (?, ?, ?)");
                $stmt->execute([$googleUser['name'], $googleUser['email'], $googleUser['id']]);
                $userId = $pdo->lastInsertId();
            } else {
                $userId = $user['id'];
                // Cập nhật google_id nếu lỡ đk bằng email trước đó
                if(empty($user['google_id'])) {
                    $stmt = $pdo->prepare("UPDATE users SET google_id = ? WHERE id = ?");
                    $stmt->execute([$googleUser['id'], $userId]);
                }
            }
            $_SESSION['user_id'] = $userId;
            
            // --- GHI NHẬN THIẾT BỊ ĐĂNG NHẬP (GOOGLE) ---
            $session_id = session_id();
            $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
            $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
            $stmtDev = $pdo->prepare("INSERT INTO user_devices (user_id, session_id, user_agent, ip_address) VALUES (?, ?, ?, ?)");
            $stmtDev->execute([$userId, $session_id, $user_agent, $ip_address]);
            // -------------------------------------------

            header("Location: /home");
            exit;
        }
    }
    header("Location: /auth/#login");
    exit;
}

// --- XỬ LÝ POST (AJAX) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $action = $_POST['action'] ?? '';

    if ($action === 'register') {
        $displayName = trim($_POST['display_name']);
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $password = $_POST['password'];
        $passwordConfirm = $_POST['password_confirm'];

        if ($password !== $passwordConfirm) {
            echo json_encode(['status' => 'error', 'message' => 'Mật khẩu xác nhận không khớp!']);
            exit;
        }

        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
        $stmt->execute([$email, $username]);
        if ($stmt->fetch()) {
            echo json_encode(['status' => 'error', 'message' => 'Email hoặc Tên đăng nhập đã tồn tại!']);
            exit;
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (display_name, username, email, password) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$displayName, $username, $email, $hashedPassword])) {
            $new_user_id = $pdo->lastInsertId();
            $_SESSION['user_id'] = $new_user_id;

            // --- GHI NHẬN THIẾT BỊ ĐĂNG NHẬP (ĐĂNG KÝ MỚI) ---
            $session_id = session_id();
            $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
            $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
            $stmtDev = $pdo->prepare("INSERT INTO user_devices (user_id, session_id, user_agent, ip_address) VALUES (?, ?, ?, ?)");
            $stmtDev->execute([$new_user_id, $session_id, $user_agent, $ip_address]);
            // ------------------------------------------------

            echo json_encode(['status' => 'success', 'message' => 'Đăng ký thành công!', 'redirect' => '/home']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Có lỗi xảy ra, thử lại sau.']);
        }
        exit;
    }

    if ($action === 'login') {
        $login_id = trim($_POST['login_id']); // có thể là email hoặc username
        $password = $_POST['password'];

        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? OR username = ?");
        $stmt->execute([$login_id, $login_id]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];

            // --- GHI NHẬN THIẾT BỊ ĐĂNG NHẬP (FORM THƯỜNG) ---
            $session_id = session_id();
            $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
            $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
            $stmtDev = $pdo->prepare("INSERT INTO user_devices (user_id, session_id, user_agent, ip_address) VALUES (?, ?, ?, ?)");
            $stmtDev->execute([$user['id'], $session_id, $user_agent, $ip_address]);
            // ------------------------------------------------

            echo json_encode(['status' => 'success', 'message' => 'Đăng nhập thành công!', 'redirect' => '/home']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Tài khoản hoặc mật khẩu không chính xác!']);
        }
        exit;
    }
}
?>

<!doctype html>
<html lang="vi">
    <head>
        <meta charset="UTF-8"/>
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0"/>
        <title>Xác thực - ZENRO.SITE</title>
        <link rel="icon" href="https://img.upanh.moe/jYZWRgJ/Orange-Black-Minimal-Professional-Letter-B-Business-Logo-2-png.png">
        <meta name="description" content="Zenro.site chuyên cung cấp các công cụ tiện ích, dịch vụ mạng xã hội và tài nguyên MMO.">
        
        <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
        <style>
            * { font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif !important; letter-spacing: -0.01em; }
            html { transition: background-color 0.3s ease; }
            [x-cloak] { display: none !important; }
        </style>
        <script src="https://cdn.tailwindcss.com?plugins=forms"></script>
        <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
        <script>
            tailwind.config = {
                darkMode: 'class',
                theme: {
                    extend: {
                        colors: {
                            brand: { 50: '#ecf3ff', 100: '#dde9ff', 200: '#c2d6ff', 300: '#9cb9ff', 400: '#7592ff', 500: '#465fff', 600: '#2e3ef5', 700: '#232fe1', 800: '#1c29b6', 900: '#1d298f', 950: '#131956' },
                            error: { 500: '#f04438' }
                        },
                        boxShadow: { 'theme-xs': '0px 1px 2px 0px rgba(16, 24, 40, 0.04)' }
                    }
                }
            }
        </script>
        <script>if (localStorage.getItem('darkMode') === 'true') document.documentElement.classList.add('dark');</script>
    </head>
    <body x-data="{ darkMode: false, view: window.location.hash.includes('login') ? 'login' : 'register' }" 
          @hashchange.window="view = window.location.hash.includes('login') ? 'login' : 'register'"
          x-init="darkMode = JSON.parse(localStorage.getItem('darkMode')) || false; $watch('darkMode', v => { localStorage.setItem('darkMode', JSON.stringify(v)); document.documentElement.classList.toggle('dark', v); })" 
          class="bg-white dark:bg-gray-900 transition-colors duration-300">
        
        <div class="relative p-6 bg-white z-1 dark:bg-gray-900 sm:p-0">
            <div class="relative flex flex-col justify-center w-full min-h-screen dark:bg-gray-900 sm:p-0 lg:flex-row">
                <div class="flex flex-col flex-1 w-full lg:w-1/2 overflow-y-auto">
                    <div class="w-full max-w-md pt-5 mx-auto sm:py-10">
                        <a href="/" class="inline-flex items-center text-sm text-gray-500 transition-colors hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300">
                            <svg class="stroke-current mr-1" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M12.7083 5L7.5 10.2083L12.7083 15.4167" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg> Về trang chủ
                        </a>
                    </div>
                    
                    <div class="flex flex-col justify-center flex-1 w-full max-w-md mx-auto pb-10">
                        <div class="mb-5 sm:mb-8">
                            <h1 class="mb-2 font-semibold text-gray-800 text-3xl dark:text-white/90" x-text="view === 'register' ? 'Đăng ký tài khoản' : 'Đăng nhập hệ thống'"></h1>
                            <p class="text-sm text-gray-500 dark:text-gray-400" x-text="view === 'register' ? 'Tham gia ZENRO.SITE ngay hôm nay!' : 'Chào mừng bạn quay trở lại!'"></p>
                        </div>
                        
                        <div>
                            <form id="registerForm" x-show="view === 'register'" x-cloak>
                                <div class="space-y-4">
                                    <div>
                                        <label class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400">Tên hiển thị <span class="text-error-500">*</span></label>
                                        <input type="text" name="display_name" placeholder="Nhập tên hiển thị" required class="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:focus:border-brand-500"/>
                                    </div>
                                    <div>
                                        <label class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400">Tên đăng nhập <span class="text-error-500">*</span></label>
                                        <input type="text" name="username" placeholder="Nhập tên đăng nhập" required class="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:focus:border-brand-500"/>
                                    </div>
                                    <div>
                                        <label class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400">Email <span class="text-error-500">*</span></label>
                                        <input type="email" name="email" placeholder="Nhập địa chỉ email" required class="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:focus:border-brand-500"/>
                                    </div>
                                    <div class="grid grid-cols-2 gap-4">
                                        <div x-data="{ show: false }" class="relative">
                                            <label class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400">Mật khẩu <span class="text-error-500">*</span></label>
                                            <input :type="show ? 'text' : 'password'" name="password" placeholder="Mật khẩu" required class="h-11 w-full rounded-lg border border-gray-300 bg-transparent py-2.5 pl-4 pr-10 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:focus:border-brand-500"/>
                                            <span @click="show = !show" class="absolute z-30 text-gray-500 cursor-pointer right-3 top-[34px] dark:text-gray-400">
                                                <svg x-show="!show" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                                                <svg x-show="show" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/></svg>
                                            </span>
                                        </div>
                                        <div x-data="{ show: false }" class="relative">
                                            <label class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400">Xác nhận <span class="text-error-500">*</span></label>
                                            <input :type="show ? 'text' : 'password'" name="password_confirm" placeholder="Nhập lại" required class="h-11 w-full rounded-lg border border-gray-300 bg-transparent py-2.5 pl-4 pr-10 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:focus:border-brand-500"/>
                                            <span @click="show = !show" class="absolute z-30 text-gray-500 cursor-pointer right-3 top-[34px] dark:text-gray-400">
                                                <svg x-show="!show" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                                                <svg x-show="show" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/></svg>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="pt-2">
                                        <button type="submit" class="submit-btn flex items-center justify-center w-full px-4 py-3 text-sm font-medium text-white transition rounded-lg bg-brand-500 shadow-theme-xs hover:bg-brand-600">Đăng ký tài khoản</button>
                                    </div>
                                </div>
                            </form>

                            <form id="loginForm" x-show="view === 'login'" x-cloak>
                                <div class="space-y-4">
                                    <div>
                                        <label class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400">Tài khoản / Email <span class="text-error-500">*</span></label>
                                        <input type="text" name="login_id" placeholder="Nhập tên đăng nhập hoặc email" required class="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:focus:border-brand-500"/>
                                    </div>
                                    <div x-data="{ show: false }" class="relative">
                                        <div class="flex justify-between items-center mb-1.5">
                                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400">Mật khẩu <span class="text-error-500">*</span></label>
                                            <a href="/change-pass" class="text-xs font-medium text-brand-500 hover:text-brand-600 dark:text-brand-400 transition-colors hover:underline">Đổi / Quên mật khẩu?</a>
                                        </div>
                                        <input :type="show ? 'text' : 'password'" name="password" placeholder="Mật khẩu" required class="h-11 w-full rounded-lg border border-gray-300 bg-transparent py-2.5 pl-4 pr-10 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:focus:border-brand-500"/>
                                        <span @click="show = !show" class="absolute z-30 text-gray-500 cursor-pointer right-3 top-[34px] dark:text-gray-400">
                                            <svg x-show="!show" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                                            <svg x-show="show" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/></svg>
                                        </span>
                                    </div>
                                    <div class="pt-2">
                                        <button type="submit" class="submit-btn flex items-center justify-center w-full px-4 py-3 text-sm font-medium text-white transition rounded-lg bg-brand-500 shadow-theme-xs hover:bg-brand-600">Đăng nhập</button>
                                    </div>
                                </div>
                            </form>
                            
                            <div class="mt-4">
                                <div class="relative flex items-center justify-center my-4">
                                    <div class="absolute inset-0 flex items-center">
                                        <div class="w-full border-t border-gray-200 dark:border-gray-700"></div>
                                    </div>
                                    <span class="relative px-3 text-xs text-gray-500 bg-white dark:bg-gray-900 dark:text-gray-400" x-text="view === 'register' ? 'hoặc đăng ký bằng' : 'hoặc đăng nhập bằng'"></span>
                                </div>
                                
                                <a href="?action=google_login" class="flex items-center justify-center w-full gap-2 px-4 py-2.5 text-sm font-medium text-gray-700 transition bg-white border border-gray-300 rounded-lg hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700 dark:hover:bg-gray-700 shadow-theme-xs">
                                    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                                        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                                        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                                        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                                    </svg>
                                    Google
                                </a>
                            </div>

                            <div class="mt-5">
                                <p class="text-sm font-normal text-center text-gray-700 dark:text-gray-400" x-show="view === 'register'">
                                    Đã có tài khoản? <a href="#login" class="text-brand-500 font-medium hover:text-brand-600 dark:text-brand-400">Đăng nhập</a>
                                </p>
                                <p class="text-sm font-normal text-center text-gray-700 dark:text-gray-400" x-show="view === 'login'">
                                    Chưa có tài khoản? <a href="#register" class="text-brand-500 font-medium hover:text-brand-600 dark:text-brand-400">Đăng ký</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="relative items-center hidden w-full h-full bg-brand-900 dark:bg-black/50 lg:flex lg:w-1/2">
                    <div class="flex flex-col items-center justify-center w-full px-10 z-10">
                        <div class="mb-6">
                            <span class="text-5xl font-bold text-white tracking-wider">ZENRO</span>
                        </div>
                        <h1 class="mb-4 text-3xl font-bold text-center text-white">Hệ sinh thái đa dịch vụ MMO</h1>
                        <p class="mb-8 text-lg text-center text-brand-200 max-w-md">Công cụ tối ưu, mạng xã hội, fake bill và hàng ngàn tài nguyên khác đang chờ bạn khám phá.</p>
                    </div>
                    <div class="absolute inset-0 bg-gradient-to-br from-brand-600/20 to-brand-900/80 z-0"></div>
                </div>
                
                <div class="fixed z-50 hidden bottom-6 right-6 sm:block">
                    <button class="inline-flex items-center justify-center text-white transition-colors rounded-full size-12 shadow-lg bg-gray-800 dark:bg-gray-700 hover:bg-gray-700 dark:hover:bg-gray-600" @click.prevent="darkMode = !darkMode">
                        <svg x-show="!darkMode" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"></path></svg>
                        <svg x-show="darkMode" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
                    </button>
                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            function handleFormSubmit(formId, actionName) {
                document.getElementById(formId).addEventListener('submit', async function(e) {
                    e.preventDefault(); 
                    
                    const btn = this.querySelector('.submit-btn');
                    const originalText = btn.innerHTML;
                    
                    btn.disabled = true;
                    btn.innerHTML = `<svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline-block" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Đang xử lý...`;
                    btn.classList.add('opacity-70', 'cursor-not-allowed');

                    const formData = new FormData(this);
                    formData.append('action', actionName); 

                    try {
                        const response = await fetch('/auth/', { method: 'POST', body: formData });
                        const result = await response.json();

                        if (result.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Thành công!',
                                text: result.message,
                                showConfirmButton: false,
                                timer: 2000,
                                background: document.documentElement.classList.contains('dark') ? '#1e293b' : '#fff',
                                color: document.documentElement.classList.contains('dark') ? '#fff' : '#000'
                            }).then(() => window.location.href = result.redirect);
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Thất bại',
                                text: result.message,
                                confirmButtonColor: '#3b82f6',
                                background: document.documentElement.classList.contains('dark') ? '#1e293b' : '#fff',
                                color: document.documentElement.classList.contains('dark') ? '#fff' : '#000'
                            });
                            btn.disabled = false;
                            btn.innerHTML = originalText;
                            btn.classList.remove('opacity-70', 'cursor-not-allowed');
                        }
                    } catch (error) {
                        Swal.fire('Lỗi', 'Không thể kết nối đến máy chủ!', 'error');
                        btn.disabled = false;
                        btn.innerHTML = originalText;
                        btn.classList.remove('opacity-70', 'cursor-not-allowed');
                    }
                });
            }

            handleFormSubmit('registerForm', 'register');
            handleFormSubmit('loginForm', 'login');
        </script>
    </body>
</html>
