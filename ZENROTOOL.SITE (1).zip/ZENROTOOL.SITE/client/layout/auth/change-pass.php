<?php
// Bọc session_start để tránh lỗi Notice
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Đường dẫn lùi 3 cấp từ: auth -> layout -> client -> root
require_once __DIR__ . '/../../../config/database.php';

// CÁC LỆNH USE BẮT BUỘC PHẢI ĐẶT Ở NGOÀI CÙNG (TOP-LEVEL)
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Chỉ chạy thư viện và xử lý Logic nếu có tham số ?action=...
if (isset($_GET['action'])) {
    
    // Nạp file thư viện (Điều chỉnh đường dẫn tương đối theo vị trí file hiện tại)
    require __DIR__ . '/../../../client/libs/PHPMailer/src/Exception.php';
    require __DIR__ . '/../../../client/libs/PHPMailer/src/PHPMailer.php';
    require __DIR__ . '/../../../client/libs/PHPMailer/src/SMTP.php';

    header('Content-Type: application/json; charset=utf-8');

    $action = $_GET['action'];
    $data = json_decode(file_get_contents("php://input"), true);

    /**
     * Hàm Helper trả về kết quả JSON và NGẮT KẾT NỐI DATABASE
     */
    function response($status, $message) {
        global $pdo;
        if (isset($pdo)) {
            $pdo = null; 
        }
        echo json_encode(['status' => $status, 'message' => $message]);
        exit;
    }

    // Hàm gửi mail bằng SMTP sử dụng PHPMailer
    function sendMailSMTP($to, $subject, $body, $isHtml = false) {
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = getenv('SMTP_HOST') ?: 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = getenv('SMTP_USER');
            $mail->Password   = getenv('SMTP_PASS');
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = getenv('SMTP_PORT') ?: 587;
            $mail->CharSet    = 'UTF-8';

            $appName = getenv('APP_NAME') ?: 'ZENRO.SITE';
            $mail->setFrom(getenv('SMTP_USER'), $appName);
            $mail->addAddress($to);

            $mail->isHTML($isHtml);
            $mail->Subject = $subject;
            $mail->Body    = $body;

            $mail->send();
            return true;
        } catch (Exception $e) {
            error_log("Lỗi gửi mail SMTP: {$mail->ErrorInfo}");
            return false;
        }
    }

    switch ($action) {
        // =====================================
        // 1. GỬI MÃ OTP VỀ EMAIL
        // =====================================
        case 'send_otp':
            $email = trim($data['email'] ?? '');
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) response('error', 'Định dạng email không hợp lệ!');

            $stmt = $pdo->prepare("SELECT id, display_name FROM users WHERE email = :email LIMIT 1");
            $stmt->execute(['email' => $email]);
            $user = $stmt->fetch();

            if (!$user) {
                usleep(500000); // Fake delay chống scan
                response('error', 'Không tìm thấy tài khoản nào với Email này!');
            }

            $otp = rand(100000, 999999);
            
            $_SESSION['reset_email'] = $email;
            $_SESSION['reset_otp'] = $otp;
            $_SESSION['reset_expires'] = time() + 300; // 5 phút

            $subject = "Mã xác nhận khôi phục mật khẩu - ZENRO.SITE";
            $message = "Chào {$user['display_name']},\n\nMã OTP khôi phục mật khẩu của bạn là: $otp\n\nMã này sẽ hết hạn sau 5 phút. Vui lòng không chia sẻ mã này cho bất kỳ ai.\n\nĐội ngũ ZENRO.SITE.";
            
            if (sendMailSMTP($email, $subject, $message, false)) {
                response('success', 'Mã xác nhận đã được gửi đến email của bạn!');
            } else {
                response('error', 'Không thể gửi email lúc này. Vui lòng kiểm tra lại cấu hình SMTP!');
            }
            break;

        // =====================================
        // 2. XÁC THỰC MÃ OTP
        // =====================================
        case 'verify_otp':
            $input_otp = trim($data['otp'] ?? '');

            if (!isset($_SESSION['reset_otp']) || !isset($_SESSION['reset_expires'])) {
                response('error', 'Phiên làm việc đã hết hạn. Vui lòng gửi lại email!');
            }

            if (time() > $_SESSION['reset_expires']) {
                response('error', 'Mã OTP đã hết hạn (quá 5 phút)!');
            }

            if ($input_otp != $_SESSION['reset_otp']) {
                response('error', 'Mã OTP không chính xác!');
            }

            $_SESSION['reset_verified'] = true;
            response('success', 'Xác thực thành công. Vui lòng nhập mật khẩu mới!');
            break;

        // =====================================
        // 3. ĐỔI MẬT KHẨU & GỬI MAIL THÔNG BÁO CHI TIẾT
        // =====================================
        case 'reset_password':
            $new_password = $data['password'] ?? '';

            if (empty($_SESSION['reset_verified']) || empty($_SESSION['reset_email'])) {
                response('error', 'Hành động bị từ chối do chưa xác thực OTP!');
            }

            $email = $_SESSION['reset_email'];
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            // Cập nhật Database
            $stmt = $pdo->prepare("UPDATE users SET password = :password WHERE email = :email");
            $stmt->execute(['password' => $hashed_password, 'email' => $email]);

            // Lấy thông tin build mail HTML
            $uStmt = $pdo->prepare("SELECT display_name FROM users WHERE email = :email LIMIT 1");
            $uStmt->execute(['email' => $email]);
            $user = $uStmt->fetch();

            $user_name = $user['display_name'] ?: 'Khách hàng';
            $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'Không xác định';
            $time_str = date('d/m/Y H:i:s');
            $os_browser = $_SERVER['HTTP_USER_AGENT'] ?? 'Trình duyệt lạ';

            // Gọi template giao diện (cùng cấp thư mục)
            $template_path = __DIR__ . '/changepass-html.php';
            if (file_exists($template_path)) {
                ob_start();
                include $template_path;
                $html_content = ob_get_clean();

                $html_content = str_replace(
                    ['{{USER_NAME}}', '{{IP_ADDRESS}}', '{{TIME}}', '{{OS_BROWSER}}'],
                    [$user_name, $ip_address, $time_str, $os_browser],
                    $html_content
                );

                $subject = "Cảnh báo: Mật khẩu ZENRO.SITE của bạn đã bị thay đổi!";
                sendMailSMTP($email, $subject, $html_content, true);
            }

            // Dọn dẹp Session
            unset($_SESSION['reset_email'], $_SESSION['reset_otp'], $_SESSION['reset_expires'], $_SESSION['reset_verified']);

            response('success', 'Đổi mật khẩu thành công! Đang chuyển hướng...');
            break;

        default:
            response('error', 'Hành động không hợp lệ!');
    }
}
?>

<!doctype html>
<html lang="vi">
    <head>
        <meta charset="UTF-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <title>Khôi phục mật khẩu - ZENRO.SITE</title>
        <link rel="icon" href="https://img.upanh.moe/jYZWRgJ/Orange-Black-Minimal-Professional-Letter-B-Business-Logo-2-png.png">
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
        <style>
            * { font-family: 'Inter', sans-serif !important; letter-spacing: -0.01em; }
            html { transition: background-color 0.3s ease; }
            /* Khóa mũi tên của input type number cho ô OTP */
            input[type=number]::-webkit-inner-spin-button, 
            input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
            [x-cloak] { display: none !important; }
        </style>
        <script src="https://cdn.tailwindcss.com?plugins=forms"></script>
        <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
        <script>
            tailwind.config = {
                darkMode: 'class',
                theme: { extend: { colors: { brand: { 50: '#ecf3ff', 100: '#dde9ff', 200: '#c2d6ff', 300: '#9cb9ff', 400: '#7592ff', 500: '#465fff', 600: '#2e3ef5', 700: '#232fe1', 800: '#1c29b6', 900: '#1d298f' } } } }
            }
            if (localStorage.getItem('darkMode') === 'true') document.documentElement.classList.add('dark');
        </script>
    </head>
    <body x-data="passwordResetFlow()" x-init="initDarkMode()" class="bg-white dark:bg-gray-900 transition-colors duration-300">
        
        <div x-show="toast.show" x-cloak x-transition.opacity.duration.300ms class="fixed top-10 left-1/2 transform -translate-x-1/2 z-[999999] flex items-center gap-3 px-6 py-4 rounded-xl shadow-xl" :class="toast.type === 'error' ? 'bg-red-500 shadow-red-500/30' : 'bg-green-500 shadow-green-500/30'">
            <svg x-show="toast.type === 'success'" class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
            <svg x-show="toast.type === 'error'" class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            <span class="text-white font-medium text-sm sm:text-base whitespace-nowrap" x-text="toast.message"></span>
        </div>

        <div class="relative p-6 bg-white z-1 dark:bg-gray-900 sm:p-0">
            <div class="relative flex flex-col justify-center w-full min-h-screen dark:bg-gray-900 sm:p-0 lg:flex-row">
                
                <div class="flex flex-col flex-1 w-full lg:w-1/2">
                    <div class="w-full max-w-md pt-10 mx-auto">
                        <a href="/auth/#login" class="inline-flex items-center text-sm text-gray-500 transition-colors hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300">
                            <svg class="stroke-current mr-1" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M12.7083 5L7.5 10.2083L12.7083 15.4167" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg> Quay lại đăng nhập
                        </a>
                    </div>
                    
                    <div class="flex flex-col justify-center flex-1 w-full max-w-md mx-auto">
                        <div class="mb-5 sm:mb-8 text-center sm:text-left">
                            <h1 class="mb-2 font-semibold text-gray-800 text-3xl dark:text-white/90" x-text="stepTitle()"></h1>
                            <p class="text-sm text-gray-500 dark:text-gray-400" x-text="stepDesc()"></p>
                        </div>
                        
                        <div>
                            <form x-show="step === 1" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" @submit.prevent="sendOTP">
                                <div class="space-y-5">
                                    <div>
                                        <label class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400">Email tài khoản <span class="text-red-500">*</span></label>
                                        <input type="email" x-model="form.email" placeholder="Nhập email đã đăng ký..." required :disabled="loading" class="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm text-gray-800 focus:border-brand-300 focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:focus:border-brand-500 disabled:opacity-50"/>
                                    </div>
                                    <button type="submit" :disabled="loading" class="flex items-center justify-center w-full px-4 py-3 text-sm font-medium text-white transition rounded-lg bg-brand-500 hover:bg-brand-600 disabled:opacity-70">
                                        <span x-show="!loading">Gửi mã xác nhận</span>
                                        <svg x-show="loading" class="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                                    </button>
                                </div>
                            </form>

                            <form x-show="step === 2" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" @submit.prevent="verifyOTP">
                                <div class="space-y-5">
                                    <div>
                                        <label class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400">Mã OTP (6 chữ số) <span class="text-red-500">*</span></label>
                                        <input type="number" x-model="form.otp" placeholder="Ví dụ: 123456" required :disabled="loading" class="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-center text-2xl tracking-[0.5em] font-bold text-brand-600 focus:border-brand-300 focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-900 dark:text-brand-400 dark:focus:border-brand-500 disabled:opacity-50"/>
                                    </div>
                                    <div class="flex gap-3">
                                        <button type="button" @click="step = 1" class="w-1/3 px-4 py-3 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700 transition">Sửa Email</button>
                                        <button type="submit" :disabled="loading" class="flex items-center justify-center w-2/3 px-4 py-3 text-sm font-medium text-white transition rounded-lg bg-brand-500 hover:bg-brand-600 disabled:opacity-70">
                                            <span x-show="!loading">Xác nhận OTP</span>
                                            <svg x-show="loading" class="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                                        </button>
                                    </div>
                                </div>
                            </form>

                            <form x-show="step === 3" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" @submit.prevent="resetPassword">
                                <div class="space-y-4">
                                    <div x-data="{ show1: false }" class="relative">
                                        <label class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400">Mật khẩu mới <span class="text-red-500">*</span></label>
                                        <input :type="show1 ? 'text' : 'password'" x-model="form.password" placeholder="Nhập mật khẩu mới" required :disabled="loading" class="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 pr-10 py-2.5 text-sm text-gray-800 focus:border-brand-300 focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 disabled:opacity-50"/>
                                        <button type="button" @click="show1 = !show1" class="absolute right-3 top-[34px] text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 focus:outline-none">
                                            <svg x-show="!show1" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                                            <svg x-show="show1" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/></svg>
                                        </button>
                                    </div>
                                    <div x-data="{ show2: false }" class="relative">
                                        <label class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400">Xác nhận mật khẩu mới <span class="text-red-500">*</span></label>
                                        <input :type="show2 ? 'text' : 'password'" x-model="form.password_confirm" placeholder="Nhập lại mật khẩu" required :disabled="loading" class="h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 pr-10 py-2.5 text-sm text-gray-800 focus:border-brand-300 focus:ring-2 focus:ring-brand-500/20 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 disabled:opacity-50"/>
                                        <button type="button" @click="show2 = !show2" class="absolute right-3 top-[34px] text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 focus:outline-none">
                                            <svg x-show="!show2" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                                            <svg x-show="show2" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/></svg>
                                        </button>
                                    </div>
                                    <div class="pt-2">
                                        <button type="submit" :disabled="loading" class="flex items-center justify-center w-full px-4 py-3 text-sm font-medium text-white transition rounded-lg bg-green-500 hover:bg-green-600 disabled:opacity-70">
                                            <span x-show="!loading">Hoàn tất đổi mật khẩu</span>
                                            <svg x-show="loading" class="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="relative items-center hidden w-full h-full bg-brand-900 dark:bg-black/50 lg:flex lg:w-1/2">
                    <div class="flex flex-col items-center justify-center w-full px-10 z-10">
                        <div class="mb-6"><span class="text-5xl font-bold text-white tracking-wider">ZENRO</span></div>
                        <h1 class="mb-4 text-3xl font-bold text-center text-white">Bảo mật là ưu tiên hàng đầu</h1>
                        <p class="mb-8 text-lg text-center text-brand-200 max-w-md">Chúng tôi sử dụng mã hóa tiêu chuẩn để bảo vệ dữ liệu và thông tin cá nhân của bạn.</p>
                    </div>
                    <div class="absolute inset-0 bg-gradient-to-br from-brand-600/20 to-brand-900/80 z-0"></div>
                </div>
                
            </div>
        </div>

        <script>
            function passwordResetFlow() {
                return {
                    darkMode: false,
                    step: 1,
                    loading: false,
                    toast: { show: false, message: '', type: 'success' },
                    form: { email: '', otp: '', password: '', password_confirm: '' },

                    initDarkMode() {
                        this.darkMode = JSON.parse(localStorage.getItem('darkMode')) || false;
                        this.$watch('darkMode', v => { localStorage.setItem('darkMode', JSON.stringify(v)); document.documentElement.classList.toggle('dark', v); });
                    },

                    stepTitle() {
                        if (this.step === 1) return 'Quên mật khẩu?';
                        if (this.step === 2) return 'Xác thực OTP';
                        return 'Tạo mật khẩu mới';
                    },

                    stepDesc() {
                        if (this.step === 1) return 'Nhập email của bạn, chúng tôi sẽ gửi mã OTP gồm 6 chữ số.';
                        if (this.step === 2) return `Mã xác thực đã được gửi tới ${this.form.email}`;
                        return 'Vui lòng nhập mật khẩu mới và xác nhận để hoàn tất.';
                    },

                    showToast(message, type = 'success') {
                        this.toast.message = message;
                        this.toast.type = type;
                        this.toast.show = true;
                        setTimeout(() => { this.toast.show = false; }, 3000);
                    },

                    // Gửi request về chính URL /change-pass đã được map trong .htaccess
                    async sendRequest(action, data) {
                        this.loading = true;
                        try {
                            const res = await fetch(`/change-pass?action=${action}`, {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify(data)
                            });
                            const result = await res.json();
                            this.loading = false;
                            
                            if (result.status === 'success') {
                                this.showToast(result.message, 'success');
                                return true;
                            } else {
                                this.showToast(result.message, 'error');
                                return false;
                            }
                        } catch (error) {
                            this.loading = false;
                            this.showToast('Có lỗi xảy ra, vui lòng kiểm tra kết nối!', 'error');
                            return false;
                        }
                    },

                    async sendOTP() {
                        if (!this.form.email) return;
                        if (await this.sendRequest('send_otp', { email: this.form.email })) {
                            this.step = 2;
                        }
                    },

                    async verifyOTP() {
                        if (this.form.otp.length < 6) {
                            this.showToast('Mã OTP phải có 6 số', 'error');
                            return;
                        }
                        if (await this.sendRequest('verify_otp', { otp: this.form.otp })) {
                            this.step = 3;
                        }
                    },

                    async resetPassword() {
                        if (this.form.password.length < 6) {
                            this.showToast('Mật khẩu phải từ 6 ký tự!', 'error');
                            return;
                        }
                        if (this.form.password !== this.form.password_confirm) {
                            this.showToast('Hai mật khẩu không khớp!', 'error');
                            return;
                        }
                        if (await this.sendRequest('reset_password', { password: this.form.password })) {
                            // Thành công, chuyển về login
                            setTimeout(() => { window.location.href = '/auth/#login'; }, 2000);
                        }
                    }
                }
            }
        </script>
    </body>
</html>
