<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thông báo thay đổi mật khẩu</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f4f7f6; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; color: #333333;">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #f4f7f6; padding: 40px 0;">
        <tr>
            <td align="center">
                <table width="600" cellpadding="0" cellspacing="0" border="0" style="background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 10px rgba(0,0,0,0.05);">
                    <tr>
                        <td style="background-color: #465fff; padding: 30px 40px; text-align: center;">
                            <h1 style="color: #ffffff; margin: 0; font-size: 28px; letter-spacing: 2px;">ZENRO.SITE</h1>
                        </td>
                    </tr>
                    
                    <tr>
                        <td style="padding: 40px;">
                            <h2 style="margin-top: 0; color: #1f2937; font-size: 22px;">Xin chào, {{USER_NAME}}!</h2>
                            <p style="font-size: 16px; line-height: 1.6; color: #4b5563;">
                                Hệ thống ZENRO.SITE xin thông báo: <strong>Mật khẩu tài khoản của bạn vừa được thay đổi thành công.</strong>
                            </p>
                            
                            <div style="background-color: #f9fafb; border-left: 4px solid #465fff; padding: 20px; margin: 25px 0; border-radius: 0 4px 4px 0;">
                                <h3 style="margin-top: 0; font-size: 14px; color: #6b7280; text-transform: uppercase;">Chi tiết phiên thao tác:</h3>
                                <ul style="list-style: none; padding: 0; margin: 0; font-size: 14px; color: #374151;">
                                    <li style="margin-bottom: 8px;"><strong>Thời gian:</strong> {{TIME}}</li>
                                    <li style="margin-bottom: 8px;"><strong>Địa chỉ IP:</strong> {{IP_ADDRESS}}</li>
                                    <li><strong>Thiết bị/Trình duyệt:</strong> {{OS_BROWSER}}</li>
                                </ul>
                            </div>
                            
                            <p style="font-size: 16px; line-height: 1.6; color: #4b5563;">
                                Nếu bạn là người thực hiện thay đổi này, xin hãy bỏ qua email này. Bạn có thể sử dụng mật khẩu mới để đăng nhập vào hệ thống bình thường.
                            </p>
                            
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top: 30px; background-color: #fef2f2; border: 1px solid #fee2e2; border-radius: 6px;">
                                <tr>
                                    <td style="padding: 15px;">
                                        <p style="margin: 0; font-size: 14px; color: #991b1b; line-height: 1.5;">
                                            <strong>🚨 Cảnh báo bảo mật:</strong> Nếu bạn KHÔNG thực hiện thay đổi này, tài khoản của bạn có thể đã bị xâm nhập. Vui lòng truy cập trang web để sử dụng tính năng "Quên mật khẩu" hoặc liên hệ với Bộ phận Hỗ trợ (Admin) ngay lập tức!
                                        </p>
                                    </td>
                                </tr>
                            </table>
                            
                            <div style="text-align: center; margin-top: 40px;">
                                <a href="https://<?= $_SERVER['HTTP_HOST'] ?>/auth/#login" style="display: inline-block; background-color: #465fff; color: #ffffff; text-decoration: none; padding: 14px 28px; border-radius: 6px; font-weight: bold; font-size: 16px;">Đăng nhập ngay</a>
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td style="background-color: #f9fafb; padding: 20px 40px; text-align: center; border-top: 1px solid #e5e7eb;">
                            <p style="margin: 0; font-size: 13px; color: #9ca3af;">
                                Đây là email tự động từ hệ thống ZENRO.SITE. Vui lòng không trả lời email này.<br>
                                &copy; <?= date('Y') ?> ZENRO.SITE
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
