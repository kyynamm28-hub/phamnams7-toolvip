<?php
session_start();

// 1. Dọn dẹp thiết bị hiện tại trong Cơ sở dữ liệu (Nếu đang đăng nhập)
if (isset($_SESSION['user_id'])) {
    try {
        // Lùi 3 cấp để về thư mục gốc: auth -> layout -> client -> root
        require_once __DIR__ . '/../../../config/database.php';
        
        $current_session = session_id();
        $user_id = $_SESSION['user_id'];
        
        // Xóa thiết bị ứng với Session hiện tại khỏi bảng user_devices
        $stmt = $pdo->prepare("DELETE FROM user_devices WHERE user_id = ? AND session_id = ?");
        $stmt->execute([$user_id, $current_session]);
    } catch (Exception $e) {
        // Bỏ qua lỗi nếu hệ thống DB hoặc bảng chưa sẵn sàng để tránh làm nghẽn luồng đăng xuất
    }
}

// 2. Xóa sạch tất cả các biến Session đang lưu trong bộ nhớ server
$_SESSION = array();

// 3. Xóa Cookie Session lưu trên trình duyệt của người dùng (Giúp bảo mật tuyệt đối)
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(), 
        '', 
        time() - 42000,
        $params["path"], 
        $params["domain"],
        $params["secure"], 
        $params["httponly"]
    );
}

// 4. Hủy hoàn toàn Session trên hệ thống server
session_destroy();

// 5. Chuyển hướng người dùng một cách an toàn về thẳng trang Đăng nhập
header("Location: /auth/#login");
exit;
