<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/settings.php';

if (!isset($_SESSION['user_id'])) { 
    header('Location: /auth/#login'); 
    exit; 
}
if (empty($_SESSION['zenro_secure_token'])) {
    $_SESSION['zenro_secure_token'] = bin2hex(random_bytes(32));
}

$stmtUser = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user_data = $stmtUser->fetch(PDO::FETCH_ASSOC);

if (!$user_data) {
    session_destroy();
    header("Location: /auth/#login");
    exit;
}

$user = $user_data;
$userData = $user_data;
$userInfo = $user_data;
$balance = number_format($user_data['balance'] ?? 0, 0, ',', '.');
$initial = strtoupper(substr($user_data['username'] ?? $user_data['display_name'] ?? 'U', 0, 1));
$user_avatar = $user_data['avatar'] ?? '';

$is_vip = false;
if (!empty($user_data['vip_expire_at']) && strtotime($user_data['vip_expire_at']) > time()) {
    $is_vip = true;
}

if (!$is_vip) { header('Location: /thue-vip'); exit; }

$pageTitle = 'Sảnh Baccarat - Live Casino';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); }
        .fade-in { animation: fadeIn 0.4s ease-out forwards; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        [x-cloak] { display: none !important; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-neutral-50 dark:bg-[#0b1120] text-neutral-800 dark:text-gray-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 w-full max-w-7xl mx-auto fade-in" x-data="baccaratManager()">
            
            <div class="mb-6 flex items-center justify-between">
                <a href="/tools" class="inline-flex items-center gap-1.5 text-[12px] font-bold text-neutral-500 hover:text-neutral-900 dark:text-gray-400 dark:hover:text-white transition-colors uppercase tracking-widest bg-white dark:bg-[#0f172a] px-4 py-2 rounded-full border border-neutral-200/60 dark:border-gray-800 shadow-sm focus:outline-none">
                    <i class="ri-arrow-left-line text-[14px]"></i> Kho Dịch Vụ
                </a>
                <div class="flex items-center gap-2">
                    <div class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                    <span class="text-[10px] font-bold text-emerald-500 uppercase tracking-widest">Live Updates</span>
                </div>
            </div>

            <div class="bg-white dark:bg-[#0f172a] rounded-[24px] border border-neutral-200/60 dark:border-gray-800 shadow-soft overflow-hidden mb-8 p-6 sm:p-8 flex items-center justify-between">
                <div>
                    <div class="inline-flex items-center px-2.5 py-1 bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-lg text-[10px] font-black uppercase tracking-widest shadow-sm mb-3 border border-amber-100 dark:border-amber-800/30">
                        <i class="ri-vip-diamond-line mr-1.5 text-[13px]"></i> Sảnh Phân Tích Độc Quyền
                    </div>
                    <h1 class="text-2xl sm:text-3xl font-black text-neutral-900 dark:text-white leading-tight tracking-tight">Sảnh Baccarat Hoàng Gia</h1>
                    <p class="text-xs text-neutral-500 dark:text-gray-400 mt-2 font-medium" x-html="statusText"></p>
                </div>
                <div class="w-16 h-16 sm:w-20 sm:h-20 rounded-[18px] bg-neutral-50 dark:bg-[#1e293b] flex items-center justify-center border border-neutral-200/60 dark:border-gray-700 p-2 shrink-0 shadow-sm">
                    <img src="https://i.ibb.co/rGY7cLXY/x.jpg" class="w-full h-full object-cover rounded-[12px]">
                </div>
            </div>

            <div x-show="isLoading" class="flex flex-col items-center justify-center py-20">
                <i class="ri-loader-4-line text-4xl text-blue-500 animate-spin mb-4"></i>
                <div class="text-[11px] font-bold text-neutral-400 uppercase tracking-widest">Đang tải cấu trúc bàn chơi...</div>
            </div>

            <div x-show="!isLoading" x-cloak class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                <template x-for="table in tables" :key="table.table_name">
                    <a :href="'/games/bacarat/' + encodeURIComponent(table.table_name)" class="bg-white dark:bg-[#0f172a] rounded-[24px] border border-neutral-200/60 dark:border-gray-800 shadow-soft overflow-hidden flex flex-col group hover:border-blue-500/40 dark:hover:border-blue-500/40 hover:shadow-xl hover:shadow-blue-500/5 transition-all duration-300">
                        
                        <div class="px-5 py-4 border-b border-neutral-100 dark:border-gray-800 flex items-center justify-between bg-neutral-50/50 dark:bg-[#1e293b]/30">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-full border border-neutral-200 dark:border-gray-700 bg-neutral-100 dark:bg-gray-900 overflow-hidden shrink-0 shadow-sm">
                                    <img :src="table.image_dealer || 'https://placehold.co/100x100/e2e8f0/475569?text=Dealer'" :alt="table.dealer_name" class="w-full h-[110%] object-contain object-bottom">
                                </div>
                                <div>
                                    <div class="text-[14px] font-black text-neutral-900 dark:text-white uppercase tracking-tight" x-text="'Bàn ' + table.table_name"></div>
                                    <div class="text-[10px] font-bold text-neutral-500 uppercase tracking-widest mt-0.5">Dealer: <span class="text-blue-500" x-text="table.dealer_name || 'Hệ Thống'"></span></div>
                                </div>
                            </div>
                            <span class="inline-flex px-2.5 py-1 bg-white dark:bg-gray-800 text-neutral-600 dark:text-gray-300 rounded-lg text-[10px] font-black uppercase tracking-widest border border-neutral-200/60 dark:border-gray-700 shadow-sm shrink-0" x-text="'Phiên ' + table.round"></span>
                        </div>

                        <div class="p-5 flex-1 flex flex-col justify-center bg-white dark:bg-[#0b1120]/50 relative">
                            <canvas :id="'canvas-' + table.table_name" class="w-full h-[100px]"></canvas>
                        </div>
                        
                        <div class="px-5 py-3.5 border-t border-neutral-100 dark:border-gray-800 flex items-center justify-between bg-neutral-50/30 dark:bg-transparent">
                           <span class="text-[10px] font-bold text-neutral-400 uppercase tracking-widest">Trạng thái: <span class="text-emerald-500">Đang cược</span></span>
                           <div class="text-[11px] font-bold text-blue-500 uppercase tracking-widest flex items-center gap-1 group-hover:gap-2 transition-all">
                               Vào Bàn <i class="ri-arrow-right-line"></i>
                           </div>
                        </div>
                    </a>
                </template>
            </div>

        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener("alpine:init", () => {
            Alpine.data("baccaratManager", () => ({
                tables: [],
                isLoading: true,
                statusText: "Đang kết nối để tải dữ liệu...",
                secureToken: "<?= $_SESSION['zenro_secure_token'] ?>",
                
                init() {
                    this.fetchData();
                    setInterval(() => this.fetchData(), 2000);
                    
                    // Vẽ lại canvas khi xoay màn hình (Resize)
                    let resizeTimer;
                    window.addEventListener('resize', () => {
                        clearTimeout(resizeTimer);
                        resizeTimer = setTimeout(() => {
                            this.tables.forEach(t => this.drawChart(t.table_name, t.results));
                        }, 200);
                    });
                },
                
                fetchData() {
                    const fd = new FormData();
                    fd.append('secure_token', this.secureToken);

                    // Fetch ngầm qua cổng API Handler
                    fetch(`/api-handler?action=bacarat_history`, {
                        method: 'POST',
                        headers: { 'X-Requested-With': 'XMLHttpRequest' },
                        body: fd
                    })
                    .then(r => r.json())
                    .then(res => {
                        if (res.status !== 'success') return;

                        // Giải mã AES
                        const SK = CryptoJS.SHA256(res.k);
                        const SI = CryptoJS.enc.Utf8.parse(CryptoJS.SHA256(res.i).toString().substring(0, 16));
                        let b64 = res.data.replace(/-/g, '+').replace(/_/g, '/');
                        const dec = CryptoJS.AES.decrypt(b64, SK, { iv: SI, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 });
                        const jsonStr = dec.toString(CryptoJS.enc.Utf8);
                        
                        if (!jsonStr) return;
                        const newTables = JSON.parse(jsonStr);

                        this.tables = newTables;
                        this.isLoading = false;
                        this.statusText = `Đang theo dõi <strong class="text-blue-500">${this.tables.length}</strong> bàn chơi trực tuyến`;

                        // Đợi AlpineJS render xong toàn bộ <template> rồi mới bắt đầu quét Canvas để vẽ
                        setTimeout(() => {
                            this.tables.forEach(t => {
                                this.drawChart(t.table_name, t.results);
                            });
                        }, 100);
                    })
                    .catch(err => console.error(err));
                },

                // Thuật toán vẽ nến mượt mà
                drawChart(tableName, results) {
                    const canvas = document.getElementById('canvas-' + tableName);
                    if (!canvas) return; // Nếu Canvas chưa tải kịp trên DOM thì bỏ qua

                    const dpr = window.devicePixelRatio || 1;
                    const rect = canvas.getBoundingClientRect();
                    if (rect.width === 0) return; // Fix lỗi trên Safari khi màn hình bị ẩn

                    canvas.width = rect.width * dpr;
                    canvas.height = rect.height * dpr;

                    const ctx = canvas.getContext('2d');
                    ctx.scale(dpr, dpr);

                    const W = rect.width;
                    const H = rect.height;

                    const maxC = 40; // Lấy 40 kết quả gần nhất để tránh tràn
                    const data = (results || []).slice(Math.max(0, (results || []).length - maxC));
                    const n = data.length;

                    // Clear màn hình trước khi vẽ đè lên
                    ctx.clearRect(0, 0, W, H);

                    if (n < 1) {
                        const midY = H / 2;
                        ctx.strokeStyle = 'rgba(100,116,139,0.2)';
                        ctx.lineWidth = 1;
                        ctx.setLineDash([4, 4]);
                        ctx.beginPath();
                        ctx.moveTo(4, midY);
                        ctx.lineTo(W - 4, midY);
                        ctx.stroke();
                        ctx.setLineDash([]);
                        ctx.fillStyle = 'rgba(100,116,139,0.6)';
                        ctx.font = 'bold 11px ui-sans-serif, system-ui, sans-serif';
                        ctx.textAlign = 'center';
                        ctx.textBaseline = 'middle';
                        ctx.fillText('Đang chờ ván mới...', W / 2, midY);
                        return;
                    }

                    const padT = 8, padB = 8, padL = 4, padR = 4;
                    const chartH = H - padT - padB;
                    const chartW = W - padL - padR;
                    const step = chartW / Math.max(n, 20);

                    function lastNonTie(idx) {
                        for (let j = idx - 1; j >= 0; j--) {
                            if (data[j] !== 'TIE') return data[j];
                        }
                        return null;
                    }

                    const openLvl = new Array(n);
                    const closeLvl = new Array(n);
                    for (let i = 0; i < n; i++) {
                        const r = data[i];
                        if (r === 'TIE') {
                            openLvl[i] = i === 0 ? 0 : openLvl[i - 1];
                            closeLvl[i] = i === 0 ? 0 : closeLvl[i - 1];
                        } else {
                            const isWin = r === 'WIN';
                            const prev = lastNonTie(i);
                            const sameDir = prev !== null && r === prev;
                            if (i === 0) {
                                openLvl[i] = 0;
                            } else if (sameDir) {
                                openLvl[i] = closeLvl[i - 1];
                            } else {
                                openLvl[i] = openLvl[i - 1];
                            }
                            closeLvl[i] = openLvl[i] + (isWin ? -1 : 1);
                        }
                    }

                    const allLvls = [...openLvl, ...closeLvl];
                    const minLvl = Math.min(...allLvls);
                    const maxLvl = Math.max(...allLvls);
                    const span = (maxLvl - minLvl) || 1;

                    const sizeH = chartH / (span + 2);
                    const sizeW = step;
                    const size = Math.max(2, Math.min(sizeW, sizeH));
                    const candleW = size;
                    const unitH = size;

                    const midLvl = (minLvl + maxLvl) / 2;
                    function lvlY(l) { return padT + chartH / 2 + (l - midLvl) * unitH; }

                    // Kẻ Line
                    ctx.strokeStyle = document.documentElement.classList.contains('dark') ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';
                    ctx.lineWidth = 1;
                    ctx.setLineDash([4, 4]);
                    ctx.beginPath();
                    ctx.moveTo(padL, lvlY(openLvl[0]));
                    ctx.lineTo(W - padR, lvlY(openLvl[0]));
                    ctx.stroke();
                    ctx.setLineDash([]);

                    // Vẽ nến
                    for (let i = 0; i < n; i++) {
                        const r = data[i];
                        const isTie = r === 'TIE';
                        const isWin = r === 'WIN';
                        const x = padL + i * candleW;

                        if (isTie) {
                            const yCenter = lvlY(openLvl[i]);
                            const yTop = yCenter - candleW / 2;
                            ctx.shadowColor = 'rgba(245,158,11,0.5)';
                            ctx.shadowBlur = 4;
                            ctx.fillStyle = '#f59e0b';
                            ctx.fillRect(x, yTop, candleW, candleW);
                            ctx.shadowBlur = 0;
                        } else {
                            const yOpen = lvlY(openLvl[i]);
                            const yClose = lvlY(closeLvl[i]);
                            const yTop = Math.min(yOpen, yClose);
                            
                            ctx.shadowColor = isWin ? 'rgba(16,185,129,0.3)' : 'rgba(244,63,94,0.3)';
                            ctx.shadowBlur = 6;
                            ctx.fillStyle = isWin ? '#10b981' : '#f43f5e';
                            ctx.fillRect(x, yTop, candleW, candleW);
                            ctx.shadowBlur = 0;
                        }
                    }
                }
            }));
        });
    </script>
</body>
</html>
