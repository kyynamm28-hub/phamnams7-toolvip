<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/settings.php';

// 1. KIỂM TRA BẢO MẬT & TẠO TOKEN
if (!isset($_SESSION['user_id'])) { 
    header('Location: /auth/#login'); 
    exit; 
}
if (empty($_SESSION['zenro_secure_token'])) {
    $_SESSION['zenro_secure_token'] = bin2hex(random_bytes(32));
}

// 2. KIỂM TRA USER VÀ GÁN BIẾN HEADER
$stmtUser = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user_data = $stmtUser->fetch(PDO::FETCH_ASSOC);

if (!$user_data) {
    session_destroy();
    header("Location: /auth/#login");
    exit;
}

$user = $user_data;
$userData = $user_data;
$userInfo = $user_data;
$balance = number_format($user_data['balance'] ?? 0, 0, ',', '.');
$initial = strtoupper(substr($user_data['username'] ?? $user_data['display_name'] ?? 'U', 0, 1));
$user_avatar = $user_data['avatar'] ?? '';

// Check VIP
$is_vip = false;
if (!empty($user_data['vip_expire_at']) && strtotime($user_data['vip_expire_at']) > time()) {
    $is_vip = true;
}

if (!$is_vip) { header('Location: /thue-vip'); exit; }

$tableName = $_GET['table'] ?? '';
if (empty($tableName)) {
    header('Location: /game/bacarat'); exit;
}

$pageTitle = 'Chi Tiết Bàn ' . htmlspecialchars($tableName) . ' - Baccarat';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); }
        .fade-in { animation: fadeIn 0.4s ease-out forwards; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        [x-cloak] { display: none !important; }
        
        /* Chỉnh màu chữ P, B, T Minimalist */
        .color-p { color: #3b82f6; } /* Player - Xanh */
        .color-b { color: #ef4444; } /* Banker - Đỏ */
        .color-t { color: #10b981; } /* Tie - Xanh lục */
        
        .bg-color-p { background-color: #eff6ff; color: #3b82f6; border-color: #bfdbfe; }
        .bg-color-b { background-color: #fef2f2; color: #ef4444; border-color: #fecaca; }
        .bg-color-t { background-color: #f0fdf4; color: #10b981; border-color: #a7f3d0; }
        
        .dark .bg-color-p { background-color: rgba(59,130,246,0.1); border-color: rgba(59,130,246,0.2); }
        .dark .bg-color-b { background-color: rgba(239,68,68,0.1); border-color: rgba(239,68,68,0.2); }
        .dark .bg-color-t { background-color: rgba(16,185,129,0.1); border-color: rgba(16,185,129,0.2); }
        
        .custom-scroll::-webkit-scrollbar { width: 4px; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #d4d4d8; border-radius: 10px; }
        .dark .custom-scroll::-webkit-scrollbar-thumb { background: #4b5563; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-neutral-50 dark:bg-[#0b1120] text-neutral-800 dark:text-gray-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 w-full max-w-5xl mx-auto fade-in" x-data="baccaratTableManager()">
            
            <div class="mb-6 flex items-center justify-between">
                <a href="/game/bacarat" class="inline-flex items-center gap-1.5 text-[12px] font-bold text-neutral-500 hover:text-neutral-900 dark:text-gray-400 dark:hover:text-white transition-colors uppercase tracking-widest bg-white dark:bg-gray-800 px-4 py-2 rounded-full border border-neutral-200 dark:border-gray-700 shadow-sm focus:outline-none">
                    <i class="ri-arrow-left-line text-[14px]"></i> Các Bàn Khác
                </a>
                <div class="flex items-center gap-2">
                    <div class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                    <span class="text-[10px] font-bold text-emerald-500 uppercase tracking-widest" x-text="tableData.time ? 'Cập nhật: ' + tableData.time : 'Live Updates'"></span>
                </div>
            </div>

            <div x-show="isLoading" class="flex flex-col items-center justify-center py-20 bg-white dark:bg-gray-800 rounded-2xl border border-neutral-200 dark:border-gray-700 shadow-soft">
                <i class="ri-loader-4-line text-4xl text-blue-500 animate-spin mb-4"></i>
                <div class="text-[11px] font-bold text-neutral-400 uppercase tracking-widest">Đang tải dữ liệu Bàn <?= htmlspecialchars($tableName) ?>...</div>
            </div>

            <div x-show="!isLoading" x-cloak class="space-y-6">
                
                <div class="bg-white dark:bg-gray-800 rounded-2xl border border-neutral-200 dark:border-gray-700 shadow-soft overflow-hidden p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-6 relative">
                    <div class="absolute top-0 right-0 w-64 h-64 bg-blue-500/5 rounded-full blur-[80px] pointer-events-none"></div>
                    
                    <div class="flex items-center gap-5 relative z-10">
                        <div class="w-20 h-20 sm:w-24 sm:h-24 rounded-[18px] border-2 border-neutral-100 dark:border-gray-600 bg-neutral-50 dark:bg-gray-700 overflow-hidden shrink-0 flex items-end justify-center shadow-sm">
                            <img :src="tableData.image_dealer || 'https://placehold.co/150x150/e2e8f0/475569?text=Dealer'" :alt="tableData.dealer_name" class="w-full h-[115%] object-contain object-bottom drop-shadow-md">
                        </div>
                        <div>
                            <div class="inline-flex items-center px-2.5 py-1 bg-neutral-100 dark:bg-gray-900/50 text-neutral-600 dark:text-gray-300 rounded-md text-[9px] font-black uppercase tracking-widest border border-neutral-200 dark:border-gray-700 mb-2">
                                Dealer: <span class="text-blue-500 ml-1" x-text="tableData.dealer_name || 'Hệ Thống'"></span>
                            </div>
                            <h1 class="text-3xl sm:text-4xl font-black text-neutral-900 dark:text-white leading-tight tracking-tight uppercase">Bàn <?= htmlspecialchars($tableName) ?></h1>
                            <div class="text-xs font-bold text-neutral-400 uppercase tracking-widest mt-1" x-text="'Phiên Hiện Tại: ' + (tableData.round || '---')"></div>
                        </div>
                    </div>
                    
                    <div class="bg-neutral-50 dark:bg-gray-900/50 rounded-[20px] p-5 border border-neutral-200/60 dark:border-gray-700 min-w-[200px] text-center relative z-10 shadow-inner">
                        <div class="text-[10px] font-bold text-neutral-400 uppercase tracking-widest mb-2">AI Dự Đoán (Phiên Tiếp)</div>
                        <div class="text-4xl font-black uppercase mb-1 drop-shadow-sm" 
                             :class="getPredictionClass(tableData.current_prediction)"
                             x-text="getPredictionText(tableData.current_prediction)">
                        </div>
                        <div class="text-[11px] font-bold text-neutral-500" x-text="tableData.goodRoad || 'Đang theo dõi cầu'"></div>
                    </div>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    
                    <div class="lg:col-span-2 space-y-6">
                        <div class="bg-white dark:bg-gray-800 rounded-2xl border border-neutral-200 dark:border-gray-700 shadow-soft overflow-hidden">
                            <div class="px-5 py-4 border-b border-neutral-100 dark:border-gray-700 flex items-center justify-between bg-neutral-50/50 dark:bg-gray-800/50">
                                <h3 class="font-bold text-neutral-800 dark:text-white text-[13px] uppercase tracking-widest flex items-center gap-2">
                                    <i class="ri-bar-chart-line text-blue-500"></i> Sơ Đồ Cầu Baccarat
                                </h3>
                            </div>
                            
                            <div class="p-6 overflow-x-auto custom-scroll">
                                <div class="flex flex-wrap gap-1.5 min-w-[300px]" x-html="renderDots(tableData.result)">
                                    </div>
                            </div>
                        </div>

                        <div class="grid grid-cols-3 gap-4">
                            <div class="bg-white dark:bg-gray-800 rounded-xl p-4 border border-neutral-200 dark:border-gray-700 shadow-sm text-center">
                                <div class="text-[10px] font-bold text-neutral-400 uppercase tracking-widest mb-1">Player (Con)</div>
                                <div class="text-xl font-black text-blue-500" x-text="countResult('P')">0</div>
                            </div>
                            <div class="bg-white dark:bg-gray-800 rounded-xl p-4 border border-neutral-200 dark:border-gray-700 shadow-sm text-center">
                                <div class="text-[10px] font-bold text-neutral-400 uppercase tracking-widest mb-1">Banker (Cái)</div>
                                <div class="text-xl font-black text-rose-500" x-text="countResult('B')">0</div>
                            </div>
                            <div class="bg-white dark:bg-gray-800 rounded-xl p-4 border border-neutral-200 dark:border-gray-700 shadow-sm text-center">
                                <div class="text-[10px] font-bold text-neutral-400 uppercase tracking-widest mb-1">Tie (Hòa)</div>
                                <div class="text-xl font-black text-emerald-500" x-text="countResult('T')">0</div>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white dark:bg-gray-800 rounded-2xl border border-neutral-200 dark:border-gray-700 shadow-soft overflow-hidden flex flex-col h-[500px]">
                        <div class="px-5 py-4 border-b border-neutral-100 dark:border-gray-700 flex items-center justify-between bg-neutral-50/50 dark:bg-gray-800/50 shrink-0">
                            <h3 class="font-bold text-neutral-800 dark:text-white text-[13px] uppercase tracking-widest flex items-center gap-2">
                                <i class="ri-history-line text-blue-500"></i> Lịch Sử Lệnh AI
                            </h3>
                            <span class="text-[10px] font-bold text-neutral-400 uppercase bg-neutral-100 dark:bg-gray-900 px-2 py-1 rounded" x-text="(tableData.history_count || 0) + ' Phiên'"></span>
                        </div>
                        
                        <div class="flex-1 overflow-y-auto p-4 custom-scroll space-y-2.5">
                            <template x-for="(hist, index) in [...(tableData.history || [])].reverse()" :key="index">
                                <div class="flex items-center justify-between p-3 bg-neutral-50 dark:bg-gray-900/50 rounded-xl border border-neutral-100 dark:border-gray-700/80 hover:bg-neutral-100 dark:hover:bg-gray-700/50 transition-colors">
                                    <div class="flex items-center gap-3">
                                        <span class="text-[10px] font-mono font-bold text-neutral-400 w-6">#<span x-text="hist.round"></span></span>
                                        <div class="flex flex-col">
                                            <span class="text-[9px] font-bold text-neutral-400 uppercase tracking-widest mb-0.5">Dự Đoán</span>
                                            <span class="text-xs font-black uppercase px-2 py-0.5 rounded border" :class="getPredictionClass(hist.prediction)" x-text="getPredictionText(hist.prediction)"></span>
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-3">
                                        <div class="flex flex-col items-center">
                                            <span class="text-[9px] font-bold text-neutral-400 uppercase tracking-widest mb-0.5">Kết Quả</span>
                                            <span class="text-xs font-black uppercase px-2 py-0.5 rounded border" :class="getPredictionClass(hist.result)" x-text="getPredictionText(hist.result)"></span>
                                        </div>
                                        <div class="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" :class="getStatusIconClass(hist.status)" x-html="getStatusIconHtml(hist.status)"></div>
                                    </div>
                                </div>
                            </template>
                            
                            <div x-show="!tableData.history || tableData.history.length === 0" class="text-center py-10 text-xs font-medium text-neutral-400">
                                Chưa có lịch sử phiên nào.
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener("alpine:init", () => {
            Alpine.data("baccaratTableManager", () => ({
                tableData: {},
                isLoading: true,
                secureToken: "<?= $_SESSION['zenro_secure_token'] ?>",
                tableName: "<?= htmlspecialchars($tableName) ?>",
                
                init() {
                    this.fetchData();
                    setInterval(() => this.fetchData(), 2000);
                },
                
                fetchData() {
                    const fd = new FormData();
                    fd.append('secure_token', this.secureToken);
                    fd.append('table_name', this.tableName);

                    fetch(`/api-handler?action=bacarat_table_api`, {
                        method: 'POST',
                        headers: { 'X-Requested-With': 'XMLHttpRequest' },
                        body: fd
                    })
                    .then(r => r.json())
                    .then(res => {
                        if (res.status !== 'success') {
                            console.error(res.msg);
                            return;
                        }

                        const SK = CryptoJS.SHA256(res.k);
                        const SI = CryptoJS.enc.Utf8.parse(CryptoJS.SHA256(res.i).toString().substring(0, 16));
                        let b64 = res.data.replace(/-/g, '+').replace(/_/g, '/');
                        const dec = CryptoJS.AES.decrypt(b64, SK, { iv: SI, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 });
                        const jsonStr = dec.toString(CryptoJS.enc.Utf8);
                        
                        if (!jsonStr) return;
                        
                        this.tableData = JSON.parse(jsonStr);
                        this.isLoading = false;
                    })
                    .catch(err => console.error(err));
                },

                // Trả về Tên (Player/Banker/Tie/Chờ)
                getPredictionText(code) {
                    if (!code) return 'CHỜ...';
                    code = code.toUpperCase();
                    if (code === 'P') return 'PLAYER';
                    if (code === 'B') return 'BANKER';
                    if (code === 'T') return 'TIE';
                    return code;
                },

                // Trả về class màu sắc theo B/P/T
                getPredictionClass(code) {
                    if (!code) return 'bg-neutral-100 text-neutral-400 border-neutral-200 dark:bg-gray-800 dark:border-gray-700';
                    code = code.toUpperCase();
                    if (code === 'P') return 'bg-color-p';
                    if (code === 'B') return 'bg-color-b';
                    if (code === 'T') return 'bg-color-t';
                    return 'bg-neutral-100 text-neutral-400 border-neutral-200';
                },

                // Class CSS cho Icon Status (Đúng / Sai)
                getStatusIconClass(status) {
                    if (!status) return 'bg-neutral-100 text-neutral-400 dark:bg-gray-800';
                    status = status.toUpperCase();
                    if (status === 'WIN') return 'bg-emerald-100 text-emerald-600 dark:bg-emerald-900/40';
                    if (status === 'LOSE') return 'bg-rose-100 text-rose-600 dark:bg-rose-900/40';
                    if (status === 'TIE') return 'bg-amber-100 text-amber-600 dark:bg-amber-900/40';
                    return 'bg-neutral-100 text-neutral-400 dark:bg-gray-800';
                },

                // HTML cho Icon Status
                getStatusIconHtml(status) {
                    if (!status) return '<i class="ri-loader-4-line animate-spin"></i>';
                    status = status.toUpperCase();
                    if (status === 'WIN') return '<i class="ri-check-line font-black"></i>';
                    if (status === 'LOSE') return '<i class="ri-close-line font-black"></i>';
                    if (status === 'TIE') return '<i class="ri-subtract-line font-black"></i>';
                    return '<i class="ri-loader-4-line animate-spin"></i>';
                },

                // Đếm số lượng P, B, T trong chuỗi kết quả
                countResult(type) {
                    if (!this.tableData.result) return 0;
                    return (this.tableData.result.match(new RegExp(type, 'g')) || []).length;
                },

                // Render chuỗi "BPBPBPPTP" thành các dấu chấm tròn
                renderDots(resultString) {
                    if (!resultString) return '<div class="text-sm text-neutral-400">Đang chờ ván mới...</div>';
                    let html = '';
                    for (let i = 0; i < resultString.length; i++) {
                        let char = resultString[i].toUpperCase();
                        let colorClass = 'bg-neutral-300';
                        if (char === 'P') colorClass = 'bg-blue-500 shadow-blue-500/30';
                        if (char === 'B') colorClass = 'bg-rose-500 shadow-rose-500/30';
                        if (char === 'T') colorClass = 'bg-emerald-500 shadow-emerald-500/30';
                        
                        html += `<div class="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold text-white shadow-sm shrink-0 ${colorClass}">${char}</div>`;
                    }
                    return html;
                }
            }));
        });
    </script>
</body>
</html>
