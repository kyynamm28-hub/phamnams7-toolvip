<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: /auth/#login");
    exit;
}
$configPath = __DIR__ . '/../../../config/settings.php';
if (file_exists($configPath)) require_once $configPath;

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmt->execute(['id' => $_SESSION['user_id']]);
$user_data = $stmt->fetch();

if (!$user_data) {
    session_destroy();
    header("Location: /auth/#login");
    exit;
}
// Lấy thông tin cấu hình nạp tiền
$stmt = $pdo->query("SELECT min_recharge FROM setting_bank LIMIT 1");
$bankConfig = $stmt->fetch(PDO::FETCH_ASSOC);
$minRecharge = $bankConfig ? $bankConfig['min_recharge'] : 10000;

$pageTitle = 'Nạp Tiền Hệ Thống';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/collapse@3.x.x/dist/cdn.min.js"></script>
    <style>
        /* Animation Phẳng - Mượt */
        .fade-up { opacity: 0; transform: translateY(15px); animation: fadeUp 0.5s cubic-bezier(0.2, 0.8, 0.2, 1) forwards; }
        @keyframes fadeUp { to { opacity: 1; transform: translateY(0); } }
        
        /* Hiệu ứng nhún (Click Effect) */
        .click-effect { transition: transform 0.15s cubic-bezier(0.4, 0, 0.2, 1); }
        .click-effect:active { transform: scale(0.96); }
        
        /* Ẩn AlpineJS khi chưa load */
        [x-cloak] { display: none !important; }
        
        /* Ẩn mũi tên của input type number */
        input[type=number]::-webkit-inner-spin-button, 
        input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-slate-50 dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-200 relative overflow-x-hidden">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen sm:ml-[260px]">
        
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 max-w-2xl mx-auto w-full fade-up">
            
            <!-- Nút Trở Về -->
            <div class="mb-5">
                <a href="/home" class="click-effect inline-flex items-center gap-1.5 text-[13px] font-bold text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white transition-colors focus:outline-none">
                    <i class="ri-arrow-left-line text-[16px]"></i> Về trang chủ
                </a>
            </div>

            <!-- Form Card Phẳng -->
            <div class="bg-white dark:bg-[#0f172a] rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-10 text-center">
                
                <!-- Icon & Tiêu đề -->
                <div class="mb-8">
                    <div class="w-14 h-14 bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-blue-100 dark:border-blue-500/20">
                        <i class="ri-qr-code-line text-[28px]"></i>
                    </div>
                    <h2 class="text-xl sm:text-2xl font-bold text-slate-800 dark:text-white mb-1.5">Nạp Tiền Vào Tài Khoản</h2>
                    <p class="text-[13px] text-slate-500 dark:text-slate-400">Chọn hoặc nhập số tiền để hệ thống tạo mã QR tự động cho bạn.</p>
                </div>

                <!-- Khu vực chọn số tiền -->
                <div x-data="rechargeForm(<?= $minRecharge ?>)" class="text-left space-y-6">
                    
                    <!-- Chọn Nhanh -->
                    <div>
                        <label class="block text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-3">Chọn Nhanh Mệnh Giá</label>
                        <div class="grid grid-cols-3 sm:grid-cols-5 gap-3">
                            <template x-for="amt in [10000, 50000, 100000, 250000, 500000]">
                                <button type="button" @click="amount = amt" 
                                        class="click-effect py-3 rounded-xl border text-[13px] font-bold transition-all duration-200 focus:outline-none"
                                        :class="amount === amt ? 'bg-blue-50 dark:bg-blue-500/10 border-blue-500 text-blue-600 dark:text-blue-400' : 'bg-transparent border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-slate-300 dark:hover:border-slate-600'">
                                    <span x-text="new Intl.NumberFormat('vi-VN').format(amt)"></span>
                                </button>
                            </template>
                        </div>
                    </div>

                    <!-- Nhập Tùy Chỉnh -->
                    <div>
                        <label class="block text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-3">Hoặc nhập số tiền khác</label>
                        <div class="relative flex items-center">
                            <input type="number" x-model="amount" class="w-full h-14 pl-5 pr-16 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl text-xl font-black text-blue-600 dark:text-blue-400 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all placeholder:text-slate-400" placeholder="VD: 50000">
                            <span class="absolute right-5 font-bold text-slate-400 text-[13px] uppercase tracking-wider pointer-events-none">VNĐ</span>
                        </div>
                        
                        <!-- Cảnh báo tối thiểu -->
                        <div class="mt-2 h-4">
                            <p class="text-[12px] font-bold text-rose-500 flex items-center gap-1" x-show="amount > 0 && amount < minAmount" x-cloak>
                                <i class="ri-error-warning-fill"></i> Tối thiểu: <span x-text="new Intl.NumberFormat('vi-VN').format(minAmount)"></span> VNĐ
                            </p>
                        </div>
                    </div>

                    <!-- Nút Xác Nhận -->
                    <button @click="submitOrder()" :disabled="isLoading || amount < minAmount" 
                            class="click-effect w-full h-12 mt-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 focus:outline-none">
                        <i class="ri-loader-4-line animate-spin text-[18px]" x-show="isLoading" x-cloak></i>
                        <i class="ri-bank-card-fill text-[16px]" x-show="!isLoading"></i>
                        <span class="text-[14px]" x-text="isLoading ? 'Đang khởi tạo giao dịch...' : 'Xác Nhận & Tạo Mã QR'"></span>
                    </button>
                    
                    <!-- Ghi chú bảo mật -->
                    <div class="text-center mt-4">
                        <p class="text-[11px] font-medium text-slate-400 flex items-center justify-center gap-1.5">
                            <i class="ri-shield-check-fill text-emerald-500"></i> Giao dịch được mã hóa và bảo mật an toàn 100%
                        </p>
                    </div>

                </div>
            </div>
        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('rechargeForm', (minAmt) => ({
                amount: minAmt,
                minAmount: minAmt,
                isLoading: false,

                async submitOrder() {
                    if (this.amount < this.minAmount) return;
                    this.isLoading = true;

                    try {
                        let formData = new FormData();
                        formData.append('amount', this.amount);

                        const res = await fetch('/api-handler?action=create_order', { method: 'POST', body: formData });
                        const data = await res.json();

                        if (data.status === 'success') {
                            window.location.href = data.redirect_url;
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Lỗi khởi tạo',
                                text: data.message,
                                confirmButtonColor: '#2563eb',
                                background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff',
                                color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a',
                                customClass: { popup: 'rounded-2xl border border-slate-200 dark:border-slate-800' }
                            });
                        }
                    } catch (e) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Mất kết nối',
                            text: 'Không thể kết nối đến máy chủ, vui lòng thử lại.',
                            confirmButtonColor: '#2563eb',
                            background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff',
                            color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a',
                            customClass: { popup: 'rounded-2xl border border-slate-200 dark:border-slate-800' }
                        });
                    } finally {
                        this.isLoading = false;
                    }
                }
            }));
        });
    </script>
</body>
</html>
