<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

// Yêu cầu thư viện setting (Nếu bạn có file cài đặt cấu hình web)
$configPath = __DIR__ . '/../../../config/settings.php';
if (file_exists($configPath)) require_once $configPath;

// 1. Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    header("Location: /auth/#login");
    exit;
}

// 2. Lấy dữ liệu User để đồng bộ thanh Header (Giống hệt logic của profile.php)
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmt->execute(['id' => $_SESSION['user_id']]);
$user_data = $stmt->fetch();

if (!$user_data) {
    session_destroy();
    header("Location: /auth/#login");
    exit;
}

// 3. Gán thêm các tên biến dự phòng để đảm bảo file header.php hoặc nav.php nhận được dữ liệu
$user = $user_data;
$userInfo = $user_data;
$userData = $user_data; // Nhiều giao diện dùng biến này
$balance = number_format($user_data['balance'] ?? 0, 0, ',', '.');
$initial = strtoupper(substr($user_data['username'] ?? $user_data['display_name'] ?? 'U', 0, 1));
$user_avatar = $user_data['avatar'] ?? '';

$pageTitle = 'Nạp Thẻ Cào';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/collapse@3.x.x/dist/cdn.min.js"></script>
    <style>
        /* Animation Phẳng - Mượt */
        .fade-up { opacity: 0; transform: translateY(15px); animation: fadeUp 0.5s cubic-bezier(0.2, 0.8, 0.2, 1) forwards; }
        @keyframes fadeUp { to { opacity: 1; transform: translateY(0); } }
        
        /* Hiệu ứng nhún (Click Effect) */
        .click-effect { transition: transform 0.15s cubic-bezier(0.4, 0, 0.2, 1); }
        .click-effect:active { transform: scale(0.96); }
        
        /* Thanh cuộn Minimal */
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background-color: #cbd5e1; border-radius: 10px; }
        .dark .custom-scrollbar::-webkit-scrollbar-thumb { background-color: #475569; }
        
        [x-cloak] { display: none !important; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-slate-50 dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-200 relative overflow-x-hidden">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen sm:ml-[260px]">
        
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 max-w-3xl mx-auto w-full fade-up" x-data="cardManager()">
            
            <!-- Nút Trở Về -->
            <div class="mb-5">
                <a href="/bank/recharge" class="click-effect inline-flex items-center gap-1.5 text-[13px] font-bold text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white transition-colors focus:outline-none">
                    <i class="ri-arrow-left-line text-[16px]"></i> Đổi phương thức
                </a>
            </div>
            
            <div class="text-center mb-6">
                <div class="w-14 h-14 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-emerald-100 dark:border-emerald-500/20">
                    <i class="ri-bank-card-fill text-[28px]"></i>
                </div>
                <h1 class="text-xl sm:text-2xl font-bold text-slate-800 dark:text-white mb-1.5">Gạch Thẻ Cào Tự Động</h1>
                <p class="text-[13px] text-slate-500 dark:text-slate-400">Hệ thống xử lý thẻ siêu tốc 24/7, cộng tiền ngay lập tức.</p>
            </div>

            <!-- Form Card Phẳng -->
            <div class="bg-white dark:bg-[#0f172a] rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-8">
                
                <!-- 1. Chọn Nhà Mạng -->
                <div class="mb-6">
                    <label class="block text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-3">Chọn Nhà Mạng</label>
                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
                        <template x-for="item in networks" :key="item.id">
                            <label class="cursor-pointer relative group click-effect block">
                                <input type="radio" name="telco" :value="item.id" x-model="telco" class="sr-only">
                                <div class="h-14 rounded-xl border flex items-center justify-center p-3 transition-colors duration-200"
                                     :class="telco === item.id ? 'border-blue-500 bg-blue-50 dark:bg-blue-500/10' : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 opacity-60 hover:opacity-100 hover:border-slate-300 dark:hover:border-slate-600'">
                                    <img :src="item.img" :alt="item.id" class="max-h-full max-w-full object-contain filter" :class="telco !== item.id ? 'grayscale' : ''">
                                </div>
                                <i x-show="telco === item.id" class="ri-checkbox-circle-fill absolute -top-2 -right-2 text-[20px] text-blue-600 dark:text-blue-400 bg-white dark:bg-[#0f172a] rounded-full"></i>
                            </label>
                        </template>
                    </div>
                </div>

                <!-- 2. Chọn Mệnh Giá -->
                <div class="mb-6">
                    <label class="block text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-3">Chọn Mệnh Giá Thẻ</label>
                    <div class="relative">
                        <select x-model="amount" class="w-full h-12 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl px-4 font-bold text-[14px] text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all appearance-none cursor-pointer">
                            <template x-for="val in [10000, 20000, 50000, 100000, 200000, 500000]">
                                <option :value="val" x-show="telco !== 'GARENA' || val !== 10000" x-text="new Intl.NumberFormat('vi-VN').format(val) + ' VNĐ'"></option>
                            </template>
                        </select>
                        <i class="ri-arrow-down-s-line absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none text-lg"></i>
                    </div>
                    <p x-show="telco === 'GARENA' && amount == 10000" class="text-[11px] text-rose-500 font-bold mt-1.5 flex items-center gap-1">
                        <i class="ri-error-warning-fill"></i> Thẻ Garena không hỗ trợ mệnh giá 10,000đ
                    </p>
                </div>

                <!-- 3. Nhập Mã & Serial -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-6">
                    <div>
                        <label class="block text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-3">Mã Thẻ (PIN)</label>
                        <input type="text" x-model="code" placeholder="Nhập mã thẻ..." class="w-full h-12 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl px-4 font-mono font-bold text-[14px] text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all placeholder:text-slate-400">
                    </div>
                    <div>
                        <label class="block text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-3">Số Serial</label>
                        <input type="text" x-model="serial" placeholder="Nhập số serial..." class="w-full h-12 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl px-4 font-mono font-bold text-[14px] text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all placeholder:text-slate-400">
                    </div>
                </div>

                <!-- 4. Thông tin Thực nhận -->
                <div class="bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50 rounded-xl p-5 mb-6">
                    <div class="flex justify-between items-center mb-3">
                        <span class="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest">Mệnh giá thẻ:</span>
                        <span class="text-[13px] font-bold text-slate-800 dark:text-white" x-text="new Intl.NumberFormat('vi-VN').format(amount) + 'đ'"></span>
                    </div>
                    <div class="flex justify-between items-center mb-4 pb-4 border-b border-slate-200 dark:border-slate-700">
                        <span class="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest">Phí gạch thẻ:</span>
                        <span class="text-[13px] font-bold text-rose-500">20%</span>
                    </div>
                    <div class="flex justify-between items-center">
                        <span class="text-[12px] font-black text-blue-600 dark:text-blue-400 uppercase tracking-widest">Thực nhận:</span>
                        <span class="text-[20px] font-black text-blue-600 dark:text-blue-400" x-text="new Intl.NumberFormat('vi-VN').format(amount * 0.8) + 'đ'"></span>
                    </div>
                </div>

                <!-- 5. Checkbox Điều khoản -->
                <div class="mb-6">
                    <label class="flex items-start gap-3 cursor-pointer group">
                        <div class="relative flex items-center justify-center mt-0.5">
                            <input type="checkbox" x-model="agreed" class="w-5 h-5 appearance-none border border-slate-300 dark:border-slate-600 rounded-lg checked:bg-blue-600 checked:border-blue-600 dark:checked:bg-blue-500 dark:checked:border-blue-500 transition-colors cursor-pointer bg-slate-50 dark:bg-slate-800/50">
                            <i class="ri-check-line absolute text-white text-[12px] pointer-events-none opacity-0 transition-opacity" :class="agreed ? 'opacity-100' : ''"></i>
                        </div>
                        <span class="text-[12px] font-medium text-slate-500 dark:text-slate-400 leading-relaxed">
                            Tôi đã kiểm tra kỹ mệnh giá và đồng ý với 
                            <button type="button" @click="showTerms = true" class="text-blue-600 dark:text-blue-400 hover:underline font-bold transition-colors focus:outline-none">điều khoản nạp thẻ</button> 
                            của hệ thống.
                        </span>
                    </label>
                </div>

                <!-- Nút Xác nhận -->
                <button @click="submitCard()" :disabled="!agreed || isProcessing" 
                        class="click-effect w-full h-12 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 focus:outline-none">
                    <i x-show="!isProcessing" class="ri-send-plane-fill text-[16px]"></i>
                    <i x-show="isProcessing" class="ri-loader-4-line animate-spin text-[18px]"></i>
                    <span class="text-[14px]" x-text="isProcessing ? 'Đang gửi thẻ...' : 'Xác Nhận Nạp Thẻ'"></span>
                </button>

            </div>

            <!-- POPUP ĐIỀU KHOẢN (Flat Design) -->
            <div x-show="showTerms" x-cloak class="fixed inset-0 z-[100] flex items-center justify-center p-4">
                <div class="absolute inset-0 bg-slate-900/60 dark:bg-slate-900/80" @click="showTerms = false"></div>
                <div class="relative bg-white dark:bg-[#0f172a] w-full max-w-md rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col max-h-[85vh] overflow-hidden" 
                     x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 scale-95 translate-y-4" x-transition:enter-end="opacity-100 scale-100 translate-y-0">
                    
                    <div class="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-800/30">
                        <h3 class="text-[14px] font-bold text-slate-800 dark:text-white uppercase tracking-wide flex items-center gap-2">
                            <i class="ri-file-list-3-fill text-blue-500"></i> Điều khoản dịch vụ
                        </h3>
                        <button @click="showTerms = false" class="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-rose-500 transition-colors focus:outline-none">
                            <i class="ri-close-line text-xl"></i>
                        </button>
                    </div>
                    
                    <div class="p-6 overflow-y-auto custom-scrollbar text-[13px] text-slate-600 dark:text-slate-400 leading-relaxed space-y-3">
                        <p><strong class="text-slate-800 dark:text-slate-200">1. Chọn sai mệnh giá:</strong> Nếu bạn chọn sai mệnh giá thẻ, thẻ của bạn sẽ bị hủy và mất 100% giá trị. Hệ thống không hỗ trợ hoàn tiền cho các trường hợp cố tình chọn sai.</p>
                        <p><strong class="text-slate-800 dark:text-slate-200">2. Phí dịch vụ:</strong> Mức phí gạch thẻ hiện tại là cố định 20% cho tất cả các nhà mạng. Số tiền thực nhận sẽ được cộng trực tiếp vào số dư website sau khi thẻ được duyệt thành công (Từ 5 - 30 giây).</p>
                        <p><strong class="text-slate-800 dark:text-slate-200">3. Xử lý sự cố:</strong> Đối với thẻ trạng thái "Chờ xử lý" quá lâu (Trên 5 phút), vui lòng liên hệ Admin qua kênh hỗ trợ để được kiểm tra thủ công.</p>
                        <p><strong class="text-slate-800 dark:text-slate-200">4. Spam thẻ sai:</strong> Các tài khoản cố tình nạp thẻ sai, thẻ đã qua sử dụng nhiều lần sẽ bị hệ thống tự động khóa vĩnh viễn.</p>
                    </div>
                    
                    <div class="p-5 border-t border-slate-100 dark:border-slate-800">
                        <button @click="showTerms = false; agreed = true" class="click-effect w-full h-11 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-[13px] transition-colors focus:outline-none">
                            Tôi Đã Hiểu & Đồng Ý
                        </button>
                    </div>
                </div>
            </div>

        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('cardManager', () => ({
                networks: [
                    { id: 'VIETTEL', img: '/client/layout/assets/card/vt.png' },
                    { id: 'VINAPHONE', img: '/client/layout/assets/card/vina.png' },
                    { id: 'MOBIFONE', img: '/client/layout/assets/card/mobifone.png' },
                    { id: 'GARENA', img: '/client/layout/assets/card/garena.svg' }
                ],
                telco: 'VIETTEL',
                amount: 10000,
                serial: '',
                code: '',
                agreed: false,
                showTerms: false,
                isProcessing: false,

                init() {
                    this.$watch('telco', (val) => {
                        if (val === 'GARENA' && this.amount == 10000) {
                            this.amount = 20000;
                        }
                    });
                },

                async submitCard() {
                    if (!this.serial || !this.code) {
                        Swal.fire({ 
                            toast: true, position: 'top-end', icon: 'warning', 
                            title: 'Vui lòng nhập Serial và Mã Thẻ!', showConfirmButton: false, timer: 3000,
                            background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff',
                            color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a'
                        });
                        return;
                    }

                    this.isProcessing = true;
                    
                    // Alert Phẳng
                    Swal.fire({
                        title: 'Đang gửi thẻ...',
                        html: '<div class="text-[13px] text-slate-500 dark:text-slate-400 mt-2">Hệ thống đang kết nối với nhà mạng, vui lòng không đóng cửa sổ này.</div>',
                        allowOutsideClick: false,
                        allowEscapeKey: false,
                        background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff',
                        color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a',
                        customClass: { popup: 'rounded-2xl border border-slate-200 dark:border-slate-800' },
                        didOpen: () => { Swal.showLoading(); }
                    });

                    try {
                        const response = await fetch('/api-handler?action=charge_card', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                telco: this.telco,
                                amount: this.amount,
                                serial: this.serial,
                                code: this.code
                            })
                        });
                        
                        const result = await response.json();
                        
                        if (result.status === 99) {
                            Swal.update({ 
                                title: 'Hệ thống đang duyệt thẻ...', 
                                html: '<div class="text-[13px] text-slate-500 dark:text-slate-400 mt-2">Nhà mạng đang kiểm tra mệnh giá.<br>Thời gian duyệt từ <b class="text-blue-500">5 - 30 giây</b>.</div>' 
                            });
                            this.pollCheckCard(result.request_id);
                        } 
                        else {
                            this.isProcessing = false;
                            Swal.fire({
                                icon: 'error',
                                title: 'Lỗi nạp thẻ',
                                text: result.message,
                                confirmButtonColor: '#2563eb',
                                background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff',
                                color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a',
                                customClass: { popup: 'rounded-2xl border border-slate-200 dark:border-slate-800' }
                            });
                        }
                    } catch (error) {
                        this.isProcessing = false;
                        Swal.fire({
                            icon: 'error',
                            title: 'Lỗi kết nối',
                            text: 'Không thể kết nối đến máy chủ xử lý.',
                            confirmButtonColor: '#2563eb',
                            background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff',
                            color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a',
                            customClass: { popup: 'rounded-2xl border border-slate-200 dark:border-slate-800' }
                        });
                    }
                },

                pollCheckCard(requestId) {
                    const checkInterval = setInterval(async () => {
                        try {
                            const res = await fetch('/api-handler?action=check_card_status', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ request_id: requestId })
                            });
                            const data = await res.json();
                            
                            if (data.status !== 99) {
                                clearInterval(checkInterval);
                                this.isProcessing = false;
                                
                                if (data.status === 1 || data.status === 2) {
                                    Swal.fire({
                                        icon: 'success',
                                        title: 'Nạp thành công!',
                                        text: data.message,
                                        confirmButtonColor: '#2563eb',
                                        background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff',
                                        color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a',
                                        customClass: { popup: 'rounded-2xl border border-slate-200 dark:border-slate-800' }
                                    }).then(() => {
                                        window.location.reload(); 
                                    });
                                } else {
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Thẻ bị từ chối',
                                        text: data.message,
                                        confirmButtonColor: '#2563eb',
                                        background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff',
                                        color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a',
                                        customClass: { popup: 'rounded-2xl border border-slate-200 dark:border-slate-800' }
                                    });
                                }
                            }
                        } catch (e) {
                            // Chặn lỗi vặt khi poll
                        }
                    }, 5000); 
                }
            }));
        });
    </script>
</body>
</html>