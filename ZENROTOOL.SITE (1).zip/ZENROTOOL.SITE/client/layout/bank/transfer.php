<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';

if (!isset($_SESSION['user_id']) || empty($_GET['token'])) { header("Location: /home"); exit; }

$token = $_GET['token'];
$user_id = $_SESSION['user_id'];
$configPath = __DIR__ . '/../../../config/settings.php';
if (file_exists($configPath)) require_once $configPath;

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmt->execute(['id' => $_SESSION['user_id']]);
$user_data = $stmt->fetch();

if (!$user_data) {
    session_destroy();
    header("Location: /auth/#login");
    exit;
}
// Lấy thông tin đơn nạp
$stmtOrder = $pdo->prepare("SELECT * FROM transfer_history WHERE order_token = :token AND user_id = :uid LIMIT 1");
$stmtOrder->execute(['token' => $token, 'uid' => $user_id]);
$order = $stmtOrder->fetch(PDO::FETCH_ASSOC);

if (!$order) { header("Location: /home"); exit; }

// Lấy thông tin Bank
$stmtBank = $pdo->query("SELECT * FROM setting_bank LIMIT 1");
$bank = $stmtBank->fetch(PDO::FETCH_ASSOC);

// QR URL
$qrUrl = "https://img.vietqr.io/image/{$bank['bin']}-{$bank['account_number']}-qr_only.png?amount={$order['amount']}&addInfo=" . urlencode($order['content']) . "&accountName=" . urlencode($bank['account_name']);

$isExpired = (strtotime($order['expires_at']) < time());
$pageTitle = 'Thanh Toán Chuyển Khoản';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/collapse@3.x.x/dist/cdn.min.js"></script>
    <style>
        /* Animation Phẳng - Mượt */
        .fade-up { opacity: 0; transform: translateY(15px); animation: fadeUp 0.5s cubic-bezier(0.2, 0.8, 0.2, 1) forwards; }
        @keyframes fadeUp { to { opacity: 1; transform: translateY(0); } }
        
        /* Hiệu ứng nhún (Click Effect) */
        .click-effect { transition: transform 0.15s cubic-bezier(0.4, 0, 0.2, 1); }
        .click-effect:active { transform: scale(0.96); }
        
        /* Khung quét QR Phẳng */
        .qr-frame { position: relative; padding: 12px; background: #fff; border-radius: 1.5rem; overflow: hidden; display: inline-block; }
        .qr-border { position: relative; border-radius: 1rem; overflow: hidden; border: 1px solid #e2e8f0; }
        .dark .qr-border { border-color: #1e293b; }
        .scan-line {
            position: absolute; width: 100%; height: 2px; background: #3b82f6; left: 0; top: 0;
            animation: scan 2s linear infinite; z-index: 20;
        }
        @keyframes scan { 0% { top: 0; opacity: 0; } 10% { opacity: 1; } 90% { opacity: 1; } 100% { top: 100%; opacity: 0; } }
        
        [x-cloak] { display: none !important; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-slate-50 dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-200 relative overflow-x-hidden">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen sm:ml-[260px]">
        
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto w-full fade-up" x-data="transferCheck('<?= $token ?>', '<?= $order['status'] ?>', <?= $isExpired ? 'true' : 'false' ?>, '<?= $bank['method'] ?>')">
            
            <div class="mb-5">
                <a href="/bank/recharge" class="click-effect inline-flex items-center gap-1.5 text-[13px] font-bold text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white transition-colors focus:outline-none">
                    <i class="ri-arrow-left-line text-[16px]"></i> Hủy & Quay lại
                </a>
            </div>

            <!-- Header Title -->
            <div class="text-center mb-8">
                <div class="w-16 h-16 bg-white dark:bg-[#0f172a] p-2 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-center mx-auto mb-4">
                    <img src="<?= htmlspecialchars($bank['logo']) ?>" alt="Logo Bank" class="w-full h-full object-contain">
                </div>
                <h1 class="text-xl sm:text-2xl font-bold text-slate-800 dark:text-white mb-1.5">Thanh Toán Hóa Đơn</h1>
                <p class="text-[13px] text-slate-500 dark:text-slate-400">Mở ứng dụng ngân hàng và quét mã QR bên dưới để thanh toán.</p>
            </div>

            <!-- TRẠNG THÁI: ĐÃ THANH TOÁN -->
            <template x-if="status === 'paid'">
                <div class="bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/20 p-8 rounded-2xl text-center w-full max-w-lg mx-auto">
                    <div class="w-16 h-16 bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center justify-center mx-auto mb-5">
                        <i class="ri-check-double-fill text-3xl"></i>
                    </div>
                    <h2 class="text-xl font-bold text-emerald-700 dark:text-emerald-400 mb-2">Thanh Toán Thành Công!</h2>
                    <p class="text-[13px] text-emerald-600 dark:text-emerald-500/80 font-medium">Hệ thống đang chuyển hướng về trang chủ...</p>
                </div>
            </template>

            <!-- TRẠNG THÁI: HẾT HẠN -->
            <template x-if="isExpired && status !== 'paid'">
                <div class="bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/20 p-8 rounded-2xl text-center w-full max-w-lg mx-auto">
                    <div class="w-16 h-16 bg-rose-100 dark:bg-rose-500/20 text-rose-600 dark:text-rose-400 rounded-2xl flex items-center justify-center mx-auto mb-5">
                        <i class="ri-timer-flash-fill text-3xl"></i>
                    </div>
                    <h2 class="text-xl font-bold text-rose-700 dark:text-rose-400 mb-2">Đơn Nạp Đã Hết Hạn!</h2>
                    <p class="text-[13px] text-rose-600 dark:text-rose-500/80 font-medium mb-6">Mã QR này không còn hiệu lực. Vui lòng tạo đơn mới.</p>
                    <a href="/bank/recharge" class="click-effect inline-flex items-center justify-center bg-rose-600 text-white px-6 h-11 rounded-xl text-[13px] font-bold hover:bg-rose-700 transition-colors focus:outline-none">
                        Tạo Đơn Mới
                    </a>
                </div>
            </template>

            <!-- TRẠNG THÁI: CHỜ THANH TOÁN (Grid 2 cột) -->
            <template x-if="status === 'pending' && !isExpired">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-0 w-full bg-white dark:bg-[#0f172a] rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
                    
                    <!-- Cột Trái: QR Code -->
                    <div class="p-8 flex flex-col items-center justify-center bg-slate-50/50 dark:bg-slate-800/30 border-b md:border-b-0 md:border-r border-slate-100 dark:border-slate-800/80">
                        <div class="qr-frame border border-slate-200 dark:border-slate-700 mb-6 bg-white dark:bg-[#0f172a]">
                            <div class="qr-border">
                                <div class="scan-line"></div>
                                <img src="<?= $qrUrl ?>" alt="QR Code" class="w-52 h-52 sm:w-60 sm:h-60 object-contain">
                            </div>
                        </div>
                        <div class="inline-flex items-center gap-2 text-blue-600 dark:text-blue-400 font-bold bg-blue-50 dark:bg-blue-500/10 px-4 py-2 rounded-xl border border-blue-100 dark:border-blue-500/20 text-[12px]">
                            <i class="ri-loader-4-line animate-spin text-[16px]"></i> Đang chờ thanh toán...
                        </div>
                    </div>

                    <!-- Cột Phải: Thông tin CK -->
                    <div class="p-8 flex flex-col justify-center">
                        <h3 class="text-[14px] font-bold mb-5 flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3 text-slate-800 dark:text-white uppercase tracking-wide">
                            <i class="ri-article-fill text-blue-500 text-[18px]"></i> Chi Tiết Giao Dịch
                        </h3>
                        
                        <div class="space-y-4 text-[13px]">
                            <div class="flex justify-between items-center">
                                <span class="text-slate-500 dark:text-slate-400 font-medium">Ngân hàng:</span>
                                <span class="font-bold text-slate-800 dark:text-white uppercase text-right"><?= htmlspecialchars($bank['bank_name']) ?></span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-slate-500 dark:text-slate-400 font-medium">Chủ tài khoản:</span>
                                <span class="font-bold text-slate-800 dark:text-white uppercase"><?= htmlspecialchars($bank['account_name']) ?></span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-slate-500 dark:text-slate-400 font-medium">Số tài khoản:</span>
                                <div class="flex items-center gap-2">
                                    <span class="font-black text-blue-600 dark:text-blue-400 text-[16px] tracking-wider"><?= htmlspecialchars($bank['account_number']) ?></span>
                                    <button onclick="copyText('<?= htmlspecialchars($bank['account_number']) ?>')" class="click-effect w-7 h-7 flex items-center justify-center rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 transition-colors focus:outline-none">
                                        <i class="ri-file-copy-fill"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-slate-500 dark:text-slate-400 font-medium">Số tiền nạp:</span>
                                <span class="font-black text-rose-500 text-[18px]"><?= number_format($order['amount']) ?>đ</span>
                            </div>
                            
                            <!-- Nội dung chuyển khoản -->
                            <div class="flex flex-col gap-2 pt-4 mt-2 border-t border-slate-100 dark:border-slate-800">
                                <span class="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Nội dung chuyển khoản (Bắt buộc)</span>
                                <div class="flex justify-between items-center bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/30 rounded-xl p-3">
                                    <span class="font-black tracking-wider text-[16px] text-blue-700 dark:text-blue-400 font-mono"><?= htmlspecialchars($order['content']) ?></span>
                                    <button onclick="copyText('<?= htmlspecialchars($order['content']) ?>')" class="click-effect bg-blue-600 hover:bg-blue-700 text-white px-4 h-8 text-[11px] rounded-lg font-bold transition-colors focus:outline-none">
                                        Copy Mã
                                    </button>
                                </div>
                                <p class="text-[11px] text-rose-500 font-medium flex items-center gap-1 mt-1">
                                    <i class="ri-error-warning-fill"></i> Chú ý: Ghi đúng nội dung để được cộng tiền tự động.
                                </p>
                            </div>
                        </div>
                        
                        <!-- Nút Xử lý (Nếu là nạp thủ công) -->
                        <template x-if="method === 'manual'">
                            <button @click="notifyAdmin()" :disabled="notified" class="click-effect w-full mt-6 bg-slate-900 hover:bg-slate-800 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-200 text-white font-bold h-12 rounded-xl text-[13px] transition-colors disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none flex items-center justify-center gap-2">
                                <i :class="notified ? 'ri-check-line' : 'ri-send-plane-fill'" class="text-[16px]"></i>
                                <span x-text="notified ? 'Đã Gửi Thông Báo' : 'Xác Nhận Đã Chuyển Tiền'"></span>
                            </button>
                        </template>
                    </div>
                </div>
            </template>

        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        function copyText(txt) {
            navigator.clipboard.writeText(txt);
            Swal.fire({ 
                toast: true, position: 'top-end', icon: 'success', title: 'Đã copy thành công!', 
                showConfirmButton: false, timer: 1500,
                background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff',
                color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a'
            });
        }

        document.addEventListener('alpine:init', () => {
            Alpine.data('transferCheck', (token, initStatus, initExpired, method) => ({
                token: token,
                status: initStatus,
                isExpired: initExpired,
                method: method,
                notified: false,
                interval: null,

                init() {
                    if (this.status === 'pending' && !this.isExpired) {
                        this.interval = setInterval(() => this.checkStatus(), 3000); 
                    }
                    if (this.status === 'paid') {
                        setTimeout(() => window.location.href = '/home', 3000);
                    }
                },

                async checkStatus() {
                    try {
                        let formData = new FormData();
                        formData.append('token', this.token);
                        
                        const res = await fetch('/api-handler?action=check_status', { method: 'POST', body: formData });
                        const data = await res.json();
                        
                        if (data.status === 'paid') {
                            clearInterval(this.interval);
                            this.status = 'paid';
                            Swal.fire({ 
                                icon: 'success', 
                                title: 'Thành công!', 
                                text: 'Hệ thống đã nhận được tiền nạp của bạn.', 
                                confirmButtonColor: '#2563eb',
                                background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff',
                                color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a',
                                customClass: { popup: 'rounded-2xl border border-slate-200 dark:border-slate-800' }
                            });
                            setTimeout(() => window.location.href = '/home', 3000);
                        } else if (data.status === 'expired') {
                            clearInterval(this.interval);
                            this.isExpired = true;
                        }
                    } catch(e) {}
                },

                async notifyAdmin() {
                    this.notified = true;
                    try {
                        let formData = new FormData();
                        formData.append('token', this.token);
                        await fetch('/api-handler?action=notify_admin', { method: 'POST', body: formData });
                        Swal.fire({ 
                            icon: 'success', 
                            title: 'Thành công', 
                            text: 'Đã gửi thông báo cho Admin. Vui lòng chờ xử lý.', 
                            confirmButtonColor: '#2563eb',
                            background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff',
                            color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a',
                            customClass: { popup: 'rounded-2xl border border-slate-200 dark:border-slate-800' }
                        });
                    } catch(e) {
                        this.notified = false;
                    }
                }
            }));
        });
    </script>
</body>
</html>
