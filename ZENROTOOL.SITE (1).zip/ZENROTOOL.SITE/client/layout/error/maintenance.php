<?php
// Tải cấu hình từ database
require_once __DIR__ . '/../../../config/settings.php';

// Nếu chế độ bảo trì đã tắt, tự động chuyển hướng về trang chủ
if (empty($config['maintenance_mode']) || $config['maintenance_mode'] != '1') {
    header("Location: /");
    exit;
}

$pageTitle = 'Hệ Thống Đang Bảo Trì';

// Lấy thông báo từ admin, nếu trống thì dùng thông báo mặc định
$admin_message = !empty($config['maintenance_html']) 
    ? $config['maintenance_html'] 
    : 'Hệ thống đang được nâng cấp và bảo trì định kỳ để mang lại trải nghiệm tốt nhất. Quá trình này sẽ diễn ra trong ít phút, vui lòng quay lại sau.';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <style>
        .shadow-soft { box-shadow: 0 10px 40px -10px rgba(0, 0, 0, 0.08); }
        .fade-in-up { animation: fadeInUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        @keyframes fadeInUp { 
            from { opacity: 0; transform: translateY(20px); } 
            to { opacity: 1; transform: translateY(0); } 
        }
        .spin-slow { animation: spin 4s linear infinite; }
        @keyframes spin { 100% { transform: rotate(360deg); } }
        
        /* Đảm bảo nội dung HTML từ Admin hiển thị đẹp */
        .admin-content p { margin-bottom: 0.5rem; }
        .admin-content b, .admin-content strong { color: #171717; }
        .dark .admin-content b, .dark .admin-content strong { color: #ffffff; }
    </style>
</head>
<body x-data="{ darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-neutral-50 dark:bg-gray-900 text-neutral-800 dark:text-gray-200 antialiased transition-colors duration-300 min-h-screen flex flex-col items-center justify-center p-4 sm:p-6 relative overflow-hidden">
    
    <div class="absolute inset-0 pointer-events-none overflow-hidden flex items-center justify-center">
        <div class="w-[800px] h-[800px] bg-blue-500/5 dark:bg-blue-500/10 rounded-full blur-3xl"></div>
    </div>

    <main class="w-full max-w-md relative z-10 fade-in-up">
        <div class="rounded-[28px] border border-neutral-200 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-soft overflow-hidden relative">
            
            <div class="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500"></div>

            <div class="p-8 sm:p-10 text-center">
                <div class="w-20 h-20 mx-auto rounded-2xl bg-neutral-50 dark:bg-gray-700/50 flex items-center justify-center border border-neutral-100 dark:border-gray-600 mb-6 relative shadow-sm">
                    <i class="ri-settings-4-line text-4xl text-blue-500 spin-slow"></i>
                    <div class="absolute -bottom-2 -right-2 w-8 h-8 bg-amber-400 rounded-full flex items-center justify-center border-[3px] border-white dark:border-gray-800 shadow-sm">
                        <i class="ri-tools-fill text-white text-[14px]"></i>
                    </div>
                </div>

                <h1 class="text-2xl sm:text-3xl font-bold text-neutral-900 dark:text-white mb-4 tracking-tight">Đang Bảo Trì</h1>
                
                <div class="admin-content text-[15px] text-neutral-500 dark:text-gray-400 leading-relaxed mb-8">
                    <?= $admin_message ?>
                </div>

                <div class="flex flex-col gap-3">
                    <button onclick="window.location.reload()" class="h-12 w-full inline-flex items-center justify-center gap-2 bg-neutral-900 hover:bg-black dark:bg-white dark:text-neutral-900 dark:hover:bg-gray-100 text-white rounded-xl text-[14px] font-bold transition-all active:scale-[0.98] shadow-sm">
                        <i class="ri-refresh-line text-lg font-normal"></i> Tải Lại Trang
                    </button>
                    
                    <?php if(!empty($config['support_link'])): ?>
                    <a href="<?= htmlspecialchars($config['support_link']) ?>" target="_blank" class="h-12 w-full inline-flex items-center justify-center gap-2 bg-white dark:bg-gray-800 border border-neutral-200 dark:border-gray-700 text-neutral-600 dark:text-gray-300 hover:bg-neutral-50 dark:hover:bg-gray-700 rounded-xl text-[14px] font-bold transition-all">
                        <i class="ri-customer-service-2-line text-lg font-normal"></i> Liên hệ hỗ trợ
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="text-center mt-6 text-sm text-neutral-400 dark:text-gray-500 font-medium">
            &copy; <?= date('Y') ?> ZENRO.SITE. All rights reserved.
        </div>
    </main>
    
</body>
</html>