<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/settings.php';

// 1. KIỂM TRA BẢO MẬT & TẠO TOKEN
if (!isset($_SESSION['user_id'])) { 
    header('Location: /auth/#login'); 
    exit; 
}
if (empty($_SESSION['zenro_secure_token'])) {
    $_SESSION['zenro_secure_token'] = bin2hex(random_bytes(32));
}

// 2. KIỂM TRA USER
$stmtUser = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user_data = $stmtUser->fetch(PDO::FETCH_ASSOC);

if (!$user_data) {
    session_destroy();
    header("Location: /auth/#login");
    exit;
}

$user = $user_data;
$userData = $user_data;
$userInfo = $user_data;
$balance = number_format($user_data['balance'] ?? 0, 0, ',', '.');
$initial = strtoupper(substr($user_data['username'] ?? $user_data['display_name'] ?? 'U', 0, 1));
$user_avatar = $user_data['avatar'] ?? '';

// Check VIP
$is_vip = false;
if (!empty($user_data['vip_expire_at']) && strtotime($user_data['vip_expire_at']) > time()) {
    $is_vip = true;
}

// 3. LẤY DATA GAME TỪ SLUG
$slug = $_GET['slug'] ?? '';
if (empty($slug)) { header('Location: /tools'); exit; }

$stmtGame = $pdo->prepare("SELECT * FROM games WHERE slug = ? AND status = 'active' LIMIT 1");
$stmtGame->execute([$slug]);
$game = $stmtGame->fetch(PDO::FETCH_ASSOC);

if (!$game) { header('Location: /tools'); exit; }
if (!$is_vip) { header('Location: /thue-vip'); exit; }

$hasHistoryMap = !empty($game['map_history_prev']) && !empty($game['map_history_result']);
$hasIframe = !empty($game['url_iframe']);
$pageTitle = htmlspecialchars($game['name']) . ' - AI Prediction';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/collapse@3.x.x/dist/cdn.min.js"></script>
    <style>
        .fade-up { opacity: 0; transform: translateY(15px); animation: fadeUp 0.5s cubic-bezier(0.2, 0.8, 0.2, 1) forwards; }
        @keyframes fadeUp { to { opacity: 1; transform: translateY(0); } }
        .click-effect { transition: transform 0.15s cubic-bezier(0.4, 0, 0.2, 1); }
        .click-effect:active { transform: scale(0.96); }
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background-color: #cbd5e1; border-radius: 10px; }
        .dark .custom-scrollbar::-webkit-scrollbar-thumb { background-color: #475569; }
        
        @keyframes ledChasing { 0% { background-position: 0% 50%; } 100% { background-position: 200% 50%; } }
        .led-bar-chasing {
            background: linear-gradient(90deg, #3b82f6, #ec4899, #10b981, #f59e0b, #3b82f6);
            background-size: 200% 100%;
            animation: ledChasing 2s linear infinite;
        }
        .txt-tai { color: #10b981; } 
        .txt-xiu { color: #f43f5e; } 
        [x-cloak] { display: none !important; }

        /* Animation Popup Iframe */
        @keyframes blinkGreen {
            0%, 100% { background-color: #00ff00; border-color: #fff; box-shadow: 0 0 15px #00ff00; transform: scale(1); }
            50% { background-color: #00cc00; border-color: rgba(255,255,255,0.7); box-shadow: 0 0 5px #00ff00; transform: scale(0.95); }
        }
        @keyframes blinkRed {
            0%, 100% { background-color: #ff0000; border-color: #fff; box-shadow: 0 0 15px #ff0000; transform: scale(1); }
            50% { background-color: #cc0000; border-color: rgba(255,255,255,0.7); box-shadow: 0 0 5px #ff0000; transform: scale(0.95); }
        }
        .active-tai { animation: blinkGreen 0.5s infinite !important; background-color: #00ff00 !important; border-color: #fff !important; }
        .active-xiu { animation: blinkRed 0.5s infinite !important; background-color: #ff0000 !important; border-color: #fff !important; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-slate-50 dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-200 relative overflow-x-hidden">
    
    <?php if ($hasIframe): ?>
        
        <!-- ================= GIAO DIỆN CHƠI GAME IFRAME ================= -->
        <div class="fixed inset-0 z-[100] bg-black overflow-hidden flex flex-col">
            <iframe src="<?= htmlspecialchars($game['url_iframe']) ?>" class="w-full h-full border-none flex-1"></iframe>
            
            <!-- Nút Quay Lại Cố Định (Trang Tools) -->
            <a href="/tools" class="fixed top-4 left-4 z-[110] w-10 h-10 bg-black/60 text-white rounded-full flex items-center justify-center border border-white/20 backdrop-blur-md shadow-lg click-effect">
                <i class="ri-arrow-left-line text-xl"></i>
            </a>

            <!-- Popup Dự Đoán Nổi Kéo Thả -->
            <div id="drag-popup" class="fixed top-[15%] left-[50%] z-[120] cursor-move shadow-2xl" style="touch-action: none; transform: translateX(-50%);">
                <!-- Giảm bo góc thành rounded-xl (hoặc 2xl), xóa chữ Tài/Xỉu, tăng kích thước vòng tròn -->
                <div id="popup-content" class="bg-[#5a5a5a]/95 backdrop-blur-md rounded-2xl px-5 py-3 flex items-center gap-6 border border-white/20 transition-transform duration-300 select-none">
                    
                    <div id="circle-tai" class="w-10 h-10 rounded-full border-[3px] border-white/40 bg-black/30 transition-all duration-200 shrink-0"></div>
                    
                    <div class="flex flex-col items-center justify-center gap-1 shrink-0">
                        <img src="<?= !empty($game['image']) ? htmlspecialchars($game['image']) : 'https://placehold.co/100x100/e2e8f0/475569?text=Logo' ?>" class="w-[45px] h-[45px] rounded-[10px] object-cover border border-white/30 shadow-inner bg-white">
                        <span id="popup-session" class="text-white font-bold text-[12px] opacity-90 drop-shadow-md tracking-wider">#---</span>
                    </div>
                    
                    <div id="circle-xiu" class="w-10 h-10 rounded-full border-[3px] border-white/40 bg-black/30 transition-all duration-200 shrink-0"></div>
                
                </div>
            </div>

            <!-- Thanh thông báo dưới cùng điện thoại -->
            <div class="fixed bottom-3 left-1/2 -translate-x-1/2 w-max px-6 py-2 bg-black/80 backdrop-blur-lg rounded-full text-white text-[13px] font-bold border border-white/20 z-[120] shadow-[0_4px_20px_rgba(0,0,0,0.5)] flex items-center justify-center whitespace-nowrap">
                <span id="bottom-info" class="tracking-wide">Đang phân tích dữ liệu...</span>
            </div>
        </div>

    <?php else: ?>

        <!-- ================= GIAO DIỆN BẢNG DỰ ĐOÁN MẶC ĐỊNH ================= -->
        <?php include __DIR__ . '/../include/nav.php'; ?>

        <div class="flex flex-col min-h-screen sm:ml-[260px]">
            
            <?php include __DIR__ . '/../include/header.php'; ?>

            <main class="flex-1 p-4 sm:p-6 lg:p-8 w-full max-w-4xl mx-auto fade-up">
                <div class="mb-5 flex justify-between items-center">
                    <a href="/tools" class="click-effect inline-flex items-center gap-1.5 text-[13px] font-bold text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white transition-colors focus:outline-none">
                        <i class="ri-arrow-left-line text-[16px]"></i> Về Kho Công Cụ
                    </a>
                </div>

                <!-- HEADER GAME -->
                <div class="bg-white dark:bg-[#0f172a] rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 flex flex-col md:flex-row md:items-center justify-between gap-5 mb-6">
                    <div class="flex items-center gap-4">
                        <div class="w-16 h-16 rounded-xl bg-slate-50 dark:bg-slate-800/50 flex items-center justify-center border border-slate-100 dark:border-slate-700/50 shrink-0">
                            <img src="<?= !empty($game['image']) ? htmlspecialchars($game['image']) : 'https://placehold.co/100x100/e2e8f0/475569?text=Logo' ?>" class="w-10 h-10 object-contain">
                        </div>
                        <div>
                            <div class="inline-flex items-center px-2 py-0.5 bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-md text-[9px] font-bold uppercase tracking-widest mb-1.5 border border-blue-100/50 dark:border-transparent">
                                Phân Tích Bằng AI
                            </div>
                            <h1 class="text-xl sm:text-2xl font-bold text-slate-800 dark:text-white leading-tight"><?= htmlspecialchars($game['name']) ?></h1>
                        </div>
                    </div>
                </div>

                <!-- KHOANG DỰ ĐOÁN (AI PREDICTION) -->
                <div class="bg-slate-900 dark:bg-[#020617] rounded-2xl border border-slate-800 p-6 sm:p-10 mb-6 text-center relative overflow-hidden">
                    <div class="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full blur-[80px] pointer-events-none"></div>
                    <div class="absolute bottom-0 left-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-[80px] pointer-events-none"></div>

                    <div class="relative z-10">
                        <div id="tx-loading" class="flex flex-col items-center justify-center py-8">
                            <i class="ri-loader-4-line text-3xl text-blue-500 animate-spin mb-3"></i>
                            <div class="text-slate-400 text-[11px] font-bold tracking-widest uppercase">Thiết lập kết nối AI...</div>
                        </div>

                        <div id="tx-predicting" style="display: none;" class="flex flex-col items-center justify-center py-8">
                            <div class="flex items-center gap-2 mb-4">
                                <div class="w-2.5 h-2.5 rounded-full bg-blue-500 animate-bounce" style="animation-delay: 0s"></div>
                                <div class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-bounce" style="animation-delay: 0.2s"></div>
                                <div class="w-2.5 h-2.5 rounded-full bg-rose-500 animate-bounce" style="animation-delay: 0.4s"></div>
                            </div>
                            <div class="text-amber-500 text-[14px] font-bold uppercase tracking-widest animate-pulse">Đang Phân Tích Cầu...</div>
                        </div>

                        <div id="tx-content" style="display: none;" class="flex flex-col items-center">
                            <div class="px-3 py-1 rounded-md bg-white/10 border border-white/10 text-[10px] font-bold text-slate-300 uppercase tracking-widest mb-4">
                                Phiên Hiện Tại: <span id="tx-session" class="text-white ml-1 font-mono">---</span>
                            </div>
                            
                            <div class="mb-6">
                                <span id="tx-text" class="text-6xl sm:text-7xl font-black uppercase tracking-wider transition-colors duration-300">---</span>
                            </div>

                            <div class="w-full max-w-[200px] h-[4px] bg-slate-800 rounded-full overflow-hidden mb-5">
                                <div class="h-full w-full led-bar-chasing"></div>
                            </div>

                            <div class="text-[11px] font-bold text-slate-400 uppercase tracking-widest flex items-center justify-center gap-2">
                                Tỉ Lệ AI: <span id="tx-ratio" class="text-amber-500 font-black text-[15px]">---</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- BẢNG LỊCH SỬ DỰ ĐOÁN -->
                <div class="bg-white dark:bg-[#0f172a] rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
                    <div class="px-5 py-4 border-b border-slate-100 dark:border-slate-800/80 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/30">
                        <h3 class="font-bold text-slate-800 dark:text-white uppercase tracking-widest text-[12px] flex items-center gap-2">
                            <i class="ri-history-fill text-blue-500 text-[16px]"></i> Lịch Sử Dự Đoán
                        </h3>
                        <span class="text-[9px] uppercase font-bold tracking-widest text-slate-500 bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded-md border border-slate-200 dark:border-slate-700">20 Phiên Gần Nhất</span>
                    </div>
                    
                    <div class="p-4 max-h-[350px] overflow-y-auto custom-scrollbar">
                        <div id="tx-history" class="space-y-2">
                            <div class="text-center py-10 text-[12px] font-medium text-slate-400">Đang đồng bộ dữ liệu với máy chủ...</div>
                        </div>
                    </div>
                </div>
            </main>
            
            <?php include __DIR__ . '/../include/footer.php'; ?>
        </div>
    <?php endif; ?>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const SECURE_TOKEN = "<?= $_SESSION['zenro_secure_token'] ?>";
            const SLUG = "<?= htmlspecialchars($slug) ?>";
            const HAS_HISTORY = <?= $hasHistoryMap ? 'true' : 'false' ?>;
            const HAS_IFRAME = <?= $hasIframe ? 'true' : 'false' ?>;
            
            const STATES = { LOADING: 'loading', DISPLAYING: 'displaying', PREDICTING: 'predicting' };

            let feedState = { state: STATES.LOADING, currentSession: null, pendingData: null };
            let historyData = [];

            // --- XỬ LÝ CHUNG: CHUẨN HOÁ & TỈ LỆ ---
            function getDeterministicRate(sessionId) {
                if (!sessionId) return "85%";
                let hash = 0; let strId = String(sessionId);
                for (let i = 0; i < strId.length; i++) { hash = strId.charCodeAt(i) + ((hash << 5) - hash); }
                return (80 + (Math.abs(hash) % 16)) + "%"; 
            }

            function checkTaiXiu(text) {
                const str = String(text).toLowerCase();
                if (str.includes('tài') || str.includes('tai') || str.includes('big') || str.includes('t')) return 'TÀI';
                if (str.includes('xỉu') || str.includes('xiu') || str.includes('small') || str.includes('x')) return 'XỈU';
                return text; 
            }

            // ============================================
            // LOGIC KHI MỞ BẢNG DỰ ĐOÁN MẶC ĐỊNH
            // ============================================
            function showLoading() {
                if(HAS_IFRAME) return;
                document.getElementById('tx-loading').style.display = 'flex';
                document.getElementById('tx-content').style.display = 'none';
                document.getElementById('tx-predicting').style.display = 'none';
            }

            function showContent() {
                if(HAS_IFRAME) return;
                document.getElementById('tx-loading').style.display = 'none';
                document.getElementById('tx-content').style.display = 'flex';
                document.getElementById('tx-predicting').style.display = 'none';
            }

            function showPredicting() {
                if(HAS_IFRAME) return;
                document.getElementById('tx-loading').style.display = 'none';
                document.getElementById('tx-content').style.display = 'none';
                document.getElementById('tx-predicting').style.display = 'flex';
            }

            function updatePredictionDisplay(session, prediction, ratio) {
                if (!prediction || prediction === '---') return;
                
                const cleanResult = checkTaiXiu(prediction);
                let finalRatio = ratio;
                if (!finalRatio || finalRatio === '0%' || finalRatio === '---' || finalRatio === '') finalRatio = getDeterministicRate(session);
                
                if (HAS_IFRAME) {
                    // Update Iframe Popup
                    document.getElementById('popup-session').textContent = '#' + session;
                    document.getElementById('bottom-info').textContent = `#${session} - ${cleanResult} - ${finalRatio}`;
                    
                    const cTai = document.getElementById('circle-tai');
                    const cXiu = document.getElementById('circle-xiu');
                    
                    if (cleanResult === 'TÀI') {
                        cTai.classList.add('active-tai');
                        cXiu.classList.remove('active-xiu');
                    } else if (cleanResult === 'XỈU') {
                        cXiu.classList.add('active-xiu');
                        cTai.classList.remove('active-tai');
                    } else {
                        cTai.classList.remove('active-tai');
                        cXiu.classList.remove('active-xiu');
                    }

                } else {
                    // Update Normal View
                    document.getElementById('tx-session').textContent = session;
                    const textEl = document.getElementById('tx-text');
                    textEl.textContent = cleanResult;
                    textEl.className = 'text-6xl sm:text-7xl font-black uppercase tracking-wider transition-colors duration-300 ' + (cleanResult === 'TÀI' ? 'txt-tai' : 'txt-xiu');
                    document.getElementById('tx-ratio').textContent = String(finalRatio).replace('%', '') + '%';
                    showContent();
                }
            }

            function renderHistory() {
                if (HAS_IFRAME) return; 
                const container = document.getElementById('tx-history');
                if (!historyData.length) return;

                container.innerHTML = historyData.map(item => {
                    const textDudoan = checkTaiXiu(item.dudoan);
                    const badgeDudoan = (textDudoan === 'TÀI') ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400' : 'bg-rose-50 text-rose-600 dark:bg-rose-500/10 dark:text-rose-400';
                    let rightSideHtml = '';
                    
                    if (HAS_HISTORY) {
                        let statusIcon = '<div class="w-7 h-7 flex items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-400"><i class="ri-loader-4-line animate-spin"></i></div>';
                        let badgeThucte = 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400';
                        let textThucte = '---';

                        if (item.thucte && item.thucte !== 'Chưa có' && item.thucte !== '---') {
                            textThucte = checkTaiXiu(item.thucte);
                            badgeThucte = (textThucte === 'TÀI') ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400' : 'bg-rose-50 text-rose-600 dark:bg-rose-500/10 dark:text-rose-400';
                            statusIcon = item.kq === 'Đúng' 
                                ? '<div class="w-7 h-7 flex items-center justify-center rounded-lg bg-emerald-100 text-emerald-600 dark:bg-emerald-500/20 dark:text-emerald-400"><i class="ri-check-line font-bold"></i></div>'
                                : '<div class="w-7 h-7 flex items-center justify-center rounded-lg bg-rose-100 text-rose-600 dark:bg-rose-500/20 dark:text-rose-400"><i class="ri-close-line font-bold"></i></div>';
                        }
                        rightSideHtml = `<div class="flex items-center gap-3 border-l border-slate-200 dark:border-slate-700 pl-3 ml-3"><div class="flex flex-col items-center"><span class="text-[8px] font-bold text-slate-400 uppercase tracking-widest mb-1">Kết Quả</span><span class="px-2 py-0.5 text-[9px] font-bold uppercase rounded-md ${badgeThucte}">${textThucte}</span></div>${statusIcon}</div>`;
                    }

                    return `<div class="flex items-center justify-between p-3 bg-slate-50/50 dark:bg-slate-800/30 hover:bg-slate-100 dark:hover:bg-slate-800/80 rounded-xl transition-colors"><div class="flex items-center gap-3"><span class="text-[10px] font-mono font-bold text-slate-500 dark:text-slate-400">#${item.phien}</span><div class="flex items-center gap-2"><span class="text-[9px] font-bold text-slate-400 uppercase tracking-widest hidden sm:block">Dự đoán:</span><span class="px-2.5 py-1 text-[10px] font-bold uppercase rounded-md ${badgeDudoan}">${textDudoan}</span></div></div>${rightSideHtml}</div>`;
                }).join('');
            }

            function startTransition(newData) {
                if (!HAS_IFRAME) {
                    feedState.state = STATES.PREDICTING;
                    feedState.pendingData = newData;
                    showPredicting();
                }
                
                setTimeout(() => {
                    const data = HAS_IFRAME ? newData : feedState.pendingData;
                    feedState.currentSession = data.phien_hien_tai;
                    if(!HAS_IFRAME) {
                        feedState.pendingData = null;
                        feedState.state = STATES.DISPLAYING;
                    }
                    
                    updatePredictionDisplay(data.phien_hien_tai, data.du_doan, data.do_tin_cay);
                    
                    if (HAS_HISTORY && data.phien && data.ket_qua && data.ket_qua !== '---') {
                        const oldP = checkTaiXiu(data.old_prediction); const realRes = checkTaiXiu(data.ket_qua); const correct = (oldP === realRes);
                        if (!historyData.find(h => h.phien === data.phien)) {
                            historyData.unshift({ phien: data.phien, dudoan: data.old_prediction, thucte: data.ket_qua, kq: correct ? 'Đúng' : 'Sai' });
                            if (historyData.length > 20) historyData.pop(); renderHistory();
                        }
                    } else if (!HAS_HISTORY && data.phien_hien_tai) {
                        if (!historyData.find(h => h.phien === data.phien_hien_tai)) {
                            historyData.unshift({ phien: data.phien_hien_tai, dudoan: data.du_doan });
                            if (historyData.length > 20) historyData.pop(); renderHistory();
                        }
                    }
                }, HAS_IFRAME ? 0 : 5000); 
            }

            // ============================================
            // KÉO THẢ & XOAY POPUP (NẾU LÀ IFRAME MODE)
            // Tối ưu hóa mượt mà với requestAnimationFrame
            // ============================================
            if (HAS_IFRAME) {
                const popup = document.getElementById('drag-popup');
                const content = document.getElementById('popup-content');
                let isDragging = false, currentX = 0, currentY = 0, initialX = 0, initialY = 0, xOffset = 0, yOffset = 0;
                let rotated = false;
                let lastTap = 0;
                let ticking = false;

                // --- Drag Logic ---
                function dragStart(e) {
                    if (e.type === "touchstart") {
                        initialX = e.touches[0].clientX - xOffset;
                        initialY = e.touches[0].clientY - yOffset;
                    } else {
                        initialX = e.clientX - xOffset;
                        initialY = e.clientY - yOffset;
                    }
                    if (e.target === popup || popup.contains(e.target)) {
                        isDragging = true;
                    }
                }

                function dragEnd(e) {
                    initialX = currentX;
                    initialY = currentY;
                    isDragging = false;
                }

                function drag(e) {
                    if (isDragging) {
                        e.preventDefault();
                        if (e.type === "touchmove") {
                            currentX = e.touches[0].clientX - initialX;
                            currentY = e.touches[0].clientY - initialY;
                        } else {
                            currentX = e.clientX - initialX;
                            currentY = e.clientY - initialY;
                        }
                        xOffset = currentX;
                        yOffset = currentY;

                        if (!ticking) {
                            requestAnimationFrame(() => {
                                setTranslate(currentX, currentY, popup);
                                ticking = false;
                            });
                            ticking = true;
                        }
                    }
                }

                function setTranslate(xPos, yPos, el) {
                    // Căn giữa (-50%) ở X do inline style ban đầu, Y cộng trực tiếp
                    el.style.transform = `translate3d(calc(-50% + ${xPos}px), ${yPos}px, 0)`;
                }

                popup.addEventListener("touchstart", dragStart, { passive: false });
                document.addEventListener("touchend", dragEnd, { passive: false });
                document.addEventListener("touchmove", drag, { passive: false });
                
                popup.addEventListener("mousedown", dragStart, false);
                document.addEventListener("mouseup", dragEnd, false);
                document.addEventListener("mousemove", drag, false);

                // --- Double Click / Double Tap to Rotate ---
                function toggleRotate(e) {
                    rotated = !rotated;
                    content.style.transform = rotated ? "rotate(90deg)" : "rotate(0deg)";
                    if(e) e.preventDefault();
                }

                popup.addEventListener("dblclick", toggleRotate);

                // Touch cho điện thoại (Double Tap)
                popup.addEventListener('touchend', function(e) {
                    const currentTime = new Date().getTime();
                    const tapLength = currentTime - lastTap;
                    if (tapLength < 300 && tapLength > 0) {
                        toggleRotate(e);
                    }
                    lastTap = currentTime;
                });
            }

            // ============================================
            // CALL API DATA
            // ============================================
            function fetchEngine() {
                if (!HAS_IFRAME && feedState.state === STATES.PREDICTING) return; 
                
                const fd = new FormData(); 
                fd.append('secure_token', SECURE_TOKEN); 
                fd.append('slug', SLUG);
                
                fetch(`/api-handler?action=taixiu_api`, { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest' }, body: fd })
                .then(r => r.json())
                .then(res => {
                    if (res.status !== 'success') return;
                    const SK = CryptoJS.SHA256(res.k);
                    const SI = CryptoJS.enc.Utf8.parse(CryptoJS.SHA256(res.i).toString().substring(0, 16));
                    const dec = CryptoJS.AES.decrypt(res.data.replace(/-/g, '+').replace(/_/g, '/'), SK, { iv: SI, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 });
                    const jsonStr = dec.toString(CryptoJS.enc.Utf8);
                    
                    if (!jsonStr) return; const data = JSON.parse(jsonStr);
                    
                    if (data && data.phien_hien_tai && data.phien_hien_tai !== '---') {
                        const newSession = data.phien_hien_tai;
                        if (feedState.currentSession === null) {
                            feedState.currentSession = newSession; 
                            if(!HAS_IFRAME) feedState.state = STATES.DISPLAYING;
                            
                            updatePredictionDisplay(data.phien_hien_tai, data.du_doan, data.do_tin_cay);
                            
                            if (!historyData.find(h => h.phien === data.phien_hien_tai)) {
                                historyData.push({ phien: data.phien_hien_tai, dudoan: data.du_doan, thucte: data.ket_qua || '---', kq: 'Chờ' }); 
                                renderHistory();
                            }
                        } else if (newSession !== feedState.currentSession) {
                            if (HAS_IFRAME || feedState.state === STATES.DISPLAYING) {
                                data.old_prediction = HAS_IFRAME ? checkTaiXiu(data.du_doan) : document.getElementById('tx-text').textContent; 
                                startTransition(data);
                            }
                        }
                    }
                }).catch(e => {});
            }

            fetchEngine(); setInterval(fetchEngine, 3000);
        });
    </script>
</body>
</html>
