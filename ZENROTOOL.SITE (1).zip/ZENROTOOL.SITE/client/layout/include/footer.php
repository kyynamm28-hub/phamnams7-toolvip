<?php
if (!isset($config)) {
    require_once __DIR__ . '/../../../config/settings.php';
}

// Lấy nội dung HTML từ database, mặc định nếu rỗng
$footer_content = $config['footer_html'] ?? '&copy; ' . date('Y') . ' ZENRO SYSTEM. All rights reserved.';
?>

<footer class="mt-auto bg-transparent border-t border-slate-200 dark:border-slate-800/80 py-6 px-4 sm:px-6 relative z-10">
    <div class="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-5">
        
        <!-- Cột Trái: Bản Quyền & Nội Dung -->
        <div class="text-[13px] font-medium text-slate-500 dark:text-slate-400 text-center md:text-left prose dark:prose-invert prose-sm max-w-none">
            <?= $footer_content ?>
        </div>

        <!-- Cột Giữa: Trạng Thái Hệ Thống (Chỉ hiện trên Desktop) -->
        <div class="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-100 dark:border-transparent text-emerald-600 dark:text-emerald-400 text-[11px] font-bold tracking-wide">
            <span class="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
            Hệ thống ổn định
        </div>

        <!-- Cột Phải: Mạng Xã Hội & Hỗ Trợ -->
        <div class="flex items-center gap-3">
            <a href="<?= htmlspecialchars($config['community_link'] ?? '#') ?>" target="_blank" 
               class="click-effect w-9 h-9 rounded-xl bg-slate-100 hover:bg-blue-50 text-slate-500 hover:text-blue-600 dark:bg-[#0f172a] dark:hover:bg-blue-500/20 dark:text-slate-400 dark:hover:text-blue-400 border border-transparent dark:border-slate-800 dark:hover:border-blue-500/30 flex items-center justify-center transition-colors focus:outline-none" title="Cộng Đồng Telegram">
                <i class="ri-telegram-fill text-[18px]"></i>
            </a>
            
            <a href="<?= htmlspecialchars($config['support_link'] ?? '#') ?>" target="_blank" 
               class="click-effect w-9 h-9 rounded-xl bg-slate-100 hover:bg-blue-50 text-slate-500 hover:text-blue-600 dark:bg-[#0f172a] dark:hover:bg-blue-500/20 dark:text-slate-400 dark:hover:text-blue-400 border border-transparent dark:border-slate-800 dark:hover:border-blue-500/30 flex items-center justify-center transition-colors focus:outline-none" title="Liên Hệ Hỗ Trợ">
                <i class="ri-customer-service-2-fill text-[18px]"></i>
            </a>
        </div>
        
    </div>
</footer>

<!-- Kịch bản kiểm tra phiên đăng nhập liên tục -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        setInterval(() => {
            fetch('/api-handler?action=check_session', { method: 'POST' })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'logout') {
                    if (typeof Swal !== 'undefined') {
                        Swal.fire({
                            icon: 'warning',
                            title: 'Phiên đăng nhập hết hạn!',
                            text: data.message || 'Vui lòng đăng nhập lại để tiếp tục sử dụng hệ thống.',
                            confirmButtonText: 'Đăng nhập lại',
                            confirmButtonColor: '#2563eb',
                            allowOutsideClick: false,
                            allowEscapeKey: false,
                            background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff',
                            color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a',
                            customClass: { popup: 'rounded-2xl border border-slate-200 dark:border-slate-800' }
                        }).then(() => {
                            window.location.href = '/logout';
                        });
                    } else {
                        alert(data.message || 'Phiên đăng nhập hết hạn. Vui lòng đăng nhập lại.');
                        window.location.href = '/logout';
                    }
                }
            }).catch(() => {
                // Bỏ qua lỗi kết nối chập chờn
            });
        }, 10000);
    });
</script>

<!-- Nạp Script chống DevTools & Sao chép -->
<script src="/public/js/devtools.js"></script>