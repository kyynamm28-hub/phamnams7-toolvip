<?php
// 1. Tự động lấy dữ liệu từ DB nếu $config chưa được khởi tạo ở file gốc
global $pdo;
if (empty($config) && isset($pdo)) {
    $config = [];
    try {
        $stmt = $pdo->query("SELECT `key`, `value` FROM settings");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $config[$row['key']] = $row['value'];
        }
    } catch (Exception $e) {
        // Bỏ qua nếu chưa có kết nối DB
    }
}

// 2. Sử dụng !empty() thay vì ?? để tránh lỗi DB có key nhưng rỗng
$site_title = !empty($config['site_title']) ? $config['site_title'] : 'ZENRO.SITE - Hệ sinh thái Công Cụ & MMO';
$site_desc = !empty($config['site_description']) ? $config['site_description'] : 'Zenro cung cấp các công cụ tiện ích, dịch vụ mạng xã hội, mua bán tài nguyên MMO uy tín.';
$site_keywords = !empty($config['site_keywords']) ? $config['site_keywords'] : 'zenro, mmo, tool mmo, dịch vụ mxh';
$site_favicon = !empty($config['favicon']) ? $config['favicon'] : 'https://img.upanh.moe/jYZWRgJ/Orange-Black-Minimal-Professional-Letter-B-Business-Logo-2-png.png';

// 3. Xử lý đường dẫn ảnh tuyệt đối cho thẻ meta og:image (MXH không đọc được link tương đối)
$site_logo = !empty($config['navbar_logo']) ? $config['navbar_logo'] : 'http://billviet.info/upload/uploads/33bd70fe37935b02.png';
if (strpos($site_logo, 'http') !== 0) {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
    $site_logo = $protocol . "://" . $_SERVER['HTTP_HOST'] . $site_logo;
}

// 4. Lấy current URL để khai báo OG URL chuẩn
$current_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

// Lấy Cấu hình Giao diện & Mã lệnh nâng cao từ Admin
$tailwind_config = !empty($config['tailwind_config']) ? $config['tailwind_config'] : "{ theme: { extend: { colors: { brand: { 50: '#ecf3ff', 100: '#dde9ff', 200: '#c3d9ff', 300: '#9fc4ff', 400: '#5fa5ff', 500: '#465fff', 600: '#3641f5', 700: '#2a31d8' } } } } }";

// CSS hiệu ứng gốc
$default_css = "
html { scroll-behavior: smooth; }
body { -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }
@keyframes fadeUp { 0% { opacity: 0; transform: translateY(24px); } 100% { opacity: 1; transform: translateY(0); } }
.fade-up { animation: fadeUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards; will-change: opacity, transform; }
.grid-bg {
    position: absolute; inset: 0; pointer-events: none;
    background-image: linear-gradient(rgba(70, 95, 255, 0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(70, 95, 255, 0.03) 1px, transparent 1px);
    background-size: 60px 60px;
    mask-image: radial-gradient(ellipse 80% 70% at 50% 30%, black 30%, transparent 100%);
    -webkit-mask-image: radial-gradient(ellipse 80% 70% at 50% 30%, black 30%, transparent 100%);
}
@keyframes float { 0%, 100% { transform: translateY(0px) rotate(0deg); } 50% { transform: translateY(-20px) rotate(5deg); } }
.floating-dot {
    position: absolute; width: 6px; height: 6px; border-radius: 50%; opacity: 0.6; pointer-events: none;
    background: linear-gradient(135deg, #465fff, #9fc4ff); animation: float 6s ease-in-out infinite;
}
.btn-glow { position: relative; overflow: hidden; }
.btn-glow::before {
    content: ''; position: absolute; inset: -2px; transform: translateX(-100%); transition: transform 0.6s;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
}
.btn-glow:hover::before { transform: translateX(100%); }
@media (prefers-reduced-motion: reduce) { *, *::before, *::after { animation-duration: 0.01ms !important; animation-iteration-count: 1 !important; transition-duration: 0.01ms !important; } }
";

$custom_css = !empty($config['custom_css']) ? $config['custom_css'] : $default_css;
$header_script = $config['header_script'] ?? "";
?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) . ' | ' . htmlspecialchars($site_title) : htmlspecialchars($site_title) ?></title>
    
    <link rel="icon" type="image/x-icon" href="<?= htmlspecialchars($site_favicon) ?>">
    <meta name="description" content="<?= htmlspecialchars($site_desc) ?>">
    <meta name="keywords" content="<?= htmlspecialchars($site_keywords) ?>">
    <meta name="robots" content="index, follow">

    <meta property="og:type" content="website">
    <meta property="og:url" content="<?= htmlspecialchars($current_url) ?>">
    <meta property="og:site_name" content="<?= htmlspecialchars($site_title) ?>">
    <meta property="og:title" content="<?= isset($pageTitle) ? htmlspecialchars($pageTitle) : htmlspecialchars($site_title) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($site_desc) ?>">
    <meta property="og:image" content="<?= htmlspecialchars($site_logo) ?>">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:url" content="<?= htmlspecialchars($current_url) ?>">
    <meta name="twitter:title" content="<?= isset($pageTitle) ? htmlspecialchars($pageTitle) : htmlspecialchars($site_title) ?>">
    <meta name="twitter:description" content="<?= htmlspecialchars($site_desc) ?>">
    <meta name="twitter:image" content="<?= htmlspecialchars($site_logo) ?>">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet">
    
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/collapse@3.x.x/dist/cdn.min.js"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <?= $header_script ?>

    <script>const _cw=console.warn;console.warn=function(){if(arguments[0]&&typeof arguments[0]==='string'&&arguments[0].includes('cdn.tailwindcss.com'))return;_cw.apply(console,arguments)};</script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = <?= $tailwind_config ?>;
        // Bổ sung Dark mode support vào Tailwind Config
        tailwind.config.darkMode = 'class';
    </script>
    
    <style>
        <?= $custom_css ?>
    </style>

    <script>
        if (localStorage.getItem('darkMode') === 'true' || (!('darkMode' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    </script>