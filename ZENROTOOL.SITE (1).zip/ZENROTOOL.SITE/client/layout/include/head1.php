<?php
// Gọi file load cấu hình nếu chưa có
if (!isset($config)) {
    require_once __DIR__ . '/../../../config/settings.php';
}

$title = isset($page_title) ? $page_title . ' - ' . ($config['site_title'] ?? 'ZENRO') : ($config['site_title'] ?? 'ZENRO');
$desc = $config['site_description'] ?? 'Mô tả trang web';
$keys = $config['site_keywords'] ?? 'mmo, tools';
$favicon = $config['favicon'] ?? '/favicon.ico';
?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title><?= htmlspecialchars($title) ?></title>
<meta name="description" content="<?= htmlspecialchars($desc) ?>">
<meta name="keywords" content="<?= htmlspecialchars($keys) ?>">

<meta property="og:type" content="website">
<meta property="og:title" content="<?= htmlspecialchars($title) ?>">
<meta property="og:description" content="<?= htmlspecialchars($desc) ?>">

<link rel="icon" href="<?= htmlspecialchars($favicon) ?>" type="image/x-icon">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

<style>
    body { font-family: 'Inter', sans-serif; }
    [x-cloak] { display: none !important; }
</style>

<script>
    tailwind.config = {
        darkMode: 'class',
        theme: {
            extend: {
                colors: {
                    brand: { 50: '#ecf3ff', 100: '#dde9ff', 200: '#c2d6ff', 300: '#9cb9ff', 400: '#7592ff', 500: '#465fff', 600: '#2e3ef5', 700: '#232fe1', 800: '#1c29b6', 900: '#1d298f' }
                }
            }
        }
    }
</script>
