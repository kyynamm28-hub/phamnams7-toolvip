<?php
// Ảnh đại diện của User
$user_avatar = $user_data['avatar'] ?? '/client/layout/assets/images/user.png';
$balance = $user_data['balance'] ?? 0;
$username = $_SESSION['username'] ?? 'User';
$role = isset($user_data['role']) && strtolower($user_data['role']) === 'admin' ? 'Quản Trị Viên' : 'Thành Viên';
?>

<header class="sticky top-0 z-[50] w-full bg-white dark:bg-[#0f172a] border-b border-slate-200 dark:border-slate-800 transition-colors duration-200">
    <div class="flex items-center justify-between h-[64px] px-4 sm:px-6">
        
        <!-- ================= TRÁI: GREETING & MENU TOGGLE ================= -->
        <div class="flex items-center gap-3">
            <!-- Nút mở Sidebar (Chỉ hiện Mobile) -->
            <button @click="sidebarOpen = true" class="sm:hidden p-2 -ml-2 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors focus:outline-none">
                <i class="ri-menu-2-line text-[22px]"></i>
            </button>
            
            <!-- Lời chào (Chỉ hiện Desktop) -->
            <div class="hidden sm:block">
                <h2 class="text-[14px] font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                    Xin chào, <?= htmlspecialchars($username) ?> 
                    <span class="inline-block hover:animate-waving-hand origin-bottom-right">👋</span>
                </h2>
                <p class="text-[11px] font-medium text-slate-500 dark:text-slate-400 mt-0.5">Chào mừng bạn quay trở lại!</p>
            </div>
        </div>

        <!-- ================= PHẢI: BALANCE, DARK MODE & USER MENU ================= -->
        <div class="flex items-center justify-end gap-3 sm:gap-4">
            
            <!-- Hiển thị nhanh Số dư (Chỉ hiện trên Desktop) -->
            <div class="hidden lg:flex items-center gap-2 px-3 py-1.5 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700">
                <i class="ri-wallet-3-line text-slate-400 text-[16px]"></i>
                <span class="text-[13px] font-bold text-slate-700 dark:text-slate-200"><?= number_format($balance) ?> <span class="text-blue-600 dark:text-blue-400 font-semibold">đ</span></span>
            </div>

            <!-- Nút Dark Mode -->
            <button @click="darkMode = !darkMode; localStorage.setItem('darkMode', darkMode); document.documentElement.classList.toggle('dark', darkMode);" 
                    class="relative flex items-center justify-center w-[36px] h-[36px] rounded-lg text-slate-500 dark:text-slate-400 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700 transition-colors focus:outline-none overflow-hidden">
                <i class="ri-sun-line text-[18px] absolute transition-all duration-300 ease-out transform" 
                   :class="darkMode ? 'opacity-0 rotate-90 scale-50' : 'opacity-100 rotate-0 scale-100'"></i>
                <i class="ri-moon-clear-line text-[18px] absolute transition-all duration-300 ease-out transform" 
                   :class="darkMode ? 'opacity-100 rotate-0 scale-100' : 'opacity-0 -rotate-90 scale-50'"></i>
            </button>

            <!-- Menu User Dropdown -->
            <div x-data="{ userOpen: false }" class="relative z-50">
                
                <!-- Nút Trigger (Avatar) -->
                <button @click="userOpen = !userOpen" @click.outside="userOpen = false" 
                        class="flex items-center justify-center rounded-lg border border-slate-200 dark:border-slate-700 hover:border-blue-400 dark:hover:border-blue-500 transition-colors focus:outline-none p-0.5">
                    <img src="<?= htmlspecialchars($user_avatar) ?>" alt="Avatar" class="w-8 h-8 rounded-md object-cover">
                </button>

                <!-- Box Dropdown hoàn toàn mới (Profile Card Layout) -->
                <div x-show="userOpen" x-cloak 
                     x-transition:enter="transition-all ease-out duration-200" 
                     x-transition:enter-start="opacity-0 translate-y-3 scale-[0.97]" 
                     x-transition:enter-end="opacity-100 translate-y-0 scale-100" 
                     x-transition:leave="transition-all ease-in duration-150" 
                     x-transition:leave-start="opacity-100 translate-y-0 scale-100" 
                     x-transition:leave-end="opacity-0 translate-y-2 scale-[0.97]" 
                     class="absolute right-0 mt-3 w-[260px] bg-white dark:bg-[#0f172a] border border-slate-200 dark:border-slate-700 rounded-xl shadow-sm py-1 origin-top-right">
                    
                    <!-- Phần Header Profile -->
                    <div class="px-4 py-3 flex items-center gap-3 border-b border-slate-100 dark:border-slate-800">
                        <img src="<?= htmlspecialchars($user_avatar) ?>" alt="Avatar" class="w-10 h-10 rounded-lg object-cover border border-slate-200 dark:border-slate-700">
                        <div class="flex-1 min-w-0">
                            <p class="text-[14px] font-bold text-slate-800 dark:text-slate-100 truncate"><?= htmlspecialchars($username) ?></p>
                            <div class="inline-flex items-center gap-1 mt-0.5 px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[9px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                                <?= $role ?>
                            </div>
                        </div>
                    </div>

                    <!-- Phần Grid Thống Kê (Số dư & Trạng thái) -->
                    <div class="p-3 grid grid-cols-2 gap-2 border-b border-slate-100 dark:border-slate-800">
                        <div class="bg-blue-50 dark:bg-blue-500/10 rounded-lg p-2.5">
                            <p class="text-[9px] font-bold text-blue-400 dark:text-blue-500/80 uppercase tracking-widest mb-1">Số Dư</p>
                            <p class="text-[13px] font-bold text-blue-600 dark:text-blue-400 truncate"><?= number_format($balance) ?>đ</p>
                        </div>
                        <div class="bg-amber-50 dark:bg-amber-500/10 rounded-lg p-2.5">
                            <p class="text-[9px] font-bold text-amber-400 dark:text-amber-500/80 uppercase tracking-widest mb-1">Gói Cước</p>
                            <p class="text-[13px] font-bold text-amber-600 dark:text-amber-500 truncate">Miễn Phí</p>
                        </div>
                    </div>

                    <!-- Phần Nút Chức Năng (Flat List) -->
                    <div class="p-2 space-y-0.5">
                        <a href="/profile" class="flex items-center gap-3 px-3 py-2 rounded-lg text-[13px] font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                            <i class="ri-user-settings-line text-[16px] text-slate-400"></i>
                            Quản lý tài khoản
                        </a>
                        <a href="/history/recharge" class="flex items-center gap-3 px-3 py-2 rounded-lg text-[13px] font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                            <i class="ri-history-line text-[16px] text-slate-400"></i>
                            Lịch sử giao dịch
                        </a>
                    </div>

                    <div class="h-px bg-slate-100 dark:bg-slate-800 my-1 mx-3"></div>

                    <!-- Nút Đăng Xuất -->
                    <div class="p-2">
                        <a href="/logout" class="flex items-center gap-3 px-3 py-2 rounded-lg text-[13px] font-medium text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 hover:text-rose-600 transition-colors">
                            <i class="ri-logout-circle-r-line text-[16px]"></i>
                            Đăng xuất
                        </a>
                    </div>

                </div>
            </div>

        </div>
    </div>
</header>

<style>
    /* Ẩn AlpineJS khi chưa load */
    [x-cloak] { display: none !important; }

    /* Hiệu ứng vẫy tay nhẹ nhàng (Chỉ kích hoạt khi hover vào icon) */
    @keyframes waving-hand {
        0% { transform: rotate(0.0deg) }
        10% { transform: rotate(14.0deg) }
        20% { transform: rotate(-8.0deg) }
        30% { transform: rotate(14.0deg) }
        40% { transform: rotate(-4.0deg) }
        50% { transform: rotate(10.0deg) }
        60% { transform: rotate(0.0deg) }
        100% { transform: rotate(0.0deg) }
    }
    .hover\:animate-waving-hand:hover {
        animation: waving-hand 2s infinite;
    }
</style>
