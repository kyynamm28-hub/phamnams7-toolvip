<?php
$community_link = $config['community_link'] ?? 'https://t.me/zenrosite_group';
$support_link = $config['support_link'] ?? 'https://t.me/zenrosite_support';
$navbar_logo = $config['navbar_logo'] ?? '/client/layout/assets/images/game.png';

// Kiểm tra quyền admin
$isShowAdmin = false;
if (isset($is_admin) && $is_admin === true) {
    $isShowAdmin = true;
} elseif (isset($user_data['role']) && strtolower($user_data['role']) === 'admin') {
    $isShowAdmin = true;
} elseif (isset($user['role']) && strtolower($user['role']) === 'admin') {
    $isShowAdmin = true;
}

// Hàm hỗ trợ active menu
$current_uri = $_SERVER['REQUEST_URI'];
function isActive($path, $uri) {
    if ($path === '/home' && ($uri === '/home' || $uri === '/')) return true;
    if ($path !== '/home' && strpos($uri, $path) === 0) return true;
    return false;
}
?>

<!-- Mobile Overlay (Sidebar) -->
<div x-show="sidebarOpen" x-cloak @click="sidebarOpen = false" 
     x-transition.opacity.duration.300ms
     class="fixed inset-0 z-[60] bg-slate-900/60 dark:bg-slate-900/80 sm:hidden touch-none pointer-events-auto">
</div>

<!-- Sidebar Layout (Flat & Clean) -->
<aside id="flat-sidebar" 
       :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'" 
       class="fixed top-0 bottom-0 left-0 z-[70] w-[260px] flex flex-col bg-white dark:bg-[#0f172a] border-r border-slate-200 dark:border-slate-800 transition-transform duration-300 ease-out sm:translate-x-0 pb-20 sm:pb-0 overflow-hidden">
    
    <!-- Logo Header -->
    <header class="h-[64px] px-5 flex items-center justify-between sm:justify-center border-b border-slate-100 dark:border-slate-800/80 shrink-0">
        <a href="/home" aria-label="Trang chủ" class="click-effect flex items-center justify-center w-full focus:outline-none">
            <img src="<?= htmlspecialchars($navbar_logo) ?>" alt="Logo" class="h-8 object-contain" />
        </a>
        <button @click="sidebarOpen = false" class="click-effect sm:hidden w-8 h-8 flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-white bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700 rounded-lg transition-colors focus:outline-none">
            <i class="ri-close-line text-xl"></i>
        </button>
    </header>

    <!-- Navigation Area -->
    <nav class="flex-1 overflow-y-auto px-3 py-4 custom-scrollbar space-y-6">
        
        <!-- Nhóm: Tổng Quan -->
        <div>
            <div class="px-3 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">Tổng Quan</div>
            <ul class="space-y-1">
                <li>
                    <a href="/home" class="click-effect flex items-center gap-3 px-3 py-2.5 rounded-xl text-[13px] transition-colors focus:outline-none <?= isActive('/home', $current_uri) ? 'bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold' : 'font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-slate-200' ?>">
                        <i class="<?= isActive('/home', $current_uri) ? 'ri-layout-grid-fill' : 'ri-layout-grid-line' ?> text-[18px]"></i>
                        <span>Bảng Điều Khiển</span>
                    </a>
                </li>
                <li>
                    <a href="/profile" class="click-effect flex items-center gap-3 px-3 py-2.5 rounded-xl text-[13px] transition-colors focus:outline-none <?= isActive('/profile', $current_uri) ? 'bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold' : 'font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-slate-200' ?>">
                        <i class="<?= isActive('/profile', $current_uri) ? 'ri-user-4-fill' : 'ri-user-4-line' ?> text-[18px]"></i>
                        <span>Hồ Sơ Cá Nhân</span>
                    </a>
                </li>
                <?php if ($isShowAdmin): ?>
                <li class="pt-1">
                    <a href="/admin/" class="click-effect flex items-center gap-3 px-3 py-2.5 rounded-xl bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-500/20 transition-colors focus:outline-none">
                        <i class="ri-shield-keyhole-fill text-[18px]"></i>
                        <span class="font-bold text-[13px]">Quản Trị Hệ Thống</span>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </div>

        <!-- Nhóm: Tài Chính -->
        <div>
            <div class="px-3 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">Tài Chính</div>
            <ul class="space-y-1">
                <li x-data="{ open: <?= (strpos($current_uri, '/bank') === 0) ? 'true' : 'false' ?> }">
                    <button @click="open = !open" class="click-effect flex items-center justify-between w-full px-3 py-2.5 rounded-xl text-[13px] transition-colors focus:outline-none <?= (strpos($current_uri, '/bank') === 0) ? 'text-blue-600 dark:text-blue-400 font-bold' : 'font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-slate-200' ?>">
                        <div class="flex items-center gap-3">
                            <i class="<?= (strpos($current_uri, '/bank') === 0) ? 'ri-safe-2-fill' : 'ri-safe-2-line' ?> text-[18px]"></i>
                            <span>Nạp Tiền</span>
                        </div>
                        <i class="ri-arrow-down-s-line text-lg text-slate-400 transition-transform duration-200" :class="open ? '-rotate-180' : ''"></i>
                    </button>
                    <ul x-show="open" x-collapse.duration.200ms class="ml-[22px] pl-3 border-l border-slate-200 dark:border-slate-700 space-y-1 mt-1">
                        <li><a href="/bank/recharge" class="click-effect flex items-center px-3 py-2 rounded-lg text-[12px] transition-colors focus:outline-none <?= isActive('/bank/recharge', $current_uri) ? 'text-blue-600 dark:text-blue-400 font-bold bg-blue-50/50 dark:bg-blue-500/5' : 'text-slate-500 dark:text-slate-400 font-medium hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/50' ?>">Chuyển Khoản / QR</a></li>
                        <li><a href="/bank/card" class="click-effect flex items-center px-3 py-2 rounded-lg text-[12px] transition-colors focus:outline-none <?= isActive('/bank/card', $current_uri) ? 'text-blue-600 dark:text-blue-400 font-bold bg-blue-50/50 dark:bg-blue-500/5' : 'text-slate-500 dark:text-slate-400 font-medium hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/50' ?>">Đổi Thẻ Cào</a></li>
                    </ul>
                </li>

                <li x-data="{ open: <?= (strpos($current_uri, '/history') === 0) ? 'true' : 'false' ?> }">
                    <button @click="open = !open" class="click-effect flex items-center justify-between w-full px-3 py-2.5 rounded-xl text-[13px] transition-colors focus:outline-none <?= (strpos($current_uri, '/history') === 0) ? 'text-blue-600 dark:text-blue-400 font-bold' : 'font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-slate-200' ?>">
                        <div class="flex items-center gap-3">
                            <i class="<?= (strpos($current_uri, '/history') === 0) ? 'ri-receipt-fill' : 'ri-receipt-line' ?> text-[18px]"></i>
                            <span>Lịch Sử</span>
                        </div>
                        <i class="ri-arrow-down-s-line text-lg text-slate-400 transition-transform duration-200" :class="open ? '-rotate-180' : ''"></i>
                    </button>
                    <ul x-show="open" x-collapse.duration.200ms class="ml-[22px] pl-3 border-l border-slate-200 dark:border-slate-700 space-y-1 mt-1">
                        <li><a href="/history/recharge" class="click-effect flex items-center px-3 py-2 rounded-lg text-[12px] transition-colors focus:outline-none <?= isActive('/history/recharge', $current_uri) ? 'text-blue-600 dark:text-blue-400 font-bold bg-blue-50/50 dark:bg-blue-500/5' : 'text-slate-500 dark:text-slate-400 font-medium hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/50' ?>">Giao Dịch Nạp</a></li>
                        <li><a href="/history/product" class="click-effect flex items-center px-3 py-2 rounded-lg text-[12px] transition-colors focus:outline-none <?= isActive('/history/product', $current_uri) ? 'text-blue-600 dark:text-blue-400 font-bold bg-blue-50/50 dark:bg-blue-500/5' : 'text-slate-500 dark:text-slate-400 font-medium hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/50' ?>">Lịch Sử Mua Hàng</a></li>
                        <li><a href="/history/work" class="click-effect flex items-center px-3 py-2 rounded-lg text-[12px] transition-colors focus:outline-none <?= isActive('/history/work', $current_uri) ? 'text-blue-600 dark:text-blue-400 font-bold bg-blue-50/50 dark:bg-blue-500/5' : 'text-slate-500 dark:text-slate-400 font-medium hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/50' ?>">Nhật Ký Hoạt Động</a></li>
                    </ul>
                </li>
            </ul>
        </div>

        <!-- Nhóm: Dịch vụ -->
        <div>
            <div class="px-3 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">Dịch Vụ</div>
            <ul class="space-y-1">
                <li>
                    <a href="/thue-vip" class="click-effect flex items-center gap-3 px-3 py-2.5 rounded-xl text-[13px] transition-colors focus:outline-none <?= isActive('/thue-vip', $current_uri) ? 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-500 font-bold' : 'font-medium text-slate-600 dark:text-slate-400 hover:bg-amber-50 dark:hover:bg-amber-500/10 hover:text-amber-600 dark:hover:text-amber-500' ?>">
                        <i class="<?= isActive('/thue-vip', $current_uri) ? 'ri-vip-diamond-fill' : 'ri-vip-diamond-line' ?> text-[18px]"></i>
                        <span>Mua Gói VIP</span>
                    </a>
                </li>
                <li>
                    <a href="/tools" class="click-effect flex items-center gap-3 px-3 py-2.5 rounded-xl text-[13px] transition-colors focus:outline-none <?= isActive('/tools', $current_uri) ? 'bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold' : 'font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-slate-200' ?>">
                        <i class="<?= isActive('/tools', $current_uri) ? 'ri-apps-2-fill' : 'ri-apps-2-line' ?> text-[18px]"></i>
                        <span>Kho Công Cụ Tools</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- Nhóm: Hỗ trợ -->
        <div class="pb-4">
            <div class="px-3 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">Hỗ Trợ & Khác</div>
            <ul class="space-y-1">
                <li>
                    <a href="<?= htmlspecialchars($community_link) ?>" target="_blank" class="click-effect flex items-center justify-between px-3 py-2.5 rounded-xl text-[13px] font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-blue-600 dark:hover:text-blue-400 transition-colors focus:outline-none">
                        <div class="flex items-center gap-3">
                            <i class="ri-discuss-line text-[18px] text-slate-400"></i>
                            <span>Box Cộng Đồng</span>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="<?= htmlspecialchars($support_link) ?>" target="_blank" class="click-effect flex items-center justify-between px-3 py-2.5 rounded-xl text-[13px] font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-blue-600 dark:hover:text-blue-400 transition-colors focus:outline-none">
                        <div class="flex items-center gap-3">
                            <i class="ri-customer-service-2-line text-[18px] text-slate-400"></i>
                            <span>Liên Hệ Hỗ Trợ</span>
                        </div>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- Footer Sidebar -->
    <footer class="h-14 flex items-center justify-between px-6 border-t border-slate-100 dark:border-slate-800/80 hidden sm:flex bg-white dark:bg-[#0f172a] shrink-0">
        <div class="text-[12px] font-medium text-slate-500">© <?= date('Y') ?> <span class="text-blue-600 dark:text-blue-400 font-bold">System</span></div>
        <div class="text-[10px] font-bold text-slate-400">V1.0.6</div>
    </footer>
</aside>

<!-- Khu Vực Bottom Nav & Mobile Popup -->
<div x-data="{ showMobileRechargeModal: false }" class="sm:hidden">

    <!-- MODAL NẠP TIỀN MOBILE (Slide up) -->
    <div x-show="showMobileRechargeModal" x-cloak class="fixed inset-0 z-[100] flex items-end justify-center p-4 pb-24">
        <!-- Overlay -->
        <div x-show="showMobileRechargeModal" x-transition.opacity.duration.300ms @click="showMobileRechargeModal = false" class="absolute inset-0 bg-slate-900/60 dark:bg-slate-900/80"></div>
        
        <!-- Bảng chọn (Modal) trượt từ dưới lên -->
        <div x-show="showMobileRechargeModal" 
             x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-full" x-transition:enter-end="opacity-100 translate-y-0" 
             x-transition:leave="transition ease-in duration-200" x-transition:leave-start="opacity-100 translate-y-0" x-transition:leave-end="opacity-0 translate-y-full" 
             class="relative bg-white dark:bg-[#0f172a] border border-slate-200 dark:border-slate-800 rounded-3xl p-6 w-full max-w-sm flex flex-col">
            
            <div class="flex items-center justify-between mb-5">
                <div>
                    <h3 class="text-[16px] font-bold text-slate-800 dark:text-white">Nạp Tiền</h3>
                    <p class="text-[12px] text-slate-500 mt-0.5">Chọn phương thức giao dịch</p>
                </div>
                <button @click="showMobileRechargeModal = false" class="click-effect w-8 h-8 flex items-center justify-center rounded-xl bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-slate-700 dark:hover:text-white transition-colors focus:outline-none">
                    <i class="ri-close-line text-xl"></i>
                </button>
            </div>

            <div class="grid grid-cols-1 gap-3">
                <!-- Nạp Ngân Hàng / QR -->
                <a href="/bank/recharge" class="click-effect group flex items-center p-4 rounded-2xl border border-slate-200 dark:border-slate-700 hover:border-blue-500 dark:hover:border-blue-500/50 bg-slate-50 dark:bg-slate-800/30 hover:bg-blue-50 dark:hover:bg-blue-500/10 transition-colors focus:outline-none">
                    <div class="w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center justify-center mr-4 group-hover:scale-105 transition-transform">
                        <i class="ri-qr-code-line text-[22px]"></i>
                    </div>
                    <div class="flex-1">
                        <h4 class="text-[14px] font-bold text-slate-800 dark:text-slate-200">Chuyển Khoản / QR</h4>
                        <p class="text-[11px] font-medium text-slate-500 dark:text-slate-400 mt-0.5">Tự động cộng (Miễn phí)</p>
                    </div>
                    <i class="ri-arrow-right-s-line text-xl text-slate-300 dark:text-slate-600 group-hover:text-blue-500 transition-colors"></i>
                </a>

                <!-- Đổi Thẻ Cào -->
                <a href="/bank/card" class="click-effect group flex items-center p-4 rounded-2xl border border-slate-200 dark:border-slate-700 hover:border-emerald-500 dark:hover:border-emerald-500/50 bg-slate-50 dark:bg-slate-800/30 hover:bg-emerald-50 dark:hover:bg-emerald-500/10 transition-colors focus:outline-none">
                    <div class="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mr-4 group-hover:scale-105 transition-transform">
                        <i class="ri-bank-card-line text-[22px]"></i>
                    </div>
                    <div class="flex-1">
                        <h4 class="text-[14px] font-bold text-slate-800 dark:text-slate-200">Đổi Thẻ Cào</h4>
                        <p class="text-[11px] font-medium text-slate-500 dark:text-slate-400 mt-0.5">Gạch thẻ nhanh (Có phí)</p>
                    </div>
                    <i class="ri-arrow-right-s-line text-xl text-slate-300 dark:text-slate-600 group-hover:text-emerald-500 transition-colors"></i>
                </a>
            </div>
        </div>
    </div>

    <!-- BOTTOM NAVIGATION (Mobile - Flat Design) -->
    <nav class="fixed bottom-0 left-0 w-full z-[90] bg-white dark:bg-[#0f172a] border-t border-slate-200 dark:border-slate-800 pb-safe">
        <div class="flex items-center justify-between h-[56px] px-1">
            
            <a href="/home" class="click-effect flex flex-col items-center justify-center w-1/5 h-full gap-1 outline-none transition-colors duration-200 <?= isActive('/home', $current_uri) ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300' ?>">
                <i class="<?= isActive('/home', $current_uri) ? 'ri-layout-grid-fill' : 'ri-layout-grid-line' ?> text-[22px]"></i>
                <span class="text-[9px] font-bold">Trang Chủ</span>
            </a>

            <a href="/tools" class="click-effect flex flex-col items-center justify-center w-1/5 h-full gap-1 outline-none transition-colors duration-200 <?= isActive('/tools', $current_uri) ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300' ?>">
                <i class="<?= isActive('/tools', $current_uri) ? 'ri-apps-2-fill' : 'ri-apps-2-line' ?> text-[22px]"></i>
                <span class="text-[9px] font-bold">Công Cụ</span>
            </a>

            <!-- Nút Mở Modal Nạp Tiền -->
            <button @click="showMobileRechargeModal = true" class="click-effect flex flex-col items-center justify-center w-1/5 h-full gap-1 outline-none transition-colors duration-200 <?= (strpos($current_uri, '/bank') === 0) ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300' ?>">
                <i class="<?= (strpos($current_uri, '/bank') === 0) ? 'ri-safe-2-fill' : 'ri-safe-2-line' ?> text-[22px]"></i>
                <span class="text-[9px] font-bold">Nạp Tiền</span>
            </button>

            <a href="/thue-vip" class="click-effect flex flex-col items-center justify-center w-1/5 h-full gap-1 outline-none transition-colors duration-200 <?= isActive('/thue-vip', $current_uri) ? 'text-amber-500 dark:text-amber-500' : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300' ?>">
                <i class="<?= isActive('/thue-vip', $current_uri) ? 'ri-vip-diamond-fill' : 'ri-vip-diamond-line' ?> text-[22px]"></i>
                <span class="text-[9px] font-bold">Gói VIP</span>
            </a>

            <a href="/profile" class="click-effect flex flex-col items-center justify-center w-1/5 h-full gap-1 outline-none transition-colors duration-200 <?= isActive('/profile', $current_uri) ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300' ?>">
                <i class="<?= isActive('/profile', $current_uri) ? 'ri-user-4-fill' : 'ri-user-4-line' ?> text-[22px]"></i>
                <span class="text-[9px] font-bold">Cá Nhân</span>
            </a>

        </div>
    </nav>
</div>

<style>
    /* Hiệu ứng nhún mượt mà khi Click */
    .click-effect { transition: transform 0.15s cubic-bezier(0.4, 0, 0.2, 1); }
    .click-effect:active { transform: scale(0.95); }

    /* Ẩn AlpineJS khi chưa render xong */
    [x-cloak] { display: none !important; }

    /* Thanh cuộn Minimal */
    .custom-scrollbar::-webkit-scrollbar { width: 4px; }
    .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
    .custom-scrollbar::-webkit-scrollbar-thumb { background-color: transparent; border-radius: 4px; transition: background-color 0.2s; }
    .custom-scrollbar:hover::-webkit-scrollbar-thumb { background-color: #cbd5e1; }
    .dark .custom-scrollbar:hover::-webkit-scrollbar-thumb { background-color: #475569; }

    /* Hỗ trợ SafeArea cho iPhone tai thỏ */
    @supports (padding-bottom: env(safe-area-inset-bottom)) {
        .pb-safe { padding-bottom: env(safe-area-inset-bottom); }
    }
    
    /* Đẩy phần body lên tương ứng với kích thước 56px của Bottom Nav */
    @media (max-width: 639px) {
        body { padding-bottom: calc(56px + env(safe-area-inset-bottom)); }
    }
</style>