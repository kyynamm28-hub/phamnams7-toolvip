<?php
$community_link = $config['community_link'] ?? 'https://t.me/zenrosite_group';
$support_link = $config['support_link'] ?? 'https://t.me/zenrosite_support';
$navbar_logo = $config['navbar_logo'] ?? '/client/layout/assets/images/game.png';

// Kiểm tra quyền admin
$isShowAdmin = false;
if (isset($is_admin) && $is_admin === true) {
    $isShowAdmin = true;
} elseif (isset($user_data['role']) && strtolower($user_data['role']) === 'admin') {
    $isShowAdmin = true;
} elseif (isset($user['role']) && strtolower($user['role']) === 'admin') {
    $isShowAdmin = true;
}

// Hàm hỗ trợ active menu cực chuẩn (để sau này bạn có thể tái sử dụng dễ dàng)
$current_uri = $_SERVER['REQUEST_URI'];
function isActive($path, $uri) {
    if ($path === '/home' && ($uri === '/home' || $uri === '/')) return true;
    if ($path !== '/home' && strpos($uri, $path) === 0) return true;
    return false;
}
?>

<div x-show="sidebarOpen" x-cloak @click="sidebarOpen = false" x-transition.opacity class="fixed inset-0 z-40 bg-neutral-900/60 backdrop-blur-sm lg:hidden"></div>

<aside :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'" class="fixed inset-y-0 left-0 z-50 w-[260px] bg-neutral-50 dark:bg-[#0b1120] border-r border-neutral-200/80 dark:border-gray-800 transition-transform duration-300 ease-out lg:translate-x-0 flex flex-col shadow-[4px_0_24px_rgba(0,0,0,0.02)]">
    
    <div class="flex items-center justify-between lg:justify-center h-[76px] px-6 shrink-0 border-b border-neutral-200/80 dark:border-gray-800 bg-white dark:bg-[#0f172a] shadow-sm relative z-10">
        <a href="/home" class="flex items-center justify-center w-full group focus:outline-none">
            <img src="<?= htmlspecialchars($navbar_logo) ?>" alt="ZENRO" class="h-10 sm:h-12 w-auto object-contain transition-transform duration-300 group-hover:scale-105">
        </a>
        <button @click="sidebarOpen = false" class="lg:hidden w-8 h-8 rounded-full bg-neutral-100 dark:bg-gray-800 flex items-center justify-center text-neutral-500 hover:text-neutral-900 dark:text-gray-400 dark:hover:text-white transition-colors focus:outline-none">
            <i class="ri-close-line text-xl"></i>
        </button>
    </div>

    <div class="flex-1 overflow-y-auto py-5 px-4 space-y-1.5 custom-scrollbar bg-neutral-50 dark:bg-[#0b1120]">
        
        <p class="text-[10px] font-black text-neutral-400 dark:text-gray-500 uppercase tracking-widest px-3 mb-3 mt-2">Tổng Quan</p>
        
        <a href="/home" class="<?= isActive('/home', $current_uri) ? 'bg-white dark:bg-[#1e293b] text-blue-600 dark:text-blue-400 shadow-sm border border-neutral-200 dark:border-gray-700/50' : 'text-neutral-600 dark:text-gray-400 hover:bg-white dark:hover:bg-[#1e293b] hover:text-blue-600 dark:hover:text-blue-400 border border-transparent' ?> flex items-center gap-3 px-3.5 py-2.5 rounded-[14px] font-bold text-[13px] transition-all focus:outline-none group">
            <i class="ri-dashboard-line text-[18px] opacity-80 group-hover:opacity-100 transition-opacity"></i> Bảng Điều Khiển
        </a>

        <a href="/profile" class="<?= isActive('/profile', $current_uri) ? 'bg-white dark:bg-[#1e293b] text-blue-600 dark:text-blue-400 shadow-sm border border-neutral-200 dark:border-gray-700/50' : 'text-neutral-600 dark:text-gray-400 hover:bg-white dark:hover:bg-[#1e293b] hover:text-blue-600 dark:hover:text-blue-400 border border-transparent' ?> flex items-center gap-3 px-3.5 py-2.5 rounded-[14px] font-bold text-[13px] transition-all focus:outline-none group">
            <i class="ri-user-settings-line text-[18px] opacity-80 group-hover:opacity-100 transition-opacity"></i> Hồ Sơ Cá Nhân
        </a>

        <?php if ($isShowAdmin): ?>
        <a href="/admin/" class="flex items-center gap-3 px-3.5 py-2.5 mt-2 rounded-[14px] text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-500/10 font-bold text-[13px] transition-all border border-rose-200/60 dark:border-rose-500/20 hover:shadow-md hover:shadow-rose-500/10 focus:outline-none">
            <i class="ri-shield-keyhole-line text-[18px]"></i> Quản Trị Hệ Thống
        </a>
        <?php endif; ?>

        <div class="pt-4 pb-1">
            <div class="h-px w-full bg-neutral-200/60 dark:bg-gray-800"></div>
        </div>
        <p class="text-[10px] font-black text-neutral-400 dark:text-gray-500 uppercase tracking-widest px-3 mb-3">Tài Chính</p>
        
        <div x-data="{ openRecharge: <?= (strpos($current_uri, '/bank') === 0) ? 'true' : 'false' ?> }" class="relative">
            <button @click="openRecharge = !openRecharge" class="<?= (strpos($current_uri, '/bank') === 0) ? 'text-blue-600 dark:text-blue-400' : 'text-neutral-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-white dark:hover:bg-[#1e293b]' ?> w-full flex items-center justify-between px-3.5 py-2.5 rounded-[14px] font-bold text-[13px] transition-all focus:outline-none group">
                <div class="flex items-center gap-3">
                    <i class="ri-wallet-3-line text-[18px] opacity-80 group-hover:opacity-100 transition-opacity"></i> Nạp Tiền
                </div>
                <i class="ri-arrow-down-s-line transition-transform duration-300" :class="openRecharge ? 'rotate-180' : ''"></i>
            </button>
            <div x-show="openRecharge" x-collapse.duration.300ms class="pl-12 pr-3 mt-1 space-y-1 relative before:absolute before:left-[22px] before:top-1 before:bottom-3 before:w-[2px] before:bg-neutral-200 dark:before:bg-gray-800 before:rounded-full">
                <a href="/bank/recharge" class="<?= isActive('/bank/recharge', $current_uri) ? 'text-blue-600 dark:text-blue-400 font-bold' : 'text-neutral-500 dark:text-gray-400 font-medium hover:text-blue-600 dark:hover:text-blue-400' ?> block px-3 py-2 text-[12px] rounded-lg hover:bg-white dark:hover:bg-[#1e293b] transition-colors focus:outline-none">Chuyển Khoản / QR</a>
                <a href="/bank/card" class="<?= isActive('/bank/card', $current_uri) ? 'text-blue-600 dark:text-blue-400 font-bold' : 'text-neutral-500 dark:text-gray-400 font-medium hover:text-blue-600 dark:hover:text-blue-400' ?> block px-3 py-2 text-[12px] rounded-lg hover:bg-white dark:hover:bg-[#1e293b] transition-colors focus:outline-none">Đổi Thẻ Cào</a>
            </div>
        </div>

        <div x-data="{ openHistory: <?= (strpos($current_uri, '/history') === 0) ? 'true' : 'false' ?> }" class="relative">
            <button @click="openHistory = !openHistory" class="<?= (strpos($current_uri, '/history') === 0) ? 'text-blue-600 dark:text-blue-400' : 'text-neutral-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-white dark:hover:bg-[#1e293b]' ?> w-full flex items-center justify-between px-3.5 py-2.5 rounded-[14px] font-bold text-[13px] transition-all focus:outline-none group">
                <div class="flex items-center gap-3">
                    <i class="ri-history-line text-[18px] opacity-80 group-hover:opacity-100 transition-opacity"></i> Lịch Sử
                </div>
                <i class="ri-arrow-down-s-line transition-transform duration-300" :class="openHistory ? 'rotate-180' : ''"></i>
            </button>
            <div x-show="openHistory" x-collapse.duration.300ms class="pl-12 pr-3 mt-1 space-y-1 relative before:absolute before:left-[22px] before:top-1 before:bottom-3 before:w-[2px] before:bg-neutral-200 dark:before:bg-gray-800 before:rounded-full">
                <a href="/history/recharge" class="<?= isActive('/history/recharge', $current_uri) ? 'text-blue-600 dark:text-blue-400 font-bold' : 'text-neutral-500 dark:text-gray-400 font-medium hover:text-blue-600 dark:hover:text-blue-400' ?> block px-3 py-2 text-[12px] rounded-lg hover:bg-white dark:hover:bg-[#1e293b] transition-colors focus:outline-none">Giao Dịch Nạp</a>
                <a href="/history/product" class="<?= isActive('/history/product', $current_uri) ? 'text-blue-600 dark:text-blue-400 font-bold' : 'text-neutral-500 dark:text-gray-400 font-medium hover:text-blue-600 dark:hover:text-blue-400' ?> block px-3 py-2 text-[12px] rounded-lg hover:bg-white dark:hover:bg-[#1e293b] transition-colors focus:outline-none">Lịch Sử Mua Hàng</a>
                <a href="/history/work" class="<?= isActive('/history/work', $current_uri) ? 'text-blue-600 dark:text-blue-400 font-bold' : 'text-neutral-500 dark:text-gray-400 font-medium hover:text-blue-600 dark:hover:text-blue-400' ?> block px-3 py-2 text-[12px] rounded-lg hover:bg-white dark:hover:bg-[#1e293b] transition-colors focus:outline-none">Nhật Ký Hoạt Động</a>
            </div>
        </div>

        <div class="pt-4 pb-1">
            <div class="h-px w-full bg-neutral-200/60 dark:bg-gray-800"></div>
        </div>
        <p class="text-[10px] font-black text-neutral-400 dark:text-gray-500 uppercase tracking-widest px-3 mb-3">Dịch Vụ</p>

        <a href="/thue-vip" class="<?= isActive('/thue-vip', $current_uri) ? 'bg-white dark:bg-[#1e293b] text-blue-600 dark:text-blue-400 shadow-sm border border-neutral-200 dark:border-gray-700/50' : 'text-neutral-600 dark:text-gray-400 hover:bg-white dark:hover:bg-[#1e293b] hover:text-blue-600 dark:hover:text-blue-400 border border-transparent' ?> flex items-center gap-3 px-3.5 py-2.5 rounded-[14px] font-bold text-[13px] transition-all focus:outline-none group">
            <i class="ri-vip-crown-2-line text-[18px] opacity-80 group-hover:opacity-100 transition-opacity"></i> Mua Gói VIP
        </a>
        
        <a href="/thue-api" class="<?= isActive('/thue-api', $current_uri) ? 'bg-white dark:bg-[#1e293b] text-blue-600 dark:text-blue-400 shadow-sm border border-neutral-200 dark:border-gray-700/50' : 'text-neutral-600 dark:text-gray-400 hover:bg-white dark:hover:bg-[#1e293b] hover:text-blue-600 dark:hover:text-blue-400 border border-transparent' ?> flex items-center gap-3 px-3.5 py-2.5 rounded-[14px] font-bold text-[13px] transition-all focus:outline-none group">
            <i class="ri-key-2-line text-[18px] opacity-80 group-hover:opacity-100 transition-opacity"></i> Thuê API Token
        </a>
        
        <a href="/tools" class="<?= isActive('/tools', $current_uri) ? 'bg-white dark:bg-[#1e293b] text-blue-600 dark:text-blue-400 shadow-sm border border-neutral-200 dark:border-gray-700/50' : 'text-neutral-600 dark:text-gray-400 hover:bg-white dark:hover:bg-[#1e293b] hover:text-blue-600 dark:hover:text-blue-400 border border-transparent' ?> flex items-center gap-3 px-3.5 py-2.5 rounded-[14px] font-bold text-[13px] transition-all focus:outline-none group">
            <i class="ri-gamepad-line text-[18px] opacity-80 group-hover:opacity-100 transition-opacity"></i> Chơi Game Dự Đoán
        </a>
        
        <a href="/product" class="<?= isActive('/product', $current_uri) ? 'bg-white dark:bg-[#1e293b] text-blue-600 dark:text-blue-400 shadow-sm border border-neutral-200 dark:border-gray-700/50' : 'text-neutral-600 dark:text-gray-400 hover:bg-white dark:hover:bg-[#1e293b] hover:text-blue-600 dark:hover:text-blue-400 border border-transparent' ?> flex items-center gap-3 px-3.5 py-2.5 rounded-[14px] font-bold text-[13px] transition-all focus:outline-none group">
            <i class="ri-code-box-line text-[18px] opacity-80 group-hover:opacity-100 transition-opacity"></i> Kho Mã Nguồn
        </a>

        <a href="/ctv/invite" class="<?= isActive('/ctv/invite', $current_uri) ? 'bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-500 shadow-sm border border-amber-200 dark:border-amber-800/30' : 'text-amber-600 dark:text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-900/20 border border-transparent' ?> flex items-center justify-between px-3.5 py-2.5 mt-1 rounded-[14px] font-black text-[13px] transition-all focus:outline-none group">
            <div class="flex items-center gap-3">
                <i class="ri-vip-diamond-line text-[18px] opacity-90 group-hover:opacity-100 transition-opacity"></i> Trở Thành CTV
            </div>
            <i class="ri-arrow-right-line text-[14px] opacity-50 group-hover:opacity-100 transition-opacity"></i>
        </a>

        <div class="pt-4 pb-1">
            <div class="h-px w-full bg-neutral-200/60 dark:bg-gray-800"></div>
        </div>
        <p class="text-[10px] font-black text-neutral-400 dark:text-gray-500 uppercase tracking-widest px-3 mb-3">Hỗ Trợ & Khác</p>

        <a href="/partner" class="<?= isActive('/partner', $current_uri) ? 'bg-white dark:bg-[#1e293b] text-blue-600 dark:text-blue-400 shadow-sm border border-neutral-200 dark:border-gray-700/50' : 'text-neutral-600 dark:text-gray-400 hover:bg-white dark:hover:bg-[#1e293b] hover:text-blue-600 dark:hover:text-blue-400 border border-transparent' ?> flex items-center gap-3 px-3.5 py-2.5 rounded-[14px] font-bold text-[13px] transition-all focus:outline-none group">
            <i class="ri-shake-hands-line text-[18px] opacity-80 group-hover:opacity-100 transition-opacity"></i> Đối Tác System
        </a>
        
        <a href="/blog" class="<?= isActive('/blog', $current_uri) ? 'bg-white dark:bg-[#1e293b] text-blue-600 dark:text-blue-400 shadow-sm border border-neutral-200 dark:border-gray-700/50' : 'text-neutral-600 dark:text-gray-400 hover:bg-white dark:hover:bg-[#1e293b] hover:text-blue-600 dark:hover:text-blue-400 border border-transparent' ?> flex items-center gap-3 px-3.5 py-2.5 rounded-[14px] font-bold text-[13px] transition-all focus:outline-none group">
            <i class="ri-article-line text-[18px] opacity-80 group-hover:opacity-100 transition-opacity"></i> Bài Viết Blog
        </a>
        
        <a href="/document" class="<?= isActive('/document', $current_uri) ? 'bg-white dark:bg-[#1e293b] text-blue-600 dark:text-blue-400 shadow-sm border border-neutral-200 dark:border-gray-700/50' : 'text-neutral-600 dark:text-gray-400 hover:bg-white dark:hover:bg-[#1e293b] hover:text-blue-600 dark:hover:text-blue-400 border border-transparent' ?> flex items-center gap-3 px-3.5 py-2.5 rounded-[14px] font-bold text-[13px] transition-all focus:outline-none group">
            <i class="ri-book-read-line text-[18px] opacity-80 group-hover:opacity-100 transition-opacity"></i> Tài Liệu API
        </a>
        
        <a href="/faq" class="<?= isActive('/faq', $current_uri) ? 'bg-white dark:bg-[#1e293b] text-blue-600 dark:text-blue-400 shadow-sm border border-neutral-200 dark:border-gray-700/50' : 'text-neutral-600 dark:text-gray-400 hover:bg-white dark:hover:bg-[#1e293b] hover:text-blue-600 dark:hover:text-blue-400 border border-transparent' ?> flex items-center gap-3 px-3.5 py-2.5 rounded-[14px] font-bold text-[13px] transition-all focus:outline-none group">
            <i class="ri-question-answer-line text-[18px] opacity-80 group-hover:opacity-100 transition-opacity"></i> Câu Hỏi Thường Gặp
        </a>

        <a href="<?= htmlspecialchars($community_link) ?>" target="_blank" class="text-neutral-600 dark:text-gray-400 hover:bg-white dark:hover:bg-[#1e293b] hover:text-blue-600 dark:hover:text-blue-400 border border-transparent flex items-center justify-between px-3.5 py-2.5 rounded-[14px] font-bold text-[13px] transition-all focus:outline-none group">
            <div class="flex items-center gap-3">
                <i class="ri-discuss-line text-[18px] opacity-80 group-hover:opacity-100 transition-opacity"></i> Box Cộng Đồng
            </div>
            <i class="ri-external-link-line text-[14px] opacity-40 group-hover:opacity-100 transition-opacity"></i>
        </a>
        
        <a href="<?= htmlspecialchars($support_link) ?>" target="_blank" class="text-neutral-600 dark:text-gray-400 hover:bg-white dark:hover:bg-[#1e293b] hover:text-blue-600 dark:hover:text-blue-400 border border-transparent flex items-center justify-between px-3.5 py-2.5 rounded-[14px] font-bold text-[13px] transition-all focus:outline-none group">
            <div class="flex items-center gap-3">
                <i class="ri-customer-service-2-line text-[18px] opacity-80 group-hover:opacity-100 transition-opacity"></i> Liên Hệ Hỗ Trợ
            </div>
            <i class="ri-external-link-line text-[14px] opacity-40 group-hover:opacity-100 transition-opacity"></i>
        </a>

    </div>

    <div class="p-4 border-t border-neutral-200/80 dark:border-gray-800 shrink-0 bg-white dark:bg-[#0f172a] shadow-[0_-4px_24px_rgba(0,0,0,0.02)] z-10">
        <a href="/logout" class="flex items-center justify-center gap-2 w-full h-11 rounded-xl text-rose-500 dark:text-rose-400 bg-rose-50 hover:bg-rose-500 hover:text-white dark:bg-rose-900/10 dark:hover:bg-rose-500 font-bold text-[13px] uppercase tracking-widest transition-colors focus:outline-none">
            <i class="ri-logout-box-r-line text-[18px]"></i> Đăng Xuất
        </a>
    </div>
</aside>

<style>
    [x-cloak] { display: none !important; }
    /* Tùy chỉnh thanh cuộn đẹp, ẩn đi khi không cuộn */
    .custom-scrollbar::-webkit-scrollbar { width: 4px; }
    .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
    .custom-scrollbar::-webkit-scrollbar-thumb { background-color: transparent; border-radius: 10px; transition: background-color 0.3s; }
    .custom-scrollbar:hover::-webkit-scrollbar-thumb { background-color: #cbd5e1; }
    .dark .custom-scrollbar:hover::-webkit-scrollbar-thumb { background-color: #334155; }
</style>
