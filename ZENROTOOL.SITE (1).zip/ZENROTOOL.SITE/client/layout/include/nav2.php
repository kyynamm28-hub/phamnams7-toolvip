<?php
$community_link = $config['community_link'] ?? 'https://t.me/zenrosite_group';
$support_link = $config['support_link'] ?? 'https://t.me/zenrosite_support';
$navbar_logo = $config['navbar_logo'] ?? '/client/layout/assets/images/game.png';

// Kiểm tra quyền admin
$isShowAdmin = false;
if (isset($is_admin) && $is_admin === true) {
    $isShowAdmin = true;
} elseif (isset($user_data['role']) && strtolower($user_data['role']) === 'admin') {
    $isShowAdmin = true;
} elseif (isset($user['role']) && strtolower($user['role']) === 'admin') {
    $isShowAdmin = true;
}

// Hàm hỗ trợ active menu cực chuẩn
$current_uri = $_SERVER['REQUEST_URI'];
function isActive($path, $uri) {
    if ($path === '/home' && ($uri === '/home' || $uri === '/')) return true;
    if ($path !== '/home' && strpos($uri, $path) === 0) return true;
    return false;
}
?>

<!-- OVERLAY BÓNG MỜ KHI MỞ MENU MOBILE -->
<div x-show="sidebarOpen" x-cloak @click="sidebarOpen = false" x-transition.opacity class="fixed inset-0 z-[60] bg-slate-900/40 dark:bg-black/60 backdrop-blur-sm lg:hidden"></div>

<!-- SIDEBAR CHÍNH -->
<aside :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'" class="fixed inset-y-0 left-0 z-[70] w-[260px] bg-white dark:bg-[#0b1120] border-r border-slate-200/50 dark:border-slate-800/50 transition-transform duration-300 ease-out lg:translate-x-0 flex flex-col shadow-2xl lg:shadow-none pb-20 lg:pb-0">
    
    <!-- LOGO -->
    <div class="flex items-center justify-between lg:justify-center h-[76px] px-6 shrink-0 border-b border-slate-100 dark:border-slate-800/50 bg-white dark:bg-[#0f172a] relative z-10">
        <a href="/home" class="flex items-center justify-center w-full group focus:outline-none">
            <img src="<?= htmlspecialchars($navbar_logo) ?>" alt="ZENRO" class="h-10 sm:h-12 w-auto object-contain transition-transform duration-300 group-hover:scale-105">
        </a>
        <button @click="sidebarOpen = false" class="lg:hidden w-8 h-8 rounded-full bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white transition-colors focus:outline-none">
            <i class="ri-close-line text-xl"></i>
        </button>
    </div>

    <!-- DANH SÁCH MENU -->
    <div class="flex-1 overflow-y-auto py-5 px-4 space-y-1 custom-scrollbar bg-white dark:bg-[#0b1120]">
        
        <p class="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest px-4 mb-2 mt-2">Tổng Quan</p>
        
        <a href="/home" class="<?= isActive('/home', $current_uri) ? 'bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-white font-medium' ?> flex items-center gap-3.5 px-4 py-2.5 rounded-xl text-[13px] transition-all focus:outline-none group">
            <i class="<?= isActive('/home', $current_uri) ? 'ri-dashboard-fill' : 'ri-dashboard-line' ?> text-[18px] transition-transform group-hover:scale-110"></i> 
            Bảng Điều Khiển
        </a>

        <a href="/profile" class="<?= isActive('/profile', $current_uri) ? 'bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-white font-medium' ?> flex items-center gap-3.5 px-4 py-2.5 rounded-xl text-[13px] transition-all focus:outline-none group">
            <i class="<?= isActive('/profile', $current_uri) ? 'ri-user-settings-fill' : 'ri-user-settings-line' ?> text-[18px] transition-transform group-hover:scale-110"></i> 
            Hồ Sơ Cá Nhân
        </a>

        <?php if ($isShowAdmin): ?>
        <a href="/admin/" class="flex items-center gap-3.5 px-4 py-2.5 mt-2 rounded-xl text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-500/10 font-bold text-[13px] transition-all hover:bg-rose-100 dark:hover:bg-rose-500/20 focus:outline-none group">
            <i class="ri-shield-keyhole-fill text-[18px] transition-transform group-hover:scale-110"></i> 
            Quản Trị Hệ Thống
        </a>
        <?php endif; ?>

        <div class="pt-4 pb-2"><div class="h-px w-full bg-slate-100 dark:bg-slate-800/60"></div></div>
        
        <p class="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest px-4 mb-2">Tài Chính</p>
        
        <!-- DROPDOWN NẠP TIỀN -->
        <div x-data="{ openRecharge: <?= (strpos($current_uri, '/bank') === 0) ? 'true' : 'false' ?> }">
            <button @click="openRecharge = !openRecharge" class="<?= (strpos($current_uri, '/bank') === 0) ? 'text-blue-600 dark:text-blue-400 font-bold' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50 font-medium' ?> w-full flex items-center justify-between px-4 py-2.5 rounded-xl text-[13px] transition-all focus:outline-none group">
                <div class="flex items-center gap-3.5">
                    <i class="<?= (strpos($current_uri, '/bank') === 0) ? 'ri-wallet-3-fill' : 'ri-wallet-3-line' ?> text-[18px] transition-transform group-hover:scale-110"></i> Nạp Tiền
                </div>
                <i class="ri-arrow-down-s-line transition-transform duration-300 opacity-50" :class="openRecharge ? 'rotate-180' : ''"></i>
            </button>
            <div x-show="openRecharge" x-collapse.duration.300ms class="pl-[42px] pr-2 mt-1 space-y-0.5">
                <a href="/bank/recharge" class="<?= isActive('/bank/recharge', $current_uri) ? 'text-blue-600 dark:text-blue-400 font-bold bg-blue-50/50 dark:bg-blue-500/5' : 'text-slate-500 dark:text-slate-400 font-medium hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50' ?> block px-3 py-2 text-[12px] rounded-lg transition-colors focus:outline-none">Chuyển Khoản / QR</a>
                <a href="/bank/card" class="<?= isActive('/bank/card', $current_uri) ? 'text-blue-600 dark:text-blue-400 font-bold bg-blue-50/50 dark:bg-blue-500/5' : 'text-slate-500 dark:text-slate-400 font-medium hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50' ?> block px-3 py-2 text-[12px] rounded-lg transition-colors focus:outline-none">Đổi Thẻ Cào</a>
            </div>
        </div>

        <!-- DROPDOWN LỊCH SỬ -->
        <div x-data="{ openHistory: <?= (strpos($current_uri, '/history') === 0) ? 'true' : 'false' ?> }" class="mt-1">
            <button @click="openHistory = !openHistory" class="<?= (strpos($current_uri, '/history') === 0) ? 'text-blue-600 dark:text-blue-400 font-bold' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50 font-medium' ?> w-full flex items-center justify-between px-4 py-2.5 rounded-xl text-[13px] transition-all focus:outline-none group">
                <div class="flex items-center gap-3.5">
                    <i class="<?= (strpos($current_uri, '/history') === 0) ? 'ri-history-fill' : 'ri-history-line' ?> text-[18px] transition-transform group-hover:scale-110"></i> Lịch Sử
                </div>
                <i class="ri-arrow-down-s-line transition-transform duration-300 opacity-50" :class="openHistory ? 'rotate-180' : ''"></i>
            </button>
            <div x-show="openHistory" x-collapse.duration.300ms class="pl-[42px] pr-2 mt-1 space-y-0.5">
                <a href="/history/recharge" class="<?= isActive('/history/recharge', $current_uri) ? 'text-blue-600 dark:text-blue-400 font-bold bg-blue-50/50 dark:bg-blue-500/5' : 'text-slate-500 dark:text-slate-400 font-medium hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50' ?> block px-3 py-2 text-[12px] rounded-lg transition-colors focus:outline-none">Giao Dịch Nạp</a>
                <a href="/history/product" class="<?= isActive('/history/product', $current_uri) ? 'text-blue-600 dark:text-blue-400 font-bold bg-blue-50/50 dark:bg-blue-500/5' : 'text-slate-500 dark:text-slate-400 font-medium hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50' ?> block px-3 py-2 text-[12px] rounded-lg transition-colors focus:outline-none">Lịch Sử Mua Hàng</a>
                <a href="/history/work" class="<?= isActive('/history/work', $current_uri) ? 'text-blue-600 dark:text-blue-400 font-bold bg-blue-50/50 dark:bg-blue-500/5' : 'text-slate-500 dark:text-slate-400 font-medium hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50' ?> block px-3 py-2 text-[12px] rounded-lg transition-colors focus:outline-none">Nhật Ký Hoạt Động</a>
            </div>
        </div>

        <div class="pt-4 pb-2"><div class="h-px w-full bg-slate-100 dark:bg-slate-800/60"></div></div>
        
        <p class="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest px-4 mb-2">Dịch Vụ</p>

        <a href="/thue-vip" class="<?= isActive('/thue-vip', $current_uri) ? 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-500 font-bold' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-white font-medium' ?> flex items-center gap-3.5 px-4 py-2.5 rounded-xl text-[13px] transition-all focus:outline-none group">
            <i class="<?= isActive('/thue-vip', $current_uri) ? 'ri-vip-crown-2-fill' : 'ri-vip-crown-2-line' ?> text-[18px] transition-transform group-hover:scale-110"></i> 
            Mua Gói VIP
        </a>
        
        <a href="/thue-api" class="<?= isActive('/thue-api', $current_uri) ? 'bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-white font-medium' ?> flex items-center gap-3.5 px-4 py-2.5 rounded-xl text-[13px] transition-all focus:outline-none group">
            <i class="<?= isActive('/thue-api', $current_uri) ? 'ri-key-2-fill' : 'ri-key-2-line' ?> text-[18px] transition-transform group-hover:scale-110"></i> 
            Thuê API Token
        </a>
        
        <a href="/tools" class="<?= isActive('/tools', $current_uri) ? 'bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-white font-medium' ?> flex items-center gap-3.5 px-4 py-2.5 rounded-xl text-[13px] transition-all focus:outline-none group">
            <i class="<?= isActive('/tools', $current_uri) ? 'ri-gamepad-fill' : 'ri-gamepad-line' ?> text-[18px] transition-transform group-hover:scale-110"></i> 
            Kho Công Cụ Tools
        </a>
        
        <a href="/product" class="<?= isActive('/product', $current_uri) ? 'bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-white font-medium' ?> flex items-center gap-3.5 px-4 py-2.5 rounded-xl text-[13px] transition-all focus:outline-none group">
            <i class="<?= isActive('/product', $current_uri) ? 'ri-code-box-fill' : 'ri-code-box-line' ?> text-[18px] transition-transform group-hover:scale-110"></i> 
            Chợ Mã Nguồn
        </a>

        <a href="/ctv/invite" class="<?= isActive('/ctv/invite', $current_uri) ? 'bg-purple-50 dark:bg-purple-500/10 text-purple-600 dark:text-purple-400 font-bold' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-white font-medium' ?> flex items-center justify-between px-4 py-2.5 mt-1 rounded-xl text-[13px] transition-all focus:outline-none group">
            <div class="flex items-center gap-3.5">
                <i class="<?= isActive('/ctv/invite', $current_uri) ? 'ri-vip-diamond-fill' : 'ri-vip-diamond-line' ?> text-[18px] transition-transform group-hover:scale-110"></i> Trở Thành CTV
            </div>
        </a>

        <div class="pt-4 pb-2"><div class="h-px w-full bg-slate-100 dark:bg-slate-800/60"></div></div>
        
        <p class="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest px-4 mb-2">Hỗ Trợ & Khác</p>

        <a href="/partner" class="<?= isActive('/partner', $current_uri) ? 'bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-white font-medium' ?> flex items-center gap-3.5 px-4 py-2.5 rounded-xl text-[13px] transition-all focus:outline-none group">
            <i class="<?= isActive('/partner', $current_uri) ? 'ri-shake-hands-fill' : 'ri-shake-hands-line' ?> text-[18px] transition-transform group-hover:scale-110"></i> 
            Đối Tác System
        </a>
        
        <a href="/blog" class="<?= isActive('/blog', $current_uri) ? 'bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-white font-medium' ?> flex items-center gap-3.5 px-4 py-2.5 rounded-xl text-[13px] transition-all focus:outline-none group">
            <i class="<?= isActive('/blog', $current_uri) ? 'ri-article-fill' : 'ri-article-line' ?> text-[18px] transition-transform group-hover:scale-110"></i> 
            Bài Viết Blog
        </a>
        
        <a href="/document" class="<?= isActive('/document', $current_uri) ? 'bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-white font-medium' ?> flex items-center gap-3.5 px-4 py-2.5 rounded-xl text-[13px] transition-all focus:outline-none group">
            <i class="<?= isActive('/document', $current_uri) ? 'ri-book-read-fill' : 'ri-book-read-line' ?> text-[18px] transition-transform group-hover:scale-110"></i> 
            Tài Liệu API
        </a>
        
        <a href="<?= htmlspecialchars($community_link) ?>" target="_blank" class="text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-white font-medium flex items-center justify-between px-4 py-2.5 rounded-xl text-[13px] transition-all focus:outline-none group">
            <div class="flex items-center gap-3.5">
                <i class="ri-discuss-line text-[18px] transition-transform group-hover:scale-110"></i> Box Cộng Đồng
            </div>
            <i class="ri-external-link-line text-[12px] opacity-40"></i>
        </a>
        
        <a href="<?= htmlspecialchars($support_link) ?>" target="_blank" class="text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-white font-medium flex items-center justify-between px-4 py-2.5 rounded-xl text-[13px] transition-all focus:outline-none group">
            <div class="flex items-center gap-3.5">
                <i class="ri-customer-service-2-line text-[18px] transition-transform group-hover:scale-110"></i> Liên Hệ Hỗ Trợ
            </div>
            <i class="ri-external-link-line text-[12px] opacity-40"></i>
        </a>

    </div>

    <!-- NÚT ĐĂNG XUẤT MÁY TÍNH -->
    <div class="p-4 border-t border-slate-100 dark:border-slate-800/50 shrink-0 bg-white dark:bg-[#0f172a] hidden lg:block">
        <a href="/logout" class="flex items-center justify-center gap-2 w-full h-10 rounded-xl text-rose-500 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-500/10 font-bold text-[12px] uppercase tracking-widest transition-colors focus:outline-none">
            <i class="ri-logout-box-r-line text-[16px]"></i> Đăng Xuất
        </a>
    </div>
</aside>

<!-- ========================================== -->
<!-- BOTTOM NAVIGATION BAR (CHỈ HIỆN ĐIỆN THOẠI) -->
<!-- ========================================== -->
<nav class="lg:hidden fixed bottom-0 left-0 w-full z-[80] bg-white/90 dark:bg-[#0f172a]/90 backdrop-blur-xl border-t border-slate-200/50 dark:border-slate-800/50 pb-safe shadow-[0_-10px_40px_rgba(0,0,0,0.03)]">
    <div class="flex justify-around items-end h-16 px-2">
        
        <!-- Home -->
        <a href="/home" class="flex flex-col items-center justify-center w-16 gap-1 mb-2 group focus:outline-none">
            <div class="w-12 h-8 flex items-center justify-center rounded-full transition-all duration-300 <?= isActive('/home', $current_uri) ? 'bg-blue-100 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400' : 'text-slate-500 dark:text-slate-400 group-hover:text-slate-800 dark:group-hover:text-slate-200' ?>">
                <i class="<?= isActive('/home', $current_uri) ? 'ri-dashboard-fill' : 'ri-dashboard-line' ?> text-[20px]"></i>
            </div>
            <span class="text-[10px] transition-colors <?= isActive('/home', $current_uri) ? 'font-bold text-blue-600 dark:text-blue-400' : 'font-medium text-slate-500 dark:text-slate-400' ?>">Home</span>
        </a>

        <!-- Tools -->
        <a href="/tools" class="flex flex-col items-center justify-center w-16 gap-1 mb-2 group focus:outline-none">
            <div class="w-12 h-8 flex items-center justify-center rounded-full transition-all duration-300 <?= isActive('/tools', $current_uri) ? 'bg-blue-100 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400' : 'text-slate-500 dark:text-slate-400 group-hover:text-slate-800 dark:group-hover:text-slate-200' ?>">
                <i class="<?= isActive('/tools', $current_uri) ? 'ri-gamepad-fill' : 'ri-gamepad-line' ?> text-[20px]"></i>
            </div>
            <span class="text-[10px] transition-colors <?= isActive('/tools', $current_uri) ? 'font-bold text-blue-600 dark:text-blue-400' : 'font-medium text-slate-500 dark:text-slate-400' ?>">Tools</span>
        </a>

        <!-- Nạp Tiền -->
        <a href="/bank/recharge" class="flex flex-col items-center justify-center w-16 gap-1 mb-2 group focus:outline-none">
            <div class="w-12 h-8 flex items-center justify-center rounded-full transition-all duration-300 <?= isActive('/bank/recharge', $current_uri) ? 'bg-blue-100 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400' : 'text-slate-500 dark:text-slate-400 group-hover:text-slate-800 dark:group-hover:text-slate-200' ?>">
                <i class="<?= isActive('/bank/recharge', $current_uri) ? 'ri-wallet-3-fill' : 'ri-wallet-3-line' ?> text-[20px]"></i>
            </div>
            <span class="text-[10px] transition-colors <?= isActive('/bank/recharge', $current_uri) ? 'font-bold text-blue-600 dark:text-blue-400' : 'font-medium text-slate-500 dark:text-slate-400' ?>">Nạp Tiền</span>
        </a>

        <!-- Mua VIP -->
        <a href="/thue-vip" class="flex flex-col items-center justify-center w-16 gap-1 mb-2 group focus:outline-none">
            <div class="w-12 h-8 flex items-center justify-center rounded-full transition-all duration-300 <?= isActive('/thue-vip', $current_uri) ? 'bg-amber-100 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400' : 'text-slate-500 dark:text-slate-400 group-hover:text-slate-800 dark:group-hover:text-slate-200' ?>">
                <i class="<?= isActive('/thue-vip', $current_uri) ? 'ri-vip-crown-2-fill' : 'ri-vip-crown-2-line' ?> text-[20px]"></i>
            </div>
            <span class="text-[10px] transition-colors <?= isActive('/thue-vip', $current_uri) ? 'font-bold text-amber-600 dark:text-amber-400' : 'font-medium text-slate-500 dark:text-slate-400' ?>">Gói VIP</span>
        </a>

        <!-- Cá Nhân -->
        <a href="/profile" class="flex flex-col items-center justify-center w-16 gap-1 mb-2 group focus:outline-none">
            <div class="w-12 h-8 flex items-center justify-center rounded-full transition-all duration-300 <?= isActive('/profile', $current_uri) ? 'bg-blue-100 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400' : 'text-slate-500 dark:text-slate-400 group-hover:text-slate-800 dark:group-hover:text-slate-200' ?>">
                <i class="<?= isActive('/profile', $current_uri) ? 'ri-user-smile-fill' : 'ri-user-smile-line' ?> text-[20px]"></i>
            </div>
            <span class="text-[10px] transition-colors <?= isActive('/profile', $current_uri) ? 'font-bold text-blue-600 dark:text-blue-400' : 'font-medium text-slate-500 dark:text-slate-400' ?>">Cá Nhân</span>
        </a>

    </div>
</nav>

<style>
    [x-cloak] { display: none !important; }
    
    /* Thanh cuộn tinh tế */
    .custom-scrollbar::-webkit-scrollbar { width: 4px; }
    .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
    .custom-scrollbar::-webkit-scrollbar-thumb { background-color: transparent; border-radius: 10px; transition: background-color 0.3s; }
    .custom-scrollbar:hover::-webkit-scrollbar-thumb { background-color: #cbd5e1; }
    .dark .custom-scrollbar:hover::-webkit-scrollbar-thumb { background-color: #334155; }
    
    /* Support hiển thị tốt trên iPhone (notch/home bar) */
    @supports (padding-bottom: env(safe-area-inset-bottom)) {
        .pb-safe { padding-bottom: env(safe-area-inset-bottom); }
    }
    
    /* Đẩy content trang lên để không bị thanh Bottom Nav che khuất (Chỉ áp dụng trên mobile) */
    @media (max-width: 1023px) {
        body { padding-bottom: calc(4rem + env(safe-area-inset-bottom)); }
    }
</style>
