<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/settings.php';

if (!isset($_SESSION['user_id'])) { header("Location: /auth/#login"); exit; }

// ĐÃ FIX: Lấy toàn bộ thông tin User vào biến $user_data để Header hiển thị đúng Avatar và Số dư
$stmtUser = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user_data = $stmtUser->fetch(PDO::FETCH_ASSOC);

// Lấy danh sách tin tức đang hiển thị (sắp xếp theo position và ngày)
$stmtBlogs = $pdo->query("SELECT token, title, short_description, image, views, created_at FROM blogs WHERE status = 'active' ORDER BY position ASC, created_at DESC");
$blogs = $stmtBlogs->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Tin Tức & Cập Nhật';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/collapse@3.x.x/dist/cdn.min.js"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); }
        .fade-in { animation: fadeIn 0.4s ease-out forwards; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-neutral-50 dark:bg-gray-900 text-neutral-800 dark:text-gray-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 w-full max-w-7xl mx-auto fade-in">
            
            <div class="mb-8">
                <h1 class="text-2xl font-black text-neutral-800 dark:text-white uppercase tracking-wide">Tin Tức Hệ Thống</h1>
                <p class="text-sm text-neutral-500 dark:text-gray-400 mt-1">Cập nhật những thông tin, tính năng và thông báo mới nhất.</p>
            </div>

            <?php if (empty($blogs)): ?>
                <div class="bg-white dark:bg-gray-800 rounded-2xl border border-neutral-200 dark:border-gray-700 p-12 flex flex-col items-center justify-center min-h-[400px] shadow-soft">
                    <i class="ri-newspaper-line text-6xl text-neutral-300 dark:text-gray-600 mb-4"></i>
                    <h3 class="text-lg font-bold text-neutral-600 dark:text-gray-300">Chưa có bài viết nào</h3>
                </div>
            <?php else: ?>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    <?php foreach ($blogs as $b): 
                        $img = $b['image'] ?: 'https://placehold.co/600x400/f8fafc/94a3b8?text=Zenro+Blog';
                    ?>
                    <a href="/view-blog/<?= htmlspecialchars($b['token']) ?>" class="bg-white dark:bg-gray-800 rounded-2xl border border-neutral-200 dark:border-gray-700 overflow-hidden shadow-sm hover:shadow-md hover:border-blue-400 dark:hover:border-blue-500 transition-all flex flex-col group block">
                        
                        <div class="relative aspect-[16/10] overflow-hidden bg-neutral-100 dark:bg-gray-700">
                            <img src="<?= htmlspecialchars($img) ?>" alt="Blog" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                            <div class="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors"></div>
                        </div>

                        <div class="p-5 flex flex-col flex-1">
                            <h3 class="text-base font-bold text-neutral-800 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 line-clamp-2 mb-2 transition-colors leading-snug">
                                <?= htmlspecialchars($b['title']) ?>
                            </h3>
                            <p class="text-[13px] text-neutral-500 dark:text-gray-400 line-clamp-2 mb-5 flex-1 leading-relaxed">
                                <?= htmlspecialchars($b['short_description']) ?>
                            </p>
                            
                            <div class="flex items-center justify-between mt-auto pt-4 border-t border-neutral-100 dark:border-gray-700 text-xs font-semibold text-neutral-400 dark:text-gray-500">
                                <div class="flex items-center gap-1.5">
                                    <i class="ri-calendar-2-line"></i> <?= date('d/m/Y', strtotime($b['created_at'])) ?>
                                </div>
                                <div class="flex items-center gap-1.5">
                                    <i class="ri-eye-line"></i> <?= number_format($b['views']) ?>
                                </div>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>
</body>
</html>
