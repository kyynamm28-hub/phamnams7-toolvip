<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/settings.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) { 
    header("Location: /auth/#login"); 
    exit; 
}

// Lấy thông tin User (Nếu cần hiển thị tên/số dư trên Header/Nav)
$stmtUser = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user_data = $stmtUser->fetch(PDO::FETCH_ASSOC);

$pageTitle = 'Trang Chủ - Tính Năng Đang Cập Nhật';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/collapse@3.x.x/dist/cdn.min.js"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); }
        .fade-in { animation: fadeIn 0.4s ease-out forwards; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .spin-slow { animation: spin 4s linear infinite; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-neutral-50 dark:bg-gray-900 text-neutral-800 dark:text-gray-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 w-full max-w-5xl mx-auto fade-in flex items-center justify-center">
            
            <div class="w-full rounded-3xl border border-neutral-200 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-soft py-16 px-6 sm:px-12 flex flex-col items-center justify-center text-center">
                
                <div class="relative mb-8 group">
                    <div class="absolute inset-0 bg-blue-100 dark:bg-blue-900/30 rounded-full blur-xl scale-150 opacity-50 transition-opacity duration-500"></div>
                    <div class="relative w-20 h-20 rounded-2xl bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-700 dark:to-slate-800 border border-neutral-200/60 dark:border-gray-600 flex items-center justify-center shadow-sm">
                        <i class="ri-tools-fill text-3xl text-slate-700 dark:text-slate-300 spin-slow"></i>
                    </div>
                </div>

                <h1 class="text-2xl sm:text-3xl font-bold text-neutral-800 dark:text-white tracking-tight mb-4">
                    Tính Năng Đang Được Nâng Cấp
                </h1>
                
                <p class="text-sm sm:text-base text-neutral-500 dark:text-gray-400 max-w-md mx-auto leading-relaxed mb-8">
                    Hệ thống đang được bảo trì và tối ưu hóa để mang lại trải nghiệm tốt nhất. Các tính năng đột phá mới sẽ sớm được ra mắt trong bản cập nhật tiếp theo. Cảm ơn bạn đã kiên nhẫn!
                </p>

                <div class="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
                    <button onclick="window.history.back()" class="w-full sm:w-auto px-6 h-11 inline-flex items-center justify-center rounded-xl border border-neutral-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-neutral-700 dark:text-gray-200 hover:bg-neutral-50 dark:hover:bg-gray-600 font-semibold text-sm transition-colors">
                        <i class="ri-arrow-left-line mr-2"></i> Quay Lại
                    </button>
                    <a href="/thue-api" class="w-full sm:w-auto px-6 h-11 inline-flex items-center justify-center rounded-xl bg-neutral-900 hover:bg-black dark:bg-white dark:hover:bg-gray-100 text-white dark:text-neutral-900 font-bold text-sm transition-all shadow-sm">
                        <i class="ri-terminal-box-line mr-2"></i> Quản Lý API
                    </a>
                </div>

            </div>

        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

</body>
</html>