<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/settings.php';

$isLogin = isset($_SESSION['user_id']);
$user_data = null;

if ($isLogin) {
    $stmtUser = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
    $stmtUser->execute(['id' => $_SESSION['user_id']]);
    $user_data = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$user_data) {
        unset($_SESSION['user_id']);
        $isLogin = false;
    } else {
        $is_admin = (strtolower($user_data['role'] ?? 'user') === 'admin');
    }
}

$page_title = 'Tài Liệu Cấu Hình API';
?>

<!DOCTYPE html>
<html lang="vi" class="scroll-smooth">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/collapse@3.x.x/dist/cdn.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .fade-up { opacity: 0; transform: translateY(15px); animation: fadeUp 0.5s ease-out forwards; }
        .delay-100 { animation-delay: 100ms; }
        .delay-200 { animation-delay: 200ms; }
        .delay-300 { animation-delay: 300ms; }
        @keyframes fadeUp { to { opacity: 1; transform: translateY(0); } }

        /* Custom scrollbar cho Code Block */
        .code-scroll::-webkit-scrollbar { height: 6px; }
        .code-scroll::-webkit-scrollbar-track { background: rgba(0,0,0,0.2); border-radius: 10px; }
        .code-scroll::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.2); border-radius: 10px; }
        .code-scroll:hover::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.4); }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-slate-50 dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-300 relative">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 max-w-[1400px] mx-auto w-full">
            
            <div class="fade-up bg-gradient-to-br from-brand-600 via-indigo-600 to-purple-600 rounded-3xl p-8 sm:p-12 shadow-lg shadow-brand-500/20 relative overflow-hidden mb-8">
                <div class="absolute top-0 right-0 -mr-20 -mt-20 w-64 h-64 bg-white/20 rounded-full blur-3xl mix-blend-overlay"></div>
                <div class="absolute bottom-0 left-0 -ml-20 -mb-20 w-64 h-64 bg-indigo-400/40 rounded-full blur-3xl mix-blend-overlay"></div>
                
                <div class="relative z-10 text-center max-w-2xl mx-auto">
                    <div class="inline-flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white/10 border border-white/20 text-white mb-6 backdrop-blur-md shadow-inner">
                        <i class="ri-code-s-slash-line text-4xl sm:text-5xl drop-shadow-md"></i>
                    </div>
                    <h1 class="text-3xl sm:text-4xl font-black text-white uppercase tracking-wide mb-4 drop-shadow-sm">API Documentation</h1>
                    <p class="text-brand-100 font-medium text-sm sm:text-base leading-relaxed">
                        Tài liệu hướng dẫn tích hợp API dự đoán Game chuyên nghiệp. Cung cấp dữ liệu chuẩn xác, tốc độ phản hồi siêu tốc với định dạng JSON dễ dàng Parsing.
                    </p>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
                
                <div class="lg:col-span-1 hidden lg:block sticky top-24">
                    <div class="fade-up delay-100 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
                        <h3 class="font-bold text-slate-900 dark:text-white uppercase mb-5 text-sm flex items-center gap-2">
                            <i class="ri-list-indefinite text-brand-500 text-lg"></i> Mục Lục
                        </h3>
                        <ul class="space-y-1.5 text-sm font-medium">
                            <li>
                                <a href="#api-taixiu" class="toc-link block px-3 py-2.5 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-brand-50 dark:hover:bg-slate-800/80 hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                                    1. Dự Đoán Tài Xỉu
                                </a>
                            </li>
                            <li>
                                <a href="#api-check" class="toc-link block px-3 py-2.5 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-brand-50 dark:hover:bg-slate-800/80 hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                                    2. Kiểm Tra Token
                                </a>
                            </li>
                            <li>
                                <a href="#api-bacarat-full" class="toc-link block px-3 py-2.5 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-brand-50 dark:hover:bg-slate-800/80 hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                                    3. Baccarat (Full Bàn)
                                </a>
                            </li>
                            <li>
                                <a href="#api-bacarat-single" class="toc-link block px-3 py-2.5 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-brand-50 dark:hover:bg-slate-800/80 hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                                    4. Baccarat (Từng Bàn)
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="lg:col-span-3 space-y-8">
                    
                    <div id="api-taixiu" class="fade-up delay-100 scroll-mt-24 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm overflow-hidden">
                        <div class="px-6 py-5 border-b border-slate-100 dark:border-slate-800/60 flex flex-wrap items-center gap-3 bg-slate-50/50 dark:bg-slate-800/30">
                            <span class="px-3 py-1 bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-black text-[11px] uppercase tracking-wider rounded-lg border border-emerald-200 dark:border-emerald-500/30 shadow-sm">GET</span>
                            <h2 class="text-lg font-bold text-slate-900 dark:text-white">API Dự Đoán Tài Xỉu</h2>
                        </div>
                        
                        <div class="p-6">
                            <div class="group relative bg-[#1E1E1E] dark:bg-[#0d1117] rounded-xl mb-6 shadow-inner overflow-hidden border border-slate-800">
                                <div class="flex items-center gap-2 px-4 py-2.5 bg-[#2D2D2D] dark:bg-[#161b22] border-b border-slate-800">
                                    <div class="w-3 h-3 rounded-full bg-rose-500"></div>
                                    <div class="w-3 h-3 rounded-full bg-amber-500"></div>
                                    <div class="w-3 h-3 rounded-full bg-emerald-500"></div>
                                    <span class="ml-2 text-xs text-slate-400 font-mono">endpoint_url</span>
                                </div>
                                <div class="p-4 flex items-center justify-between gap-4 overflow-x-auto code-scroll">
                                    <code class="text-emerald-400 font-mono text-sm whitespace-nowrap" id="url-taixiu">https://<?= $_SERVER['HTTP_HOST'] ?>/api/v2/taixiu/{KEY_GAMES}/{TOKEN}</code>
                                    <button type="button" onclick="copyCode('url-taixiu')" class="shrink-0 w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 text-slate-300 flex items-center justify-center transition-colors">
                                        <i class="ri-file-copy-line"></i>
                                    </button>
                                </div>
                            </div>

                            <h3 class="text-[12px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-3">Tham Số Đường Dẫn</h3>
                            <div class="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800 mb-8 shadow-sm">
                                <table class="min-w-full text-sm text-left whitespace-nowrap">
                                    <thead class="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 uppercase text-[11px] font-bold tracking-wider">
                                        <tr>
                                            <th class="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800">Tham Số</th>
                                            <th class="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800">Kiểu</th>
                                            <th class="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800">Mô Tả</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-100 dark:divide-slate-800/50 text-slate-700 dark:text-slate-300 font-medium">
                                        <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                                            <td class="px-5 py-3 font-bold text-rose-500">KEY_GAMES <span class="text-xs text-slate-400">(*)</span></td>
                                            <td class="px-5 py-3"><span class="px-2 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-brand-600 dark:text-brand-400 font-mono text-[11px]">string</span></td>
                                            <td class="px-5 py-3">Mã định dạng của game (VD: sunwin, go88...)</td>
                                        </tr>
                                        <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                                            <td class="px-5 py-3 font-bold text-rose-500">TOKEN <span class="text-xs text-slate-400">(*)</span></td>
                                            <td class="px-5 py-3"><span class="px-2 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-brand-600 dark:text-brand-400 font-mono text-[11px]">string</span></td>
                                            <td class="px-5 py-3">Mã Token truy cập API của bạn</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <h3 class="text-[12px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-3">Response JSON Thành Công</h3>
                            <div class="group relative bg-[#1E1E1E] dark:bg-[#0d1117] rounded-xl shadow-inner border border-slate-800 overflow-hidden">
                                <div class="flex items-center justify-between px-4 py-2.5 bg-[#2D2D2D] dark:bg-[#161b22] border-b border-slate-800">
                                    <div class="flex items-center gap-2">
                                        <div class="w-3 h-3 rounded-full bg-rose-500"></div>
                                        <div class="w-3 h-3 rounded-full bg-amber-500"></div>
                                        <div class="w-3 h-3 rounded-full bg-emerald-500"></div>
                                        <span class="ml-2 text-xs text-slate-400 font-mono">response.json</span>
                                    </div>
                                    <button type="button" onclick="copyCode('res-taixiu')" class="text-xs text-slate-400 hover:text-white transition-colors flex items-center gap-1 font-semibold">
                                        <i class="ri-file-copy-line"></i> Copy
                                    </button>
                                </div>
                                <div class="p-4 overflow-x-auto code-scroll">
<pre><code class="text-sm font-mono leading-relaxed" id="res-taixiu"><span class="text-[#D4D4D4]">{</span>
    <span class="text-[#9CDCFE]">"code"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"200"</span><span class="text-[#D4D4D4]">,</span>
    <span class="text-[#9CDCFE]">"key_games"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"sunwin"</span><span class="text-[#D4D4D4]">,</span>
    <span class="text-[#9CDCFE]">"du_doan"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#D4D4D4]">[</span>
        <span class="text-[#D4D4D4]">{</span>
            <span class="text-[#9CDCFE]">"phien"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"272632"</span><span class="text-[#D4D4D4]">,</span>
            <span class="text-[#9CDCFE]">"total"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"13 - [5-6-2]"</span><span class="text-[#D4D4D4]">,</span>
            <span class="text-[#9CDCFE]">"ket_qua"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"Tài"</span><span class="text-[#D4D4D4]">,</span>
            <span class="text-[#9CDCFE]">"phien_hien_tai"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"272633"</span><span class="text-[#D4D4D4]">,</span>
            <span class="text-[#9CDCFE]">"du_doan"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"Xỉu"</span><span class="text-[#D4D4D4]">,</span>
            <span class="text-[#9CDCFE]">"ti_le"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"80%"</span>
        <span class="text-[#D4D4D4]">}</span>
    <span class="text-[#D4D4D4]">]</span>
<span class="text-[#D4D4D4]">}</span></code></pre>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="api-check" class="fade-up delay-200 scroll-mt-24 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm overflow-hidden">
                        <div class="px-6 py-5 border-b border-slate-100 dark:border-slate-800/60 flex flex-wrap items-center gap-3 bg-slate-50/50 dark:bg-slate-800/30">
                            <span class="px-3 py-1 bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-black text-[11px] uppercase tracking-wider rounded-lg border border-emerald-200 dark:border-emerald-500/30 shadow-sm">GET</span>
                            <h2 class="text-lg font-bold text-slate-900 dark:text-white">API Kiểm Tra Hạn Token</h2>
                        </div>
                        
                        <div class="p-6">
                            <div class="group relative bg-[#1E1E1E] dark:bg-[#0d1117] rounded-xl mb-6 shadow-inner overflow-hidden border border-slate-800">
                                <div class="flex items-center gap-2 px-4 py-2.5 bg-[#2D2D2D] dark:bg-[#161b22] border-b border-slate-800">
                                    <div class="w-3 h-3 rounded-full bg-rose-500"></div>
                                    <div class="w-3 h-3 rounded-full bg-amber-500"></div>
                                    <div class="w-3 h-3 rounded-full bg-emerald-500"></div>
                                    <span class="ml-2 text-xs text-slate-400 font-mono">endpoint_url</span>
                                </div>
                                <div class="p-4 flex items-center justify-between gap-4 overflow-x-auto code-scroll">
                                    <code class="text-emerald-400 font-mono text-sm whitespace-nowrap" id="url-check">https://<?= $_SERVER['HTTP_HOST'] ?>/api/v2/check/{TOKEN}</code>
                                    <button type="button" onclick="copyCode('url-check')" class="shrink-0 w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 text-slate-300 flex items-center justify-center transition-colors">
                                        <i class="ri-file-copy-line"></i>
                                    </button>
                                </div>
                            </div>

                            <h3 class="text-[12px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-3">Response JSON Thành Công</h3>
                            <div class="group relative bg-[#1E1E1E] dark:bg-[#0d1117] rounded-xl shadow-inner border border-slate-800 overflow-hidden">
                                <div class="flex items-center justify-between px-4 py-2.5 bg-[#2D2D2D] dark:bg-[#161b22] border-b border-slate-800">
                                    <div class="flex items-center gap-2">
                                        <div class="w-3 h-3 rounded-full bg-rose-500"></div>
                                        <div class="w-3 h-3 rounded-full bg-amber-500"></div>
                                        <div class="w-3 h-3 rounded-full bg-emerald-500"></div>
                                        <span class="ml-2 text-xs text-slate-400 font-mono">response.json</span>
                                    </div>
                                    <button type="button" onclick="copyCode('res-check')" class="text-xs text-slate-400 hover:text-white transition-colors flex items-center gap-1 font-semibold">
                                        <i class="ri-file-copy-line"></i> Copy
                                    </button>
                                </div>
                                <div class="p-4 overflow-x-auto code-scroll">
<pre><code class="text-sm font-mono leading-relaxed" id="res-check"><span class="text-[#D4D4D4]">{</span>
    <span class="text-[#9CDCFE]">"code"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"200"</span><span class="text-[#D4D4D4]">,</span>
    <span class="text-[#9CDCFE]">"token"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"ed54b33fa06b74a6bb1fcf99c90b76af"</span><span class="text-[#D4D4D4]">,</span>
    <span class="text-[#9CDCFE]">"remaining_time"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"65m"</span> <span class="text-[#6A9955]">// Thời gian sử dụng còn lại (phút)</span>
<span class="text-[#D4D4D4]">}</span></code></pre>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="api-bacarat-full" class="fade-up delay-300 scroll-mt-24 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm overflow-hidden">
                        <div class="px-6 py-5 border-b border-slate-100 dark:border-slate-800/60 flex flex-wrap items-center gap-3 bg-slate-50/50 dark:bg-slate-800/30">
                            <span class="px-3 py-1 bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-black text-[11px] uppercase tracking-wider rounded-lg border border-emerald-200 dark:border-emerald-500/30 shadow-sm">GET</span>
                            <h2 class="text-lg font-bold text-slate-900 dark:text-white">API Dự Đoán Baccarat (Full Bàn)</h2>
                        </div>
                        
                        <div class="p-6">
                            <div class="group relative bg-[#1E1E1E] dark:bg-[#0d1117] rounded-xl mb-6 shadow-inner overflow-hidden border border-slate-800">
                                <div class="flex items-center gap-2 px-4 py-2.5 bg-[#2D2D2D] dark:bg-[#161b22] border-b border-slate-800">
                                    <div class="w-3 h-3 rounded-full bg-rose-500"></div>
                                    <div class="w-3 h-3 rounded-full bg-amber-500"></div>
                                    <div class="w-3 h-3 rounded-full bg-emerald-500"></div>
                                    <span class="ml-2 text-xs text-slate-400 font-mono">endpoint_url</span>
                                </div>
                                <div class="p-4 flex items-center justify-between gap-4 overflow-x-auto code-scroll">
                                    <code class="text-emerald-400 font-mono text-sm whitespace-nowrap" id="url-bac-full">https://<?= $_SERVER['HTTP_HOST'] ?>/api/v2/bacarat/{TOKEN}</code>
                                    <button type="button" onclick="copyCode('url-bac-full')" class="shrink-0 w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 text-slate-300 flex items-center justify-center transition-colors">
                                        <i class="ri-file-copy-line"></i>
                                    </button>
                                </div>
                            </div>

                            <h3 class="text-[12px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-3">Response JSON Thành Công</h3>
                            <div class="group relative bg-[#1E1E1E] dark:bg-[#0d1117] rounded-xl shadow-inner border border-slate-800 overflow-hidden">
                                <div class="flex items-center justify-between px-4 py-2.5 bg-[#2D2D2D] dark:bg-[#161b22] border-b border-slate-800">
                                    <div class="flex items-center gap-2">
                                        <div class="w-3 h-3 rounded-full bg-rose-500"></div>
                                        <div class="w-3 h-3 rounded-full bg-amber-500"></div>
                                        <div class="w-3 h-3 rounded-full bg-emerald-500"></div>
                                        <span class="ml-2 text-xs text-slate-400 font-mono">response.json</span>
                                    </div>
                                    <button type="button" onclick="copyCode('res-bac-full')" class="text-xs text-slate-400 hover:text-white transition-colors flex items-center gap-1 font-semibold">
                                        <i class="ri-file-copy-line"></i> Copy
                                    </button>
                                </div>
                                <div class="p-4 overflow-x-auto code-scroll">
<pre><code class="text-sm font-mono leading-relaxed" id="res-bac-full"><span class="text-[#D4D4D4]">{</span>
    <span class="text-[#9CDCFE]">"code"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"200"</span><span class="text-[#D4D4D4]">,</span>
    <span class="text-[#9CDCFE]">"total"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"29"</span><span class="text-[#D4D4D4]">,</span>
    <span class="text-[#9CDCFE]">"data"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#D4D4D4]">[</span>
        <span class="text-[#D4D4D4]">{</span>
            <span class="text-[#9CDCFE]">"table"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"1"</span><span class="text-[#D4D4D4]">,</span>
            <span class="text-[#9CDCFE]">"result"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"BPTPPPPPT"</span><span class="text-[#D4D4D4]">,</span>
            <span class="text-[#9CDCFE]">"round"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"#9"</span><span class="text-[#D4D4D4]">,</span>
            <span class="text-[#9CDCFE]">"prediction"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"B"</span><span class="text-[#D4D4D4]">,</span>
            <span class="text-[#9CDCFE]">"confidence"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"87%"</span>
        <span class="text-[#D4D4D4]">},</span>
        <span class="text-[#6A9955]">... (Các bàn khác)</span>
    <span class="text-[#D4D4D4]">]</span>
<span class="text-[#D4D4D4]">}</span></code></pre>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="api-bacarat-single" class="fade-up delay-300 scroll-mt-24 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm overflow-hidden mb-10">
                        <div class="px-6 py-5 border-b border-slate-100 dark:border-slate-800/60 flex flex-wrap items-center gap-3 bg-slate-50/50 dark:bg-slate-800/30">
                            <span class="px-3 py-1 bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-black text-[11px] uppercase tracking-wider rounded-lg border border-emerald-200 dark:border-emerald-500/30 shadow-sm">GET</span>
                            <h2 class="text-lg font-bold text-slate-900 dark:text-white">API Dự Đoán Baccarat (Từng Bàn)</h2>
                        </div>
                        
                        <div class="p-6">
                            <div class="group relative bg-[#1E1E1E] dark:bg-[#0d1117] rounded-xl mb-6 shadow-inner overflow-hidden border border-slate-800">
                                <div class="flex items-center gap-2 px-4 py-2.5 bg-[#2D2D2D] dark:bg-[#161b22] border-b border-slate-800">
                                    <div class="w-3 h-3 rounded-full bg-rose-500"></div>
                                    <div class="w-3 h-3 rounded-full bg-amber-500"></div>
                                    <div class="w-3 h-3 rounded-full bg-emerald-500"></div>
                                    <span class="ml-2 text-xs text-slate-400 font-mono">endpoint_url</span>
                                </div>
                                <div class="p-4 flex items-center justify-between gap-4 overflow-x-auto code-scroll">
                                    <code class="text-emerald-400 font-mono text-sm whitespace-nowrap" id="url-bac-single">https://<?= $_SERVER['HTTP_HOST'] ?>/api/v2/bacarat/{TABLE}/{TOKEN}</code>
                                    <button type="button" onclick="copyCode('url-bac-single')" class="shrink-0 w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 text-slate-300 flex items-center justify-center transition-colors">
                                        <i class="ri-file-copy-line"></i>
                                    </button>
                                </div>
                            </div>

                            <h3 class="text-[12px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-3">Response JSON Thành Công</h3>
                            <div class="group relative bg-[#1E1E1E] dark:bg-[#0d1117] rounded-xl shadow-inner border border-slate-800 overflow-hidden">
                                <div class="flex items-center justify-between px-4 py-2.5 bg-[#2D2D2D] dark:bg-[#161b22] border-b border-slate-800">
                                    <div class="flex items-center gap-2">
                                        <div class="w-3 h-3 rounded-full bg-rose-500"></div>
                                        <div class="w-3 h-3 rounded-full bg-amber-500"></div>
                                        <div class="w-3 h-3 rounded-full bg-emerald-500"></div>
                                        <span class="ml-2 text-xs text-slate-400 font-mono">response.json</span>
                                    </div>
                                    <button type="button" onclick="copyCode('res-bac-single')" class="text-xs text-slate-400 hover:text-white transition-colors flex items-center gap-1 font-semibold">
                                        <i class="ri-file-copy-line"></i> Copy
                                    </button>
                                </div>
                                <div class="p-4 overflow-x-auto code-scroll">
<pre><code class="text-sm font-mono leading-relaxed" id="res-bac-single"><span class="text-[#D4D4D4]">{</span>
    <span class="text-[#9CDCFE]">"code"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"200"</span><span class="text-[#D4D4D4]">,</span>
    <span class="text-[#9CDCFE]">"table"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"1"</span><span class="text-[#D4D4D4]">,</span>
    <span class="text-[#9CDCFE]">"data"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#D4D4D4]">[</span>
        <span class="text-[#D4D4D4]">{</span>
            <span class="text-[#9CDCFE]">"table"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"1"</span><span class="text-[#D4D4D4]">,</span>
            <span class="text-[#9CDCFE]">"result"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"BPTPPPPPT"</span><span class="text-[#D4D4D4]">,</span>
            <span class="text-[#9CDCFE]">"round"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"#9"</span><span class="text-[#D4D4D4]">,</span>
            <span class="text-[#9CDCFE]">"prediction"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"B"</span><span class="text-[#D4D4D4]">,</span>
            <span class="text-[#9CDCFE]">"confidence"</span><span class="text-[#D4D4D4]">:</span> <span class="text-[#CE9178]">"87%"</span>
        <span class="text-[#D4D4D4]">}</span>
    <span class="text-[#D4D4D4]">]</span>
<span class="text-[#D4D4D4]">}</span></code></pre>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Cấu hình SweetAlert Toast cho màu sắc hợp Theme
            const Toast = Swal.mixin({
                toast: true, position: 'top-end', showConfirmButton: false, timer: 3000, timerProgressBar: true,
                background: document.documentElement.classList.contains('dark') ? '#1e293b' : '#ffffff',
                color: document.documentElement.classList.contains('dark') ? '#f1f5f9' : '#0f172a'
            });

            // Hàm Copy Code
            window.copyCode = function(elementId) {
                const el = document.getElementById(elementId);
                if(el) {
                    navigator.clipboard.writeText(el.innerText).then(() => {
                        Toast.fire({ icon: 'success', title: 'Đã sao chép vào khay nhớ tạm!' });
                    }).catch(err => {
                        Toast.fire({ icon: 'error', title: 'Lỗi sao chép!' });
                    });
                }
            }

            // Xử lý Active Menu Mục lục
            const tocLinks = document.querySelectorAll('.toc-link');
            
            // Intersection Observer để tự động đổi màu Mục lục khi cuộn tới API tương ứng
            const observerOptions = { root: null, rootMargin: '-100px 0px -40% 0px', threshold: 0 };
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const id = entry.target.getAttribute('id');
                        tocLinks.forEach(link => {
                            if (link.getAttribute('href') === `#${id}`) {
                                link.classList.add('bg-brand-50', 'dark:bg-slate-800/80', 'text-brand-600', 'dark:text-brand-400', 'font-bold');
                            } else {
                                link.classList.remove('bg-brand-50', 'dark:bg-slate-800/80', 'text-brand-600', 'dark:text-brand-400', 'font-bold');
                            }
                        });
                    }
                });
            }, observerOptions);

            document.querySelectorAll('div[id^="api-"]').forEach(section => {
                observer.observe(section);
            });
        });
    </script>
</body>
</html>
