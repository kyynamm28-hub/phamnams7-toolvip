<?php
session_start();

// Kết nối database và load config (Đồng bộ chuẩn như home.php)
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/settings.php';

// Kiểm tra đăng nhập và lấy data (Dùng biến $user_data để không bị lỗi header/nav)
$isLogin = isset($_SESSION['user_id']);
$user_data = null;

if ($isLogin) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
    $stmt->execute(['id' => $_SESSION['user_id']]);
    $user_data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user_data) {
        unset($_SESSION['user_id']);
        $isLogin = false;
    } else {
        // Phân quyền giống home.php
        $is_admin = (strtolower($user_data['role'] ?? 'user') === 'admin');
        $role_display = $is_admin ? 'Quản Trị Viên' : 'Thành Viên';
    }
}

// Biến tên trang đồng bộ với layout
$page_title = 'Câu Hỏi Thường Gặp & Chính Sách';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/collapse@3.x.x/dist/cdn.min.js"></script>
    <style>
        .fade-up { opacity: 0; transform: translateY(15px); animation: fadeUp 0.5s ease-out forwards; }
        .delay-100 { animation-delay: 100ms; }
        .delay-200 { animation-delay: 200ms; }
        .delay-300 { animation-delay: 300ms; }
        @keyframes fadeUp { to { opacity: 1; transform: translateY(0); } }
        /* Tùy chỉnh thanh cuộn cho phần chính sách */
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
        .dark .custom-scrollbar::-webkit-scrollbar-thumb { background: #334155; }
    </style>
</head>

<!-- Khai báo body y hệt như home.php -->
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true', showComingSoon: false }" 
      :class="{ 'dark': darkMode }" 
      class="bg-slate-50 dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-300 relative overflow-x-hidden">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
            
            <!-- HEADER BANNER -->
            <div class="fade-up bg-brand-600 dark:bg-brand-700 rounded-xl p-6 sm:p-8 mb-6 sm:mb-8 border border-brand-700 dark:border-brand-600/50 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative overflow-hidden">
                <div class="relative z-10">
                    <div class="inline-flex items-center gap-2 px-2.5 py-1 rounded-md bg-white/10 text-white text-[11px] font-semibold uppercase tracking-wider mb-3">
                        <i class="ri-shield-check-fill text-green-400"></i> An toàn & Minh bạch
                    </div>
                    <h2 class="text-2xl sm:text-3xl font-bold text-white mb-1.5 uppercase tracking-wide">FAQ & Điều khoản</h2>
                    <p class="text-brand-100 text-sm max-w-2xl leading-relaxed">Tổng hợp các câu hỏi thường gặp và những chính sách ràng buộc pháp lý siêu chi tiết giữa người dùng và hệ thống. Bằng việc đăng ký tài khoản, bạn mặc định đồng ý với mọi điều khoản.</p>
                </div>
                <div class="absolute right-0 top-0 opacity-10 pointer-events-none transform translate-x-1/4 -translate-y-1/4">
                    <i class="ri-question-answer-fill text-[150px] text-white"></i>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                <!-- CỘT TRÁI: CÂU HỎI THƯỜNG GẶP -->
                <div class="lg:col-span-2 space-y-6">
                    <div class="fade-up delay-100 bg-white dark:bg-slate-900 rounded-xl p-6 border border-slate-200 dark:border-slate-800 transition-all hover:border-brand-500/50">
                        <div class="flex items-center gap-3 mb-6 border-b border-slate-100 dark:border-slate-800/60 pb-4">
                            <div class="w-10 h-10 rounded-lg bg-blue-50 dark:bg-blue-500/10 flex items-center justify-center text-blue-600 dark:text-blue-400 shrink-0">
                                <i class="ri-chat-smile-3-line text-xl"></i>
                            </div>
                            <h2 class="text-lg font-bold text-slate-800 dark:text-white uppercase">Câu Hỏi Thường Gặp (FAQ)</h2>
                        </div>
                        
                        <div class="space-y-3">
                            <!-- FAQ Item 1 -->
                            <div x-data="{ expanded: false }" class="border border-slate-200 dark:border-slate-700/60 rounded-xl overflow-hidden transition-all duration-300" :class="expanded ? 'border-blue-500/50 shadow-sm' : 'hover:border-blue-500/30'">
                                <button @click="expanded = !expanded" class="w-full flex items-center justify-between p-4 bg-slate-50/50 dark:bg-slate-800/30 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors text-left focus:outline-none">
                                    <span class="font-semibold text-sm text-slate-800 dark:text-slate-200">Tại sao tôi nạp tiền mà không được cộng số dư?</span>
                                    <div class="w-6 h-6 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center shrink-0 ml-4 transition-transform duration-300" :class="expanded ? 'rotate-180 bg-blue-100 text-blue-600 dark:bg-blue-500/20 dark:text-blue-400' : 'text-slate-500'">
                                        <i class="ri-arrow-down-s-line"></i>
                                    </div>
                                </button>
                                <div x-show="expanded" x-collapse x-cloak>
                                    <div class="p-4 text-sm text-slate-600 dark:text-slate-400 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 leading-relaxed">
                                        Điều này thường xảy ra khi bạn <b class="text-slate-800 dark:text-slate-200">chỉnh sửa hoặc quên nhập NỘI DUNG CHUYỂN KHOẢN</b>. Hệ thống Auto Bank của chúng tôi được thiết kế để đọc nội dung và map với UID tài khoản của bạn. Nếu sai nội dung, giao dịch sẽ trở thành "Giao dịch treo". Vui lòng liên hệ Admin qua Telegram, cung cấp bill chuyển khoản và UID tài khoản để được cộng dồn thủ công. Lưu ý: Lỗi do phía người dùng sẽ bị tính phí xử lý 20%.
                                    </div>
                                </div>
                            </div>
                            
                            <!-- FAQ Item 2 -->
                            <div x-data="{ expanded: false }" class="border border-slate-200 dark:border-slate-700/60 rounded-xl overflow-hidden transition-all duration-300" :class="expanded ? 'border-blue-500/50 shadow-sm' : 'hover:border-blue-500/30'">
                                <button @click="expanded = !expanded" class="w-full flex items-center justify-between p-4 bg-slate-50/50 dark:bg-slate-800/30 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors text-left focus:outline-none">
                                    <span class="font-semibold text-sm text-slate-800 dark:text-slate-200">API của tôi bị lỗi, hệ thống có đền bù không?</span>
                                    <div class="w-6 h-6 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center shrink-0 ml-4 transition-transform duration-300" :class="expanded ? 'rotate-180 bg-blue-100 text-blue-600 dark:bg-blue-500/20 dark:text-blue-400' : 'text-slate-500'">
                                        <i class="ri-arrow-down-s-line"></i>
                                    </div>
                                </button>
                                <div x-show="expanded" x-collapse x-cloak>
                                    <div class="p-4 text-sm text-slate-600 dark:text-slate-400 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 leading-relaxed">
                                        Tất cả API được cam kết Uptime 99.9%. Trong trường hợp API chết (die) do máy chủ, chúng tôi sẽ hoàn lại 100% số tiền tương ứng với thời gian API ngừng hoạt động vào ví của bạn. Tuy nhiên, nếu API bị khóa do bạn lạm dụng (Spam request, DDOS, vượt quá Rate Limit cho phép), chúng tôi sẽ khóa vĩnh viễn tài khoản và KHÔNG hoàn tiền.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- CỘT PHẢI: CHÍNH SÁCH & PHÁP LÝ -->
                <div class="space-y-6">
                    
                    <!-- Box Chính Sách -->
                    <div class="fade-up delay-200 bg-white dark:bg-slate-900 rounded-xl p-6 border border-slate-200 dark:border-slate-800 transition-all hover:border-brand-500/50">
                        <div class="flex items-center gap-3 mb-5 border-b border-slate-100 dark:border-slate-800/60 pb-4">
                            <div class="w-10 h-10 rounded-lg bg-rose-50 dark:bg-rose-500/10 flex items-center justify-center text-rose-600 dark:text-rose-400 shrink-0">
                                <i class="ri-file-paper-2-line text-xl"></i>
                            </div>
                            <h2 class="text-[15px] font-bold text-slate-800 dark:text-white uppercase leading-snug">Chính Sách &<br>Điều Khoản Sử Dụng</h2>
                        </div>
                        
                        <div class="space-y-6 text-[13px] text-slate-600 dark:text-slate-400 leading-relaxed h-[360px] overflow-y-auto pr-3 custom-scrollbar">
                            <div>
                                <h3 class="text-slate-800 dark:text-slate-200 font-bold mb-2 uppercase text-xs flex items-center gap-1.5"><i class="ri-shield-keyhole-line text-brand-500"></i> Điều 1: Thu thập và bảo mật</h3>
                                <p class="mb-2">Hệ thống ZENRO TOOLS cam kết bảo vệ quyền riêng tư dữ liệu cá nhân. Chúng tôi tự động thu thập IP, thiết bị đăng nhập nhằm phát hiện gian lận. Mật khẩu được mã hóa Bcrypt 100% không thể dịch ngược.</p>
                                <p>Bạn có trách nhiệm tự bảo vệ thiết bị. Chúng tôi miễn trừ trách nhiệm nếu tài khoản bị hack do lộ Cookie/Session từ phía cá nhân.</p>
                            </div>

                            <div class="pt-4 border-t border-slate-100 dark:border-slate-800/60">
                                <h3 class="text-slate-800 dark:text-slate-200 font-bold mb-2 uppercase text-xs flex items-center gap-1.5"><i class="ri-refund-2-line text-brand-500"></i> Điều 2: Thanh toán & Hoàn tiền</h3>
                                <p class="mb-2">Tất cả nạp tiền là <b class="text-rose-500">GIAO DỊCH MỘT CHIỀU VÀ KHÔNG THỂ HOÀN TÁC (FIAT)</b>. Số dư chỉ dùng để quy đổi sản phẩm/API trên web.</p>
                                <ul class="list-disc pl-4 space-y-1">
                                    <li>Không hoàn tiền cho sản phẩm Digital đã sinh Key.</li>
                                    <li>Nạp tối thiểu 10.000đ. Giao dịch dưới mức này sẽ bị hủy.</li>
                                    <li>Spam Fake Bill sẽ bị band IP, MAC vĩnh viễn.</li>
                                </ul>
                            </div>

                            <div class="pt-4 border-t border-slate-100 dark:border-slate-800/60">
                                <h3 class="text-slate-800 dark:text-slate-200 font-bold mb-2 uppercase text-xs flex items-center gap-1.5"><i class="ri-error-warning-line text-brand-500"></i> Điều 3: Chống gian lận (Anti-Fraud)</h3>
                                <p class="mb-2">Key API, Tool cung cấp thuộc bản quyền ZENRO DIGITAL MARKETING. NGHIÊM CẤM:</p>
                                <ul class="list-disc pl-4 space-y-1">
                                    <li>Share Key, Tool làm vượt băng thông.</li>
                                    <li>Decompile, Crack, Null mã nguồn.</li>
                                    <li>Dùng cho mục đích lừa đảo, vi phạm pháp luật.</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Box Thông Tin Công Ty -->
                    <div class="fade-up delay-300 bg-slate-100/50 dark:bg-slate-800/30 rounded-xl p-5 border border-slate-200 dark:border-slate-700/50">
                        <h3 class="text-[13px] font-bold text-slate-800 dark:text-white mb-4 uppercase tracking-wide border-b border-slate-200 dark:border-slate-700 pb-2">Thông Tin & Trụ Sở</h3>
                        <div class="space-y-4 text-xs text-slate-600 dark:text-slate-400">
                            
                            <div class="flex items-start gap-2.5">
                                <i class="ri-building-4-fill text-blue-500 mt-0.5 text-base"></i>
                                <div>
                                    <strong class="text-slate-800 dark:text-slate-200 text-[13px]">CÔNG TY TNHH ZENRO DIGITAL MARKETING</strong>
                                    <p class="mt-1">MST: 0318 888 420</p>
                                    <p class="mt-0.5">Thành lập: 15/11/2025</p>
                                </div>
                            </div>
                            
                            <div class="flex items-start gap-2.5">
                                <i class="ri-customer-service-2-fill text-amber-500 mt-0.5 text-base"></i>
                                <div>
                                    <strong class="text-slate-800 dark:text-slate-200">Liên hệ hỗ trợ</strong>
                                    <p class="mt-1">Hotline: 1900 68 69</p>
                                    <p class="mt-0.5">Email: <a href="mailto:contact@zenro.site" class="text-brand-600 dark:text-brand-400 hover:underline">contact@zenro.site</a></p>
                                </div>
                            </div>

                            <div class="flex items-start gap-2.5">
                                <i class="ri-map-pin-2-fill text-rose-500 mt-0.5 text-base"></i>
                                <div>
                                    <strong class="text-slate-800 dark:text-slate-200">Trụ sở chính</strong>
                                    <p class="mt-1 leading-relaxed">Số 69, Đường số 3, Khu phố 7, Phường An Phú, TP. Thủ Đức, TP. Hồ Chí Minh</p>
                                </div>
                            </div>

                            <div class="flex items-start gap-2.5">
                                <i class="ri-map-pin-user-fill text-emerald-500 mt-0.5 text-base"></i>
                                <div>
                                    <strong class="text-slate-800 dark:text-slate-200">Giao dịch số 2</strong>
                                    <p class="mt-1 leading-relaxed">Tầng 12, Tòa nhà Zen Tower, 420 Cộng Hòa, Phường 13, Quận Tân Bình, TP. Hồ Chí Minh</p>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>
</body>
</html>
