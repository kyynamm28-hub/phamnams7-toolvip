<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/settings.php';

if (!isset($_SESSION['user_id'])) { 
    header("Location: /auth/#login"); 
    exit; 
}

$user_id = $_SESSION['user_id'];
$type = $_GET['type'] ?? 'recharge';

// Validate type
if (!in_array($type, ['recharge', 'product', 'work'])) {
    $type = 'recharge';
}

// Fetch thông tin user
$stmtUser = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $user_id]);
$user_data = $stmtUser->fetch(PDO::FETCH_ASSOC);
$is_admin = (strtolower($user_data['role'] ?? 'user') === 'admin');

// Lấy dữ liệu lịch sử dựa theo Tab
$history_data = [];

try {
    if ($type === 'recharge') {
        $pageTitle = 'Lịch Sử Nạp Tiền';
        $icon = 'ri-safe-2-fill';
        $stmt = $pdo->prepare("SELECT order_token as ref_code, content as title, amount, created_at, status, 'Nạp Tiền' as log_type, '' as download_url FROM transfer_history WHERE user_id = ? ORDER BY created_at DESC");
        $stmt->execute([$user_id]);
        $history_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } elseif ($type === 'product') {
        $pageTitle = 'Lịch Sử Mua Hàng';
        $icon = 'ri-shopping-bag-3-fill';
        // Gộp cả 3 bảng (VIP, Token API, và Mã Nguồn/Tools)
        $stmt = $pdo->prepare("
            SELECT CONCAT('VIP', id, LPAD(user_id, 3, '0')) as ref_code, package_name as title, price as amount, purchased_at as created_at, 'paid' as status, 'Gói VIP' as log_type, '' as download_url FROM history_package WHERE user_id = ?
            UNION ALL
            SELECT CONCAT('API', id, LPAD(user_id, 3, '0')) as ref_code, package_name as title, price as amount, purchased_at as created_at, 'paid' as status, 'Token API' as log_type, '' as download_url FROM history_token WHERE user_id = ?
            UNION ALL
            SELECT CONCAT('PRO', id, LPAD(user_id, 3, '0')) as ref_code, product_name as title, price as amount, purchased_at as created_at, 'paid' as status, 'Mã Nguồn' as log_type, download_url FROM history_product WHERE user_id = ?
            ORDER BY created_at DESC
        ");
        $stmt->execute([$user_id, $user_id, $user_id]);
        $history_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } elseif ($type === 'work') {
        $pageTitle = 'Nhật Ký Hoạt Động';
        $icon = 'ri-history-fill';
        $stmt = $pdo->prepare("SELECT CONCAT('LOG', id, LPAD(user_id, 3, '0')) as ref_code, action as title, 0 as amount, created_at, 'paid' as status, 'Hệ Thống' as log_type, '' as download_url FROM user_logs WHERE user_id = ? ORDER BY created_at DESC");
        $stmt->execute([$user_id]);
        $history_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Exception $e) {
    $history_data = [];
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/collapse@3.x.x/dist/cdn.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* Animation Phẳng - Mượt */
        .fade-up { opacity: 0; transform: translateY(15px); animation: fadeUp 0.5s cubic-bezier(0.2, 0.8, 0.2, 1) forwards; }
        @keyframes fadeUp { to { opacity: 1; transform: translateY(0); } }
        
        /* Hiệu ứng nhún (Click Effect) */
        .click-effect { transition: transform 0.15s cubic-bezier(0.4, 0, 0.2, 1); }
        .click-effect:active { transform: scale(0.96); }
        
        /* Thanh cuộn Minimal */
        .custom-scrollbar::-webkit-scrollbar { height: 4px; width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background-color: #cbd5e1; border-radius: 10px; }
        .dark .custom-scrollbar::-webkit-scrollbar-thumb { background-color: #475569; }
        
        /* Ẩn AlpineJS khi chưa load */
        [x-cloak] { display: none !important; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-slate-50 dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-200 relative overflow-x-hidden">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen sm:ml-[260px]">
        
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full fade-up" x-data="historyHandler()">
            
            <!-- Tab Menu -->
            <div class="flex items-center gap-3 mb-6 overflow-x-auto pb-2 custom-scrollbar">
                <a href="/history/recharge" class="click-effect px-5 h-[42px] flex items-center justify-center rounded-xl text-[13px] font-bold transition-colors whitespace-nowrap border <?= $type === 'recharge' ? 'bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-500/30' : 'bg-white dark:bg-[#0f172a] text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-700 dark:hover:text-slate-300' ?>">
                    <i class="ri-safe-2-fill mr-2 text-[16px]"></i> Nạp Tiền
                </a>
                <a href="/history/product" class="click-effect px-5 h-[42px] flex items-center justify-center rounded-xl text-[13px] font-bold transition-colors whitespace-nowrap border <?= $type === 'product' ? 'bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-500/30' : 'bg-white dark:bg-[#0f172a] text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-700 dark:hover:text-slate-300' ?>">
                    <i class="ri-shopping-bag-3-fill mr-2 text-[16px]"></i> Mua Hàng
                </a>
                <a href="/history/work" class="click-effect px-5 h-[42px] flex items-center justify-center rounded-xl text-[13px] font-bold transition-colors whitespace-nowrap border <?= $type === 'work' ? 'bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-500/30' : 'bg-white dark:bg-[#0f172a] text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-700 dark:hover:text-slate-300' ?>">
                    <i class="ri-history-fill mr-2 text-[16px]"></i> Hoạt Động
                </a>
            </div>

            <!-- Bảng Dữ Liệu Phẳng -->
            <div class="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0f172a] overflow-hidden flex flex-col">
                
                <!-- Header Box -->
                <div class="px-5 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-slate-100 dark:border-slate-800 gap-4">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-500/10 flex items-center justify-center">
                            <i class="<?= $icon ?> text-blue-600 dark:text-blue-400 text-lg"></i>
                        </div>
                        <div>
                            <h2 class="text-[15px] font-bold text-slate-800 dark:text-white"><?= $pageTitle ?></h2>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 font-medium mt-0.5">Dữ liệu sẽ tự động xóa sau 7 ngày lưu trữ.</p>
                        </div>
                    </div>
                    <button onclick="window.location.reload()" class="click-effect px-4 h-9 inline-flex items-center justify-center text-[12px] font-bold rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors focus:outline-none">
                        <i class="ri-refresh-line mr-1.5 text-[14px]"></i> Làm Mới
                    </button>
                </div>

                <!-- Table Content -->
                <div class="overflow-x-auto custom-scrollbar">
                    <table class="min-w-full w-full text-left border-collapse">
                        <thead class="bg-slate-50/50 dark:bg-slate-800/30">
                            <tr>
                                <th class="px-5 py-4 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest whitespace-nowrap">Mã Giao Dịch</th>
                                <th class="px-5 py-4 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest whitespace-nowrap">Nội Dung</th>
                                <?php if ($type !== 'work'): ?>
                                <th class="px-5 py-4 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest whitespace-nowrap">Số Tiền</th>
                                <?php endif; ?>
                                <th class="px-5 py-4 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest whitespace-nowrap">Thời Gian</th>
                                <th class="px-5 py-4 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest whitespace-nowrap">Trạng Thái</th>
                                <th class="px-5 py-4 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest whitespace-nowrap text-right">Thao Tác</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-800/80">
                            
                            <?php if (empty($history_data)): ?>
                            <tr>
                                <td colspan="<?= $type !== 'work' ? '6' : '5' ?>" class="px-6 py-16">
                                    <div class="flex flex-col items-center justify-center text-center">
                                        <div class="w-14 h-14 rounded-2xl bg-slate-50 dark:bg-slate-800/50 flex items-center justify-center mb-3">
                                            <i class="ri-file-list-3-fill text-2xl text-slate-300 dark:text-slate-600"></i>
                                        </div>
                                        <div class="text-slate-800 dark:text-white font-bold text-[14px]">Chưa có giao dịch</div>
                                        <div class="text-slate-500 dark:text-slate-400 text-[12px] mt-1">Lịch sử của bạn đang trống.</div>
                                    </div>
                                </td>
                            </tr>
                            <?php else: ?>
                                <?php foreach ($history_data as $row): 
                                    $statusClass = ''; $statusText = '';
                                    if ($row['status'] === 'paid' || $row['status'] === 'success' || $row['status'] === 'completed') {
                                        $statusClass = 'bg-emerald-50 text-emerald-600 border-emerald-100 dark:bg-emerald-500/10 dark:text-emerald-400 dark:border-emerald-500/20';
                                        $statusText = 'Thành Công';
                                    } elseif ($row['status'] === 'pending') {
                                        $statusClass = 'bg-amber-50 text-amber-600 border-amber-100 dark:bg-amber-500/10 dark:text-amber-500 dark:border-amber-500/20';
                                        $statusText = 'Đang Chờ';
                                    } else {
                                        $statusClass = 'bg-rose-50 text-rose-600 border-rose-100 dark:bg-rose-500/10 dark:text-rose-400 dark:border-rose-500/20';
                                        $statusText = 'Thất Bại / Đã Hủy';
                                    }
                                ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors group">
                                    <td class="px-5 py-4 whitespace-nowrap">
                                        <span class="font-mono text-[11px] font-bold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700">
                                            <?= htmlspecialchars(substr($row['ref_code'], 0, 12)) ?>
                                        </span>
                                    </td>
                                    <td class="px-5 py-4 min-w-[200px]">
                                        <div class="text-[13px] font-bold text-slate-800 dark:text-white mb-0.5 line-clamp-1" title="<?= htmlspecialchars($row['title']) ?>">
                                            <?= htmlspecialchars($row['title']) ?>
                                        </div>
                                        <div class="text-[10px] font-bold text-slate-400 uppercase tracking-widest"><?= $row['log_type'] ?></div>
                                    </td>
                                    
                                    <?php if ($type !== 'work'): ?>
                                    <td class="px-5 py-4 whitespace-nowrap">
                                        <span class="text-[13px] font-black text-blue-600 dark:text-blue-400"><?= number_format($row['amount']) ?>đ</span>
                                    </td>
                                    <?php endif; ?>

                                    <td class="px-5 py-4 whitespace-nowrap">
                                        <div class="text-[12px] font-bold text-slate-600 dark:text-slate-300"><?= date('d/m/Y', strtotime($row['created_at'])) ?></div>
                                        <div class="text-[10px] font-bold text-slate-400"><?= date('H:i:s', strtotime($row['created_at'])) ?></div>
                                    </td>
                                    <td class="px-5 py-4 whitespace-nowrap">
                                        <span class="inline-flex items-center px-2 py-1 rounded-md text-[10px] font-bold border <?= $statusClass ?> uppercase tracking-wider">
                                            <?= $statusText ?>
                                        </span>
                                    </td>
                                    <td class="px-5 py-4 whitespace-nowrap text-right">
                                        <button @click="openModal('<?= $row['ref_code'] ?>', '<?= htmlspecialchars(addslashes($row['title'])) ?>', '<?= $row['amount'] ?>', '<?= date('d/m/Y H:i', strtotime($row['created_at'])) ?>', '<?= $statusText ?>', '<?= htmlspecialchars(addslashes($row['download_url'] ?? '')) ?>')" 
                                                class="click-effect w-8 h-8 rounded-lg bg-slate-100 hover:bg-blue-100 text-slate-500 hover:text-blue-600 dark:bg-slate-800 dark:hover:bg-blue-500/20 dark:text-slate-400 dark:hover:text-blue-400 transition-colors inline-flex items-center justify-center focus:outline-none" title="Xem chi tiết">
                                            <i class="ri-eye-fill text-[15px]"></i>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- MODAL CHI TIẾT GIAO DỊCH (Flat Design) -->
            <div x-show="showModal" x-cloak class="fixed inset-0 z-[100] flex items-center justify-center p-4">
                <div class="absolute inset-0 bg-slate-900/60 dark:bg-slate-900/80" @click="showModal = false"></div>
                
                <div class="relative bg-white dark:bg-[#0f172a] w-full max-w-sm rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden" 
                     x-transition:enter="transition ease-out duration-300" 
                     x-transition:enter-start="opacity-0 scale-95 translate-y-4" 
                     x-transition:enter-end="opacity-100 scale-100 translate-y-0">
                    
                    <!-- Modal Header -->
                    <div class="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-800/30">
                        <h3 class="text-[14px] font-bold text-slate-800 dark:text-white uppercase tracking-wide flex items-center gap-2">
                            <i class="ri-receipt-fill text-blue-500"></i> Hóa Đơn Chi Tiết
                        </h3>
                        <button @click="showModal = false" class="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-rose-500 transition-colors focus:outline-none">
                            <i class="ri-close-line text-xl"></i>
                        </button>
                    </div>
                    
                    <!-- Modal Body -->
                    <div class="p-6">
                        <div class="text-center mb-6">
                            <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Mã Giao Dịch</p>
                            <span class="font-mono text-[14px] font-bold text-slate-800 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-lg border border-slate-200 dark:border-slate-700" x-text="modalData.ref"></span>
                        </div>

                        <div class="space-y-4 mb-6">
                            <div class="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-3">
                                <span class="text-[12px] font-bold text-slate-500 dark:text-slate-400">Trạng thái</span>
                                <span class="text-[12px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider" x-text="modalData.status"></span>
                            </div>
                            <div class="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-3">
                                <span class="text-[12px] font-bold text-slate-500 dark:text-slate-400">Thời gian</span>
                                <span class="text-[12px] font-bold text-slate-800 dark:text-white" x-text="modalData.date"></span>
                            </div>
                            <div class="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-3">
                                <span class="text-[12px] font-bold text-slate-500 dark:text-slate-400">Nội dung</span>
                                <span class="text-[12px] font-bold text-slate-800 dark:text-white text-right max-w-[200px] truncate" :title="modalData.title" x-text="modalData.title"></span>
                            </div>
                            <?php if ($type !== 'work'): ?>
                            <div class="flex justify-between items-center pt-1">
                                <span class="text-[12px] font-bold text-slate-500 dark:text-slate-400">Tổng tiền</span>
                                <span class="text-[18px] font-black text-blue-600 dark:text-blue-400" x-text="new Intl.NumberFormat('vi-VN').format(modalData.amount) + 'đ'"></span>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="flex flex-col gap-3">
                            <template x-if="modalData.downloadUrl">
                                <a :href="modalData.downloadUrl" target="_blank" class="click-effect w-full h-[42px] bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-[13px] transition-colors flex items-center justify-center gap-2 focus:outline-none">
                                    <i class="ri-link-m text-[16px]"></i> Tải Source Code
                                </a>
                            </template>

                            <button @click="downloadReceipt()" class="click-effect w-full h-[42px] bg-slate-900 hover:bg-slate-800 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-200 text-white rounded-xl font-bold text-[13px] transition-colors flex items-center justify-center gap-2 focus:outline-none">
                                <i class="ri-download-2-fill text-[16px]"></i> Tải Biên Lai (.txt)
                            </button>
                        </div>
                    </div>
                </div>
            </div>

        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('historyHandler', () => ({
                showModal: false,
                modalData: { ref: '', title: '', amount: 0, date: '', status: '', downloadUrl: '' },

                openModal(ref, title, amount, date, status, downloadUrl = '') {
                    this.modalData = { ref, title, amount, date, status, downloadUrl };
                    this.showModal = true;
                },

                downloadReceipt() {
                    const content = `=== BIÊN LAI GIAO DỊCH ZENRO ===\r\n\r\n`
                                  + `Mã Giao Dịch : ${this.modalData.ref}\r\n`
                                  + `Thời Gian    : ${this.modalData.date}\r\n`
                                  + `Nội Dung     : ${this.modalData.title}\r\n`
                                  + `Trạng Thái   : ${this.modalData.status}\r\n`
                                  <?php if ($type !== 'work'): ?>
                                  + `Tổng Tiền    : ${new Intl.NumberFormat('vi-VN').format(this.modalData.amount)} VNĐ\r\n`
                                  <?php endif; ?>
                                  + `\r\n--------------------------------\r\n`
                                  + `Cảm ơn bạn đã sử dụng dịch vụ!`;

                    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `Zenro_Receipt_${this.modalData.ref}.txt`;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                }
            }));
        });
    </script>
</body>
</html>