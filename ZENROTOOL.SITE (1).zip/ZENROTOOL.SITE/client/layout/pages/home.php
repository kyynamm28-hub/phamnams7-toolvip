<?php
session_start();

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    header("Location: /auth/#login");
    exit;
}

// Kết nối database và load config
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/settings.php';

// Lấy thông tin user
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmt->execute(['id' => $_SESSION['user_id']]);
$user_data = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user_data) {
    session_destroy();
    header("Location: /auth/#login");
    exit;
}

// ---------------------------------------------------------
// LOGIC XỬ LÝ HIỂN THỊ
// ---------------------------------------------------------

$game_count = 0;
try {
    $gStmt = $pdo->query("SELECT COUNT(id) FROM games WHERE status = 'active'");
    $game_count = $gStmt->fetchColumn();
} catch (Exception $e) {
    $game_count = 0; 
}

$vip_name = $user_data['vip_name'] ?? 'Chưa đăng ký';
$vip_expire_text = 'Không có hạn';

if (!empty($user_data['vip_expire_at'])) {
    $expire_time = strtotime($user_data['vip_expire_at']);
    $current_time = time();
    
    if ($expire_time > $current_time) {
        $diff = $expire_time - $current_time;
        $days = floor($diff / (60 * 60 * 24));
        $hours = floor(($diff % (60 * 60 * 24)) / (60 * 60));
        $vip_expire_text = "Còn {$days} ngày {$hours} giờ";
    } else {
        $vip_name = 'Đã hết hạn';
        $vip_expire_text = 'Vui lòng gia hạn';
    }
} else {
    if (empty($user_data['vip_name'])) {
        $vip_expire_text = 'Nâng cấp ngay';
    }
}

$is_admin = (strtolower($user_data['role'] ?? 'user') === 'admin');
$role_display = $is_admin ? 'Quản Trị Viên' : 'Thành Viên';

$page_title = 'Bảng Điều Khiển';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/collapse@3.x.x/dist/cdn.min.js"></script>
    <style>
        /* Animation Phẳng - Mượt */
        .fade-up { opacity: 0; transform: translateY(15px); animation: fadeUp 0.5s cubic-bezier(0.2, 0.8, 0.2, 1) forwards; }
        .delay-100 { animation-delay: 100ms; }
        .delay-200 { animation-delay: 200ms; }
        .delay-300 { animation-delay: 300ms; }
        @keyframes fadeUp { to { opacity: 1; transform: translateY(0); } }
        
        .click-effect { transition: transform 0.15s cubic-bezier(0.4, 0, 0.2, 1); }
        .click-effect:active { transform: scale(0.96); }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true', showComingSoon: false, showRechargePopup: false }" 
      :class="{ 'dark': darkMode }" 
      class="bg-slate-50 dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-200 relative overflow-x-hidden">
    
    <!-- POPUP CHỌN PHƯƠNG THỨC NẠP TIỀN (Chuyên nghiệp) -->
    <div x-show="showRechargePopup" x-cloak class="fixed inset-0 z-[999999] flex items-center justify-center p-4">
        <!-- Overlay -->
        <div x-show="showRechargePopup" x-transition.opacity.duration.300ms @click="showRechargePopup = false" class="absolute inset-0 bg-slate-900/60 dark:bg-slate-900/80"></div>
        
        <!-- Bảng chọn (Modal) -->
        <div x-show="showRechargePopup" 
             x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 scale-95 translate-y-4" x-transition:enter-end="opacity-100 scale-100 translate-y-0" 
             x-transition:leave="transition ease-in duration-200" x-transition:leave-start="opacity-100 scale-100 translate-y-0" x-transition:leave-end="opacity-0 scale-95 translate-y-4" 
             class="relative bg-white dark:bg-[#0f172a] border border-slate-200 dark:border-slate-800 rounded-2xl p-6 w-full max-w-md flex flex-col">
            
            <div class="flex items-center justify-between mb-5">
                <div>
                    <h3 class="text-lg font-bold text-slate-800 dark:text-white">Nạp Tiền Vào Tài Khoản</h3>
                    <p class="text-[12px] text-slate-500 mt-0.5">Vui lòng chọn phương thức giao dịch</p>
                </div>
                <button @click="showRechargePopup = false" class="w-8 h-8 flex items-center justify-center rounded-lg bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-slate-700 dark:hover:text-white transition-colors">
                    <i class="ri-close-line text-xl"></i>
                </button>
            </div>

            <div class="grid grid-cols-1 gap-3">
                <!-- Nạp Ngân Hàng / QR -->
                <a href="/bank/recharge" class="click-effect group flex items-center p-4 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-blue-500 dark:hover:border-blue-500/50 bg-slate-50/50 dark:bg-slate-800/30 hover:bg-blue-50 dark:hover:bg-blue-500/10 transition-colors">
                    <div class="w-12 h-12 rounded-lg bg-blue-100 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center justify-center mr-4 group-hover:scale-110 transition-transform">
                        <i class="ri-qr-code-line text-2xl"></i>
                    </div>
                    <div class="flex-1">
                        <h4 class="text-[14px] font-bold text-slate-800 dark:text-slate-200">Chuyển Khoản / Quét QR</h4>
                        <p class="text-[11px] text-slate-500 mt-0.5">Tự động cộng tiền trong 30 giây (Miễn phí)</p>
                    </div>
                    <i class="ri-arrow-right-s-line text-xl text-slate-300 group-hover:text-blue-500 transition-colors"></i>
                </a>

                <!-- Đổi Thẻ Cào -->
                <a href="/bank/card" class="click-effect group flex items-center p-4 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-emerald-500 dark:hover:border-emerald-500/50 bg-slate-50/50 dark:bg-slate-800/30 hover:bg-emerald-50 dark:hover:bg-emerald-500/10 transition-colors">
                    <div class="w-12 h-12 rounded-lg bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mr-4 group-hover:scale-110 transition-transform">
                        <i class="ri-bank-card-line text-2xl"></i>
                    </div>
                    <div class="flex-1">
                        <h4 class="text-[14px] font-bold text-slate-800 dark:text-slate-200">Đổi Thẻ Cào Điện Thoại</h4>
                        <p class="text-[11px] text-slate-500 mt-0.5">Hỗ trợ Viettel, Mobi, Vina (Có chiết khấu)</p>
                    </div>
                    <i class="ri-arrow-right-s-line text-xl text-slate-300 group-hover:text-emerald-500 transition-colors"></i>
                </a>
            </div>
        </div>
    </div>

    <!-- POPUP COMING SOON -->
    <div x-show="showComingSoon" x-cloak class="fixed inset-0 z-[999999] flex items-center justify-center p-4">
        <div x-show="showComingSoon" x-transition.opacity.duration.300ms @click="showComingSoon = false" class="absolute inset-0 bg-slate-900/60 dark:bg-slate-900/80"></div>
        <div x-show="showComingSoon" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 scale-95 translate-y-4" x-transition:enter-end="opacity-100 scale-100 translate-y-0" class="relative bg-white dark:bg-[#0f172a] border border-slate-200 dark:border-slate-800 rounded-2xl p-8 w-full max-w-sm text-center">
            <div class="mx-auto flex items-center justify-center w-14 h-14 rounded-xl bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 mb-5">
                <i class="ri-rocket-2-fill text-2xl"></i>
            </div>
            <h3 class="text-lg font-bold text-slate-800 dark:text-white mb-2">Sắp Ra Mắt!</h3>
            <p class="text-[13px] text-slate-500 dark:text-slate-400 mb-6">Tính năng đang được phát triển.</p>
            <button @click="showComingSoon = false" class="click-effect w-full h-11 text-[13px] font-bold text-white bg-blue-600 rounded-xl hover:bg-blue-700 transition-colors">Đóng</button>
        </div>
    </div>

    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen sm:ml-[260px]">
        
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-3 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
            
            <!-- HEADER BANNER -->
            <div class="fade-up relative bg-blue-600 rounded-2xl p-5 sm:p-7 mb-5 overflow-hidden">
                <div class="absolute top-0 right-0 -mt-8 -mr-8 w-32 h-32 bg-white/10 rounded-full"></div>
                <div class="absolute bottom-0 right-20 -mb-6 w-24 h-24 bg-white/5 rounded-full"></div>
                
                <div class="relative z-10">
                    <div class="inline-flex items-center gap-2 px-2.5 py-1 rounded-md bg-white/20 text-white text-[10px] font-bold uppercase tracking-widest mb-2">
                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span> Hoạt động ổn định
                    </div>
                    <h2 class="text-xl sm:text-2xl font-bold text-white mb-1">Bảng Điều Khiển</h2>
                    <p class="text-blue-100 text-[12px] max-w-md">Quản lý tổng quan tài khoản và truy cập nhanh các dịch vụ.</p>
                </div>
            </div>

            <!-- THỐNG KÊ TỔNG QUAN (Grid 2x2 Siêu Gọn) -->
            <div class="grid grid-cols-2 gap-3 sm:gap-4 mb-6">
                
                <!-- 1. Số Dư -->
                <div class="fade-up delay-100 bg-white dark:bg-[#0f172a] rounded-xl p-4 border border-slate-200 dark:border-slate-800 flex flex-col justify-between">
                    <div class="flex items-center gap-3 mb-3">
                        <div class="w-10 h-10 rounded-lg bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                            <i class="ri-wallet-3-fill text-lg"></i>
                        </div>
                        <div>
                            <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Số Dư</p>
                            <h4 class="text-[15px] sm:text-lg font-bold text-slate-800 dark:text-white leading-tight truncate"><?= number_format($user_data['balance']) ?>đ</h4>
                        </div>
                    </div>
                    <button @click="showRechargePopup = true" class="click-effect w-full py-2 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-500/20 rounded-lg text-[11px] font-bold transition-colors">
                        Nạp Ngay
                    </button>
                </div>

                <!-- 2. VIP -->
                <div class="fade-up delay-100 bg-white dark:bg-[#0f172a] rounded-xl p-4 border border-slate-200 dark:border-slate-800 flex flex-col justify-between">
                    <div class="flex items-center gap-3 mb-3">
                        <div class="w-10 h-10 rounded-lg bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-500 flex items-center justify-center shrink-0">
                            <i class="ri-vip-diamond-fill text-lg"></i>
                        </div>
                        <div class="min-w-0">
                            <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Cấp Bậc</p>
                            <h4 class="text-[15px] sm:text-lg font-bold <?= $vip_name === 'Đã hết hạn' ? 'text-rose-500' : 'text-amber-600 dark:text-amber-500' ?> leading-tight truncate" title="<?= htmlspecialchars($vip_name) ?>"><?= htmlspecialchars($vip_name) ?></h4>
                        </div>
                    </div>
                    <a href="/thue-vip" class="click-effect w-full py-2 bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-500 hover:bg-amber-100 dark:hover:bg-amber-500/20 rounded-lg text-[11px] font-bold text-center transition-colors">
                        Nâng Cấp
                    </a>
                </div>

                <!-- 3. Kho Công Cụ -->
                <div class="fade-up delay-200 bg-white dark:bg-[#0f172a] rounded-xl p-4 border border-slate-200 dark:border-slate-800 flex flex-col justify-between">
                    <div class="flex items-center gap-3 mb-3">
                        <div class="w-10 h-10 rounded-lg bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                            <i class="ri-apps-2-fill text-lg"></i>
                        </div>
                        <div>
                            <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Công Cụ</p>
                            <h4 class="text-[15px] sm:text-lg font-bold text-slate-800 dark:text-white leading-tight truncate"><?= number_format($game_count) ?> Tools</h4>
                        </div>
                    </div>
                    <a href="/tools" class="click-effect w-full py-2 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg text-[11px] font-bold text-center transition-colors">
                        Truy Cập
                    </a>
                </div>

                <!-- 4. Tài Khoản -->
                <div class="fade-up delay-200 bg-white dark:bg-[#0f172a] rounded-xl p-4 border border-slate-200 dark:border-slate-800 flex flex-col justify-between">
                    <div class="flex items-center gap-3 mb-3">
                        <div class="w-10 h-10 rounded-lg <?= $is_admin ? 'bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400' : 'bg-purple-50 dark:bg-purple-500/10 text-purple-600 dark:text-purple-400' ?> flex items-center justify-center shrink-0">
                            <i class="<?= $is_admin ? 'ri-shield-keyhole-fill' : 'ri-user-4-fill' ?> text-lg"></i>
                        </div>
                        <div class="min-w-0">
                            <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Tài Khoản</p>
                            <h4 class="text-[15px] sm:text-lg font-bold <?= $is_admin ? 'text-rose-600 dark:text-rose-500' : 'text-purple-600 dark:text-purple-400' ?> leading-tight truncate"><?= $role_display ?></h4>
                        </div>
                    </div>
                    <?php if($is_admin): ?>
                        <a href="/admin" class="click-effect w-full py-2 bg-rose-50 dark:bg-rose-500/10 text-rose-700 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-500/20 rounded-lg text-[11px] font-bold text-center transition-colors">
                            Quản Trị
                        </a>
                    <?php else: ?>
                        <a href="/profile" class="click-effect w-full py-2 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg text-[11px] font-bold text-center transition-colors">
                            Cài Đặt
                        </a>
                    <?php endif; ?>
                </div>

            </div>

            <!-- BÀI VIẾT THÔNG BÁO CHI TIẾT -->
            <div class="fade-up delay-300 mb-6">
                <h3 class="text-[13px] font-bold text-slate-800 dark:text-white uppercase tracking-wide mb-3">Thông Báo Hệ Thống</h3>
                
                <div class="bg-white dark:bg-[#0f172a] border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 relative overflow-hidden">
                    <!-- Ribbon trang trí -->
                    <div class="absolute top-0 left-0 w-1 h-full bg-blue-500"></div>

                    <!-- Header Tác Giả -->
                    <div class="flex justify-between items-start mb-4">
                        <div class="flex items-center gap-3">
                            <div class="relative">
                                <img src="/client/layout/assets/images/user.png" alt="Admin" class="w-10 h-10 rounded-full object-cover border border-slate-100 dark:border-slate-700">
                                <div class="absolute -bottom-1 -right-1 w-4 h-4 bg-blue-500 rounded-full border-2 border-white dark:border-[#0f172a] flex items-center justify-center text-white">
                                    <i class="ri-check-line text-[10px]"></i>
                                </div>
                            </div>
                            <div>
                                <h4 class="text-[14px] font-bold text-slate-800 dark:text-white flex items-center gap-1">
                                    Admin Quản Trị
                                </h4>
                                <p class="text-[11px] text-slate-500">Hôm nay lúc 08:30 Sáng</p>
                            </div>
                        </div>
                        <span class="px-2 py-1 bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 text-[9px] font-bold uppercase tracking-widest rounded">Cập Nhật Lớn</span>
                    </div>

                    <!-- Nội dung bài viết -->
                    <div class="pl-0 sm:pl-[52px]">
                        <h3 class="text-[16px] sm:text-lg font-bold text-slate-800 dark:text-white mb-2">🎉 Ra mắt giao diện Flat Design V2 & Tối ưu hóa siêu mượt!</h3>
                        <div class="text-[13px] text-slate-600 dark:text-slate-300 leading-relaxed space-y-3">
                            <p>Chào các thành viên thân thiết, để mang lại trải nghiệm chuyên nghiệp và đẳng cấp hơn, hệ thống vừa tiến hành bản cập nhật giao diện quy mô lớn nhất trong năm.</p>
                            
                            <ul class="space-y-1.5 list-none">
                                <li class="flex items-start gap-2">
                                    <i class="ri-magic-line text-blue-500 mt-0.5"></i>
                                    <span><strong>Flat Design 100%:</strong> Loại bỏ hoàn toàn các lỗi tràn chữ, đè viền trên thiết bị di động. Giao diện trở nên phẳng, sạch sẽ và tối giản hơn.</span>
                                </li>
                                <li class="flex items-start gap-2">
                                    <i class="ri-flashlight-fill text-amber-500 mt-0.5"></i>
                                    <span><strong>Hoạt ảnh siêu mượt:</strong> Bổ sung Click-effect (hiệu ứng nhún) giống hệt các ứng dụng Native cao cấp.</span>
                                </li>
                                <li class="flex items-start gap-2">
                                    <i class="ri-secure-payment-fill text-emerald-500 mt-0.5"></i>
                                    <span><strong>Popup Nạp Tiền:</strong> Tích hợp bảng chọn phương thức nạp tiền thông minh ngay tại trang chủ, không cần tải lại trang.</span>
                                </li>
                            </ul>
                            
                            <p class="pt-2">Cảm ơn các bạn đã luôn đồng hành. Chúc các bạn một ngày trải nghiệm tuyệt vời cùng hệ thống!</p>
                        </div>

                        <!-- Tương tác -->
                        <div class="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center gap-4">
                            <button class="flex items-center gap-1.5 text-[12px] font-semibold text-slate-500 hover:text-rose-500 transition-colors click-effect">
                                <i class="ri-heart-3-line text-[16px]"></i> Đã hiểu
                            </button>
                            <button class="flex items-center gap-1.5 text-[12px] font-semibold text-slate-500 hover:text-blue-500 transition-colors click-effect">
                                <i class="ri-share-forward-line text-[16px]"></i> Chia sẻ
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- HỆ SINH THÁI DỊCH VỤ -->
            <div class="mb-4 fade-up delay-300">
                <h3 class="text-[13px] font-bold text-slate-800 dark:text-white uppercase tracking-wide">Hệ Sinh Thái Dịch Vụ</h3>
            </div>
            
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 fade-up delay-300">
                
                <a href="/tools" class="click-effect bg-white dark:bg-[#0f172a] rounded-xl p-4 border border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500/50 hover:-translate-y-1 transition-all text-center group">
                    <div class="w-10 h-10 mx-auto rounded-lg bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-400 dark:text-slate-500 mb-2 group-hover:bg-blue-50 dark:group-hover:bg-blue-500/10 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                        <i class="ri-apps-2-fill text-xl"></i>
                    </div>
                    <h4 class="text-[12px] font-bold text-slate-800 dark:text-slate-200">Kho Game</h4>
                    <p class="text-[9px] text-slate-500 mt-0.5">Khám phá tools</p>
                </a>
                
                <a href="#" @click.prevent="showComingSoon = true" class="click-effect bg-white dark:bg-[#0f172a] rounded-xl p-4 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500/50 hover:-translate-y-1 transition-all text-center group">
                    <div class="w-10 h-10 mx-auto rounded-lg bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-400 dark:text-slate-500 mb-2 group-hover:bg-emerald-50 dark:group-hover:bg-emerald-500/10 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                        <i class="ri-receipt-fill text-xl"></i>
                    </div>
                    <h4 class="text-[12px] font-bold text-slate-800 dark:text-slate-200">Fake Bill</h4>
                    <p class="text-[9px] text-slate-500 mt-0.5">Tạo bill nhanh</p>
                </a>

                <a href="#" @click.prevent="showComingSoon = true" class="click-effect bg-white dark:bg-[#0f172a] rounded-xl p-4 border border-slate-200 dark:border-slate-800 hover:border-sky-500 dark:hover:border-sky-500/50 hover:-translate-y-1 transition-all text-center group">
                    <div class="w-10 h-10 mx-auto rounded-lg bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-400 dark:text-slate-500 mb-2 group-hover:bg-sky-50 dark:group-hover:bg-sky-500/10 group-hover:text-sky-600 dark:group-hover:text-sky-400 transition-colors">
                        <i class="ri-thumb-up-fill text-xl"></i>
                    </div>
                    <h4 class="text-[12px] font-bold text-slate-800 dark:text-slate-200">Dịch Vụ MXH</h4>
                    <p class="text-[9px] text-slate-500 mt-0.5">Tăng tương tác</p>
                </a>

                <a href="#" @click.prevent="showComingSoon = true" class="click-effect bg-white dark:bg-[#0f172a] rounded-xl p-4 border border-slate-200 dark:border-slate-800 hover:border-purple-500 dark:hover:border-purple-500/50 hover:-translate-y-1 transition-all text-center group">
                    <div class="w-10 h-10 mx-auto rounded-lg bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-400 dark:text-slate-500 mb-2 group-hover:bg-purple-50 dark:group-hover:bg-purple-500/10 group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">
                        <i class="ri-folder-zip-fill text-xl"></i>
                    </div>
                    <h4 class="text-[12px] font-bold text-slate-800 dark:text-slate-200">Tài Nguyên</h4>
                    <p class="text-[9px] text-slate-500 mt-0.5">Source & Data</p>
                </a>

                <a href="#" @click.prevent="showComingSoon = true" class="click-effect bg-white dark:bg-[#0f172a] rounded-xl p-4 border border-slate-200 dark:border-slate-800 hover:border-rose-500 dark:hover:border-rose-500/50 hover:-translate-y-1 transition-all text-center group relative overflow-hidden">
                    <div class="absolute top-0 right-0 px-2 py-0.5 bg-rose-500 rounded-bl-md">
                        <span class="text-[7px] font-bold text-white uppercase tracking-wider">Hot</span>
                    </div>
                    <div class="w-10 h-10 mx-auto rounded-lg bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-400 dark:text-slate-500 mb-2 group-hover:bg-rose-50 dark:group-hover:bg-rose-500/10 group-hover:text-rose-600 dark:group-hover:text-rose-400 transition-colors">
                        <i class="ri-gift-fill text-xl"></i>
                    </div>
                    <h4 class="text-[12px] font-bold text-slate-800 dark:text-slate-200">Túi Mù</h4>
                    <p class="text-[9px] text-slate-500 mt-0.5">Sự kiện bất ngờ</p>
                </a>

            </div>

        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>
</body>
</html>
