<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/settings.php';

if (!isset($_SESSION['user_id'])) { 
    header("Location: /auth/#login"); 
    exit; 
}

// Lấy thông tin User
$stmtUser = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user_data = $stmtUser->fetch(PDO::FETCH_ASSOC);

// Lấy danh sách gói API
$stmtPackages = $pdo->query("SELECT * FROM api_packages WHERE status = 'active' ORDER BY price ASC");
$packages = $stmtPackages->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Đăng Ký Token API';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/collapse@3.x.x/dist/cdn.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); }
        .fade-in { animation: fadeIn 0.4s ease-out forwards; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-neutral-50 dark:bg-gray-900 text-neutral-800 dark:text-gray-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 w-full max-w-5xl mx-auto fade-in" x-data="apiPackageHandler()">
            
            <div class="rounded-2xl border border-neutral-200 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-soft">
                
                <div class="px-6 py-5 border-b border-neutral-100 dark:border-gray-700 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-slate-700 to-slate-800 flex items-center justify-center shadow-inner">
                            <i class="ri-terminal-box-line text-white text-lg"></i>
                        </div>
                        <div>
                            <div class="text-lg font-bold text-neutral-800 dark:text-white uppercase tracking-wide">Thuê Token API</div>
                            <div class="text-xs text-neutral-500 dark:text-gray-400 font-medium">Khởi tạo Token SHA-256 để kết nối với hệ thống dữ liệu</div>
                        </div>
                    </div>
                    <div class="flex items-center gap-2 sm:gap-3 flex-nowrap justify-end">
                        <a href="/document" target="_blank" class="px-4 h-9 inline-flex items-center justify-center text-xs font-semibold rounded-lg border border-neutral-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-neutral-700 dark:text-gray-200 hover:bg-neutral-50 dark:hover:bg-gray-600 transition-colors whitespace-nowrap">
                            <i class="ri-book-read-line mr-1.5"></i>Tài Liệu API
                        </a>
                    </div>
                </div>

                <div class="p-4 sm:p-6 lg:p-8 bg-neutral-50/50 dark:bg-transparent">
                    
                    <?php if (empty($packages)): ?>
                        <div class="flex flex-col items-center justify-center min-h-[300px] bg-white dark:bg-gray-800 rounded-xl border border-dashed border-neutral-200 dark:border-gray-700">
                            <div class="w-16 h-16 rounded-full bg-neutral-100 dark:bg-gray-700 flex items-center justify-center mb-4">
                                <i class="ri-store-3-line text-2xl text-neutral-400"></i>
                            </div>
                            <div class="text-neutral-800 dark:text-white font-bold text-lg">Chưa Cập Nhật Gói API</div>
                            <div class="text-neutral-500 text-sm mt-1 text-center max-w-sm">Hệ thống đang được cấu hình. Vui lòng quay lại sau nhé!</div>
                        </div>
                    <?php else: ?>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                            <?php foreach ($packages as $pkg): ?>
                            <div class="bg-white dark:bg-gray-800 rounded-xl border border-neutral-200 dark:border-gray-700 p-5 shadow-sm hover:border-blue-400 dark:hover:border-blue-500 transition-all group flex flex-col h-full">
                                
                                <div class="flex items-start justify-between mb-4">
                                    <div class="w-12 h-12 rounded-lg bg-neutral-50 dark:bg-gray-700 flex items-center justify-center border border-neutral-100 dark:border-gray-600">
                                        <img src="<?= htmlspecialchars($pkg['image']) ?>" alt="API" class="w-7 h-7 object-contain opacity-80 group-hover:opacity-100 transition-opacity">
                                    </div>
                                    <div class="inline-flex items-center px-2.5 py-1 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-800/30 rounded-md text-[11px] font-bold">
                                        <i class="ri-time-line mr-1"></i> <?= $pkg['duration_days'] ?> Ngày
                                    </div>
                                </div>

                                <div class="flex-1">
                                    <h3 class="text-base font-bold text-neutral-800 dark:text-white mb-2"><?= htmlspecialchars($pkg['name']) ?></h3>
                                    <p class="text-xs text-neutral-500 dark:text-gray-400 leading-relaxed line-clamp-2" title="<?= htmlspecialchars($pkg['description']) ?>">
                                        <?= htmlspecialchars($pkg['description']) ?>
                                    </p>
                                </div>

                                <div class="mt-5 pt-4 border-t border-neutral-100 dark:border-gray-700 flex items-center justify-between">
                                    <div>
                                        <div class="text-[10px] text-neutral-400 uppercase tracking-widest font-semibold mb-0.5">Giá thuê</div>
                                        <div class="text-lg font-black text-blue-600 dark:text-blue-400">
                                            <?= number_format($pkg['price']) ?><span class="text-xs text-neutral-500 font-bold ml-0.5">đ</span>
                                        </div>
                                    </div>
                                    <button @click="buyToken(<?= $pkg['id'] ?>, '<?= htmlspecialchars($pkg['name']) ?>', <?= $pkg['price'] ?>)" class="h-9 px-5 bg-neutral-800 hover:bg-neutral-900 dark:bg-white dark:text-neutral-900 dark:hover:bg-gray-100 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 shadow-sm">
                                        <i class="ri-key-2-line"></i> Đăng Ký
                                    </button>
                                </div>

                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                </div>
            </div>

            <div x-show="showTokenModal" x-cloak class="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-0">
                <div class="absolute inset-0 bg-neutral-900/40 dark:bg-black/60 backdrop-blur-sm" @click="showTokenModal = false"></div>
                <div class="relative bg-white dark:bg-gray-800 w-full max-w-md rounded-[28px] shadow-2xl overflow-hidden" 
                     x-transition:enter="transition ease-out duration-300" 
                     x-transition:enter-start="opacity-0 scale-95 translate-y-4" 
                     x-transition:enter-end="opacity-100 scale-100 translate-y-0">
                    
                    <div class="p-7 sm:p-9">
                        <div class="w-[68px] h-[68px] bg-[#f0fdf4] dark:bg-emerald-900/20 text-[#10b981] rounded-full flex items-center justify-center mx-auto mb-5">
                            <i class="ri-check-line text-4xl font-bold"></i>
                        </div>
                        
                        <h3 class="text-[22px] font-bold text-center text-neutral-800 dark:text-white mb-2 tracking-tight">Đăng Ký Token Thành Công</h3>
                        <p class="text-center text-neutral-500 dark:text-gray-400 text-[13px] mb-8 leading-relaxed px-2">Mã Token của bạn đã được khởi tạo. Vui lòng lưu trữ cẩn thận vì lý do bảo mật.</p>

                        <div class="mb-6 relative">
                            <label class="block text-[11px] font-bold text-neutral-500 dark:text-gray-400 uppercase tracking-widest mb-2 ml-1">Mã API Token (SHA-256)</label>
                            <div class="relative flex items-center">
                                <input type="text" readonly :value="generatedToken" class="w-full bg-white dark:bg-gray-900 border border-neutral-200 dark:border-gray-700 rounded-xl py-3.5 pl-4 pr-12 text-sm font-mono text-neutral-800 dark:text-gray-200 focus:outline-none focus:border-blue-500 transition-colors shadow-sm">
                                <button @click="copyToken()" class="absolute right-2 w-9 h-9 flex items-center justify-center rounded-lg text-neutral-400 hover:text-neutral-700 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-gray-800 transition-colors" title="Copy">
                                    <i class="ri-file-copy-line text-[17px]"></i>
                                </button>
                            </div>
                        </div>

                        <div class="bg-[#eff6ff] dark:bg-blue-900/10 rounded-xl p-4 mb-8 text-[13px] text-blue-700 dark:text-blue-400 flex items-start gap-2.5">
                            <i class="ri-information-line text-lg mt-0.5"></i>
                            <div class="leading-relaxed">
                                Gói <strong x-text="purchasedPackage"></strong> sẽ hết hạn vào lúc <strong x-text="expireDate"></strong>. Hãy tải file Text xuống để tránh quên mã Token này.
                            </div>
                        </div>

                        <div class="flex flex-col gap-3">
                            <button @click="downloadTokenFile()" class="w-full h-[46px] bg-[#1a1a1a] hover:bg-black dark:bg-white dark:text-neutral-900 dark:hover:bg-gray-100 text-white rounded-full font-bold text-[14px] transition-colors flex items-center justify-center gap-2 shadow-md">
                                <i class="ri-download-cloud-2-line text-lg"></i> Tải File (.txt)
                            </button>
                            <button @click="window.location.reload()" class="w-full h-[46px] bg-white dark:bg-gray-800 border border-neutral-200 dark:border-gray-700 text-neutral-700 dark:text-gray-300 hover:bg-neutral-50 dark:hover:bg-gray-700 rounded-full font-bold text-[14px] transition-colors">
                                Đóng & Tải Lại
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('apiPackageHandler', () => ({
                isProcessing: false,
                currentBalance: <?= (int)$user_data['balance'] ?>,
                
                showTokenModal: false,
                generatedToken: '',
                purchasedPackage: '',
                expireDate: '',

                async buyToken(id, name, price) {
                    if (this.isProcessing) return;

                    const confirm = await Swal.fire({
                        title: 'Xác Nhận Đăng Ký',
                        html: `Gói: <b>${name}</b><br>Chi phí: <b>${new Intl.NumberFormat('vi-VN').format(price)}đ</b>`,
                        icon: 'info',
                        showCancelButton: true,
                        confirmButtonColor: '#171717', 
                        cancelButtonColor: '#e5e5e5',
                        cancelButtonText: '<span style="color:#171717">Hủy bỏ</span>',
                        confirmButtonText: 'Thanh Toán',
                        customClass: {
                            popup: document.documentElement.classList.contains('dark') ? 'bg-gray-800 text-white' : ''
                        }
                    });

                    if (confirm.isConfirmed) {
                        if (this.currentBalance < price) {
                            Swal.fire({ icon: 'error', title: 'Số dư không đủ!', text: 'Vui lòng nạp thêm tiền.'}).then(() => window.location.href = '/bank/recharge');
                            return;
                        }

                        this.isProcessing = true;
                        Swal.fire({ title: 'Đang khởi tạo Token...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });

                        try {
                            let formData = new FormData();
                            formData.append('package_id', id);
                            
                            const res = await fetch('/api-handler?action=buy_token', { method: 'POST', body: formData });
                            const data = await res.json();

                            if (data.status === 'success') {
                                // Gọi ngầm thông báo Admin
                                let notifyData = new FormData();
                                notifyData.append('history_id', data.history_id);
                                fetch('/api-handler?action=notify_token', { method: 'POST', body: notifyData });

                                Swal.close();
                                // Hiện Popup Token theo design mới
                                this.generatedToken = data.api_token;
                                this.purchasedPackage = name;
                                this.expireDate = data.expires_at;
                                this.showTokenModal = true;
                            } else {
                                Swal.fire('Lỗi', data.message, 'error');
                            }
                        } catch (e) {
                            Swal.fire('Lỗi', 'Lỗi kết nối máy chủ. Vui lòng thử lại.', 'error');
                        } finally {
                            this.isProcessing = false;
                        }
                    }
                },

                copyToken() {
                    navigator.clipboard.writeText(this.generatedToken);
                    Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Đã copy vào bộ nhớ tạm!', showConfirmButton: false, timer: 1500 });
                },

                downloadTokenFile() {
                    const domain = window.location.hostname;
                    const textContent = `=== ZENRO API TOKEN INFORMATION ===\r\n\r\n`
                                      + `Gói Dịch Vụ  : ${this.purchasedPackage}\r\n`
                                      + `API Token    : ${this.generatedToken}\r\n`
                                      + `Ngày hết hạn : ${this.expireDate}\r\n\r\n`
                                      + `-------------------------------------\r\n`
                                      + `HƯỚNG DẪN SỬ DỤNG:\r\n`
                                      + `1. Copy mã Token bên trên.\r\n`
                                      + `2. Gắn vào tham số {TOKEN} trên thanh URL khi gọi API.\r\n`
                                      + `3. Đọc kỹ tài liệu cấu hình tại: https://${domain}/document\r\n\r\n`
                                      + `Bảo mật Token của bạn. Tuyệt đối không chia sẻ cho người khác!`;

                    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `Zenro_API_Token_${this.generatedToken.substring(0, 8)}.txt`;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                }
            }));
        });
    </script>
</body>
</html>
