<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/settings.php';

if (!isset($_SESSION['user_id'])) { 
    header("Location: /auth/#login"); 
    exit; 
}

// Lấy thông tin User
$stmtUser = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user_data = $stmtUser->fetch(PDO::FETCH_ASSOC);

// Lấy danh sách gói VIP
$stmtPackages = $pdo->query("SELECT * FROM packages WHERE status = 'active' ORDER BY price ASC");
$packages = $stmtPackages->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Nâng Cấp Gói VIP';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/collapse@3.x.x/dist/cdn.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* Animation Phẳng - Mượt */
        .fade-up { opacity: 0; transform: translateY(15px); animation: fadeUp 0.5s cubic-bezier(0.2, 0.8, 0.2, 1) forwards; }
        .delay-100 { animation-delay: 100ms; }
        .delay-200 { animation-delay: 200ms; }
        .delay-300 { animation-delay: 300ms; }
        @keyframes fadeUp { to { opacity: 1; transform: translateY(0); } }
        
        /* Hiệu ứng nhún (Click Effect) cho giao diện phẳng */
        .click-effect { transition: transform 0.15s cubic-bezier(0.4, 0, 0.2, 1); }
        .click-effect:active { transform: scale(0.96); }
        
        /* Ẩn AlpineJS khi chưa load */
        [x-cloak] { display: none !important; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-slate-50 dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-200 relative overflow-x-hidden">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen sm:ml-[260px]">
        
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full" x-data="vipPackageHandler()">
            
            <!-- HEADER PAGE (Đồng bộ Profile/Home) -->
            <div class="mb-6 fade-up flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                    <h2 class="text-xl sm:text-2xl font-bold text-slate-800 dark:text-white">Nâng Cấp VIP</h2>
                    <p class="text-slate-500 dark:text-slate-400 text-[13px] mt-1">Lựa chọn gói VIP phù hợp để mở khóa toàn bộ tính năng và đặc quyền.</p>
                </div>
                <a href="/faq" target="_blank" class="click-effect inline-flex items-center justify-center px-4 h-[42px] rounded-xl bg-white dark:bg-[#0f172a] border border-slate-200 dark:border-slate-800 text-[13px] font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors focus:outline-none">
                    <i class="ri-shield-star-fill text-amber-500 mr-2 text-[16px]"></i> Bảng Quyền Lợi
                </a>
            </div>

            <!-- KHU VỰC DANH SÁCH GÓI VIP -->
            <div class="fade-up delay-100">
                
                <?php if (empty($packages)): ?>
                    <!-- Trạng thái trống (Empty State) -->
                    <div class="flex flex-col items-center justify-center py-20 bg-white dark:bg-[#0f172a] rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 text-center">
                        <div class="w-16 h-16 rounded-2xl bg-slate-50 dark:bg-slate-800/50 flex items-center justify-center mb-4">
                            <i class="ri-store-3-fill text-3xl text-slate-300 dark:text-slate-600"></i>
                        </div>
                        <h3 class="text-[16px] font-bold text-slate-800 dark:text-white mb-2">Chưa Cập Nhật Gói VIP</h3>
                        <p class="text-[13px] text-slate-500 dark:text-slate-400 max-w-[280px]">Hệ thống đang được bảo trì hoặc chưa cấu hình gói. Vui lòng quay lại sau nhé!</p>
                    </div>
                <?php else: ?>
                    <!-- Danh sách gói (Grid 1-2-3 mượt mà) -->
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                        <?php foreach ($packages as $pkg): ?>
                        <div class="bg-white dark:bg-[#0f172a] rounded-2xl border border-slate-200 dark:border-slate-800 p-6 flex flex-col hover:border-amber-400 dark:hover:border-amber-500/50 transition-colors relative overflow-hidden group">
                            
                            <!-- Badge Băng rôn (Thời hạn) -->
                            <div class="absolute top-0 right-0 bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-500 px-3 py-1.5 rounded-bl-xl border-b border-l border-slate-100 dark:border-slate-800/50">
                                <span class="text-[10px] font-bold uppercase tracking-widest flex items-center gap-1">
                                    <i class="ri-time-fill"></i> <?= $pkg['duration_days'] ?> Ngày
                                </span>
                            </div>
                            
                            <!-- Icon & Tiêu đề -->
                            <div class="flex items-center gap-4 mb-4 mt-2">
                                <div class="w-14 h-14 rounded-2xl bg-slate-50 dark:bg-slate-800/50 flex items-center justify-center border border-slate-100 dark:border-slate-700/50 transition-transform group-hover:scale-105">
                                    <img src="<?= htmlspecialchars($pkg['image']) ?>" alt="VIP" class="w-8 h-8 object-contain">
                                </div>
                                <div>
                                    <h3 class="text-[17px] font-bold text-slate-800 dark:text-white leading-tight"><?= htmlspecialchars($pkg['name']) ?></h3>
                                </div>
                            </div>

                            <!-- Mô tả -->
                            <div class="flex-1 mb-6">
                                <p class="text-[13px] font-medium text-slate-500 dark:text-slate-400 leading-relaxed line-clamp-3" title="<?= htmlspecialchars($pkg['description']) ?>">
                                    <?= htmlspecialchars($pkg['description']) ?>
                                </p>
                            </div>

                            <!-- Footer Card: Giá & Nút mua -->
                            <div class="pt-5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                                <div>
                                    <div class="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1">Thanh toán</div>
                                    <div class="text-[20px] font-bold text-amber-500 dark:text-amber-400 leading-none">
                                        <?= number_format($pkg['price']) ?><span class="text-[12px] font-bold text-slate-400 ml-0.5">đ</span>
                                    </div>
                                </div>
                                <button @click="buyPackage(<?= $pkg['id'] ?>, '<?= htmlspecialchars($pkg['name']) ?>', <?= $pkg['price'] ?>)" class="click-effect h-10 px-5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-[13px] font-bold flex items-center gap-2 transition-colors focus:outline-none">
                                    <i class="ri-shopping-cart-2-fill text-[15px]"></i> Mua Gói
                                </button>
                            </div>

                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

            </div>

            <!-- POPUP THÀNH CÔNG (Flat Design Đồng Bộ) -->
            <div x-show="showSuccessModal" x-cloak class="fixed inset-0 z-[100] flex items-center justify-center p-4">
                <div class="absolute inset-0 bg-slate-900/60 dark:bg-slate-900/80" @click="goHome()"></div>
                
                <div class="relative bg-white dark:bg-[#0f172a] w-full max-w-sm rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 text-center" 
                     x-transition:enter="transition ease-out duration-300" 
                     x-transition:enter-start="opacity-0 scale-95 translate-y-4" 
                     x-transition:enter-end="opacity-100 scale-100 translate-y-0">
                    
                    <div class="w-16 h-16 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-500 rounded-2xl flex items-center justify-center mx-auto mb-5">
                        <i class="ri-checkbox-circle-fill text-[32px]"></i>
                    </div>
                    
                    <h3 class="text-lg font-bold text-slate-800 dark:text-white mb-2">Thanh Toán Thành Công!</h3>
                    <p class="text-[13px] font-medium text-slate-500 dark:text-slate-400 mb-6">Đặc quyền VIP của bạn đã được hệ thống kích hoạt ngay lập tức.</p>

                    <div class="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 mb-6 text-left border border-slate-100 dark:border-slate-700/50">
                        <div class="flex justify-between items-center mb-2 pb-2 border-b border-slate-200 dark:border-slate-700">
                            <span class="text-[11px] font-bold text-slate-400 uppercase tracking-widest">Gói Đăng Ký</span>
                            <span class="text-[13px] font-bold text-amber-500" x-text="purchasedPackage"></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-[11px] font-bold text-slate-400 uppercase tracking-widest">Hết hạn</span>
                            <span class="text-[13px] font-bold text-emerald-600 dark:text-emerald-400" x-text="expireDate"></span>
                        </div>
                    </div>

                    <button @click="goHome()" class="click-effect w-full h-[42px] bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-200 rounded-xl font-bold text-[13px] flex items-center justify-center gap-2 transition-colors focus:outline-none">
                        Quay Lại Trang Chủ
                    </button>
                </div>
            </div>

        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('vipPackageHandler', () => ({
                isProcessing: false,
                currentBalance: <?= (int)$user_data['balance'] ?>,
                
                showSuccessModal: false,
                purchasedPackage: '',
                expireDate: '',

                async buyPackage(id, name, price) {
                    if (this.isProcessing) return;

                    // SweetAlert Phẳng & Đồng bộ
                    const confirm = await Swal.fire({
                        title: 'Xác Nhận Nâng Cấp',
                        html: `<div class="text-[13px] mt-1 font-medium text-slate-500 dark:text-slate-400">Gói dịch vụ: <b class="text-slate-800 dark:text-white">${name}</b><br>Thanh toán: <b class="text-amber-500">${new Intl.NumberFormat('vi-VN').format(price)}đ</b></div>`,
                        icon: 'info',
                        showCancelButton: true,
                        confirmButtonColor: '#2563eb', 
                        cancelButtonColor: document.documentElement.classList.contains('dark') ? '#334155' : '#e2e8f0',
                        cancelButtonText: `<span class="${document.documentElement.classList.contains('dark') ? 'text-white' : 'text-slate-700'} font-bold text-[13px]">Hủy Bỏ</span>`,
                        confirmButtonText: '<span class="font-bold text-[13px]">Thanh Toán</span>',
                        background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff',
                        color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a',
                        customClass: {
                            popup: 'rounded-2xl border border-slate-200 dark:border-slate-800'
                        }
                    });

                    if (confirm.isConfirmed) {
                        if (this.currentBalance < price) {
                            Swal.fire({ 
                                icon: 'error', 
                                title: 'Số dư không đủ!', 
                                text: 'Vui lòng nạp thêm tiền để tiếp tục.',
                                confirmButtonColor: '#2563eb',
                                background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff',
                                color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a',
                                customClass: { popup: 'rounded-2xl border border-slate-200 dark:border-slate-800' }
                            }).then(() => window.location.href = '/bank/recharge');
                            return;
                        }

                        this.isProcessing = true;
                        Swal.fire({ 
                            title: 'Đang xử lý giao dịch...', 
                            allowOutsideClick: false, 
                            background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff',
                            color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a',
                            customClass: { popup: 'rounded-2xl border border-slate-200 dark:border-slate-800' },
                            didOpen: () => Swal.showLoading() 
                        });

                        try {
                            let formData = new FormData();
                            formData.append('package_id', id);
                            
                            const res = await fetch('/api-handler?action=buy_vip', { method: 'POST', body: formData });
                            const data = await res.json();

                            if (data.status === 'success') {
                                // Gọi ngầm notify_vip
                                let notifyData = new FormData();
                                notifyData.append('history_id', data.history_id);
                                await fetch('/api-handler?action=notify_vip', { method: 'POST', body: notifyData }).catch(e => console.log(e));

                                Swal.close();
                                
                                this.purchasedPackage = name;
                                this.expireDate = data.expires_at || "Cộng dồn vào tài khoản"; 
                                this.showSuccessModal = true;
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Lỗi giao dịch',
                                    text: data.message,
                                    confirmButtonColor: '#2563eb',
                                    background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff',
                                    color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a',
                                    customClass: { popup: 'rounded-2xl border border-slate-200 dark:border-slate-800' }
                                });
                            }
                        } catch (e) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Lỗi kết nối',
                                text: 'Mất kết nối với máy chủ, vui lòng thử lại sau.',
                                confirmButtonColor: '#2563eb',
                                background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff',
                                color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a',
                                customClass: { popup: 'rounded-2xl border border-slate-200 dark:border-slate-800' }
                            });
                        } finally {
                            this.isProcessing = false;
                        }
                    }
                },

                goHome() {
                    window.location.href = '/home';
                }
            }));
        });
    </script>
</body>
</html>
