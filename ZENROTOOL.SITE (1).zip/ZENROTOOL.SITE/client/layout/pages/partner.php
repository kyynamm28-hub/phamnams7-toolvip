<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/settings.php';

$isLogin = isset($_SESSION['user_id']);
$user_data = null;

if ($isLogin) {
    // Lấy thông tin User để Header hiển thị đúng Số dư
    $stmtUser = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
    $stmtUser->execute(['id' => $_SESSION['user_id']]);
    $user_data = $stmtUser->fetch(PDO::FETCH_ASSOC);
}

// Lấy danh sách đối tác
$stmtPartners = $pdo->query("SELECT * FROM partners WHERE status = 'active' ORDER BY id DESC");
$partners = $stmtPartners->fetchAll(PDO::FETCH_ASSOC);

// Lấy cấu hình bảng giá quảng cáo
$stmtSetting = $pdo->query("SELECT * FROM setting_partner LIMIT 1");
$setting_partner = $stmtSetting->fetch(PDO::FETCH_ASSOC);

// Fallback nếu chưa cấu hình DB
if (!$setting_partner) {
    $setting_partner = [
        'price_day' => 20000,
        'price_week' => 80000,
        'price_month' => 300000,
        'contact_link' => '#'
    ];
}

$pageTitle = 'Đối Tác & Quảng Cáo';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/collapse@3.x.x/dist/cdn.min.js"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); }
        .fade-in-up { animation: fadeInUp 0.5s ease-out forwards; }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(15px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-neutral-50 dark:bg-gray-900 text-neutral-800 dark:text-gray-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 w-full max-w-5xl mx-auto fade-in-up">
            
            <div class="mb-10">
                <div class="flex items-center gap-3 mb-6">
                    <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-inner">
                        <i class="ri-shake-hands-fill text-xl"></i>
                    </div>
                    <div>
                        <h1 class="text-xl font-black text-neutral-800 dark:text-white uppercase tracking-wide">Hợp Tác Cùng Chúng Tôi</h1>
                        <p class="text-xs text-neutral-500 dark:text-gray-400 font-medium">Danh sách các đối tác uy tín đang đồng hành cùng nền tảng</p>
                    </div>
                </div>

                <?php if (empty($partners)): ?>
                    <div class="bg-white dark:bg-gray-800 rounded-2xl border border-neutral-200 dark:border-gray-700 p-10 flex flex-col items-center justify-center shadow-soft">
                        <div class="w-16 h-16 rounded-full bg-neutral-100 dark:bg-gray-700 flex items-center justify-center mb-4 border border-neutral-200 dark:border-gray-600">
                            <i class="ri-links-line text-3xl text-neutral-400"></i>
                        </div>
                        <h3 class="text-base font-bold text-neutral-800 dark:text-white mb-1">Chưa Có Đối Tác Nào</h3>
                        <p class="text-neutral-500 text-sm">Hãy là người đầu tiên đặt logo tại đây!</p>
                    </div>
                <?php else: ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <?php foreach ($partners as $p): ?>
                        <div class="bg-white dark:bg-gray-800 rounded-2xl border border-neutral-200 dark:border-gray-700 p-5 shadow-soft hover:border-blue-400 hover:shadow-md transition-all flex flex-col sm:flex-row items-center text-center sm:text-left gap-5 group">
                            
                            <div class="w-20 h-20 shrink-0 rounded-full border border-neutral-100 dark:border-gray-600 p-1 bg-neutral-50 dark:bg-gray-700 group-hover:scale-105 transition-transform duration-300">
                                <img src="<?= htmlspecialchars($p['logo_url']) ?>" alt="Logo" class="w-full h-full rounded-full object-cover">
                            </div>

                            <div class="flex-1">
                                <h3 class="text-base font-bold text-neutral-800 dark:text-white mb-1 uppercase tracking-tight"><?= htmlspecialchars($p['name']) ?></h3>
                                <p class="text-[13px] text-neutral-500 dark:text-gray-400 line-clamp-2 leading-relaxed mb-4 sm:mb-0">
                                    <?= htmlspecialchars($p['description']) ?>
                                </p>
                            </div>

                            <div class="shrink-0 w-full sm:w-auto">
                                <a href="<?= htmlspecialchars($p['website_url']) ?>" target="_blank" class="w-full sm:w-auto px-5 h-10 inline-flex items-center justify-center text-[13px] font-bold rounded-xl border border-neutral-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-neutral-700 dark:text-gray-200 hover:bg-neutral-900 hover:text-white dark:hover:bg-white dark:hover:text-neutral-900 transition-colors gap-2">
                                    Truy Cập Ngay <i class="ri-external-link-line"></i>
                                </a>
                            </div>

                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="pt-8 border-t border-neutral-200 dark:border-gray-800">
                
                <div class="text-center max-w-2xl mx-auto mb-10">
                    <span class="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 rounded-md text-[11px] font-bold border border-emerald-100 dark:border-emerald-800/30 uppercase tracking-wider mb-4">
                        <i class="ri-megaphone-line"></i> Quảng Cáo Hệ Thống
                    </span>
                    <h2 class="text-2xl sm:text-3xl font-black text-neutral-800 dark:text-white uppercase tracking-tight mb-3">Bảng Giá Quảng Cáo Đối Tác</h2>
                    <p class="text-sm text-neutral-500 dark:text-gray-400 leading-relaxed">
                        Logo & thương hiệu của bạn sẽ được hiển thị đến toàn bộ khách hàng trên nền tảng. Tiếp cận hàng ngàn người dùng tiềm năng mỗi ngày.
                    </p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
                    
                    <div class="bg-white dark:bg-gray-800 rounded-3xl border border-neutral-200 dark:border-gray-700 p-6 shadow-soft hover:shadow-lg transition-shadow flex flex-col relative overflow-hidden">
                        <div class="text-neutral-500 dark:text-gray-400 font-bold uppercase tracking-widest text-xs mb-4">Gói Ngày</div>
                        <div class="flex items-baseline gap-1 text-neutral-800 dark:text-white mb-6">
                            <span class="text-4xl font-black"><?= number_format($setting_partner['price_day']) ?></span>
                            <span class="text-lg font-bold text-neutral-400">đ</span>
                        </div>
                        <ul class="space-y-3.5 mb-8 flex-1">
                            <li class="flex items-start gap-2.5 text-sm text-neutral-600 dark:text-gray-300 font-medium">
                                <i class="ri-checkbox-circle-fill text-emerald-500 text-lg"></i> Logo + Tên hiển thị
                            </li>
                            <li class="flex items-start gap-2.5 text-sm text-neutral-600 dark:text-gray-300 font-medium">
                                <i class="ri-checkbox-circle-fill text-emerald-500 text-lg"></i> Link website, chuyển hướng
                            </li>
                            <li class="flex items-start gap-2.5 text-sm text-neutral-600 dark:text-gray-300 font-medium">
                                <i class="ri-checkbox-circle-fill text-emerald-500 text-lg"></i> Hiển thị cho tất cả thành viên
                            </li>
                        </ul>
                    </div>

                    <div class="bg-white dark:bg-gray-800 rounded-3xl border border-neutral-200 dark:border-gray-700 p-6 shadow-soft hover:shadow-lg transition-shadow flex flex-col relative overflow-hidden">
                        <div class="text-neutral-500 dark:text-gray-400 font-bold uppercase tracking-widest text-xs mb-4">Gói Tuần</div>
                        <div class="flex items-baseline gap-1 text-neutral-800 dark:text-white mb-6">
                            <span class="text-4xl font-black"><?= number_format($setting_partner['price_week']) ?></span>
                            <span class="text-lg font-bold text-neutral-400">đ</span>
                        </div>
                        <ul class="space-y-3.5 mb-8 flex-1">
                            <li class="flex items-start gap-2.5 text-sm text-neutral-600 dark:text-gray-300 font-medium">
                                <i class="ri-checkbox-circle-fill text-emerald-500 text-lg"></i> Logo + Tên hiển thị
                            </li>
                            <li class="flex items-start gap-2.5 text-sm text-neutral-600 dark:text-gray-300 font-medium">
                                <i class="ri-checkbox-circle-fill text-emerald-500 text-lg"></i> Link website, chuyển hướng
                            </li>
                            <li class="flex items-start gap-2.5 text-sm text-neutral-600 dark:text-gray-300 font-medium">
                                <i class="ri-checkbox-circle-fill text-emerald-500 text-lg"></i> Hiển thị cho tất cả thành viên
                            </li>
                            <li class="flex items-start gap-2.5 text-[13px] text-blue-600 dark:text-blue-400 font-bold bg-blue-50 dark:bg-blue-900/20 px-3 py-1.5 rounded-lg border border-blue-100 dark:border-blue-800/30">
                                <i class="ri-funds-line text-base"></i> Tiết kiệm hơn 42.9% so với ngày
                            </li>
                        </ul>
                    </div>

                    <div class="bg-neutral-900 dark:bg-[#0f172a] rounded-3xl border border-neutral-800 dark:border-gray-700 p-6 shadow-lg shadow-neutral-900/20 relative overflow-hidden flex flex-col">
                        <div class="absolute top-0 right-0 w-32 h-32 bg-indigo-500/20 rounded-full blur-2xl"></div>
                        <div class="relative z-10">
                            <div class="flex items-center justify-between mb-4">
                                <div class="text-neutral-400 font-bold uppercase tracking-widest text-xs">Gói Tháng</div>
                                <div class="px-2.5 py-1 bg-amber-500/20 text-amber-500 rounded border border-amber-500/30 text-[10px] font-black uppercase tracking-wider">Đề Xuất</div>
                            </div>
                            <div class="flex items-baseline gap-1 text-white mb-6">
                                <span class="text-4xl font-black"><?= number_format($setting_partner['price_month']) ?></span>
                                <span class="text-lg font-bold text-neutral-500">đ</span>
                            </div>
                            <ul class="space-y-3.5 mb-8 flex-1">
                                <li class="flex items-start gap-2.5 text-sm text-neutral-300 font-medium">
                                    <i class="ri-checkbox-circle-fill text-emerald-400 text-lg"></i> Logo + Tên hiển thị
                                </li>
                                <li class="flex items-start gap-2.5 text-sm text-neutral-300 font-medium">
                                    <i class="ri-checkbox-circle-fill text-emerald-400 text-lg"></i> Link website, chuyển hướng
                                </li>
                                <li class="flex items-start gap-2.5 text-sm text-neutral-300 font-medium">
                                    <i class="ri-checkbox-circle-fill text-emerald-400 text-lg"></i> Hiển thị cho tất cả thành viên
                                </li>
                                <li class="flex items-start gap-2.5 text-sm text-amber-400 font-bold">
                                    <i class="ri-star-smile-fill text-lg"></i> Ưu tiên vị trí đầu tiên
                                </li>
                                <li class="flex items-start gap-2.5 text-sm text-amber-400 font-bold">
                                    <i class="ri-telegram-fill text-lg"></i> Quảng cáo trên kênh Telegram
                                </li>
                            </ul>
                        </div>
                    </div>

                </div>

                <div class="bg-blue-50 dark:bg-gray-800/80 rounded-2xl border border-blue-100 dark:border-gray-700 p-8 text-center max-w-3xl mx-auto shadow-sm">
                    <div class="w-14 h-14 bg-white dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm border border-blue-100 dark:border-gray-600">
                        <i class="ri-customer-service-2-fill text-2xl text-blue-500"></i>
                    </div>
                    <p class="text-sm font-semibold text-neutral-600 dark:text-gray-300 mb-6 leading-relaxed">
                        Hiệu lực quảng cáo có tác dụng ngay sau khi xác nhận & thanh toán. Vui lòng liên hệ Admin để được hỗ trợ set up nhanh nhất.
                    </p>
                    <a href="<?= htmlspecialchars($setting_partner['contact_link']) ?>" target="_blank" class="inline-flex h-12 items-center justify-center px-8 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-[14px] transition-colors gap-2 shadow-md hover:shadow-lg">
                        <i class="ri-send-plane-fill"></i> Liên Hệ Đặt Quảng Cáo
                    </a>
                </div>

            </div>

        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>
</body>
</html>
