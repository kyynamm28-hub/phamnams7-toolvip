<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/settings.php';

if (!isset($_SESSION['user_id'])) { header("Location: /auth/#login"); exit; }

$stmtUser = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user_data = $stmtUser->fetch(PDO::FETCH_ASSOC);

// Lấy danh sách sản phẩm kèm ảnh chính (is_primary = 1)
$stmtProds = $pdo->query("
    SELECT p.*, pi.image_url 
    FROM products p 
    LEFT JOIN product_images pi ON p.id = pi.product_id AND pi.is_primary = 1 
    WHERE p.status = 'active' 
    ORDER BY p.id DESC
");
$products = $stmtProds->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Kho Mã Nguồn & Tools';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/collapse@3.x.x/dist/cdn.min.js"></script>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-neutral-50 dark:bg-gray-900 text-neutral-800 dark:text-gray-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 w-full max-w-7xl mx-auto">
            
            <div class="mb-8 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                <div>
                    <h1 class="text-2xl font-black text-neutral-800 dark:text-white uppercase tracking-wide">Cửa Hàng Kỹ Thuật Số</h1>
                    <p class="text-sm text-neutral-500 dark:text-gray-400 mt-1">Cung cấp mã nguồn, tools, script bản quyền chất lượng cao.</p>
                </div>
            </div>

            <?php if (empty($products)): ?>
                <div class="bg-white dark:bg-gray-800 rounded-2xl border border-neutral-200 dark:border-gray-700 p-12 flex flex-col items-center justify-center min-h-[400px]">
                    <i class="ri-shopping-cart-2-line text-6xl text-neutral-300 dark:text-gray-600 mb-4"></i>
                    <h3 class="text-lg font-bold text-neutral-600 dark:text-gray-300">Cửa hàng đang trống</h3>
                </div>
            <?php else: ?>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    <?php foreach ($products as $p): 
                        $img = $p['image_url'] ?: 'https://placehold.co/600x400/f8fafc/94a3b8?text=No+Image';
                    ?>
                    <div class="bg-white dark:bg-gray-800 rounded-2xl border border-neutral-200 dark:border-gray-700 overflow-hidden shadow-sm hover:shadow-md hover:border-blue-400 transition-all flex flex-col group">
                        
                        <a href="/view/<?= htmlspecialchars($p['slug']) ?>" class="block relative aspect-video overflow-hidden bg-neutral-100 dark:bg-gray-700">
                            <img src="<?= htmlspecialchars($img) ?>" alt="Product" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                            <div class="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors"></div>
                        </a>

                        <div class="p-5 flex flex-col flex-1">
                            <a href="/view/<?= htmlspecialchars($p['slug']) ?>" class="text-base font-bold text-neutral-800 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 line-clamp-2 mb-2 transition-colors">
                                <?= htmlspecialchars($p['name']) ?>
                            </a>
                            <p class="text-xs text-neutral-500 dark:text-gray-400 line-clamp-2 mb-4 flex-1">
                                <?= htmlspecialchars($p['short_description']) ?>
                            </p>
                            
                            <div class="flex items-center justify-between mt-auto pt-4 border-t border-neutral-100 dark:border-gray-700">
                                <div class="text-lg font-black text-blue-600 dark:text-blue-400">
                                    <?= number_format($p['price']) ?><span class="text-xs ml-0.5 text-neutral-400">đ</span>
                                </div>
                                <a href="/view/<?= htmlspecialchars($p['slug']) ?>" class="px-4 py-2 bg-neutral-800 hover:bg-neutral-900 dark:bg-white dark:text-neutral-900 dark:hover:bg-gray-100 text-white text-xs font-bold rounded-lg transition-colors">
                                    Xem Ngay
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>
</body>
</html>
