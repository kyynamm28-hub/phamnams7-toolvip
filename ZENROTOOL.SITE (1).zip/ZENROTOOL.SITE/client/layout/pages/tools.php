<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/settings.php';

// 1. KIỂM TRA ĐĂNG NHẬP
if (!isset($_SESSION['user_id'])) { 
    header("Location: /auth/#login"); 
    exit; 
}

// 2. LẤY THÔNG TIN USER VÀ ĐỒNG BỘ BIẾN
$stmtUser = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user_data = $stmtUser->fetch(PDO::FETCH_ASSOC);

if (!$user_data) {
    session_destroy();
    header("Location: /auth/#login");
    exit;
}

$user = $user_data;
$userData = $user_data;
$userInfo = $user_data;
$balance = number_format($user_data['balance'] ?? 0, 0, ',', '.');
$initial = strtoupper(substr($user_data['username'] ?? $user_data['display_name'] ?? 'U', 0, 1));
$user_avatar = $user_data['avatar'] ?? '';

// Kiểm tra VIP
$is_vip = false;
if (!empty($user_data['vip_expire_at']) && strtotime($user_data['vip_expire_at']) > time()) {
    $is_vip = true;
}

// 3. LẤY DANH SÁCH DANH MỤC TỪ DATABASE
try {
    $stmtCategories = $pdo->query("SELECT * FROM category WHERE status = 'active' ORDER BY position ASC");
    $categories = $stmtCategories->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $categories = [];
}

// 4. LẤY DANH SÁCH GAME
try {
    $stmtGames = $pdo->query("SELECT * FROM games WHERE status = 'active' ORDER BY position ASC, id DESC");
    $games = $stmtGames->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $games = []; 
}

// 5. TÍNH TOÁN SỐ LƯỢNG GAME CHO TỪNG DANH MỤC
$categoryCounts = ['all' => count($games)];
foreach ($games as $game) {
    $catSlug = strtolower($game['category'] ?? 'khac');
    if (!isset($categoryCounts[$catSlug])) $categoryCounts[$catSlug] = 0;
    $categoryCounts[$catSlug]++;
}

// 6. HÀM XỬ LÝ LOGIC ĐƯỜNG DẪN URL GAME
function generateGameUrl($game) {
    $category = strtolower($game['category'] ?? '');
    $slug = $game['slug'] ?? '';
    
    if ($category === 'bacarat') return "/game/bacarat";
    if ($category === 'taixiu' || $category === 'tai_xiu') return "/game/taixiu/" . $slug; 
    if ($category === 'sicbo') return "/game/sicbo/" . $slug; 
    
    return "#";
}

$pageTitle = 'Kho Tiện Ích & Game';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        /* Animation Phẳng - Mượt */
        .fade-up { opacity: 0; transform: translateY(15px); animation: fadeUp 0.5s cubic-bezier(0.2, 0.8, 0.2, 1) forwards; }
        @keyframes fadeUp { to { opacity: 1; transform: translateY(0); } }
        
        /* Hiệu ứng nhún (Click Effect) */
        .click-effect { transition: transform 0.15s cubic-bezier(0.4, 0, 0.2, 1); }
        .click-effect:active { transform: scale(0.96); }
        
        /* Thanh cuộn Minimal */
        .custom-scrollbar::-webkit-scrollbar { height: 4px; width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background-color: #cbd5e1; border-radius: 10px; }
        .dark .custom-scrollbar::-webkit-scrollbar-thumb { background-color: #475569; }
        
        [x-cloak] { display: none !important; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-slate-50 dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-200 relative overflow-x-hidden">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen sm:ml-[260px]">
        
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full fade-up" 
              x-data="{ 
                  searchQuery: '', 
                  activeTab: 'all',
                  get filteredGames() {
                      const query = this.searchQuery.toLowerCase();
                      const items = Array.from(document.querySelectorAll('.game-item'));
                      let visibleCount = 0;
                      
                      items.forEach(el => {
                          const name = el.getAttribute('data-name').toLowerCase();
                          const cat = el.getAttribute('data-category').toLowerCase();
                          
                          const matchSearch = name.includes(query);
                          const matchTab = this.activeTab === 'all' || cat === this.activeTab;
                          
                          if (matchSearch && matchTab) {
                              el.style.display = 'flex';
                              visibleCount++;
                          } else {
                              el.style.display = 'none';
                          }
                      });
                      return visibleCount;
                  }
              }">
            
            <!-- HEADER PAGE & SEARCH -->
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                <div>
                    <h2 class="text-xl sm:text-2xl font-bold text-slate-800 dark:text-white">Kho Công Cụ</h2>
                    <p class="text-[13px] text-slate-500 dark:text-slate-400 mt-1">Khám phá và sử dụng các công cụ hỗ trợ độc quyền từ hệ thống.</p>
                </div>
                <div class="relative w-full sm:w-72">
                    <i class="ri-search-line absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 text-[16px]"></i>
                    <input type="text" x-model="searchQuery" @input="filteredGames" placeholder="Tìm kiếm tên công cụ..." 
                           class="w-full h-11 pl-10 pr-4 bg-white dark:bg-[#0f172a] border border-slate-200 dark:border-slate-800 rounded-xl text-[13px] font-medium text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all placeholder:text-slate-400">
                </div>
            </div>

            <!-- BANNER TRẠNG THÁI VIP -->
            <?php if ($is_vip): ?>
                <div class="bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/20 rounded-2xl p-5 mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div class="flex items-center gap-4">
                        <div class="w-12 h-12 bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center justify-center shrink-0">
                            <i class="ri-vip-diamond-fill text-[24px]"></i>
                        </div>
                        <div>
                            <div class="text-[15px] font-bold text-emerald-800 dark:text-emerald-400 mb-0.5">Đặc Quyền Đã Mở Khóa</div>
                            <div class="text-[12px] font-medium text-emerald-600 dark:text-emerald-500/80">Bạn đang dùng gói VIP, có thể truy cập toàn bộ công cụ. Hạn đến <span class="font-bold"><?= date('d/m/Y', strtotime($user_data['vip_expire_at'])) ?></span></div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/20 rounded-2xl p-5 mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div class="flex items-center gap-4">
                        <div class="w-12 h-12 bg-rose-100 dark:bg-rose-500/20 text-rose-600 dark:text-rose-400 rounded-xl flex items-center justify-center shrink-0">
                            <i class="ri-lock-2-fill text-[24px]"></i>
                        </div>
                        <div>
                            <div class="text-[15px] font-bold text-rose-800 dark:text-rose-400 mb-0.5">Công Cụ Đang Bị Khóa</div>
                            <div class="text-[12px] font-medium text-rose-600 dark:text-rose-500/80">Bạn cần có Đặc quyền VIP để truy cập hệ thống công cụ.</div>
                        </div>
                    </div>
                    <a href="/thue-vip" class="click-effect h-10 px-5 bg-rose-500 hover:bg-rose-600 text-white rounded-xl text-[13px] font-bold transition-colors flex items-center justify-center gap-2 whitespace-nowrap focus:outline-none">
                        <i class="ri-vip-diamond-fill"></i> Nâng Cấp VIP
                    </a>
                </div>
            <?php endif; ?>

            <!-- TABS DANH MỤC (Flat Buttons) -->
            <div class="flex items-center gap-2.5 overflow-x-auto pb-4 mb-2 custom-scrollbar">
                
                <!-- Tab All -->
                <button @click="activeTab = 'all'; filteredGames;" 
                        :class="activeTab === 'all' ? 'bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500' : 'bg-white dark:bg-[#0f172a] text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50'"
                        class="click-effect h-10 px-4 rounded-xl text-[12px] font-bold uppercase tracking-wider flex items-center justify-center gap-2 border transition-all whitespace-nowrap focus:outline-none">
                    <i class="ri-apps-2-fill text-[16px]"></i> Tất Cả
                    <span class="ml-1 px-1.5 py-0.5 rounded-md text-[10px]" :class="activeTab === 'all' ? 'bg-blue-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-500'">
                        <?= $categoryCounts['all'] ?>
                    </span>
                </button>

                <?php if (!empty($categories)): ?>
                    <?php foreach ($categories as $cat): 
                        $slug = $cat['slug'];
                        $count = $categoryCounts[$slug] ?? 0;
                    ?>
                    <button @click="activeTab = '<?= $slug ?>'; filteredGames;" 
                            :class="activeTab === '<?= $slug ?>' ? 'bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500' : 'bg-white dark:bg-[#0f172a] text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50'"
                            class="click-effect h-10 px-4 rounded-xl text-[12px] font-bold uppercase tracking-wider flex items-center justify-center gap-2 border transition-all whitespace-nowrap focus:outline-none">
                        <img src="<?= htmlspecialchars($cat['icon']) ?>" class="w-[16px] h-[16px] object-contain" :class="activeTab === '<?= $slug ?>' ? '' : 'grayscale opacity-60'">
                        <?= htmlspecialchars($cat['name']) ?>
                        <span class="ml-1 px-1.5 py-0.5 rounded-md text-[10px]" :class="activeTab === '<?= $slug ?>' ? 'bg-blue-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-500'">
                            <?= $count ?>
                        </span>
                    </button>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- DANH SÁCH GAME (Grid Layout) -->
            <?php if (empty($games)): ?>
                <div class="flex flex-col items-center justify-center py-20 bg-white dark:bg-[#0f172a] rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 text-center mt-4">
                    <div class="w-16 h-16 rounded-2xl bg-slate-50 dark:bg-slate-800/50 flex items-center justify-center mb-4">
                        <i class="ri-code-s-slash-fill text-3xl text-slate-300 dark:text-slate-600"></i>
                    </div>
                    <h3 class="text-[16px] font-bold text-slate-800 dark:text-white mb-2">Chưa Có Công Cụ Nào</h3>
                    <p class="text-[13px] text-slate-500 dark:text-slate-400 max-w-[280px]">Hệ thống đang cập nhật các bộ công cụ mới nhất. Vui lòng quay lại sau!</p>
                </div>
            <?php else: ?>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
                    <?php foreach ($games as $game): 
                        $playUrl = generateGameUrl($game);
                        $catSlug = strtolower($game['category'] ?? 'khac');
                        
                        $catName = 'Khác';
                        foreach($categories as $c) {
                            if ($c['slug'] == $catSlug) { $catName = $c['name']; break; }
                        }
                    ?>
                    <!-- Card Game Phẳng -->
                    <div class="game-item bg-white dark:bg-[#0f172a] rounded-2xl border border-slate-200 dark:border-slate-800 p-5 flex flex-col hover:border-blue-400 dark:hover:border-blue-500/50 transition-colors relative overflow-hidden group"
                         data-name="<?= htmlspecialchars($game['name']) ?>" 
                         data-category="<?= htmlspecialchars($catSlug) ?>">
                        
                        <!-- Badge -->
                        <?php if (!empty($game['badge'])): ?>
                            <div class="absolute top-0 right-0 bg-rose-500 text-white text-[9px] font-bold uppercase tracking-widest px-3 py-1.5 rounded-bl-xl z-10">
                                <?= htmlspecialchars($game['badge']) ?>
                            </div>
                        <?php endif; ?>

                        <!-- Card Header -->
                        <div class="flex items-center gap-4 mb-4">
                            <div class="w-14 h-14 rounded-2xl bg-slate-50 dark:bg-slate-800/50 flex items-center justify-center border border-slate-100 dark:border-slate-700/50 overflow-hidden shrink-0 transition-transform group-hover:scale-105">
                                <img src="<?= !empty($game['image']) ? htmlspecialchars($game['image']) : 'https://placehold.co/100x100/e2e8f0/475569?text=Tool' ?>" class="w-full h-full object-cover">
                            </div>
                            <div>
                                <div class="inline-flex items-center px-2 py-0.5 bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-100/50 dark:border-transparent rounded-md text-[9px] font-bold uppercase tracking-widest mb-1.5">
                                    <?= htmlspecialchars($catName) ?>
                                </div>
                                <h3 class="text-[16px] font-bold text-slate-800 dark:text-white leading-tight"><?= htmlspecialchars($game['name']) ?></h3>
                            </div>
                        </div>

                        <!-- Card Body (Mô tả) -->
                        <div class="flex-1 mb-5">
                            <div class="text-[12px] font-medium text-slate-500 dark:text-slate-400 leading-relaxed line-clamp-2">
                                <?= $game['description'] ?>
                            </div>
                        </div>

                        <!-- Card Footer -->
                        <div class="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                            <div>
                                <div class="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1">Trạng thái</div>
                                <div class="text-[13px] font-bold <?= $is_vip ? 'text-emerald-500' : 'text-slate-500 dark:text-slate-400' ?>">
                                    <?= $is_vip ? '<i class="ri-lock-unlock-fill"></i> Đã Mở Khóa' : '<i class="ri-lock-fill"></i> Đã Khóa' ?>
                                </div>
                            </div>
                            
                            <?php if ($is_vip): ?>
                                <a href="<?= $playUrl ?>" class="click-effect h-10 px-5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-[13px] font-bold transition-colors flex items-center gap-1.5 focus:outline-none">
                                    <i class="ri-play-fill text-[16px]"></i> Chơi Ngay
                                </a>
                            <?php else: ?>
                                <a href="/thue-vip" class="click-effect h-10 px-4 bg-slate-100 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl text-[13px] font-bold transition-colors flex items-center gap-1.5 border border-slate-200 dark:border-slate-700 focus:outline-none">
                                    <i class="ri-vip-diamond-fill text-amber-500 text-[15px]"></i> Cần VIP
                                </a>
                            <?php endif; ?>
                        </div>

                    </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Hiển thị khi tìm kiếm rỗng -->
                <div x-show="filteredGames === 0" x-cloak class="flex flex-col items-center justify-center py-20 bg-white dark:bg-[#0f172a] rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 text-center">
                    <div class="w-16 h-16 rounded-2xl bg-slate-50 dark:bg-slate-800/50 flex items-center justify-center mb-4">
                        <i class="ri-search-eye-fill text-3xl text-slate-300 dark:text-slate-600"></i>
                    </div>
                    <h3 class="text-[15px] font-bold text-slate-800 dark:text-white mb-1">Không tìm thấy công cụ</h3>
                    <p class="text-[12px] text-slate-500 dark:text-slate-400">Thử tìm kiếm với một từ khóa khác xem sao.</p>
                </div>

            <?php endif; ?>
            
        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

</body>
</html>