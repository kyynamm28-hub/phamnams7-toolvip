<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/settings.php';

// 1. KIỂM TRA ĐĂNG NHẬP
if (!isset($_SESSION['user_id'])) { 
    header("Location: /auth/#login"); 
    exit; 
}

// 2. LẤY THÔNG TIN USER VÀ ĐỒNG BỘ BIẾN (FIX LỖI 0đ HEADER)
$stmtUser = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user_data = $stmtUser->fetch(PDO::FETCH_ASSOC);

if (!$user_data) {
    session_destroy();
    header("Location: /auth/#login");
    exit;
}

// Gán biến "Bao Lô" để Header & Nav nhận diện đúng số dư
$user = $user_data;
$userData = $user_data;
$userInfo = $user_data;
$balance = number_format($user_data['balance'] ?? 0, 0, ',', '.');
$initial = strtoupper(substr($user_data['username'] ?? $user_data['display_name'] ?? 'U', 0, 1));
$user_avatar = $user_data['avatar'] ?? '';

// Kiểm tra VIP
$is_vip = false;
if (!empty($user_data['vip_expire_at']) && strtotime($user_data['vip_expire_at']) > time()) {
    $is_vip = true;
}

// 3. LẤY DANH SÁCH GAME TỪ DATABASE
try {
    $stmtGames = $pdo->query("SELECT * FROM games WHERE status = 'active' ORDER BY position ASC, id DESC");
    $games = $stmtGames->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $games = []; 
}

// 4. HÀM XỬ LÝ LOGIC ĐƯỜNG DẪN URL GAME (CẬP NHẬT MỚI)
function generateGameUrl($game) {
    $category = strtolower($game['category'] ?? '');
    $slug = $game['slug'] ?? '';
    
    if ($category === 'bacarat') {
        return "/game/bacarat";
    }

    if ($category === 'taixiu' || $category === 'tai_xiu') {
        return "/game/taixiu/" . $slug; 
    }

    if ($category === 'sicbo') {
        return "/game/sicbo/" . $slug; 
    }

    return "#";
}

$pageTitle = 'Kho Tiện Ích & Game';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); }
        .fade-in { animation: fadeIn 0.4s ease-out forwards; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-neutral-50 dark:bg-gray-900 text-neutral-800 dark:text-gray-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 w-full max-w-5xl mx-auto fade-in">
            
            <div class="rounded-2xl border border-neutral-200 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-soft">
                
                <div class="px-6 py-5 border-b border-neutral-100 dark:border-gray-700 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center shadow-inner">
                            <i class="ri-gamepad-line text-white text-lg"></i>
                        </div>
                        <div>
                            <div class="text-lg font-bold text-neutral-800 dark:text-white uppercase tracking-wide">Công Cụ Dự Đoán</div>
                            <div class="text-xs text-neutral-500 dark:text-gray-400 font-medium">Hệ sinh thái game và soi cầu VIP</div>
                        </div>
                    </div>
                </div>

                <div class="p-4 sm:p-6 lg:p-8 bg-neutral-50/50 dark:bg-transparent">
                    
                    <?php if ($is_vip): ?>
                        <div class="bg-[#f0fdf4] dark:bg-emerald-900/10 border border-emerald-100 dark:border-emerald-800/30 rounded-xl p-4 flex items-center gap-4 mb-6 shadow-sm">
                            <div class="w-10 h-10 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-lg flex items-center justify-center shrink-0">
                                <i class="ri-vip-crown-fill text-xl"></i>
                            </div>
                            <div>
                                <div class="text-sm font-bold text-emerald-800 dark:text-emerald-400">Đặc Quyền Đã Mở Khóa</div>
                                <div class="text-xs font-medium text-emerald-600 dark:text-emerald-500/80 mt-0.5">Gói VIP của bạn còn hạn đến <?= date('d/m/Y', strtotime($user_data['vip_expire_at'])) ?></div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="bg-[#fff1f2] dark:bg-rose-900/10 border border-rose-100 dark:border-rose-800/30 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 shadow-sm">
                            <div class="flex items-center gap-4">
                                <div class="w-10 h-10 bg-rose-100 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400 rounded-lg flex items-center justify-center shrink-0">
                                    <i class="ri-lock-2-fill text-xl"></i>
                                </div>
                                <div>
                                    <div class="text-sm font-bold text-rose-800 dark:text-rose-400">Công Cụ Đang Bị Khóa</div>
                                    <div class="text-xs font-medium text-rose-600 dark:text-rose-500/80 mt-0.5">Bạn cần có Đặc Quyền VIP để truy cập.</div>
                                </div>
                            </div>
                            <a href="/thue-vip" class="h-9 px-5 bg-rose-500 hover:bg-rose-600 text-white rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-sm whitespace-nowrap">
                                Đăng Ký VIP Ngay
                            </a>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (empty($games)): ?>
                        <div class="flex flex-col items-center justify-center min-h-[300px] bg-white dark:bg-gray-800 rounded-xl border border-dashed border-neutral-200 dark:border-gray-700 mt-6">
                            <div class="w-16 h-16 rounded-full bg-neutral-100 dark:bg-gray-700 flex items-center justify-center mb-4">
                                <i class="ri-code-s-slash-line text-2xl text-neutral-400"></i>
                            </div>
                            <div class="text-neutral-800 dark:text-white font-bold text-lg">Chưa Có Công Cụ Nào</div>
                            <div class="text-neutral-500 text-sm mt-1 text-center max-w-sm">Hệ thống đang cập nhật các bộ công cụ. Vui lòng quay lại sau!</div>
                        </div>
                    <?php else: ?>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                            <?php foreach ($games as $game): 
                                $playUrl = generateGameUrl($game);
                                $catName = 'Khác';
                                if(strtolower($game['category']) == 'taixiu') $catName = 'Tài Xỉu';
                                if(strtolower($game['category']) == 'sicbo') $catName = 'Sicbo';
                                if(strtolower($game['category']) == 'bacarat') $catName = 'Baccarat';
                            ?>
                            <div class="bg-white dark:bg-gray-800 rounded-xl border border-neutral-200 dark:border-gray-700 p-5 shadow-sm hover:border-blue-400 dark:hover:border-blue-500 transition-all group flex flex-col h-full relative overflow-hidden">
                                
                                <?php if (!empty($game['badge'])): ?>
                                    <div class="absolute top-0 right-4 bg-rose-500 text-white text-[9px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-b-md shadow-sm z-10">
                                        <?= htmlspecialchars($game['badge']) ?>
                                    </div>
                                <?php endif; ?>

                                <div class="flex items-start justify-between mb-4">
                                    <div class="w-14 h-14 rounded-lg bg-neutral-50 dark:bg-gray-700 flex items-center justify-center border border-neutral-100 dark:border-gray-600 overflow-hidden shrink-0">
                                        <img src="<?= !empty($game['image']) ? htmlspecialchars($game['image']) : 'https://placehold.co/100x100/e2e8f0/475569?text=Game' ?>" class="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity">
                                    </div>
                                    <div class="inline-flex items-center px-2.5 py-1 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 border border-blue-100 dark:border-blue-800/30 rounded-md text-[11px] font-bold">
                                        <i class="ri-folder-info-line mr-1"></i> <?= $catName ?>
                                    </div>
                                </div>

                                <div class="flex-1">
                                    <h3 class="text-base font-bold text-neutral-800 dark:text-white mb-2"><?= htmlspecialchars($game['name']) ?></h3>
                                    <div class="text-xs text-neutral-500 dark:text-gray-400 leading-relaxed line-clamp-2 mb-4">
                                        <?= $game['description'] ?>
                                    </div>
                                </div>

                                <div class="mt-4 pt-4 border-t border-neutral-100 dark:border-gray-700 flex items-center justify-between">
                                    <div>
                                        <div class="text-[10px] text-neutral-400 uppercase tracking-widest font-semibold mb-0.5">Trạng thái</div>
                                        <div class="text-[13px] font-bold <?= $is_vip ? 'text-emerald-500' : 'text-rose-500' ?>">
                                            <?= $is_vip ? 'Đã Mở Khóa' : 'Yêu Cầu VIP' ?>
                                        </div>
                                    </div>
                                    
                                    <?php if ($is_vip): ?>
                                        <a href="<?= $playUrl ?>" class="h-9 px-5 bg-neutral-800 hover:bg-neutral-900 dark:bg-white dark:text-neutral-900 dark:hover:bg-gray-100 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 shadow-sm">
                                            <i class="ri-play-fill"></i> Chơi Ngay
                                        </a>
                                    <?php else: ?>
                                        <a href="/thue-vip" class="h-9 px-4 bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 hover:bg-rose-500 hover:text-white dark:hover:bg-rose-600 dark:hover:text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 shadow-sm border border-rose-200 dark:border-rose-800/30">
                                            <i class="ri-lock-fill"></i> Thuê VIP
                                        </a>
                                    <?php endif; ?>
                                </div>

                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
            
        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

</body>
</html>
