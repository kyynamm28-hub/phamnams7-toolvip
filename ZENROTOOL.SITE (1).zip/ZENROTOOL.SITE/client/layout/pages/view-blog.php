<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/settings.php';

if (!isset($_SESSION['user_id'])) { header("Location: /auth/#login"); exit; }
$user_id = $_SESSION['user_id'];

// ĐÃ FIX: Lấy toàn bộ thông tin User vào biến $user_data để Header hiển thị đúng Số dư
$stmtUser = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $user_id]);
$user_data = $stmtUser->fetch(PDO::FETCH_ASSOC);

$token = $_GET['token'] ?? '';
$stmt = $pdo->prepare("SELECT * FROM blogs WHERE token = ? AND status = 'active' LIMIT 1");
$stmt->execute([$token]);
$blog = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$blog) { header("Location: /blog"); exit; }

// Xử lý tăng Views (Chống f5 liên tục)
if (!isset($_SESSION['viewed_blogs'])) { $_SESSION['viewed_blogs'] = []; }
if (!in_array($blog['id'], $_SESSION['viewed_blogs'])) {
    $pdo->prepare("UPDATE blogs SET views = views + 1 WHERE id = ?")->execute([$blog['id']]);
    $blog['views']++;
    $_SESSION['viewed_blogs'][] = $blog['id'];
}

// Kiểm tra user đã Like chưa
$stmtLike = $pdo->prepare("SELECT 1 FROM blog_likes WHERE user_id = ? AND blog_id = ?");
$stmtLike->execute([$user_id, $blog['id']]);
$is_liked = $stmtLike->fetchColumn() ? true : false;

$pageTitle = $blog['title'];
$current_url = "https://" . $_SERVER['HTTP_HOST'] . "/view-blog/" . $blog['token'];
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/collapse@3.x.x/dist/cdn.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .shadow-soft { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); }
        .fade-in-up { animation: fadeInUp 0.5s ease-out forwards; }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(15px); } to { opacity: 1; transform: translateY(0); } }
        
        /* CSS tuỳ chỉnh cho nội dung HTML của bài viết */
        .blog-content img { max-width: 100%; height: auto; border-radius: 12px; margin: 16px 0; }
        .blog-content h1, .blog-content h2, .blog-content h3 { font-weight: bold; margin-top: 24px; margin-bottom: 12px; color: inherit; }
        .blog-content h2 { font-size: 1.5rem; }
        .blog-content h3 { font-size: 1.25rem; }
        .blog-content p { margin-bottom: 16px; line-height: 1.8; }
        .blog-content a { color: #2563eb; text-decoration: underline; }
        .blog-content ul, .blog-content ol { padding-left: 20px; margin-bottom: 16px; }
        .blog-content li { margin-bottom: 8px; }
        .dark .blog-content a { color: #60a5fa; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-neutral-50 dark:bg-gray-900 text-neutral-800 dark:text-gray-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 w-full max-w-4xl mx-auto fade-in-up" x-data="blogHandler(<?= $blog['id'] ?>, <?= $is_liked ? 'true' : 'false' ?>, <?= $blog['likes'] ?>)">
            
            <div class="mb-4">
                <a href="/blog" class="text-sm font-semibold text-neutral-500 hover:text-neutral-800 dark:hover:text-white transition-colors">
                    <i class="ri-arrow-left-line"></i> Trở về danh sách
                </a>
            </div>

            <article class="bg-white dark:bg-gray-800 rounded-3xl border border-neutral-200 dark:border-gray-700 shadow-soft overflow-hidden">
                
                <?php if (!empty($blog['image'])): ?>
                <div class="w-full aspect-[21/9] sm:aspect-[21/7] bg-neutral-100 dark:bg-gray-700">
                    <img src="<?= htmlspecialchars($blog['image']) ?>" alt="Cover" class="w-full h-full object-cover">
                </div>
                <?php endif; ?>

                <div class="p-6 sm:p-10">
                    <h1 class="text-2xl sm:text-4xl font-black text-neutral-800 dark:text-white leading-tight mb-4 tracking-tight">
                        <?= htmlspecialchars($blog['title']) ?>
                    </h1>
                    
                    <div class="flex flex-wrap items-center gap-4 text-xs font-semibold text-neutral-500 dark:text-gray-400 mb-8 border-b border-neutral-100 dark:border-gray-700 pb-6">
                        <div class="flex items-center gap-1.5 bg-neutral-100 dark:bg-gray-700 px-3 py-1.5 rounded-lg">
                            <i class="ri-calendar-event-line"></i> <?= date('d/m/Y - H:i', strtotime($blog['created_at'])) ?>
                        </div>
                        <div class="flex items-center gap-1.5">
                            <i class="ri-eye-line text-lg"></i> <?= number_format($blog['views']) ?> lượt xem
                        </div>
                        <div class="flex items-center gap-1.5">
                            <i class="ri-heart-3-line text-lg"></i> <span x-text="likesCount"></span> lượt thích
                        </div>
                    </div>

                    <div class="blog-content text-sm sm:text-base text-neutral-700 dark:text-gray-300">
                        <?= $blog['content'] ?>
                    </div>

                    <div class="mt-10 pt-6 border-t border-neutral-100 dark:border-gray-700 flex flex-col sm:flex-row items-center justify-between gap-4">
                        
                        <button @click="toggleLike()" class="w-full sm:w-auto px-6 py-2.5 rounded-full font-bold text-sm transition-all flex items-center justify-center gap-2 border"
                                :class="isLiked ? 'bg-rose-50 border-rose-200 text-rose-500 dark:bg-rose-900/20 dark:border-rose-800/30' : 'bg-white border-neutral-200 text-neutral-600 hover:bg-neutral-50 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-700'">
                            <i :class="isLiked ? 'ri-heart-3-fill text-rose-500 text-lg' : 'ri-heart-3-line text-lg'"></i>
                            <span x-text="isLiked ? 'Đã Yêu Thích' : 'Thích Bài Viết'"></span>
                        </button>

                        <button @click="showShare = true" class="w-full sm:w-auto px-6 py-2.5 bg-[#1a1a1a] hover:bg-black dark:bg-white dark:text-neutral-900 dark:hover:bg-gray-100 text-white rounded-full font-bold text-sm transition-colors flex items-center justify-center gap-2 shadow-md">
                            <i class="ri-share-forward-line text-lg"></i> Chia Sẻ
                        </button>
                    </div>

                </div>
            </article>

            <div x-show="showShare" x-cloak class="fixed inset-0 z-[100] flex items-center justify-center p-4">
                <div class="absolute inset-0 bg-neutral-900/60 dark:bg-black/60 backdrop-blur-sm" @click="showShare = false"></div>
                <div class="relative bg-white dark:bg-gray-800 w-full max-w-sm rounded-[24px] shadow-2xl overflow-hidden" 
                     x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 scale-95 translate-y-4" x-transition:enter-end="opacity-100 scale-100 translate-y-0">
                    
                    <div class="p-6">
                        <div class="flex justify-between items-center mb-5">
                            <h3 class="text-lg font-bold text-neutral-800 dark:text-white">Chia sẻ bài viết</h3>
                            <button @click="showShare = false" class="w-8 h-8 flex items-center justify-center rounded-full bg-neutral-100 dark:bg-gray-700 text-neutral-500 hover:text-red-500 transition-colors"><i class="ri-close-line text-xl"></i></button>
                        </div>
                        
                        <div class="grid grid-cols-4 gap-3 mb-6">
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode($current_url) ?>" target="_blank" class="flex flex-col items-center gap-2 group">
                                <div class="w-12 h-12 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center text-2xl group-hover:bg-blue-600 group-hover:text-white transition-colors"><i class="ri-facebook-circle-fill"></i></div>
                                <span class="text-[10px] font-semibold text-neutral-500">Facebook</span>
                            </a>
                            <a href="fb-messenger://share/?link=<?= urlencode($current_url) ?>" class="flex flex-col items-center gap-2 group">
                                <div class="w-12 h-12 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center text-2xl group-hover:bg-indigo-600 group-hover:text-white transition-colors"><i class="ri-messenger-fill"></i></div>
                                <span class="text-[10px] font-semibold text-neutral-500">Messenger</span>
                            </a>
                            <a href="https://t.me/share/url?url=<?= urlencode($current_url) ?>&text=<?= urlencode($blog['title']) ?>" target="_blank" class="flex flex-col items-center gap-2 group">
                                <div class="w-12 h-12 rounded-full bg-sky-50 text-sky-500 flex items-center justify-center text-2xl group-hover:bg-sky-500 group-hover:text-white transition-colors"><i class="ri-telegram-fill"></i></div>
                                <span class="text-[10px] font-semibold text-neutral-500">Telegram</span>
                            </a>
                            <a href="mailto:?subject=<?= urlencode($blog['title']) ?>&body=<?= urlencode("Xem bài viết này: " . $current_url) ?>" class="flex flex-col items-center gap-2 group">
                                <div class="w-12 h-12 rounded-full bg-red-50 text-red-500 flex items-center justify-center text-2xl group-hover:bg-red-500 group-hover:text-white transition-colors"><i class="ri-mail-send-fill"></i></div>
                                <span class="text-[10px] font-semibold text-neutral-500">Email</span>
                            </a>
                        </div>

                        <div class="relative">
                            <input type="text" readonly value="<?= $current_url ?>" class="w-full bg-neutral-50 dark:bg-gray-900 border border-neutral-200 dark:border-gray-700 rounded-xl py-3 pl-4 pr-12 text-xs font-mono text-neutral-500 focus:outline-none">
                            <button @click="copyLink('<?= $current_url ?>')" class="absolute right-1.5 top-1.5 w-8 h-8 flex items-center justify-center rounded-lg bg-neutral-200 dark:bg-gray-700 text-neutral-600 dark:text-white hover:bg-neutral-300 transition-colors" title="Copy">
                                <i class="ri-file-copy-line"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

        </main>
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('blogHandler', (id, initLiked, initCount) => ({
                blogId: id,
                isLiked: initLiked,
                likesCount: initCount,
                showShare: false,
                isToggling: false,

                async toggleLike() {
                    if (this.isToggling) return;
                    this.isToggling = true;
                    
                    this.isLiked = !this.isLiked;
                    this.likesCount += this.isLiked ? 1 : -1;

                    try {
                        let fd = new FormData();
                        fd.append('blog_id', this.blogId);
                        
                        const res = await fetch('/api-handler?action=like_blog', { method: 'POST', body: fd });
                        const data = await res.json();
                        
                        if (data.status !== 'success') {
                            this.isLiked = !this.isLiked;
                            this.likesCount += this.isLiked ? 1 : -1;
                            Swal.fire({ toast: true, position: 'top-end', icon: 'error', title: 'Lỗi đồng bộ!', showConfirmButton: false, timer: 1500 });
                        }
                    } catch (e) {
                        this.isLiked = !this.isLiked;
                        this.likesCount += this.isLiked ? 1 : -1;
                    } finally {
                        this.isToggling = false;
                    }
                },

                copyLink(url) {
                    navigator.clipboard.writeText(url);
                    Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Đã copy liên kết', showConfirmButton: false, timer: 1500 });
                }
            }));
        });
    </script>
</body>
</html>
