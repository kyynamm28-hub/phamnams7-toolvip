<?php
session_start();
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/settings.php';

if (!isset($_SESSION['user_id'])) { header("Location: /auth/#login"); exit; }

$slug = $_GET['slug'] ?? '';
$stmt = $pdo->prepare("SELECT * FROM products WHERE slug = ? AND status = 'active' LIMIT 1");
$stmt->execute([$slug]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) { header("Location: /product"); exit; }

// Lấy tất cả ảnh của sản phẩm
$stmtImg = $pdo->prepare("SELECT image_url FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, id ASC");
$stmtImg->execute([$product['id']]);
$images = $stmtImg->fetchAll(PDO::FETCH_COLUMN);
if(empty($images)) $images[] = 'https://placehold.co/800x500/f8fafc/94a3b8?text=No+Image';

// ĐỒNG BỘ CÁC BIẾN ĐỂ HEADER KHÔNG LỖI SỐ DƯ
$stmtUser = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute(['id' => $_SESSION['user_id']]);
$user_data = $stmtUser->fetch(PDO::FETCH_ASSOC);

$user = $user_data;
$userData = $user_data;
$userInfo = $user_data;
$balance = number_format($user_data['balance'] ?? 0, 0, ',', '.');
$initial = strtoupper(substr($user_data['username'] ?? $user_data['display_name'] ?? 'U', 0, 1));
$user_avatar = $user_data['avatar'] ?? '';

$pageTitle = $product['name'];
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/collapse@3.x.x/dist/cdn.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .shadow-soft { box-shadow: 0 10px 40px -10px rgba(0,0,0,0.03); }
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
        
        /* Cấu hình khung render HTML đẹp mắt (Minimalist Prose) */
        .html-preview-frame { font-size: 15px; line-height: 1.8; color: #475569; }
        .dark .html-preview-frame { color: #cbd5e1; }
        .html-preview-frame img { max-width: 100%; height: auto; border-radius: 16px; margin: 24px 0; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
        .html-preview-frame p { margin-bottom: 16px; }
        .html-preview-frame h1, .html-preview-frame h2, .html-preview-frame h3 { font-weight: 900; margin: 32px 0 16px 0; color: #0f172a; line-height: 1.3; }
        .dark .html-preview-frame h1, .dark .html-preview-frame h2, .dark .html-preview-frame h3 { color: #f8fafc; }
        .html-preview-frame b, .html-preview-frame strong { color: #0f172a; font-weight: 800; }
        .dark .html-preview-frame b, .dark .html-preview-frame strong { color: #ffffff; }
        .html-preview-frame ul, .html-preview-frame ol { margin-left: 20px; margin-bottom: 16px; }
        .html-preview-frame li { margin-bottom: 8px; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-neutral-50 dark:bg-gray-900 text-neutral-800 dark:text-gray-200 antialiased transition-colors duration-300">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen lg:ml-[260px]">
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 w-full max-w-6xl mx-auto" x-data="productHandler()">
            
            <div class="mb-6">
                <a href="/product" class="inline-flex items-center gap-1.5 text-[12px] font-bold text-neutral-500 hover:text-neutral-900 dark:text-gray-400 dark:hover:text-white transition-colors uppercase tracking-widest bg-white dark:bg-gray-800 px-4 py-2 rounded-full border border-neutral-200 dark:border-gray-700 shadow-sm focus:outline-none">
                    <i class="ri-arrow-left-line text-[14px]"></i> Trở Về Cửa Hàng
                </a>
            </div>

            <div class="bg-white dark:bg-[#0f172a] rounded-[32px] border border-neutral-200/60 dark:border-gray-800 shadow-soft overflow-hidden">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-0 lg:gap-10 p-6 sm:p-10">
                    
                    <div class="w-full" x-data="{ activeImage: 0, images: <?= htmlspecialchars(json_encode($images)) ?> }">
                        <div class="aspect-video bg-neutral-50 dark:bg-[#1e293b] rounded-[24px] overflow-hidden mb-6 border border-neutral-100 dark:border-gray-700/50 relative p-4 flex items-center justify-center">
                            <img :src="images[activeImage]" class="max-w-full max-h-full object-contain transition-opacity duration-300 drop-shadow-md" alt="Product Image">
                            
                            <button x-show="images.length > 1" @click="activeImage = activeImage === 0 ? images.length - 1 : activeImage - 1" class="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/80 dark:bg-black/50 text-neutral-800 dark:text-white rounded-full flex items-center justify-center hover:bg-white dark:hover:bg-black/80 transition-all shadow-md backdrop-blur-md focus:outline-none"><i class="ri-arrow-left-s-line text-lg"></i></button>
                            <button x-show="images.length > 1" @click="activeImage = activeImage === images.length - 1 ? 0 : activeImage + 1" class="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/80 dark:bg-black/50 text-neutral-800 dark:text-white rounded-full flex items-center justify-center hover:bg-white dark:hover:bg-black/80 transition-all shadow-md backdrop-blur-md focus:outline-none"><i class="ri-arrow-right-s-line text-lg"></i></button>
                        </div>
                        
                        <div class="flex gap-4 overflow-x-auto pb-2 scrollbar-hide px-1">
                            <template x-for="(img, index) in images" :key="index">
                                <button @click="activeImage = index" :class="activeImage === index ? 'ring-2 ring-blue-500 opacity-100 scale-105 shadow-md' : 'opacity-50 hover:opacity-100'" class="shrink-0 w-24 h-16 rounded-[12px] overflow-hidden border border-neutral-200 dark:border-gray-700 transition-all focus:outline-none bg-neutral-50 dark:bg-[#1e293b] p-1 flex items-center justify-center">
                                    <img :src="img" class="max-w-full max-h-full object-contain">
                                </button>
                            </template>
                        </div>
                    </div>

                    <div class="flex flex-col mt-8 lg:mt-0">
                        <div class="inline-flex items-center px-3 py-1 bg-emerald-50 dark:bg-emerald-900/10 text-emerald-600 dark:text-emerald-400 text-[10px] font-black uppercase tracking-widest rounded-lg border border-emerald-100 dark:border-emerald-800/30 w-max mb-5 shadow-sm">
                            <i class="ri-shield-check-fill text-[14px] mr-1.5"></i> Sản phẩm có sẵn
                        </div>
                        
                        <h1 class="text-2xl sm:text-3xl font-black text-neutral-900 dark:text-white mb-4 leading-tight tracking-tight"><?= htmlspecialchars($product['name']) ?></h1>
                        <p class="text-[14px] text-neutral-500 dark:text-gray-400 mb-8 leading-relaxed"><?= htmlspecialchars($product['short_description']) ?></p>

                        <div class="p-6 bg-blue-50/50 dark:bg-gray-800/50 rounded-[24px] border border-blue-100 dark:border-gray-700/80 mb-8 shadow-inner">
                            <div class="text-[11px] text-neutral-500 dark:text-gray-400 font-bold uppercase tracking-widest mb-1.5">Giá Bán</div>
                            <div class="text-4xl font-black text-blue-600 dark:text-blue-400 leading-none">
                                <?= number_format($product['price']) ?><span class="text-xl ml-1 text-blue-400/60 font-bold">đ</span>
                            </div>
                        </div>

                        <div class="space-y-5 text-[13px] font-medium mb-10 text-neutral-700 dark:text-gray-300">
                            <div class="flex items-start gap-4 p-4 rounded-2xl bg-neutral-50 dark:bg-gray-800/40 border border-neutral-100 dark:border-gray-700/50">
                                <div class="w-10 h-10 rounded-full bg-indigo-50 dark:bg-indigo-900/20 text-indigo-500 flex items-center justify-center shrink-0">
                                    <i class="ri-customer-service-2-fill text-lg"></i>
                                </div>
                                <div>
                                    <div class="text-neutral-400 dark:text-gray-500 text-[10px] font-black uppercase tracking-widest mb-0.5">Hỗ trợ cài đặt</div>
                                    <div class="font-bold"><?= htmlspecialchars($product['support_contact']) ?></div>
                                </div>
                            </div>
                            <div class="flex items-start gap-4 p-4 rounded-2xl bg-neutral-50 dark:bg-gray-800/40 border border-neutral-100 dark:border-gray-700/50">
                                <div class="w-10 h-10 rounded-full bg-emerald-50 dark:bg-emerald-900/20 text-emerald-500 flex items-center justify-center shrink-0">
                                    <i class="ri-download-cloud-2-fill text-lg"></i>
                                </div>
                                <div>
                                    <div class="text-neutral-400 dark:text-gray-500 text-[10px] font-black uppercase tracking-widest mb-0.5">Hình thức nhận file</div>
                                    <div class="font-bold">Link tải Drive (Tự động mở sau khi mua)</div>
                                </div>
                            </div>
                        </div>

                        <button @click="buyProduct(<?= $product['id'] ?>, '<?= htmlspecialchars(addslashes($product['name'])) ?>', <?= $product['price'] ?>)" class="mt-auto w-full h-14 bg-neutral-900 hover:bg-black dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 text-white rounded-[16px] font-black text-[14px] uppercase tracking-widest transition-all shadow-md shadow-neutral-900/10 dark:shadow-white/5 flex items-center justify-center gap-3 focus:outline-none">
                            <i class="ri-shopping-cart-2-fill text-[18px]"></i> Mua Mã Nguồn Này
                        </button>
                    </div>
                </div>

                <div class="p-6 sm:p-10 border-t border-neutral-100 dark:border-gray-800 bg-neutral-50/50 dark:bg-[#0b1120]/30">
                    <h3 class="text-[14px] font-black text-neutral-800 dark:text-white uppercase tracking-widest mb-6 flex items-center gap-2">
                        <i class="ri-file-text-line text-blue-500"></i> Bài Viết Chi Tiết
                    </h3>
                    <div class="html-preview-frame">
                        <?= $product['content'] ?>
                    </div>
                </div>
            </div>

            <div x-show="showDownloadModal" x-cloak class="fixed inset-0 z-[100] flex items-center justify-center p-4">
                <div class="absolute inset-0 bg-neutral-900/60 dark:bg-black/80 backdrop-blur-md" @click="window.location.reload()"></div>
                <div class="relative bg-white dark:bg-gray-900 w-full max-w-md rounded-[32px] shadow-2xl overflow-hidden" 
                     x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 scale-95" x-transition:enter-end="opacity-100 scale-100">
                    <div class="p-8 sm:p-10 text-center">
                        <div class="w-20 h-20 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-inner">
                            <i class="ri-check-line text-[40px] font-bold"></i>
                        </div>
                        <h3 class="text-2xl font-black text-neutral-900 dark:text-white mb-2 tracking-tight">Thanh Toán Hoàn Tất</h3>
                        <p class="text-[13px] text-neutral-500 dark:text-gray-400 mb-8 leading-relaxed">Sản phẩm mã nguồn đã được mở khóa cho tài khoản của bạn. Bấm vào nút bên dưới để bắt đầu tải xuống.</p>
                        
                        <a :href="downloadUrl" target="_blank" class="flex w-full h-12 bg-blue-600 hover:bg-blue-700 text-white rounded-[14px] font-bold text-[14px] uppercase tracking-widest transition-colors items-center justify-center gap-2 mb-3 shadow-md focus:outline-none">
                            <i class="ri-download-cloud-2-line text-xl"></i> Tải Source Code
                        </a>
                        <button @click="window.location.reload()" class="w-full h-12 bg-transparent text-neutral-500 dark:text-gray-400 hover:text-neutral-800 dark:hover:text-white font-bold text-[13px] transition-colors focus:outline-none">
                            Đóng & Tải Lại Trang
                        </button>
                    </div>
                </div>
            </div>

        </main>
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('productHandler', () => ({
                isProcessing: false,
                currentBalance: <?= (int)$user_data['balance'] ?>,
                showDownloadModal: false,
                downloadUrl: '',

                async buyProduct(id, name, price) {
                    if (this.isProcessing) return;

                    const confirm = await Swal.fire({
                        title: 'Xác Nhận Mua Hàng',
                        html: `<div class="text-[14px] mt-2">Mã nguồn: <b>${name}</b><br>Chi phí: <b class="text-blue-600">${new Intl.NumberFormat('vi-VN').format(price)}đ</b></div>`,
                        icon: 'info',
                        showCancelButton: true,
                        confirmButtonColor: '#0f172a', cancelButtonColor: '#e2e8f0',
                        cancelButtonText: '<span style="color:#475569;font-weight:bold;">Hủy bỏ</span>',
                        confirmButtonText: 'Đồng Ý Mua',
                        background: document.documentElement.classList.contains('dark') ? '#1e293b' : '#ffffff',
                        color: document.documentElement.classList.contains('dark') ? '#ffffff' : '#0f172a'
                    });

                    if (confirm.isConfirmed) {
                        if (this.currentBalance < price) {
                            Swal.fire({ icon: 'error', title: 'Số dư không đủ!', text: 'Vui lòng nạp thêm tiền.', background: document.documentElement.classList.contains('dark') ? '#1e293b' : '#ffffff', color: document.documentElement.classList.contains('dark') ? '#ffffff' : '#0f172a'}).then(() => window.location.href = '/bank/recharge');
                            return;
                        }

                        this.isProcessing = true;
                        Swal.fire({ title: 'Đang xử lý thanh toán...', allowOutsideClick: false, background: document.documentElement.classList.contains('dark') ? '#1e293b' : '#ffffff', color: document.documentElement.classList.contains('dark') ? '#ffffff' : '#0f172a', didOpen: () => Swal.showLoading() });

                        try {
                            let formData = new FormData();
                            formData.append('product_id', id);
                            
                            const res = await fetch('/api-handler?action=buy_product', { method: 'POST', body: formData });
                            const data = await res.json();

                            if (data.status === 'success') {
                                // Gửi log Telegram cho Admin
                                let notifyData = new FormData();
                                notifyData.append('history_id', data.history_id);
                                fetch('/api-handler?action=notify_product', { method: 'POST', body: notifyData });

                                Swal.close();
                                // Hiện Link Tải
                                this.downloadUrl = data.download_url;
                                this.showDownloadModal = true;
                            } else {
                                Swal.fire('Lỗi', data.message, 'error');
                            }
                        } catch (e) {
                            Swal.fire('Lỗi', 'Mất kết nối máy chủ.', 'error');
                        } finally {
                            this.isProcessing = false;
                        }
                    }
                }
            }));
        });
    </script>
</body>
</html>
