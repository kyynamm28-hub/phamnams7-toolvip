<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Vui lòng đăng nhập!']);
    exit;
}

require_once __DIR__ . '/../../../config/database.php';

$action = $_GET['action'] ?? '';
$user_id = $_SESSION['user_id'];

switch ($action) {
    case 'update_avatar':
        if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
            echo json_encode(['status' => 'error', 'message' => 'Lỗi upload ảnh.']);
            exit;
        }

        $file = $_FILES['avatar'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        if (!in_array($ext, $allowed)) {
            echo json_encode(['status' => 'error', 'message' => 'Chỉ chấp nhận ảnh định dạng JPG, PNG, GIF, WEBP.']);
            exit;
        }

        if ($file['size'] > 5 * 1024 * 1024) { // 5MB
            echo json_encode(['status' => 'error', 'message' => 'Kích thước ảnh không được vượt quá 5MB.']);
            exit;
        }

        // Tạo thư mục nếu chưa có
        $upload_dir = __DIR__ . '/../../../assets/uploads/avatars/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        $filename = 'avatar_' . $user_id . '_' . time() . '.' . $ext;
        $dest_path = $upload_dir . $filename;
        $url_path = '/assets/uploads/avatars/' . $filename;

        if (move_uploaded_file($file['tmp_name'], $dest_path)) {
            // Lấy ảnh cũ để xóa đi cho nhẹ server
            $stmt = $pdo->prepare("SELECT avatar FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $old_avatar = $stmt->fetchColumn();
            
            if ($old_avatar && strpos($old_avatar, '/assets/uploads/avatars/') !== false) {
                $old_file_path = __DIR__ . '/../../..' . $old_avatar;
                if (file_exists($old_file_path)) unlink($old_file_path);
            }

            // Update DB
            $stmt = $pdo->prepare("UPDATE users SET avatar = ? WHERE id = ?");
            $stmt->execute([$url_path, $user_id]);

            echo json_encode(['status' => 'success', 'message' => 'Cập nhật ảnh đại diện thành công!', 'avatar_url' => $url_path]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Không thể lưu ảnh. Kiểm tra CHMOD thư mục.']);
        }
        break;

    case 'update_profile':
        $display_name = trim($_POST['display_name'] ?? '');
        if (empty($display_name)) {
            echo json_encode(['status' => 'error', 'message' => 'Tên hiển thị không được để trống.']);
            exit;
        }

        $stmt = $pdo->prepare("UPDATE users SET display_name = ? WHERE id = ?");
        if ($stmt->execute([$display_name, $user_id])) {
            echo json_encode(['status' => 'success', 'message' => 'Cập nhật thông tin thành công!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Có lỗi xảy ra, thử lại sau.']);
        }
        break;

    case 'change_password':
        $old_password = $_POST['old_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        if (empty($old_password) || empty($new_password) || empty($confirm_password)) {
            echo json_encode(['status' => 'error', 'message' => 'Vui lòng điền đầy đủ các trường mật khẩu.']);
            exit;
        }

        if ($new_password !== $confirm_password) {
            echo json_encode(['status' => 'error', 'message' => 'Mật khẩu xác nhận không khớp!']);
            exit;
        }

        if (strlen($new_password) < 6) {
            echo json_encode(['status' => 'error', 'message' => 'Mật khẩu mới phải có ít nhất 6 ký tự.']);
            exit;
        }

        $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();

        // Nếu user tạo bằng Google (chưa có pass) hoặc check pass
        if (!empty($user['password']) && !password_verify($old_password, $user['password'])) {
            echo json_encode(['status' => 'error', 'message' => 'Mật khẩu hiện tại không chính xác!']);
            exit;
        }

        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        if ($stmt->execute([$hashed_password, $user_id])) {
            echo json_encode(['status' => 'success', 'message' => 'Đổi mật khẩu thành công!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Có lỗi xảy ra, thử lại sau.']);
        }
        break;

    case 'remove_device':
        $device_id = $_POST['device_id'] ?? '';
        $stmt = $pdo->prepare("SELECT session_id FROM user_devices WHERE id = ? AND user_id = ?");
        $stmt->execute([$device_id, $user_id]);
        $device = $stmt->fetch();

        if ($device) {
            // Xóa session file của PHP (Đăng xuất thiết bị đó)
            $session_file = session_save_path() . '/sess_' . $device['session_id'];
            if (file_exists($session_file)) {
                unlink($session_file);
            }
            
            // Xóa khỏi DB
            $stmt = $pdo->prepare("DELETE FROM user_devices WHERE id = ?");
            $stmt->execute([$device_id]);
            
            echo json_encode(['status' => 'success', 'message' => 'Đã đăng xuất thiết bị thành công!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Thiết bị không tồn tại hoặc đã bị đăng xuất!']);
        }
        break;

    default:
        echo json_encode(['status' => 'error', 'message' => 'Hành động không hợp lệ!']);
        break;
}
