<?php
session_start();

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    header("Location: /auth/#login");
    exit;
}

require_once __DIR__ . '/../../../config/database.php';
// Yêu cầu thư viện setting (Nếu bạn có file cài đặt cấu hình web)
$configPath = __DIR__ . '/../../../config/settings.php';
if (file_exists($configPath)) require_once $configPath;

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
$stmt->execute(['id' => $_SESSION['user_id']]);
$user_data = $stmt->fetch();

if (!$user_data) {
    session_destroy();
    header("Location: /auth/#login");
    exit;
}

// Lấy danh sách thiết bị
$devices = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM user_devices WHERE user_id = ? ORDER BY last_active DESC LIMIT 10");
    $stmt->execute([$_SESSION['user_id']]);
    $devices = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Bỏ qua nếu bảng user_devices chưa được tạo
}
$current_session = session_id();

$page_title = 'Hồ Sơ Cá Nhân';
$user_avatar = $user_data['avatar'] ?? '';
$initial = strtoupper(substr($user_data['username'] ?? $user_data['display_name'] ?? 'U', 0, 1));

$vip_name = $user_data['vip_name'] ?? 'Chưa đăng ký';
$is_vip = !empty($user_data['vip_expire_at']) && strtotime($user_data['vip_expire_at']) > time();
$role_display = (strtolower($user_data['role'] ?? 'user') === 'admin') ? 'Quản Trị Viên' : 'Thành Viên';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <?php include __DIR__ . '/../include/head.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/collapse@3.x.x/dist/cdn.min.js"></script>
    <style>
        /* Animation Phẳng - Mượt */
        .fade-up { opacity: 0; transform: translateY(15px); animation: fadeUp 0.5s cubic-bezier(0.2, 0.8, 0.2, 1) forwards; }
        .delay-100 { animation-delay: 100ms; }
        .delay-200 { animation-delay: 200ms; }
        .delay-300 { animation-delay: 300ms; }
        @keyframes fadeUp { to { opacity: 1; transform: translateY(0); } }
        
        /* Hiệu ứng nhún (Click Effect) */
        .click-effect { transition: transform 0.15s cubic-bezier(0.4, 0, 0.2, 1); }
        .click-effect:active { transform: scale(0.96); }
        
        /* Ẩn AlpineJS khi chưa load */
        [x-cloak] { display: none !important; }
    </style>
</head>
<body x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      :class="{ 'dark': darkMode }" 
      class="bg-slate-50 dark:bg-[#0b1120] text-slate-800 dark:text-slate-200 antialiased transition-colors duration-200 relative overflow-x-hidden">
    
    <?php include __DIR__ . '/../include/nav.php'; ?>

    <div class="flex flex-col min-h-screen sm:ml-[260px]">
        
        <?php include __DIR__ . '/../include/header.php'; ?>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
            
            <div class="mb-5 fade-up">
                <h2 class="text-xl sm:text-2xl font-bold text-slate-800 dark:text-white">Cài Đặt Tài Khoản</h2>
                <p class="text-slate-500 dark:text-slate-400 text-[13px] mt-1">Quản lý thông tin cá nhân và bảo mật thiết bị của bạn.</p>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-12 gap-5 sm:gap-6">
                
                <!-- BÊN TRÁI: THẺ HỒ SƠ -->
                <div class="lg:col-span-4 flex flex-col gap-5 fade-up delay-100">
                    <div class="bg-white dark:bg-[#0f172a] rounded-2xl border border-slate-200 dark:border-slate-800 p-6 relative flex flex-col items-center text-center overflow-hidden">
                        
                        <!-- Background trang trí nửa trên -->
                        <div class="absolute top-0 left-0 w-full h-[80px] bg-blue-50 dark:bg-blue-500/10"></div>

                        <input type="file" id="avatarInput" accept="image/png, image/jpeg, image/gif, image/webp" class="hidden">

                        <!-- Avatar -->
                        <div class="relative inline-block mb-3 mt-4 group z-10">
                            <div class="w-24 h-24 rounded-[1.5rem] bg-white dark:bg-[#0f172a] p-1.5 shadow-sm border border-slate-100 dark:border-slate-700 mx-auto overflow-hidden">
                                <img id="avatarPreview" src="<?= !empty($user_avatar) ? htmlspecialchars($user_avatar) : 'https://ui-avatars.com/api/?name='.$initial.'&background=2563eb&color=fff' ?>" alt="Avatar" class="w-full h-full rounded-[1.1rem] object-cover">
                            </div>
                            
                            <button onclick="document.getElementById('avatarInput').click()" class="click-effect absolute -bottom-2 -right-2 w-9 h-9 bg-blue-600 text-white rounded-xl flex items-center justify-center ring-4 ring-white dark:ring-[#0f172a] hover:bg-blue-700 transition-colors focus:outline-none z-10" title="Đổi ảnh đại diện">
                                <i class="ri-camera-fill text-lg"></i>
                            </button>
                            
                            <div id="avatarLoading" class="absolute inset-0 bg-white/80 dark:bg-[#0f172a]/80 rounded-[1.5rem] hidden flex items-center justify-center z-20">
                                <i class="ri-loader-4-line text-2xl text-blue-600 animate-spin"></i>
                            </div>
                        </div>
                        
                        <!-- Info -->
                        <h3 class="text-lg font-bold text-slate-900 dark:text-white z-10"><?= htmlspecialchars($user_data['display_name'] ?? $user_data['username']) ?></h3>
                        <p class="text-[12px] font-bold text-blue-600 dark:text-blue-400 mt-1 uppercase tracking-widest z-10"><?= htmlspecialchars($role_display) ?></p>
                        
                        <!-- Badges -->
                        <div class="flex items-center justify-center gap-2 mt-4 w-full z-10">
                            <div class="px-3 py-1.5 rounded-lg text-[11px] font-bold bg-amber-50 text-amber-600 dark:bg-amber-500/10 dark:text-amber-500 flex items-center gap-1.5 flex-1 justify-center">
                                <i class="ri-vip-diamond-fill"></i> <?= htmlspecialchars($vip_name) ?>
                            </div>
                            <div class="px-3 py-1.5 rounded-lg text-[11px] font-bold bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-500 flex items-center gap-1.5 flex-1 justify-center">
                                <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> Online
                            </div>
                        </div>

                        <!-- Thống kê nhỏ -->
                        <div class="grid grid-cols-2 gap-3 w-full mt-5 z-10">
                            <div class="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-3 text-left border border-slate-100 dark:border-slate-700/50">
                                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Số dư ví</p>
                                <p class="text-[13px] font-bold text-slate-800 dark:text-white truncate"><?= number_format($user_data['balance'] ?? 0) ?>đ</p>
                            </div>
                            <div class="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-3 text-left border border-slate-100 dark:border-slate-700/50">
                                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Tham gia</p>
                                <p class="text-[13px] font-bold text-slate-800 dark:text-white"><?= date('d/m/Y', strtotime($user_data['created_at'])) ?></p>
                            </div>
                        </div>

                    </div>
                </div>

                <!-- BÊN PHẢI: FORM CÀI ĐẶT -->
                <div class="lg:col-span-8 flex flex-col gap-5 fade-up delay-200">
                    
                    <!-- Box 1: Cập nhật thông tin -->
                    <div class="bg-white dark:bg-[#0f172a] rounded-2xl border border-slate-200 dark:border-slate-800">
                        <div class="px-5 sm:px-7 pt-5 pb-3 border-b border-slate-100 dark:border-slate-800/80 flex items-center gap-2">
                            <div class="w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                                <i class="ri-profile-fill text-lg"></i>
                            </div>
                            <h3 class="text-[15px] font-bold text-slate-900 dark:text-white">Thông Tin Chung</h3>
                        </div>
                        
                        <div class="p-5 sm:p-7">
                            <form id="formProfile" onsubmit="submitForm(event, 'update_profile', 'formProfile')">
                                
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                                    <div>
                                        <label class="block text-[12px] font-bold text-slate-600 dark:text-slate-400 mb-2 flex items-center gap-1.5">
                                            Tên đăng nhập <i class="ri-lock-fill text-[11px] text-slate-400"></i>
                                        </label>
                                        <input type="text" value="<?= htmlspecialchars($user_data['username'] ?? 'Tài khoản Google') ?>" disabled class="w-full h-[46px] px-4 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl text-[13px] font-medium text-slate-500 dark:text-slate-400 focus:outline-none cursor-not-allowed opacity-80">
                                    </div>
                                    
                                    <div>
                                        <label class="block text-[12px] font-bold text-slate-600 dark:text-slate-400 mb-2 flex items-center gap-1.5">
                                            Địa chỉ Email <i class="ri-lock-fill text-[11px] text-slate-400"></i>
                                        </label>
                                        <input type="email" value="<?= htmlspecialchars($user_data['email']) ?>" disabled class="w-full h-[46px] px-4 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl text-[13px] font-medium text-slate-500 dark:text-slate-400 focus:outline-none cursor-not-allowed opacity-80">
                                    </div>
                                </div>

                                <div class="mt-5 sm:w-1/2 sm:pr-2.5">
                                    <label class="block text-[12px] font-bold text-slate-600 dark:text-slate-400 mb-2">
                                        Tên hiển thị công khai <span class="text-rose-500">*</span>
                                    </label>
                                    <input type="text" name="display_name" value="<?= htmlspecialchars($user_data['display_name']) ?>" required class="w-full h-[46px] px-4 bg-transparent border border-slate-300 dark:border-slate-600 rounded-xl text-[13px] font-medium text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all placeholder:text-slate-400">
                                </div>

                                <div class="flex justify-end mt-6">
                                    <button type="submit" class="submit-btn click-effect px-6 h-[42px] bg-blue-600 text-white text-[13px] font-bold rounded-xl transition-colors flex items-center justify-center gap-2 hover:bg-blue-700 focus:outline-none">
                                        <i class="ri-save-3-fill"></i> <span>Lưu Thay Đổi</span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Box 2: Bảo mật -->
                    <div class="bg-white dark:bg-[#0f172a] rounded-2xl border border-slate-200 dark:border-slate-800 fade-up delay-200">
                        <div class="px-5 sm:px-7 pt-5 pb-3 border-b border-slate-100 dark:border-slate-800/80 flex items-center gap-2">
                            <div class="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-500 flex items-center justify-center">
                                <i class="ri-shield-keyhole-fill text-lg"></i>
                            </div>
                            <h3 class="text-[15px] font-bold text-slate-900 dark:text-white">Bảo Mật Mật Khẩu</h3>
                        </div>
                        
                        <div class="p-5 sm:p-7">
                            <form id="formPassword" onsubmit="submitForm(event, 'change_password', 'formPassword')">
                                
                                <div class="sm:w-1/2 sm:pr-2.5">
                                    <label class="block text-[12px] font-bold text-slate-600 dark:text-slate-400 mb-2">
                                        Mật khẩu hiện tại <span class="text-rose-500">*</span>
                                    </label>
                                    <div x-data="{ show: false }" class="relative">
                                        <input :type="show ? 'text' : 'password'" name="old_password" required class="w-full h-[46px] px-4 pr-12 bg-transparent border border-slate-300 dark:border-slate-600 rounded-xl text-[13px] font-medium text-slate-800 dark:text-white focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all placeholder:text-slate-400" placeholder="••••••••">
                                        <button type="button" @click="show = !show" class="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 focus:outline-none rounded-lg">
                                            <i :class="show ? 'ri-eye-fill' : 'ri-eye-off-fill'" class="text-[16px]"></i>
                                        </button>
                                    </div>
                                </div>

                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5 mt-5">
                                    <div>
                                        <label class="block text-[12px] font-bold text-slate-600 dark:text-slate-400 mb-2">
                                            Mật khẩu mới <span class="text-rose-500">*</span>
                                        </label>
                                        <div x-data="{ show: false }" class="relative">
                                            <input :type="show ? 'text' : 'password'" name="new_password" required class="w-full h-[46px] px-4 pr-12 bg-transparent border border-slate-300 dark:border-slate-600 rounded-xl text-[13px] font-medium text-slate-800 dark:text-white focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all placeholder:text-slate-400" placeholder="Nhập mật khẩu mới">
                                            <button type="button" @click="show = !show" class="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 focus:outline-none rounded-lg">
                                                <i :class="show ? 'ri-eye-fill' : 'ri-eye-off-fill'" class="text-[16px]"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <div>
                                        <label class="block text-[12px] font-bold text-slate-600 dark:text-slate-400 mb-2">
                                            Xác nhận mật khẩu mới <span class="text-rose-500">*</span>
                                        </label>
                                        <div x-data="{ show: false }" class="relative">
                                            <input :type="show ? 'text' : 'password'" name="confirm_password" required class="w-full h-[46px] px-4 pr-12 bg-transparent border border-slate-300 dark:border-slate-600 rounded-xl text-[13px] font-medium text-slate-800 dark:text-white focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all placeholder:text-slate-400" placeholder="Nhập lại mật khẩu mới">
                                            <button type="button" @click="show = !show" class="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 focus:outline-none rounded-lg">
                                                <i :class="show ? 'ri-eye-fill' : 'ri-eye-off-fill'" class="text-[16px]"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="flex justify-end mt-6">
                                    <button type="submit" class="submit-btn click-effect px-6 h-[42px] bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-[13px] font-bold rounded-xl transition-colors flex items-center justify-center gap-2 hover:bg-slate-800 dark:hover:bg-slate-200 focus:outline-none">
                                        <i class="ri-lock-2-fill"></i> <span>Đổi Mật Khẩu</span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Box 3: Thiết bị đăng nhập -->
                    <div class="bg-white dark:bg-[#0f172a] rounded-2xl border border-slate-200 dark:border-slate-800 fade-up delay-300">
                        <div class="px-5 sm:px-7 pt-5 pb-3 border-b border-slate-100 dark:border-slate-800/80 flex items-center gap-2">
                            <div class="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-500 flex items-center justify-center">
                                <i class="ri-macbook-fill text-lg"></i>
                            </div>
                            <div>
                                <h3 class="text-[15px] font-bold text-slate-900 dark:text-white">Thiết Bị Hoạt Động</h3>
                            </div>
                        </div>
                        
                        <div class="p-5 sm:p-7">
                            <?php if (empty($devices)): ?>
                                <div class="text-center py-6 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-dashed border-slate-200 dark:border-slate-700">
                                    <i class="ri-computer-line text-3xl text-slate-300 dark:text-slate-600 mb-2 block"></i>
                                    <p class="text-[13px] font-medium text-slate-500 dark:text-slate-400">Chưa có thông tin lịch sử thiết bị.</p>
                                </div>
                            <?php else: ?>
                                <div class="space-y-3">
                                    <?php foreach ($devices as $dev): 
                                        $is_current = ($dev['session_id'] === $current_session);
                                        $is_mobile = strpos(strtolower($dev['user_agent']), 'mobile') !== false;
                                    ?>
                                    <div class="flex items-center justify-between p-4 rounded-xl border border-slate-200 dark:border-slate-700/50 bg-white dark:bg-[#0f172a] hover:border-blue-300 dark:hover:border-blue-500/50 transition-colors">
                                        <div class="flex items-center gap-4">
                                            <div class="w-10 h-10 rounded-xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center shrink-0">
                                                <i class="<?= $is_mobile ? 'ri-smartphone-fill' : 'ri-computer-fill' ?> text-[22px] text-slate-500 dark:text-slate-400"></i>
                                            </div>
                                            <div>
                                                <p class="text-[13px] font-bold text-slate-800 dark:text-slate-200 leading-tight">
                                                    <?= htmlspecialchars(substr($dev['user_agent'], 0, 35)) ?><?= strlen($dev['user_agent']) > 35 ? '...' : '' ?>
                                                    <?php if($is_current): ?>
                                                        <span class="inline-block ml-2 px-1.5 py-0.5 rounded-md bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 text-[9px] uppercase tracking-widest align-middle">Đang dùng</span>
                                                    <?php endif; ?>
                                                </p>
                                                <div class="flex items-center gap-3 mt-1">
                                                    <p class="text-[11px] font-medium text-slate-500 dark:text-slate-400"><i class="ri-global-line"></i> <?= htmlspecialchars($dev['ip_address']) ?></p>
                                                    <p class="text-[11px] font-medium text-slate-400 dark:text-slate-500"><i class="ri-time-line"></i> <?= date('d/m/y H:i', strtotime($dev['last_active'])) ?></p>
                                                </div>
                                            </div>
                                        </div>
                                        <?php if(!$is_current): ?>
                                            <button onclick="removeDevice(<?= $dev['id'] ?>)" class="click-effect w-8 h-8 rounded-lg bg-rose-50 text-rose-500 hover:bg-rose-500 hover:text-white dark:bg-rose-900/20 dark:hover:bg-rose-600 transition-colors flex items-center justify-center shrink-0" title="Đăng xuất thiết bị này">
                                                <i class="ri-logout-circle-r-fill text-[16px]"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            </div>

        </main>
        
        <?php include __DIR__ . '/../include/footer.php'; ?>
    </div>

    <script>
        const API_URL = '/ajax_profile';

        // 1. Submit Forms
        async function submitForm(e, actionName, formId) {
            e.preventDefault();
            const form = document.getElementById(formId);
            const btn = form.querySelector('.submit-btn');
            const originalHTML = btn.innerHTML;
            
            btn.disabled = true;
            btn.innerHTML = '<i class="ri-loader-4-line animate-spin"></i> <span>Đang xử lý...</span>';
            
            const formData = new FormData(form);
            
            try {
                const res = await fetch(`${API_URL}?action=${actionName}`, { method: 'POST', body: formData });
                const data = await res.json();
                
                Swal.fire({
                    icon: data.status,
                    title: data.status === 'success' ? 'Thành công!' : 'Lỗi!',
                    text: data.message,
                    background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff',
                    color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a',
                    confirmButtonColor: '#2563eb',
                    customClass: {
                        popup: 'rounded-2xl border border-slate-200 dark:border-slate-700'
                    }
                });

                if (data.status === 'success' && actionName === 'change_password') {
                    form.reset();
                }
            } catch (error) {
                Swal.fire('Lỗi kết nối', 'Không thể gửi dữ liệu lên máy chủ', 'error');
            } finally {
                btn.disabled = false;
                btn.innerHTML = originalHTML;
            }
        }

        // 2. Upload Avatar
        document.getElementById('avatarInput').addEventListener('change', async function() {
            if (this.files.length === 0) return;
            
            const file = this.files[0];
            const formData = new FormData();
            formData.append('avatar', file);
            
            const loading = document.getElementById('avatarLoading');
            const preview = document.getElementById('avatarPreview');
            
            loading.classList.remove('hidden');

            try {
                const res = await fetch(`${API_URL}?action=update_avatar`, { method: 'POST', body: formData });
                const data = await res.json();
                
                if (data.status === 'success') {
                    preview.src = data.avatar_url;
                    Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: data.message, showConfirmButton: false, timer: 2000, background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff', color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a' });
                } else {
                    Swal.fire('Lỗi', data.message, 'error');
                }
            } catch (error) {
                Swal.fire('Lỗi', 'Không thể upload ảnh!', 'error');
            } finally {
                loading.classList.add('hidden');
                this.value = '';
            }
        });

        // 3. Xóa thiết bị
        async function removeDevice(deviceId) {
            const confirm = await Swal.fire({
                title: 'Đăng xuất thiết bị?',
                text: "Thiết bị này sẽ bị đăng xuất khỏi tài khoản của bạn.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#64748b',
                confirmButtonText: 'Đăng xuất ngay',
                cancelButtonText: 'Hủy',
                background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff',
                color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a',
                customClass: {
                    popup: 'rounded-2xl border border-slate-200 dark:border-slate-700'
                }
            });

            if (confirm.isConfirmed) {
                const formData = new FormData();
                formData.append('device_id', deviceId);

                const res = await fetch(`${API_URL}?action=remove_device`, { method: 'POST', body: formData });
                const data = await res.json();
                
                if (data.status === 'success') {
                    Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Đã đăng xuất thiết bị', showConfirmButton: false, timer: 1500, background: document.documentElement.classList.contains('dark') ? '#0f172a' : '#fff', color: document.documentElement.classList.contains('dark') ? '#fff' : '#0f172a' });
                    setTimeout(() => window.location.reload(), 1500);
                } else {
                    Swal.fire('Lỗi', data.message, 'error');
                }
            }
        }
    </script>
</body>
</html>
