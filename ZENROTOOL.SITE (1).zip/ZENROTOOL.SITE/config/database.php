<?php
require_once __DIR__ . '/config.php';

try {
    $host = getenv('DB_HOST') ?: 'localhost';
    $db   = getenv('DB_DATABASE') ?: 'fhdyjksi_hi';
    $user = getenv('DB_USERNAME') ?: 'fhdyjksi_hi';
    $pass = getenv('DB_PASSWORD') ?: 'fhdyjksi_hi';
    $port = getenv('DB_PORT') ?: '3306';

    $pdo = new PDO("mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Tự động tạo bảng nếu chưa tồn tại
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        display_name VARCHAR(100) NOT NULL,
        username VARCHAR(50) NULL UNIQUE,
        email VARCHAR(100) NOT NULL UNIQUE,
        password VARCHAR(255) NULL,
        google_id VARCHAR(100) NULL UNIQUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
} catch (PDOException $e) {
    die("Lỗi kết nối CSDL: " . $e->getMessage());
}
