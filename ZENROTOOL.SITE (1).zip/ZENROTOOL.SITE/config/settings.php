<?php
// config/settings.php
require_once __DIR__ . '/database.php';

$config = [];
try {
    $stmt = $pdo->query("SELECT `key`, `value` FROM settings");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $config[$row['key']] = $row['value'];
    }
} catch (Exception $e) {
    // Xử lý lỗi nếu bảng chưa tồn tại
    error_log("Lỗi load settings: " . $e->getMessage());
}

// ==========================================
// KIỂM TRA TRẠNG THÁI BẢO TRÌ TOÀN HỆ THỐNG
// ==========================================
if (!empty($config['maintenance_mode']) && $config['maintenance_mode'] == '1') {
    
    $current_uri = $_SERVER['REQUEST_URI'];
    $script_name = $_SERVER['SCRIPT_NAME'];

    // Nếu KHÔNG phải là trang maintenance thì mới chuyển hướng
    // (Tránh lỗi lặp vô hạn do trang maintenance cũng gọi file settings.php này)
    if (strpos($current_uri, '/maintenance') === false && strpos($script_name, 'maintenance.php') === false) {
        
        // (Tùy chọn) Bỏ chặn cho Admin nếu bạn muốn Admin vẫn vào được web để test
        // Bỏ comment 3 dòng dưới nếu muốn áp dụng:
        // session_start(); // Đảm bảo session đã chạy
        // if (isset($_SESSION['user_id']) && isset($user_data['role']) && $user_data['role'] === 'admin') { return; }

        header("Location: /maintenance");
        exit;
    }
}
?>