<?php
require_once __DIR__ . '/../config/database.php';

// Bật log lỗi để dễ debug nếu cần
ini_set('display_errors', 1);
error_reporting(E_ALL);

// 1. Lấy cấu hình Nạp Thẻ
$stmtCard = $pdo->query("SELECT partner_id, partner_key, discounts FROM setting_card LIMIT 1");
$cardConfig = $stmtCard->fetch(PDO::FETCH_ASSOC);
if (!$cardConfig || empty($cardConfig['partner_id'])) {
    die("Chua cau hinh the cao hoac thieu Partner ID.\n");
}

$partner_id = $cardConfig['partner_id'];
$partner_key = $cardConfig['partner_key'];
$discounts = json_decode($cardConfig['discounts'], true);

// 2. Lấy cấu hình Bot Telegram
$stmtBot = $pdo->query("SELECT telegram_token, chat_id FROM setting_bot LIMIT 1");
$botConfig = $stmtBot->fetch(PDO::FETCH_ASSOC);

// 3. TÌM TẤT CẢ CÁC THẺ ĐANG CHỜ XỬ LÝ (STATUS = 99)
$stmtPending = $pdo->query("SELECT * FROM card_history WHERE status = 99 ORDER BY id ASC LIMIT 20");
$cards = $stmtPending->fetchAll(PDO::FETCH_ASSOC);

if (empty($cards)) {
    die("Khong co the nao dang cho xu ly.\n");
}

// 4. KIỂM TRA TRẠNG THÁI TỪNG THẺ
foreach ($cards as $card) {
    $sign = md5($partner_key . $card['code'] . $card['serial']);
    $postData = [
        'telco' => $card['telco'],
        'code' => $card['code'],
        'serial' => $card['serial'],
        'amount' => $card['amount'],
        'request_id' => $card['request_id'],
        'partner_id' => $partner_id,
        'sign' => $sign,
        'command' => 'check'
    ];

    $ch = curl_init('https://gachthefast.com/chargingws/v2');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $response = curl_exec($ch);
    curl_close($ch);

    $resArray = json_decode($response, true);

    if (is_array($resArray) && isset($resArray['status'])) {
        $api_status = (int)$resArray['status'];

        // Nếu thẻ ĐÃ ĐƯỢC XỬ LÝ XONG (Trạng thái khác 99)
        if ($api_status != 99) {
            $amount_real = isset($resArray['declared_value']) ? (int)$resArray['declared_value'] : 0;
            $msg = 'Thất bại / Sai thẻ';
            $money_add = 0;

            $req_amount = (int)$card['amount'];
            $discount_percent = $discounts[$card['telco']][$req_amount] ?? 20;

            // Xử lý tiền
            if ($api_status == 1) { // Thành công
                $msg = 'Thành công';
                $money_add = $req_amount * (1 - $discount_percent / 100);
            } elseif ($api_status == 2) { // Sai mệnh giá
                $msg = "Sai mệnh giá (Thực: " . number_format($amount_real) . ")";
                $real_discount = $discounts[$card['telco']][$amount_real] ?? 30; // Trừ chiết khấu phạt nếu có
                $money_add = $amount_real * (1 - $real_discount / 100);
            } else {
                $msg = $resArray['message'] ?? 'Sai thẻ hoặc lỗi';
            }

            // Giao dịch cập nhật trạng thái và cộng tiền
            $pdo->beginTransaction();
            try {
                // Cập nhật trạng thái thẻ
                $pdo->prepare("UPDATE card_history SET status=?, message=?, real_amount=? WHERE id=?")->execute([$api_status, $msg, $amount_real, $card['id']]);

                // Cộng tiền nếu thành công
                if ($money_add > 0) {
                    $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id=?")->execute([$money_add, $card['user_id']]);

                    // =====================================
                    // BẮN TELEGRAM CHỈ KHI NẠP THÀNH CÔNG
                    // =====================================
                    if (!empty($botConfig['telegram_token']) && !empty($botConfig['chat_id'])) {
                        $stmtU = $pdo->prepare("SELECT username FROM users WHERE id = ?");
                        $stmtU->execute([$card['user_id']]);
                        $username = $stmtU->fetchColumn() ?: 'Unknown';

                        $msg_tele = "✅ <b>NẠP THẺ THÀNH CÔNG</b>\n";
                        $msg_tele .= "━━━━━━━━━━━━━━━━━\n";
                        $msg_tele .= "👤 User: <b>$username</b>\n";
                        $msg_tele .= "📶 Loại thẻ: <b>{$card['telco']}</b>\n";
                        $msg_tele .= "💵 Mệnh giá nạp: <b>" . number_format($req_amount) . "đ</b>\n";
                        $msg_tele .= "💰 Web thực nhận: <b>" . number_format($money_add) . "đ</b>\n";

                        $urlTele = "https://api.telegram.org/bot{$botConfig['telegram_token']}/sendMessage";
                        $post_tele = ['chat_id' => $botConfig['chat_id'], 'text' => $msg_tele, 'parse_mode' => 'HTML'];

                        $chBot = curl_init($urlTele);
                        curl_setopt($chBot, CURLOPT_POST, 1);
                        curl_setopt($chBot, CURLOPT_POSTFIELDS, $post_tele);
                        curl_setopt($chBot, CURLOPT_RETURNTRANSFER, true);
                        curl_setopt($chBot, CURLOPT_TIMEOUT, 3);
                        curl_exec($chBot);
                        curl_close($chBot);
                    }
                }
                $pdo->commit();
                echo "Da xu ly the ID {$card['id']} -> Status: $api_status ($msg)\n";
            } catch (Exception $e) {
                $pdo->rollBack();
                echo "Loi xu ly the ID {$card['id']}: " . $e->getMessage() . "\n";
            }
        } else {
            echo "The ID {$card['id']} van dang cho nha mang xu ly...\n";
        }
    } else {
        echo "Loi ket noi hoac API gachthefast khong tra ve status cho the ID {$card['id']}\n";
    }
}
?>
