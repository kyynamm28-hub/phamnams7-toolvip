<?php
require_once __DIR__ . '/../config/database.php';

// Cấu hình Email gửi đi
$admin_email = "no-reply@zenrotool.site";
$subject = "Thông báo: Làm sạch dữ liệu lịch sử định kỳ";

try {
    $pdo->beginTransaction();

    // Lấy mốc thời gian 7 ngày trước
    $date_threshold = date('Y-m-d H:i:s', strtotime('-7 days'));

    // 1. Tìm các User có lịch sử bị xóa để gửi mail
    // (Ở đây demo bảng transfer_history, bạn có thể Union thêm các bảng history_package...)
    $stmtUsers = $pdo->prepare("
        SELECT DISTINCT u.id, u.username, u.email 
        FROM transfer_history t 
        JOIN users u ON t.user_id = u.id 
        WHERE t.created_at < ?
    ");
    $stmtUsers->execute([$date_threshold]);
    $users_to_notify = $stmtUsers->fetchAll(PDO::FETCH_ASSOC);

    // 2. Xóa dữ liệu cũ (> 7 ngày)
    $tables = ['transfer_history', 'history_package', 'history_token', 'user_logs'];
    foreach ($tables as $table) {
        // Bỏ qua nếu bảng không tồn tại
        try {
            $pdo->prepare("DELETE FROM $table WHERE created_at < ?")->execute([$date_threshold]);
        } catch (Exception $e) { continue; }
    }

    $pdo->commit();

    // 3. Gửi Email thông báo (Chạy nền)
    foreach ($users_to_notify as $user) {
        if (!empty($user['email'])) {
            $message = "Xin chào " . $user['username'] . ",\n\n";
            $message .= "Hệ thống ZENRO xin thông báo: Dựa theo chính sách bảo mật tối đa và bảo vệ quyền riêng tư Minimalist của chúng tôi, toàn bộ lịch sử giao dịch và hoạt động của bạn quá 7 ngày đã được xóa vĩnh viễn khỏi máy chủ.\n\n";
            $message .= "Cảm ơn bạn đã tin tưởng sử dụng dịch vụ.\n\n";
            $message .= "Trân trọng,\nĐội ngũ ZENRO.";
            
            $headers = "From: " . $admin_email . "\r\n";
            @mail($user['email'], $subject, $message, $headers);
        }
    }

    echo "Cronjob chạy thành công. Đã xóa dữ liệu cũ và gửi email.";

} catch (Exception $e) {
    if ($pdo->inTransaction()) { $pdo->rollBack(); }
    echo "Lỗi: " . $e->getMessage();
}
?>
