<?php
require_once __DIR__ . '/../config/database.php';

// ==========================================
// 1. LẤY CẤU HÌNH TỪ DATABASE (Lấy 1 lần duy nhất để tối ưu)
// ==========================================
// Lấy cấu hình Ngân Hàng
$stmtBank = $pdo->query("SELECT account_number, sepay_token FROM setting_bank WHERE method = 'auto' LIMIT 1");
$bankInfo = $stmtBank->fetch(PDO::FETCH_ASSOC);

// Lấy cấu hình Bot Telegram
$stmtBot = $pdo->query("SELECT telegram_token, chat_id FROM setting_bot LIMIT 1");
$botInfo = $stmtBot->fetch(PDO::FETCH_ASSOC);

if (!$bankInfo || empty($bankInfo['sepay_token'])) {
    die("Chua cau hinh Sepay Token hoac dang dung che do thu cong.\n");
}

$sepay_token = trim($bankInfo['sepay_token']);
$account_number = trim($bankInfo['account_number']);

// ==========================================
// 2. KẾT NỐI API SEPAY LẤY GIAO DỊCH MỚI
// ==========================================
$url = "https://my.sepay.vn/userapi/transactions/list?account_number={$account_number}&limit=20";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: Bearer {$sepay_token}",
    "Content-Type: application/json"
]);
$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);

if (isset($data['status']) && $data['status'] == 200 && !empty($data['transactions'])) {
    
    foreach ($data['transactions'] as $tran) {
        $amount_in = (int)$tran['amount_in'];
        $tran_content = strtoupper(trim($tran['transaction_content']));
        $reference = $tran['reference_number'];
        
        // Nếu không có tiền nạp vào, bỏ qua
        if ($amount_in <= 0) continue;

        // 3. Tìm trong DB xem có đơn nào đang chờ và khớp nội dung CK không
        $stmtFind = $pdo->prepare("SELECT * FROM transfer_history WHERE status = 'pending' AND ? LIKE CONCAT('%', content, '%') LIMIT 1");
        $stmtFind->execute([$tran_content]);
        $order = $stmtFind->fetch(PDO::FETCH_ASSOC);

        if ($order) {
            // Kiểm tra xem số tiền gửi vào có >= số tiền tạo đơn không
            if ($amount_in >= $order['amount']) {
                $pdo->beginTransaction();
                try {
                    // Cập nhật trạng thái hóa đơn -> Paid
                    $pdo->prepare("UPDATE transfer_history SET status = 'paid', paid_at = NOW() WHERE id = ?")->execute([$order['id']]);
                    
                    // Cộng tiền cho User
                    $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$amount_in, $order['user_id']]);
                    
                    // ==========================================
                    // THÊM MỚI: CỘNG HOA HỒNG CHO CTV (NGƯỜI GIỚI THIỆU)
                    // ==========================================
                    $stmtRefCheck = $pdo->prepare("SELECT ref_by FROM users WHERE id = ?");
                    $stmtRefCheck->execute([$order['user_id']]);
                    $ref_by = $stmtRefCheck->fetchColumn();

                    if (!empty($ref_by)) {
                        // Lấy % hoa hồng
                        $stmtCtv = $pdo->query("SELECT commission_rate FROM setting_ctv LIMIT 1");
                        $ctvData = $stmtCtv->fetch(PDO::FETCH_ASSOC);
                        $commission_rate = $ctvData ? (float)$ctvData['commission_rate'] : 10;

                        // Tính tiền và cộng vào ví hoa hồng (commission_balance)
                        $commission_amount = $amount_in * ($commission_rate / 100);
                        if ($commission_amount > 0) {
                            $pdo->prepare("UPDATE users SET commission_balance = commission_balance + ? WHERE id = ?")
                                ->execute([$commission_amount, $ref_by]);
                        }
                    }
                    // ==========================================

                    $pdo->commit();
                    
                    // ==========================================
                    // 4. GỬI THÔNG BÁO ĐÃ ĐƯỢC FIX LỖI & LÀM ĐẸP QUA TELEGRAM
                    // ==========================================
                    if ($botInfo && !empty($botInfo['telegram_token']) && !empty($botInfo['chat_id'])) {
                        
                        // Lấy thông tin user sau khi đã cộng tiền
                        $stmtUser = $pdo->prepare("SELECT username, email, balance FROM users WHERE id = ? LIMIT 1");
                        $stmtUser->execute([$order['user_id']]);
                        $uInfo = $stmtUser->fetch(PDO::FETCH_ASSOC);

                        $botToken = trim($botInfo['telegram_token']);
                        $chatId = trim($botInfo['chat_id']);
                        
                        $user_display = !empty($uInfo['username']) ? $uInfo['username'] : 'Unknown';

                        // Soạn tin nhắn Telegram đẹp mắt bằng HTML
                        $msg = "🔔 <b>THÔNG BÁO NẠP TIỀN THÀNH CÔNG</b>\n";
                        $msg .= "━━━━━━━━━━━━━━━━━━━━━━\n\n";
                        $msg .= "👤 <b>Khách hàng:</b> <code>" . htmlspecialchars($user_display) . "</code> (ID: " . $order['user_id'] . ")\n";
                        $msg .= "💰 <b>Số tiền:</b> <tg-spoiler><b>" . number_format($amount_in) . " VNĐ</b></tg-spoiler>\n";
                        $msg .= "📝 <b>Nội dung:</b> <code>" . htmlspecialchars($tran_content) . "</code>\n";
                        $msg .= "🔍 <b>Mã giao dịch:</b> <code>" . $reference . "</code>\n\n";
                        $msg .= "━━━━━━━━━━━━━━━━━━━━━━\n";
                        $msg .= "✅ <b>Kênh Chính Thức:</b> @zenrotool\n";
                        $msg .= "💡 <i>Hệ thống đã tự động cộng tiền qua SePay!</i>";

                        // Cấu hình nút bấm chuyển hướng đến trang web
                        $keyboard = [
                            'inline_keyboard' => [
                                [
                                    ['text' => '🌐 Truy Cập Website', 'url' => 'https://zenrotool.site/']
                                ]
                            ]
                        ];

                        // Gửi thông báo qua cURL kèm reply_markup chứa button
                        $urlTele = "https://api.telegram.org/bot{$botToken}/sendMessage";
                        $post_fields = [
                            'chat_id' => $chatId,
                            'text' => $msg,
                            'parse_mode' => 'HTML',
                            'reply_markup' => json_encode($keyboard)
                        ];
                        
                        $chBot = curl_init();
                        curl_setopt($chBot, CURLOPT_URL, $urlTele);
                        curl_setopt($chBot, CURLOPT_POST, 1);
                        curl_setopt($chBot, CURLOPT_POSTFIELDS, $post_fields);
                        curl_setopt($chBot, CURLOPT_RETURNTRANSFER, true);
                        curl_setopt($chBot, CURLOPT_SSL_VERIFYPEER, false);
                        curl_setopt($chBot, CURLOPT_TIMEOUT, 5);
                        curl_exec($chBot);
                        curl_close($chBot);
                    }

                    echo "Da xu ly don: {$order['order_token']} va cong tien thanh cong!\n";
                } catch (Exception $e) {
                    $pdo->rollBack();
                    echo "Loi khi xu ly don {$order['order_token']}: " . $e->getMessage() . "\n";
                }
            }
        }
    }
} else {
    echo "Khong co giao dich moi hoac loi ket noi SePay.\n";
}
?>
