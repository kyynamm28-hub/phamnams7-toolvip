
CREATE TABLE `api_packages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` int(11) NOT NULL,
  `duration_days` int(11) NOT NULL,
  `image` varchar(255) DEFAULT 'https://cdn-icons-png.flaticon.com/512/8144/8144288.png',
  `status` enum('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `blogs`

CREATE TABLE `blogs` (
  `id` int(11) NOT NULL,
  `token` varchar(64) NOT NULL,
  `title` varchar(255) NOT NULL,
  `short_description` varchar(500) NOT NULL,
  `content` longtext NOT NULL,
  `image` varchar(500) NOT NULL,
  `position` int(11) DEFAULT 0,
  `views` int(11) DEFAULT 0,
  `likes` int(11) DEFAULT 0,
  `status` enum('active','hidden') DEFAULT 'active',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `blog_likes`

CREATE TABLE `blog_likes` (
  `user_id` int(11) NOT NULL,
  `blog_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `card_history`

CREATE TABLE `card_history` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL COMMENT 'ID của người nạp',
  `telco` varchar(50) NOT NULL COMMENT 'Nhà mạng (VIETTEL, VINAPHONE...)',
  `amount` int(11) NOT NULL COMMENT 'Mệnh giá khách chọn',
  `real_amount` int(11) DEFAULT 0 COMMENT 'Mệnh giá thực nhận (nếu khách chọn sai mệnh giá)',
  `serial` varchar(100) NOT NULL COMMENT 'Số seri thẻ',
  `code` varchar(100) NOT NULL COMMENT 'Mã thẻ (PIN)',
  `request_id` varchar(100) NOT NULL COMMENT 'Mã Request ID gửi lên API',
  `status` int(11) NOT NULL DEFAULT 99 COMMENT '1: Thành công, 2: Sai mệnh giá, 99: Đang chờ, 100+: Thất bại',
  `message` varchar(255) DEFAULT NULL COMMENT 'Thông báo trả về từ API đối tác',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `category`

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `icon` varchar(255) DEFAULT 'https://cdn-icons-png.flaticon.com/512/8144/8144288.png',
  `status` enum('active','inactive') DEFAULT 'active',
  `position` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `slug`, `icon`, `status`, `position`) VALUES
(1, 'Tất cả', 'all', 'https://cdn-icons-png.flaticon.com/512/3843/3843037.png', 'active', 0),
(2, 'Tài Xỉu', 'taixiu', 'https://cdn-icons-png.flaticon.com/512/6890/6890731.png', 'active', 1),
(3, 'Sicbo', 'sicbo', 'https://cdn-icons-png.flaticon.com/512/2928/2928929.png', 'active', 2),
(4, 'Baccarat', 'bacarat', 'https://cdn-icons-png.flaticon.com/512/1033/1033333.png', 'active', 3);

-- --------------------------------------------------------

--
-- Table structure for table `games`
--

CREATE TABLE `games` (
  `id` int(11) NOT NULL,
  `category` varchar(50) NOT NULL DEFAULT 'khac' COMMENT 'Thể loại: taixiu, sicbo, bacarat',
  `slug` varchar(150) NOT NULL COMMENT 'Đường dẫn tĩnh duy nhất',
  `name` varchar(255) NOT NULL COMMENT 'Tên game',
  `image` varchar(500) DEFAULT NULL COMMENT 'Đường dẫn ảnh Thumbnail',
  `description` longtext DEFAULT NULL COMMENT 'Mô tả chi tiết (hỗ trợ HTML)',
  `badge` varchar(50) DEFAULT NULL COMMENT 'Mác nổi bật (HOT, NEW...)',
  `position` int(11) DEFAULT 0 COMMENT 'Vị trí sắp xếp',
  `url_iframe` varchar(500) DEFAULT NULL COMMENT 'URL Iframe nhúng game',
  `api_predict_url` varchar(500) DEFAULT NULL COMMENT 'URL API dự đoán',
  `map_notify` varchar(100) DEFAULT NULL COMMENT 'Map báo phiên',
  `map_predict` varchar(100) DEFAULT NULL COMMENT 'Map dự đoán',
  `map_predict_vi` varchar(100) DEFAULT NULL COMMENT 'Map dự đoán vị (Sicbo)',
  `map_rate` varchar(100) DEFAULT NULL COMMENT 'Map tỷ lệ',
  `map_history_prev` varchar(100) DEFAULT NULL COMMENT 'Map phiên trước',
  `map_history_result` varchar(100) DEFAULT NULL COMMENT 'Map kết quả',
  `map_history_sum` varchar(100) DEFAULT NULL COMMENT 'Map tổng 3 xúc xắc',
  `map_history_dice1` varchar(100) DEFAULT NULL COMMENT 'Map xúc xắc 1',
  `map_history_dice2` varchar(100) DEFAULT NULL COMMENT 'Map xúc xắc 2',
  `map_history_dice3` varchar(100) DEFAULT NULL COMMENT 'Map xúc xắc 3',
  `status` enum('active','inactive','maintenance') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `history_bank_ctv`

CREATE TABLE `history_bank_ctv` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `account_number` varchar(50) NOT NULL,
  `account_name` varchar(100) NOT NULL,
  `amount` int(11) NOT NULL,
  `actual_amount` int(11) NOT NULL,
  `status` enum('pending','success','rejected') DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `history_package`

CREATE TABLE `history_package` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `package_name` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `duration_days` int(11) NOT NULL,
  `purchased_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `history_product`

CREATE TABLE `history_product` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `download_url` varchar(500) NOT NULL,
  `purchased_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `history_token`

CREATE TABLE `history_token` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `package_id` int(11) NOT NULL,
  `package_name` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `duration_days` int(11) NOT NULL,
  `api_token` varchar(128) NOT NULL,
  `purchased_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `packages`

CREATE TABLE `packages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` int(11) NOT NULL,
  `duration_days` int(11) NOT NULL,
  `image` varchar(255) DEFAULT '/client/layout/assets/images/default-vip.png',
  `status` enum('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `partners`

CREATE TABLE `partners` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(500) NOT NULL,
  `logo_url` varchar(500) NOT NULL,
  `website_url` varchar(500) NOT NULL,
  `status` enum('active','hidden') DEFAULT 'active',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `products`

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `short_description` varchar(500) NOT NULL,
  `content` text NOT NULL,
  `price` int(11) NOT NULL,
  `support_contact` varchar(255) NOT NULL,
  `download_url` varchar(500) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `product_images`

CREATE TABLE `product_images` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image_url` varchar(500) NOT NULL,
  `is_primary` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `settings`

CREATE TABLE `settings` (
  `key` varchar(50) NOT NULL,
  `value` text DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `setting_bank`

CREATE TABLE `setting_bank` (
  `id` int(11) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `short_name` varchar(50) NOT NULL,
  `bin` varchar(20) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `account_number` varchar(50) NOT NULL,
  `account_name` varchar(100) NOT NULL,
  `min_recharge` int(11) DEFAULT 10000,
  `method` enum('auto','manual') DEFAULT 'auto',
  `sepay_token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `setting_bot`

CREATE TABLE `setting_bot` (
  `id` int(11) NOT NULL,
  `telegram_token` varchar(255) DEFAULT NULL,
  `chat_id` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `setting_card`

CREATE TABLE `setting_card` (
  `id` int(11) NOT NULL,
  `partner_id` varchar(255) NOT NULL COMMENT 'Partner ID của GachTheFast',
  `partner_key` varchar(255) NOT NULL COMMENT 'Partner Key của GachTheFast',
  `discounts` text NOT NULL COMMENT 'Chiết khấu các nhà mạng (Định dạng JSON)',
  `status` enum('active','maintenance') DEFAULT 'active' COMMENT 'Trạng thái bảo trì nạp thẻ',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `setting_ctv`

CREATE TABLE `setting_ctv` (
  `id` int(11) NOT NULL,
  `commission_rate` int(11) NOT NULL DEFAULT 10,
  `min_withdraw` int(11) NOT NULL DEFAULT 50000,
  `withdraw_fee` int(11) NOT NULL DEFAULT 5
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `setting_partner`

CREATE TABLE `setting_partner` (
  `id` int(11) NOT NULL,
  `price_day` int(11) NOT NULL DEFAULT 20000,
  `price_week` int(11) NOT NULL DEFAULT 80000,
  `price_month` int(11) NOT NULL DEFAULT 300000,
  `contact_link` varchar(255) NOT NULL DEFAULT 'https://t.me/zenroadmin'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `transfer_history`

CREATE TABLE `transfer_history` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_token` varchar(64) NOT NULL,
  `amount` int(11) NOT NULL,
  `content` varchar(100) NOT NULL,
  `status` enum('pending','paid','expired','success') DEFAULT 'pending',
  `created_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `paid_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `users`

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `ref_by` int(11) DEFAULT NULL,
  `display_name` varchar(100) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `google_id` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `role` varchar(20) DEFAULT 'user',
  `referred_by` int(11) DEFAULT NULL,
  `balance` decimal(15,2) DEFAULT 0.00,
  `commission_balance` decimal(15,2) DEFAULT 0.00,
  `vip_name` varchar(50) DEFAULT NULL,
  `vip_expire_at` datetime DEFAULT NULL,
  `avatar` varchar(255) DEFAULT '/client/layout/assets/images/user.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `user_devices`

CREATE TABLE `user_devices` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `ip_address` varchar(50) NOT NULL,
  `last_active` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `user_logs`

CREATE TABLE `user_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Indexes for table `api_packages`

ALTER TABLE `api_packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`);

--
-- Indexes for table `blog_likes`
--
ALTER TABLE `blog_likes`
  ADD PRIMARY KEY (`user_id`,`blog_id`);

--
-- Indexes for table `card_history`
--
ALTER TABLE `card_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `request_id` (`request_id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `games`
--
ALTER TABLE `games`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_slug` (`slug`);

--
-- Indexes for table `history_bank_ctv`
--
ALTER TABLE `history_bank_ctv`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history_package`
--
ALTER TABLE `history_package`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history_product`
--
ALTER TABLE `history_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history_token`
--
ALTER TABLE `history_token`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `api_token` (`api_token`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `partners`
--
ALTER TABLE `partners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `setting_bank`
--
ALTER TABLE `setting_bank`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setting_bot`
--
ALTER TABLE `setting_bot`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setting_card`
--
ALTER TABLE `setting_card`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setting_ctv`
--
ALTER TABLE `setting_ctv`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setting_partner`
--
ALTER TABLE `setting_partner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transfer_history`
--
ALTER TABLE `transfer_history`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_token` (`order_token`),
  ADD UNIQUE KEY `content` (`content`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `google_id` (`google_id`);

--
-- Indexes for table `user_devices`
--
ALTER TABLE `user_devices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_logs`
--
ALTER TABLE `user_logs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `api_packages`
--
ALTER TABLE `api_packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `card_history`
--
ALTER TABLE `card_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `games`
--
ALTER TABLE `games`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `history_bank_ctv`
--
ALTER TABLE `history_bank_ctv`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `history_package`
--
ALTER TABLE `history_package`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=179;

--
-- AUTO_INCREMENT for table `history_product`
--
ALTER TABLE `history_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `history_token`
--
ALTER TABLE `history_token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `partners`
--
ALTER TABLE `partners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `setting_bank`
--
ALTER TABLE `setting_bank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `setting_bot`
--
ALTER TABLE `setting_bot`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `setting_card`
--
ALTER TABLE `setting_card`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `setting_ctv`
--
ALTER TABLE `setting_ctv`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `setting_partner`
--
ALTER TABLE `setting_partner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `transfer_history`
--
ALTER TABLE `transfer_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=290;

ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=693;

ALTER TABLE `user_devices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2098;

ALTER TABLE `user_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;


ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;