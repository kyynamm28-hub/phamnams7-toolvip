<?php
// Tải toàn bộ cấu hình, kết nối DB và khởi tạo Session
require_once __DIR__ . '/config/settings.php';

// 2. Kiểm tra nếu user đã đăng nhập thì chuyển hướng vào dashboard (/home)
if (isset($_SESSION['user_id'])) {
    header("Location: /home");
    exit;
}

// Thiết lập pageTitle trước khi gọi head.php
$pageTitle = "Trang chủ";
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <?php 
        // 3. Kế thừa thông tin SEO, Cấu hình màu sắc (Tailwind), và Thẻ Head gốc
        require_once __DIR__ . '/client/layout/include/head.php'; 
    ?>
    
    <style>
        .delay-1 { animation-delay: 0.05s; opacity: 0; }
        .delay-2 { animation-delay: 0.15s; opacity: 0; }
        .delay-3 { animation-delay: 0.25s; opacity: 0; }
        .delay-4 { animation-delay: 0.35s; opacity: 0; }
        
        @keyframes float-reverse {
            0%, 100% { transform: translateY(-10px) rotate(0deg); }
            50% { transform: translateY(10px) rotate(-5deg); }
        }
        @keyframes pulse-glow {
            0%, 100% { box-shadow: 0 0 20px rgba(70, 95, 255, 0.3), 0 0 40px rgba(70, 95, 255, 0.1); }
            50% { box-shadow: 0 0 30px rgba(70, 95, 255, 0.5), 0 0 60px rgba(70, 95, 255, 0.2); }
        }
        @keyframes gradient-shift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        @keyframes orbit {
            0% { transform: rotate(0deg) translateX(120px) rotate(0deg); }
            100% { transform: rotate(360deg) translateX(120px) rotate(-360deg); }
        }
        @keyframes orbit-reverse {
            0% { transform: rotate(0deg) translateX(80px) rotate(0deg); }
            100% { transform: rotate(-360deg) translateX(80px) rotate(360deg); }
        }
        @keyframes blink {
            0%, 100% { opacity: 0.3; }
            50% { opacity: 1; }
        }
        
        .floating-dot:nth-child(2) { animation: float-reverse 8s ease-in-out infinite; animation-delay: -2s; }
        .floating-dot:nth-child(3) { animation: float 7s ease-in-out infinite; animation-delay: -4s; }
        
        .orbit-dot {
            position: absolute;
            width: 8px;
            height: 8px;
            background: #465fff;
            border-radius: 50%;
            animation: orbit 20s linear infinite;
            opacity: 0.4;
        }
        .orbit-dot:nth-child(2) {
            animation: orbit-reverse 25s linear infinite;
            width: 6px;
            height: 6px;
            background: #9fc4ff;
        }
        
        .card-tech {
            --mouse-x: 50%;
            --mouse-y: 50%;
            position: relative;
            transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .card-tech::before {
            content: '';
            position: absolute;
            inset: 0;
            border-radius: inherit;
            padding: 1px;
            background: linear-gradient(135deg, transparent 40%, rgba(70, 95, 255, 0.3), transparent 60%);
            -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
            mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
            -webkit-mask-composite: xor;
            mask-composite: exclude;
            opacity: 0;
            transition: opacity 0.4s;
        }
        .card-tech::after {
            content: '';
            position: absolute;
            inset: 0;
            border-radius: inherit;
            background: radial-gradient(400px circle at var(--mouse-x) var(--mouse-y), rgba(70, 95, 255, 0.06), transparent 40%);
            opacity: 0;
            transition: opacity 0.4s;
            pointer-events: none;
        }
        .card-tech:hover::before { opacity: 1; }
        .card-tech:hover::after { opacity: 1; }
        .card-tech:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 40px rgba(70, 95, 255, 0.1), 0 0 0 1px rgba(70, 95, 255, 0.1);
        }
        
        .icon-pulse {
            animation: pulse-glow 3s ease-in-out infinite;
        }
        
        .code-window {
            position: relative;
        }
        .code-window::after {
            content: '';
            position: absolute;
            inset: -1px;
            border-radius: inherit;
            background: linear-gradient(135deg, rgba(70, 95, 255, 0.5), transparent 50%, rgba(159, 196, 255, 0.5));
            z-index: -1;
            opacity: 0.5;
            filter: blur(10px);
            animation: pulse-glow 4s ease-in-out infinite;
        }
        
        .scroll-reveal {
            opacity: 0;
            transform: translateY(30px);
            transition: all 0.8s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .scroll-reveal.revealed {
            opacity: 1;
            transform: translateY(0);
        }
        
        .gradient-text {
            background: linear-gradient(135deg, #465fff 0%, #2a31d8 50%, #465fff 100%);
            background-size: 200% auto;
            -webkit-background-clip: text;
            background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: gradient-shift 4s ease infinite;
        }
        
        .tech-line {
            position: absolute;
            width: 1px;
            background: linear-gradient(to bottom, transparent, rgba(70, 95, 255, 0.3), transparent);
            animation: blink 3s ease-in-out infinite;
        }
        
        .cta-glow {
            position: relative;
        }
        .cta-glow::before {
            content: '';
            position: absolute;
            inset: -40px;
            background: radial-gradient(ellipse at center, rgba(70, 95, 255, 0.15), transparent 70%);
            z-index: -1;
            animation: pulse-glow 4s ease-in-out infinite;
        }
    </style>
</head>
<body class="bg-white text-gray-800">
    <header id="mainHeader" class="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-sm border-b border-gray-100 transition-all duration-300">
        <nav class="max-w-6xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
            <a href="/" class="flex items-center gap-2 group">
                <span class="text-2xl font-bold gradient-text transition-transform group-hover:scale-105">ZENRO.SITE</span>
            </a>
            <div class="flex items-center gap-2">
                <a href="/auth/#login" class="px-4 py-2 text-sm font-medium text-gray-600 hover:text-brand-600 transition relative after:absolute after:bottom-1 after:left-1/2 after:w-0 after:h-0.5 after:bg-brand-500 after:transition-all after:duration-300 hover:after:w-4/5 hover:after:-translate-x-1/2">Đăng nhập</a>
                <a href="/auth/#register" class="btn-glow px-4 py-2 text-sm font-medium text-white bg-brand-500 rounded-lg hover:bg-brand-600 transition">Đăng ký</a>
            </div>
        </nav>
    </header>

    <section class="min-h-screen pt-20 pb-16 flex items-center bg-gradient-to-b from-brand-50/50 to-white relative overflow-hidden">
        <div class="grid-bg"></div>
        <div class="floating-dot" style="top:15%;left:10%;"></div>
        <div class="floating-dot" style="top:60%;left:5%;width:4px;height:4px;"></div>
        <div class="floating-dot" style="top:30%;right:8%;width:8px;height:8px;"></div>
        <div class="floating-dot" style="top:70%;right:15%;width:5px;height:5px;"></div>
        <div class="floating-dot" style="top:80%;left:20%;width:3px;height:3px;"></div>
        <div class="orbit-dot" style="top:50%;left:50%;"></div>
        <div class="orbit-dot" style="top:50%;left:50%;"></div>
        <div class="tech-line" style="height:120px;top:10%;left:15%;animation-delay:0s;"></div>
        <div class="tech-line" style="height:80px;top:40%;right:20%;animation-delay:1s;"></div>
        <div class="tech-line" style="height:60px;bottom:20%;left:25%;animation-delay:2s;"></div>
        
        <div class="max-w-6xl mx-auto px-4 sm:px-6 w-full relative z-10">
            <div class="grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
                <div class="text-center lg:text-left">
                    <div class="fade-up delay-1 inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-green-50 text-green-700 text-sm mb-5">
                        <span class="w-2 h-2 bg-green-500 rounded-full"></span>
                        <span>Chào mừng quý khách đến với</span>
                    </div>
                    
                    <h1 class="fade-up delay-2 text-3xl sm:text-4xl lg:text-5xl font-bold leading-tight mb-4">
                        <span class="gradient-text">ZENRO.SITE</span>
                    </h1>
                    <p class="fade-up delay-2 text-lg sm:text-xl text-brand-600 font-semibold mb-5">Hệ sinh thái đa dịch vụ dành cho MMO</p>
                    
                    <p class="fade-up delay-3 text-base text-gray-500 mb-8 max-w-md mx-auto lg:mx-0">
                        Cung cấp đa dạng các công cụ tiện ích, dịch vụ mạng xã hội, mua bán tài nguyên MMO, fake bill và các trò chơi giải trí cực hấp dẫn.
                    </p>
                    
                    <div class="fade-up delay-4 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3">
                        <a href="/auth/#register" class="btn-glow w-full sm:w-auto px-6 py-3 text-sm font-semibold text-white bg-brand-500 rounded-lg hover:bg-brand-600 transition flex items-center justify-center gap-2">
                            <i class="ri-rocket-line"></i> Khám phá ngay
                        </a>
                        <a href="#services" class="w-full sm:w-auto px-6 py-3 text-sm font-semibold text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition flex items-center justify-center gap-2 hover:shadow-lg">
                            <i class="ri-arrow-down-line"></i> Xem dịch vụ
                        </a>
                    </div>
                    
                    <div class="fade-up delay-4 flex items-center justify-center lg:justify-start gap-5 mt-8 text-sm text-gray-500">
                        <span class="flex items-center gap-1.5"><i class="ri-checkbox-circle-fill text-green-500"></i> Xử lý tự động</span>
                        <span class="flex items-center gap-1.5"><i class="ri-checkbox-circle-fill text-green-500"></i> Nhanh chóng & Bảo mật</span>
                    </div>
                </div>
                
                <div class="fade-up delay-3 relative mt-6 lg:mt-0">
                    <div class="code-window bg-gray-900 rounded-xl p-5 shadow-xl">
                        <div class="flex items-center gap-2 mb-4">
                            <div class="w-3 h-3 rounded-full bg-red-400"></div>
                            <div class="w-3 h-3 rounded-full bg-yellow-400"></div>
                            <div class="w-3 h-3 rounded-full bg-green-400"></div>
                            <span class="ml-2 text-xs text-gray-500">zenro_api_response.json</span>
                        </div>
                        <pre class="text-sm text-gray-300 overflow-x-auto"><code>{
  <span class="text-blue-400">"status"</span>: <span class="text-green-400">"success"</span>,
  <span class="text-blue-400">"data"</span>: {
    <span class="text-blue-400">"service_type"</span>: <span class="text-amber-400">"Tăng Tương Tác"</span>,
    <span class="text-blue-400">"quantity"</span>: <span class="text-cyan-400">5000</span>,
    <span class="text-blue-400">"platform"</span>: <span class="text-amber-400">"Facebook"</span>,
    <span class="text-blue-400">"process"</span>: <span class="text-amber-400">"Hoàn tất"</span>
  }
}</code></pre>
                    </div>
                    
                    <div class="absolute -bottom-3 -right-3 sm:-bottom-4 sm:-right-4 bg-white rounded-lg p-3 shadow-lg border border-gray-100 max-w-[180px]">
                        <div class="flex items-center gap-2">
                            <div class="w-9 h-9 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                                <i class="ri-check-line text-green-600 text-lg"></i>
                            </div>
                            <div class="min-w-0">
                                <p class="text-xs text-gray-500">Trạng thái đơn</p>
                                <p class="text-sm font-semibold text-green-600">Thành công!</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="services" class="py-16 sm:py-20 bg-gray-50 relative overflow-hidden">
        <div class="floating-dot" style="top:20%;right:10%;width:10px;height:10px;opacity:0.3;"></div>
        <div class="floating-dot" style="bottom:30%;left:8%;width:6px;height:6px;opacity:0.4;"></div>
        <div class="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
            <h2 class="text-2xl sm:text-3xl font-bold text-gray-900 text-center mb-10 scroll-reveal">Các dịch vụ cung cấp</h2>
            
            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                <div class="card-tech scroll-reveal bg-white rounded-xl p-6 border border-gray-100 hover:border-brand-200 hover:shadow-lg transition" style="transition-delay:0.1s;">
                    <div class="w-12 h-12 bg-brand-500 rounded-lg flex items-center justify-center mb-4 group-hover:icon-pulse">
                        <i class="ri-tools-line text-white text-xl"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 mb-2">Công Cụ (Tools)</h3>
                    <p class="text-gray-500 text-sm">Cung cấp bộ công cụ mạnh mẽ hỗ trợ tự động hóa, tăng tốc công việc cho dân MMO.</p>
                </div>
                
                <div class="card-tech scroll-reveal bg-white rounded-xl p-6 border border-gray-100 hover:border-green-200 hover:shadow-lg transition" style="transition-delay:0.15s;">
                    <div class="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mb-4 group-hover:icon-pulse">
                        <i class="ri-receipt-line text-white text-xl"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 mb-2">Fake Bill</h3>
                    <p class="text-gray-500 text-sm">Hệ thống tạo bill giao dịch, bill chuyển khoản đa ngân hàng với độ chân thực tuyệt đối.</p>
                </div>
                
                <div class="card-tech scroll-reveal bg-white rounded-xl p-6 border border-gray-100 hover:border-blue-200 hover:shadow-lg transition" style="transition-delay:0.2s;">
                    <div class="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center mb-4 group-hover:icon-pulse">
                        <i class="ri-thumb-up-line text-white text-xl"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 mb-2">Dịch Vụ Mạng Xã Hội</h3>
                    <p class="text-gray-500 text-sm">Tăng like, sub, view, tương tác cho Facebook, TikTok, Instagram an toàn và nhanh chóng.</p>
                </div>

                <div class="card-tech scroll-reveal bg-white rounded-xl p-6 border border-gray-100 hover:border-amber-200 hover:shadow-lg transition" style="transition-delay:0.25s;">
                    <div class="w-12 h-12 bg-amber-500 rounded-lg flex items-center justify-center mb-4 group-hover:icon-pulse">
                        <i class="ri-store-2-line text-white text-xl"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 mb-2">Mua Bán Tài Nguyên MMO</h3>
                    <p class="text-gray-500 text-sm">Chợ giao dịch tài nguyên như Via, Clone, Proxy, Email chất lượng với giá cả cạnh tranh.</p>
                </div>

                <div class="card-tech scroll-reveal bg-white rounded-xl p-6 border border-gray-100 hover:border-purple-200 hover:shadow-lg transition" style="transition-delay:0.3s;">
                    <div class="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center mb-4 group-hover:icon-pulse">
                        <i class="ri-gift-line text-white text-xl"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 mb-2">Random Túi Mù Game</h3>
                    <p class="text-gray-500 text-sm">Giải trí trúng thưởng với hệ thống túi mù, nhận random các vật phẩm game giá trị cao.</p>
                </div>
            </div>
        </div>
    </section>

    <section id="features" class="py-16 sm:py-20 bg-white relative overflow-hidden">
        <div class="grid-bg" style="opacity:0.5;"></div>
        <div class="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
            <div class="text-center mb-12 scroll-reveal">
                <h2 class="text-2xl sm:text-3xl font-bold text-gray-900 mb-3">Lý do đồng hành cùng ZENRO</h2>
                <p class="text-gray-500 max-w-xl mx-auto">Chúng tôi cam kết mang lại trải nghiệm tốt nhất cho người dùng</p>
            </div>
            
            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                <div class="card-tech scroll-reveal bg-gray-50 rounded-xl p-5 hover:bg-brand-50 transition group border border-transparent hover:border-brand-100" style="transition-delay:0.1s;">
                    <div class="w-11 h-11 bg-brand-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-brand-500 transition group-hover:icon-pulse">
                        <i class="ri-flashlight-line text-xl text-brand-600 group-hover:text-white transition"></i>
                    </div>
                    <h3 class="text-base font-bold text-gray-900 mb-2">Hệ thống tự động</h3>
                    <p class="text-gray-500 text-sm">Xử lý mọi giao dịch và đơn hàng hoàn toàn tự động 24/24 với tốc độ chớp nhoáng.</p>
                </div>
                
                <div class="card-tech scroll-reveal bg-gray-50 rounded-xl p-5 hover:bg-green-50 transition group border border-transparent hover:border-green-100" style="transition-delay:0.15s;">
                    <div class="w-11 h-11 bg-green-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-green-500 transition">
                        <i class="ri-shield-check-line text-xl text-green-600 group-hover:text-white transition"></i>
                    </div>
                    <h3 class="text-base font-bold text-gray-900 mb-2">Bảo mật tuyệt đối</h3>
                    <p class="text-gray-500 text-sm">Thông tin khách hàng và lịch sử sử dụng dịch vụ được mã hóa an toàn, riêng tư.</p>
                </div>
                
                <div class="card-tech scroll-reveal bg-gray-50 rounded-xl p-5 hover:bg-purple-50 transition group border border-transparent hover:border-purple-100" style="transition-delay:0.2s;">
                    <div class="w-11 h-11 bg-purple-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-purple-500 transition">
                        <i class="ri-money-dollar-circle-line text-xl text-purple-600 group-hover:text-white transition"></i>
                    </div>
                    <h3 class="text-base font-bold text-gray-900 mb-2">Giá cả cạnh tranh</h3>
                    <p class="text-gray-500 text-sm">Cam kết mức giá tốt nhất thị trường cùng nhiều chương trình khuyến mãi cho đại lý.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="py-16 sm:py-20 bg-brand-500 relative overflow-hidden">
        <div class="absolute inset-0" style="background:linear-gradient(135deg,rgba(42,49,216,0.3) 0%,transparent 50%,rgba(159,196,255,0.2) 100%);"></div>
        <div class="floating-dot" style="top:20%;left:15%;background:rgba(255,255,255,0.3);width:8px;height:8px;"></div>
        <div class="floating-dot" style="bottom:25%;right:20%;background:rgba(255,255,255,0.2);width:6px;height:6px;"></div>
        <div class="floating-dot" style="top:60%;left:80%;background:rgba(255,255,255,0.25);width:4px;height:4px;"></div>
        <div class="max-w-3xl mx-auto px-4 sm:px-6 text-center relative z-10 cta-glow scroll-reveal">
            <h2 class="text-2xl sm:text-3xl font-bold text-white mb-3">Sẵn sàng trải nghiệm?</h2>
            <p class="text-brand-100 mb-8">Tham gia hệ sinh thái dịch vụ đa dạng của ZENRO ngay hôm nay!</p>
            <div class="flex flex-col sm:flex-row items-center justify-center gap-3">
                <a href="/auth/#register" class="btn-glow w-full sm:w-auto px-8 py-3 text-sm font-semibold text-brand-600 bg-white rounded-lg hover:bg-gray-100 transition flex items-center justify-center gap-2 hover:shadow-xl">
                    <i class="ri-user-add-line"></i> Bắt đầu ngay
                </a>
                <a href="/auth/#login" class="w-full sm:w-auto px-8 py-3 text-sm font-semibold text-white border border-white/30 rounded-lg hover:bg-white/10 transition flex items-center justify-center gap-2 hover:border-white/60">
                    <i class="ri-login-box-line"></i> Đăng nhập
                </a>
            </div>
        </div>
    </section>

    <footer class="py-6 bg-white border-t border-gray-100 text-center">
        <p class="text-gray-500 text-sm">&copy; 2026 ZENRO.SITE. Phát triển bởi <span class="text-brand-500 font-medium">ZENTEAM</span></p>
    </footer>

    <script>
        console.log('%cPowered by ZENTeam %c Telegram @ThienNhanVn', 'background:#1e3a5f;color:#fff;padding:4px 10px;border-radius:4px 0 0 4px;font-weight:bold', 'background:#f59e0b;color:#1e3a5f;padding:4px 10px;border-radius:0 4px 4px 0;font-weight:bold');
    </script>
    <script>
    (function(){
        var reveals = document.querySelectorAll('.scroll-reveal');
        var observer = new IntersectionObserver(function(entries){
            entries.forEach(function(entry){
                if(entry.isIntersecting){
                    entry.target.classList.add('revealed');
                }
            });
        }, {threshold:0.1, rootMargin:'0px 0px -50px 0px'});
        reveals.forEach(function(el){ observer.observe(el); });
        
        var codeEl = document.querySelector('.code-window pre code');
        if(codeEl){
            var lines = codeEl.innerHTML.split('\n');
            var i = 0;
            codeEl.innerHTML = '';
            function typeLine(){
                if(i < lines.length){
                    codeEl.innerHTML += (i > 0 ? '\n' : '') + lines[i];
                    i++;
                    setTimeout(typeLine, 80);
                }
            }
            setTimeout(typeLine, 800);
        }
        
        document.querySelectorAll('.card-tech').forEach(function(card){
            card.addEventListener('mousemove', function(e){
                var rect = card.getBoundingClientRect();
                var x = e.clientX - rect.left;
                var y = e.clientY - rect.top;
                card.style.setProperty('--mouse-x', x + 'px');
                card.style.setProperty('--mouse-y', y + 'px');
            });
        });
        
        var header = document.getElementById('mainHeader');
        var lastScroll = 0;
        window.addEventListener('scroll', function(){
            var currentScroll = window.pageYOffset;
            if(currentScroll > 50){
                header.style.boxShadow = '0 4px 20px rgba(70, 95, 255, 0.08)';
                header.style.background = 'rgba(255,255,255,0.95)';
            } else {
                header.style.boxShadow = 'none';
                header.style.background = 'rgba(255,255,255,0.9)';
            }
            lastScroll = currentScroll;
        });
    })();
    </script>
</body>
</html>