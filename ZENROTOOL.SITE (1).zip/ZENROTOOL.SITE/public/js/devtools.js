// public/js/devtools.js
(function() {
    'use strict';

    // 1. Chặn Click chuột phải (Context Menu)
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
    });

    // 2. Chặn bôi đen văn bản (Text Selection)
    document.addEventListener('selectstart', function(e) {
        e.preventDefault();
    });

    // 3. Chặn các hành động Copy / Cut / Paste
    ['copy', 'cut', 'paste'].forEach(function(event) {
        document.addEventListener(event, function(e) {
            e.preventDefault();
        });
    });

    // 4. Chặn các phím tắt nguy hiểm (F12, Ctrl+U, Ctrl+Shift+I, v.v.)
    document.addEventListener('keydown', function(e) {
        // Chặn F12
        if (e.key === 'F12' || e.keyCode === 123) {
            e.preventDefault();
        }
        
        // Chặn Ctrl + U (Xem Source Code)
        if (e.ctrlKey && (e.key === 'u' || e.key === 'U' || e.keyCode === 85)) {
            e.preventDefault();
        }
        
        // Chặn Ctrl + S (Lưu trang web)
        if (e.ctrlKey && (e.key === 's' || e.key === 'S' || e.keyCode === 83)) {
            e.preventDefault();
        }
        
        // Chặn Ctrl + P (In trang web)
        if (e.ctrlKey && (e.key === 'p' || e.key === 'P' || e.keyCode === 80)) {
            e.preventDefault();
        }

        // Chặn Ctrl + Shift + I / J / C (Mở DevTools & Inspect Element)
        if (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'i' || e.keyCode === 73)) {
            e.preventDefault();
        }
        if (e.ctrlKey && e.shiftKey && (e.key === 'J' || e.key === 'j' || e.keyCode === 74)) {
            e.preventDefault();
        }
        if (e.ctrlKey && e.shiftKey && (e.key === 'C' || e.key === 'c' || e.keyCode === 67)) {
            e.preventDefault();
        }
    });

    // 5. Bẫy Debugger vô tận (Làm treo DevTools nếu cố tình dùng menu trình duyệt để mở)
    // Nếu họ cố mở DevTools, browser sẽ bị kẹt ở dòng debugger này.
    var devtoolsDetector = function() {
        var start = new Date().getTime();
        debugger;
        var end = new Date().getTime();
        
        // Nếu chênh lệch thời gian quá lớn, tức là DevTools đang mở và kẹt ở debugger
        if (end - start > 100) {
            // Phạt bằng cách xóa trắng nội dung body
            document.body.innerHTML = "<div style='display:flex; height:100vh; width:100vw; align-items:center; justify-content:center; font-family:sans-serif; background:#0f172a; color:#ef4444; font-weight:bold; font-size:24px;'>Hành vi đáng ngờ bị từ chối!</div>";
        }
    };
    
    // Gọi bẫy mỗi giây
    setInterval(devtoolsDetector, 1000);

})();